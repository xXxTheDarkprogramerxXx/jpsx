/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PMGClass
/*     */   extends Attribute
/*     */ {
/*     */   private int pmg_class_index;
/*     */   private int pmg_index;
/*     */   
/*  78 */   public PMGClass(PMGClass c) { this(c.getNameIndex(), c.getLength(), c.getPMGIndex(), c.getPMGClassIndex(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   PMGClass(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException { this(name_index, length, file.readUnsignedShort(), file.readUnsignedShort(), constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PMGClass(int name_index, int length, int pmg_index, int pmg_class_index, ConstantPool constant_pool) {
/* 105 */     super((byte)9, name_index, length, constant_pool);
/* 106 */     this.pmg_index = pmg_index;
/* 107 */     this.pmg_class_index = pmg_class_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public void accept(Visitor v) { System.err.println("Visiting non-standard PMGClass object"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 129 */     super.dump(file);
/* 130 */     file.writeShort(this.pmg_index);
/* 131 */     file.writeShort(this.pmg_class_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public final int getPMGClassIndex() { return this.pmg_class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public final void setPMGClassIndex(int pmg_class_index) { this.pmg_class_index = pmg_class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public final int getPMGIndex() { return this.pmg_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public final void setPMGIndex(int pmg_index) { this.pmg_index = pmg_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getPMGName() {
/* 162 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.pmg_index, (byte)
/* 163 */         1);
/* 164 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getPMGClassName() {
/* 171 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.pmg_class_index, (byte)
/* 172 */         1);
/* 173 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public final String toString() { return "PMGClass(" + getPMGName() + ", " + getPMGClassName() + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public Attribute copy(ConstantPool constant_pool) { return (PMGClass)clone(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\PMGClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */