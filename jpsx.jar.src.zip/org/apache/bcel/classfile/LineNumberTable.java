/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LineNumberTable
/*     */   extends Attribute
/*     */ {
/*     */   private int line_number_table_length;
/*     */   private LineNumber[] line_number_table;
/*     */   
/*  80 */   public LineNumberTable(LineNumberTable c) { this(c.getNameIndex(), c.getLength(), c.getLineNumberTable(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberTable(int name_index, int length, LineNumber[] line_number_table, ConstantPool constant_pool) {
/*  93 */     super((byte)4, name_index, length, constant_pool);
/*  94 */     setLineNumberTable(line_number_table);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LineNumberTable(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 108 */     this(name_index, length, null, constant_pool);
/* 109 */     this.line_number_table_length = file.readUnsignedShort();
/* 110 */     this.line_number_table = new LineNumber[this.line_number_table_length];
/*     */     
/* 112 */     for (int i = 0; i < this.line_number_table_length; i++) {
/* 113 */       this.line_number_table[i] = new LineNumber(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void accept(Visitor v) { v.visitLineNumberTable(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 133 */     super.dump(file);
/* 134 */     file.writeShort(this.line_number_table_length);
/* 135 */     for (int i = 0; i < this.line_number_table_length; i++) {
/* 136 */       this.line_number_table[i].dump(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 142 */   public final LineNumber[] getLineNumberTable() { return this.line_number_table; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLineNumberTable(LineNumber[] line_number_table) {
/* 148 */     this.line_number_table = line_number_table;
/*     */     
/* 150 */     this.line_number_table_length = (line_number_table == null) ? 0 : 
/* 151 */       line_number_table.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 158 */     StringBuffer buf = new StringBuffer();
/* 159 */     StringBuffer line = new StringBuffer();
/*     */     
/* 161 */     for (int i = 0; i < this.line_number_table_length; i++) {
/* 162 */       line.append(this.line_number_table[i].toString());
/*     */       
/* 164 */       if (i < this.line_number_table_length - 1) {
/* 165 */         line.append(", ");
/*     */       }
/* 167 */       if (line.length() > 72) {
/* 168 */         line.append('\n');
/* 169 */         buf.append(line);
/* 170 */         line.setLength(0);
/*     */       } 
/*     */     } 
/*     */     
/* 174 */     buf.append(line);
/*     */     
/* 176 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSourceLine(int pos) {
/* 186 */     int l = 0, r = this.line_number_table_length - 1;
/*     */     
/* 188 */     if (r < 0) {
/* 189 */       return -1;
/*     */     }
/* 191 */     int min_index = -1, min = -1;
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 196 */       int i = (l + r) / 2;
/* 197 */       int j = this.line_number_table[i].getStartPC();
/*     */       
/* 199 */       if (j == pos)
/* 200 */         return this.line_number_table[i].getLineNumber(); 
/* 201 */       if (pos < j) {
/* 202 */         r = i - 1;
/*     */       } else {
/* 204 */         l = i + 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       if (j >= pos || j <= min)
/* 211 */         continue;  min = j;
/* 212 */       min_index = i;
/*     */     }
/* 214 */     while (l <= r);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 219 */     if (min_index < 0) {
/* 220 */       return -1;
/*     */     }
/* 222 */     return this.line_number_table[min_index].getLineNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/* 229 */     LineNumberTable c = (LineNumberTable)clone();
/*     */     
/* 231 */     c.line_number_table = new LineNumber[this.line_number_table_length];
/* 232 */     for (int i = 0; i < this.line_number_table_length; i++) {
/* 233 */       c.line_number_table[i] = this.line_number_table[i].copy();
/*     */     }
/* 235 */     c.constant_pool = constant_pool;
/* 236 */     return c;
/*     */   }
/*     */   
/* 239 */   public final int getTableLength() { return this.line_number_table_length; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\LineNumberTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */