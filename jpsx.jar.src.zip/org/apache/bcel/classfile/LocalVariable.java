/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LocalVariable
/*     */   implements Constants, Cloneable, Node, Serializable
/*     */ {
/*     */   private int start_pc;
/*     */   private int length;
/*     */   private int name_index;
/*     */   private int signature_index;
/*     */   private int index;
/*     */   private ConstantPool constant_pool;
/*     */   
/*  87 */   public LocalVariable(LocalVariable c) { this(c.getStartPC(), c.getLength(), c.getNameIndex(), c.getSignatureIndex(), c.getIndex(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   LocalVariable(DataInputStream file, ConstantPool constant_pool) throws IOException { this(file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariable(int start_pc, int length, int name_index, int signature_index, int index, ConstantPool constant_pool) {
/* 115 */     this.start_pc = start_pc;
/* 116 */     this.length = length;
/* 117 */     this.name_index = name_index;
/* 118 */     this.signature_index = signature_index;
/* 119 */     this.index = index;
/* 120 */     this.constant_pool = constant_pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public void accept(Visitor v) { v.visitLocalVariable(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 142 */     file.writeShort(this.start_pc);
/* 143 */     file.writeShort(this.length);
/* 144 */     file.writeShort(this.name_index);
/* 145 */     file.writeShort(this.signature_index);
/* 146 */     file.writeShort(this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public final ConstantPool getConstantPool() { return this.constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public final int getLength() { return this.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 165 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.name_index, (byte)1);
/* 166 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public final int getNameIndex() { return this.name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSignature() {
/* 179 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.signature_index, (byte)
/* 180 */         1);
/* 181 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public final int getSignatureIndex() { return this.signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public final int getIndex() { return this.index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public final int getStartPC() { return this.start_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public final void setConstantPool(ConstantPool constant_pool) { this.constant_pool = constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public final void setLength(int length) { this.length = length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public final void setNameIndex(int name_index) { this.name_index = name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public final void setSignatureIndex(int signature_index) { this.signature_index = signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 230 */   public final void setIndex(int index) { this.index = index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public final void setStartPC(int start_pc) { this.start_pc = start_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 243 */     String name = getName(), signature = Utility.signatureToString(getSignature());
/*     */     
/* 245 */     return "LocalVariable(start_pc = " + this.start_pc + ", length = " + this.length + 
/* 246 */       ", index = " + this.index + ":" + signature + " " + name + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariable copy() {
/*     */     try {
/* 254 */       return (LocalVariable)clone();
/* 255 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 257 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\LocalVariable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */