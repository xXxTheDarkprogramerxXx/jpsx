/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantClass
/*     */   extends Constant
/*     */   implements ConstantObject
/*     */ {
/*     */   private int name_index;
/*     */   
/*  76 */   public ConstantClass(ConstantClass c) { this(c.getNameIndex()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   ConstantClass(DataInputStream file) throws IOException { this(file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantClass(int name_index) {
/*  95 */     super((byte)7);
/*  96 */     this.name_index = name_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void accept(Visitor v) { v.visitConstantClass(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 118 */     file.writeByte(this.tag);
/* 119 */     file.writeShort(this.name_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public final int getNameIndex() { return this.name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public final void setNameIndex(int name_index) { this.name_index = name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getConstantValue(ConstantPool cp) {
/* 138 */     Constant c = cp.getConstant(this.name_index, (byte)1);
/* 139 */     return ((ConstantUtf8)c).getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public String getBytes(ConstantPool cp) { return (String)getConstantValue(cp); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public final String toString() { return String.valueOf(super.toString()) + "(name_index = " + this.name_index + ")"; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */