/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackMapType
/*     */   implements Cloneable
/*     */ {
/*     */   private byte type;
/*     */   private int index;
/*     */   private ConstantPool constant_pool;
/*     */   
/*     */   StackMapType(DataInputStream file, ConstantPool constant_pool) throws IOException {
/*  82 */     this(file.readByte(), -1, constant_pool);
/*     */     
/*  84 */     if (hasIndex()) {
/*  85 */       setIndex(file.readShort());
/*     */     }
/*  87 */     setConstantPool(constant_pool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackMapType(byte type, int index, ConstantPool constant_pool) {
/*     */     this.index = -1;
/*  95 */     setType(type);
/*  96 */     setIndex(index);
/*  97 */     setConstantPool(constant_pool);
/*     */   }
/*     */   
/*     */   public void setType(byte t) {
/* 101 */     if (t < 0 || t > 8)
/* 102 */       throw new RuntimeException("Illegal type for StackMapType: " + t); 
/* 103 */     this.type = t;
/*     */   }
/*     */   
/* 106 */   public byte getType() { return this.type; }
/* 107 */   public void setIndex(int t) { this.index = t; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public int getIndex() { return this.index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 122 */     file.writeByte(this.type);
/* 123 */     if (hasIndex()) {
/* 124 */       file.writeShort(getIndex());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasIndex() {
/* 130 */     if (this.type != 7 && 
/* 131 */       this.type != 8) return false; 
/*     */     return true;
/*     */   }
/*     */   private String printIndex() {
/* 135 */     if (this.type == 7)
/* 136 */       return ", class=" + this.constant_pool.constantToString(this.index, (byte)7); 
/* 137 */     if (this.type == 8) {
/* 138 */       return ", offset=" + this.index;
/*     */     }
/* 140 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public final String toString() { return "(type=" + Constants.ITEM_NAMES[this.type] + printIndex() + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackMapType copy() {
/*     */     try {
/* 155 */       return (StackMapType)clone();
/* 156 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 158 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 164 */   public final ConstantPool getConstantPool() { return this.constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public final void setConstantPool(ConstantPool constant_pool) { this.constant_pool = constant_pool; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\StackMapType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */