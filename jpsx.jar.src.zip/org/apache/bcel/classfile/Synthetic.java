/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Synthetic
/*     */   extends Attribute
/*     */ {
/*     */   private byte[] bytes;
/*     */   
/*  81 */   public Synthetic(Synthetic c) { this(c.getNameIndex(), c.getLength(), c.getBytes(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Synthetic(int name_index, int length, byte[] bytes, ConstantPool constant_pool) {
/*  95 */     super((byte)7, name_index, length, constant_pool);
/*  96 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Synthetic(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 110 */     this(name_index, length, null, constant_pool);
/*     */     
/* 112 */     if (length > 0) {
/* 113 */       this.bytes = new byte[length];
/* 114 */       file.readFully(this.bytes);
/* 115 */       System.err.println("Synthetic attribute with length > 0");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void accept(Visitor v) { v.visitSynthetic(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 136 */     super.dump(file);
/* 137 */     if (this.length > 0) {
/* 138 */       file.write(this.bytes, 0, this.length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 143 */   public final byte[] getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public final void setBytes(byte[] bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 156 */     StringBuffer buf = new StringBuffer("Synthetic");
/*     */     
/* 158 */     if (this.length > 0) {
/* 159 */       buf.append(" " + Utility.toHexString(this.bytes));
/*     */     }
/* 161 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/* 168 */     Synthetic c = (Synthetic)clone();
/*     */     
/* 170 */     if (this.bytes != null) {
/* 171 */       c.bytes = (byte[])this.bytes.clone();
/*     */     }
/* 173 */     c.constant_pool = constant_pool;
/* 174 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Synthetic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */