/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AccessFlags
/*     */   implements Serializable
/*     */ {
/*     */   protected int access_flags;
/*     */   
/*     */   public AccessFlags() {}
/*     */   
/*  75 */   public AccessFlags(int a) { this.access_flags = a; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public final int getAccessFlags() { return this.access_flags; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public final int getModifiers() { return this.access_flags; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public final void setAccessFlags(int access_flags) { this.access_flags = access_flags; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public final void setModifiers(int access_flags) { setAccessFlags(access_flags); }
/*     */ 
/*     */   
/*     */   private final void setFlag(int flag, boolean set) {
/* 103 */     if ((this.access_flags & flag) != 0) {
/* 104 */       if (!set) {
/* 105 */         this.access_flags ^= flag;
/*     */       }
/* 107 */     } else if (set) {
/* 108 */       this.access_flags |= flag;
/*     */     } 
/*     */   }
/*     */   
/* 112 */   public final void isPublic(boolean flag) { setFlag(1, flag); }
/*     */   
/* 114 */   public final boolean isPublic() { return ((this.access_flags & true) != 0); }
/*     */ 
/*     */   
/* 117 */   public final void isPrivate(boolean flag) { setFlag(2, flag); }
/*     */   
/* 119 */   public final boolean isPrivate() { return ((this.access_flags & 0x2) != 0); }
/*     */ 
/*     */   
/* 122 */   public final void isProtected(boolean flag) { setFlag(4, flag); }
/*     */   
/* 124 */   public final boolean isProtected() { return ((this.access_flags & 0x4) != 0); }
/*     */ 
/*     */   
/* 127 */   public final void isStatic(boolean flag) { setFlag(8, flag); }
/*     */   
/* 129 */   public final boolean isStatic() { return ((this.access_flags & 0x8) != 0); }
/*     */ 
/*     */   
/* 132 */   public final void isFinal(boolean flag) { setFlag(16, flag); }
/*     */   
/* 134 */   public final boolean isFinal() { return ((this.access_flags & 0x10) != 0); }
/*     */ 
/*     */   
/* 137 */   public final void isSynchronized(boolean flag) { setFlag(32, flag); }
/*     */   
/* 139 */   public final boolean isSynchronized() { return ((this.access_flags & 0x20) != 0); }
/*     */ 
/*     */   
/* 142 */   public final void isVolatile(boolean flag) { setFlag(64, flag); }
/*     */   
/* 144 */   public final boolean isVolatile() { return ((this.access_flags & 0x40) != 0); }
/*     */ 
/*     */   
/* 147 */   public final void isTransient(boolean flag) { setFlag(128, flag); }
/*     */   
/* 149 */   public final boolean isTransient() { return ((this.access_flags & 0x80) != 0); }
/*     */ 
/*     */   
/* 152 */   public final void isNative(boolean flag) { setFlag(256, flag); }
/*     */   
/* 154 */   public final boolean isNative() { return ((this.access_flags & 0x100) != 0); }
/*     */ 
/*     */   
/* 157 */   public final void isInterface(boolean flag) { setFlag(512, flag); }
/*     */   
/* 159 */   public final boolean isInterface() { return ((this.access_flags & 0x200) != 0); }
/*     */ 
/*     */   
/* 162 */   public final void isAbstract(boolean flag) { setFlag(1024, flag); }
/*     */   
/* 164 */   public final boolean isAbstract() { return ((this.access_flags & 0x400) != 0); }
/*     */ 
/*     */   
/* 167 */   public final void isStrictfp(boolean flag) { setFlag(2048, flag); }
/*     */   
/* 169 */   public final boolean isStrictfp() { return ((this.access_flags & 0x800) != 0); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\AccessFlags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */