/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantLong
/*     */   extends Constant
/*     */   implements ConstantObject
/*     */ {
/*     */   private long bytes;
/*     */   
/*     */   public ConstantLong(long bytes) {
/*  77 */     super((byte)5);
/*  78 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public ConstantLong(ConstantLong c) { this(c.getBytes()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   ConstantLong(DataInputStream file) throws IOException { this(file.readLong()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void accept(Visitor v) { v.visitConstantLong(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 114 */     file.writeByte(this.tag);
/* 115 */     file.writeLong(this.bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 120 */   public final long getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public final void setBytes(long bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public final String toString() { return String.valueOf(super.toString()) + "(bytes = " + this.bytes + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public Object getConstantValue(ConstantPool cp) { return new Long(this.bytes); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantLong.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */