/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantInteger
/*     */   extends Constant
/*     */   implements ConstantObject
/*     */ {
/*     */   private int bytes;
/*     */   
/*     */   public ConstantInteger(int bytes) {
/*  79 */     super((byte)3);
/*  80 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public ConstantInteger(ConstantInteger c) { this(c.getBytes()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   ConstantInteger(DataInputStream file) throws IOException { this(file.readInt()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void accept(Visitor v) { v.visitConstantInteger(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 120 */     file.writeByte(this.tag);
/* 121 */     file.writeInt(this.bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public final int getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public final void setBytes(int bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public final String toString() { return String.valueOf(super.toString()) + "(bytes = " + this.bytes + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public Object getConstantValue(ConstantPool cp) { return new Integer(this.bytes); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantInteger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */