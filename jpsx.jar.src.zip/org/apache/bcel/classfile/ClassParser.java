/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassParser
/*     */ {
/*     */   private DataInputStream file;
/*     */   private ZipFile zip;
/*     */   private String file_name;
/*     */   private int class_name_index;
/*     */   private int superclass_name_index;
/*     */   private int major;
/*     */   private int minor;
/*     */   private int access_flags;
/*     */   private int[] interfaces;
/*     */   private ConstantPool constant_pool;
/*     */   private Field[] fields;
/*     */   private Method[] methods;
/*     */   private Attribute[] attributes;
/*     */   private boolean is_zip;
/*     */   private static final int BUFSIZE = 8192;
/*     */   
/*     */   public ClassParser(InputStream file, String file_name) {
/*  99 */     this.file_name = file_name;
/*     */     
/* 101 */     String clazz = file.getClass().getName();
/* 102 */     this.is_zip = !(!clazz.startsWith("java.util.zip.") && !clazz.startsWith("java.util.jar."));
/*     */     
/* 104 */     if (file instanceof DataInputStream) {
/* 105 */       this.file = (DataInputStream)file;
/*     */     } else {
/* 107 */       this.file = new DataInputStream(new BufferedInputStream(file, ' '));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassParser(String file_name) throws IOException {
/* 117 */     this.is_zip = false;
/* 118 */     this.file_name = file_name;
/* 119 */     this.file = new DataInputStream(new BufferedInputStream(
/* 120 */           new FileInputStream(file_name), ' '));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassParser(String zip_file, String file_name) throws IOException {
/* 130 */     this.is_zip = true;
/* 131 */     this.zip = new ZipFile(zip_file);
/* 132 */     ZipEntry entry = this.zip.getEntry(file_name);
/*     */     
/* 134 */     this.file_name = file_name;
/*     */     
/* 136 */     this.file = new DataInputStream(new BufferedInputStream(this.zip.getInputStream(entry), 
/* 137 */           ' '));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass parse() throws IOException, ClassFormatException {
/* 155 */     readID();
/*     */ 
/*     */     
/* 158 */     readVersion();
/*     */ 
/*     */ 
/*     */     
/* 162 */     readConstantPool();
/*     */ 
/*     */     
/* 165 */     readClassInfo();
/*     */ 
/*     */     
/* 168 */     readInterfaces();
/*     */ 
/*     */ 
/*     */     
/* 172 */     readFields();
/*     */ 
/*     */     
/* 175 */     readMethods();
/*     */ 
/*     */     
/* 178 */     readAttributes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     this.file.close();
/* 199 */     if (this.zip != null) {
/* 200 */       this.zip.close();
/*     */     }
/*     */     
/* 203 */     return new JavaClass(this.class_name_index, this.superclass_name_index, 
/* 204 */         this.file_name, this.major, this.minor, this.access_flags, 
/* 205 */         this.constant_pool, this.interfaces, this.fields, 
/* 206 */         this.methods, this.attributes, this.is_zip ? 3 : 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readAttributes() throws IOException, ClassFormatException {
/* 218 */     int attributes_count = this.file.readUnsignedShort();
/* 219 */     this.attributes = new Attribute[attributes_count];
/*     */     
/* 221 */     for (int i = 0; i < attributes_count; i++) {
/* 222 */       this.attributes[i] = Attribute.readAttribute(this.file, this.constant_pool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readClassInfo() throws IOException, ClassFormatException {
/* 232 */     this.access_flags = this.file.readUnsignedShort();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     if ((this.access_flags & 0x200) != 0) {
/* 238 */       this.access_flags |= 0x400;
/*     */     }
/* 240 */     if ((this.access_flags & 0x400) != 0 && (
/* 241 */       this.access_flags & 0x10) != 0) {
/* 242 */       throw new ClassFormatException("Class can't be both final and abstract");
/*     */     }
/* 244 */     this.class_name_index = this.file.readUnsignedShort();
/* 245 */     this.superclass_name_index = this.file.readUnsignedShort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   private final void readConstantPool() throws IOException, ClassFormatException { this.constant_pool = new ConstantPool(this.file); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readFields() throws IOException, ClassFormatException {
/* 266 */     int fields_count = this.file.readUnsignedShort();
/* 267 */     this.fields = new Field[fields_count];
/*     */     
/* 269 */     for (int i = 0; i < fields_count; i++) {
/* 270 */       this.fields[i] = new Field(this.file, this.constant_pool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readID() throws IOException, ClassFormatException {
/* 283 */     int magic = -889275714;
/*     */     
/* 285 */     if (this.file.readInt() != magic) {
/* 286 */       throw new ClassFormatException(String.valueOf(this.file_name) + " is not a Java .class file");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readInterfaces() throws IOException, ClassFormatException {
/* 297 */     int interfaces_count = this.file.readUnsignedShort();
/* 298 */     this.interfaces = new int[interfaces_count];
/*     */     
/* 300 */     for (int i = 0; i < interfaces_count; i++) {
/* 301 */       this.interfaces[i] = this.file.readUnsignedShort();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readMethods() throws IOException, ClassFormatException {
/* 312 */     int methods_count = this.file.readUnsignedShort();
/* 313 */     this.methods = new Method[methods_count];
/*     */     
/* 315 */     for (int i = 0; i < methods_count; i++) {
/* 316 */       this.methods[i] = new Method(this.file, this.constant_pool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readVersion() throws IOException, ClassFormatException {
/* 325 */     this.minor = this.file.readUnsignedShort();
/* 326 */     this.major = this.file.readUnsignedShort();
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ClassParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */