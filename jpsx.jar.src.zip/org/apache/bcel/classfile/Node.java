package org.apache.bcel.classfile;

public interface Node {
  void accept(Visitor paramVisitor);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Node.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */