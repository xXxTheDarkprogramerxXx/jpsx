/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldOrMethod
/*     */   extends AccessFlags
/*     */   implements Cloneable, Node
/*     */ {
/*     */   protected int name_index;
/*     */   protected int signature_index;
/*     */   protected int attributes_count;
/*     */   protected Attribute[] attributes;
/*     */   protected ConstantPool constant_pool;
/*     */   
/*     */   FieldOrMethod() {}
/*     */   
/*  80 */   protected FieldOrMethod(FieldOrMethod c) { this(c.getAccessFlags(), c.getNameIndex(), c.getSignatureIndex(), c.getAttributes(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldOrMethod(DataInputStream file, ConstantPool constant_pool) throws IOException, ClassFormatException {
/*  93 */     this(file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), null, constant_pool);
/*     */     
/*  95 */     this.attributes_count = file.readUnsignedShort();
/*  96 */     this.attributes = new Attribute[this.attributes_count];
/*  97 */     for (int i = 0; i < this.attributes_count; i++) {
/*  98 */       this.attributes[i] = Attribute.readAttribute(file, constant_pool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldOrMethod(int access_flags, int name_index, int signature_index, Attribute[] attributes, ConstantPool constant_pool) {
/* 111 */     this.access_flags = access_flags;
/* 112 */     this.name_index = name_index;
/* 113 */     this.signature_index = signature_index;
/* 114 */     this.constant_pool = constant_pool;
/*     */     
/* 116 */     setAttributes(attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 127 */     file.writeShort(this.access_flags);
/* 128 */     file.writeShort(this.name_index);
/* 129 */     file.writeShort(this.signature_index);
/* 130 */     file.writeShort(this.attributes_count);
/*     */     
/* 132 */     for (int i = 0; i < this.attributes_count; i++) {
/* 133 */       this.attributes[i].dump(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 139 */   public final Attribute[] getAttributes() { return this.attributes; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAttributes(Attribute[] attributes) {
/* 145 */     this.attributes = attributes;
/* 146 */     this.attributes_count = (attributes == null) ? 0 : attributes.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public final ConstantPool getConstantPool() { return this.constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public final void setConstantPool(ConstantPool constant_pool) { this.constant_pool = constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public final int getNameIndex() { return this.name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public final void setNameIndex(int name_index) { this.name_index = name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public final int getSignatureIndex() { return this.signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public final void setSignatureIndex(int signature_index) { this.signature_index = signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 190 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.name_index, (byte)
/* 191 */         1);
/* 192 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSignature() {
/* 200 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.signature_index, (byte)
/* 201 */         1);
/* 202 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldOrMethod copy_(ConstantPool constant_pool) {
/* 209 */     FieldOrMethod c = null;
/*     */     
/*     */     try {
/* 212 */       c = (FieldOrMethod)clone();
/* 213 */     } catch (CloneNotSupportedException cloneNotSupportedException) {}
/*     */     
/* 215 */     c.constant_pool = constant_pool;
/* 216 */     c.attributes = new Attribute[this.attributes_count];
/*     */     
/* 218 */     for (int i = 0; i < this.attributes_count; i++) {
/* 219 */       c.attributes[i] = this.attributes[i].copy(constant_pool);
/*     */     }
/* 221 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\FieldOrMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */