/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import org.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Attribute
/*     */   implements Cloneable, Node, Serializable
/*     */ {
/*     */   protected int name_index;
/*     */   protected int length;
/*     */   protected byte tag;
/*     */   protected ConstantPool constant_pool;
/*     */   
/*     */   protected Attribute(byte tag, int name_index, int length, ConstantPool constant_pool) {
/*  91 */     this.tag = tag;
/*  92 */     this.name_index = name_index;
/*  93 */     this.length = length;
/*  94 */     this.constant_pool = constant_pool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void accept(Visitor paramVisitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream file) throws IOException {
/* 114 */     file.writeShort(this.name_index);
/* 115 */     file.writeInt(this.length);
/*     */   }
/*     */   
/* 118 */   private static HashMap readers = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public static void addAttributeReader(String name, AttributeReader r) { readers.put(name, r); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public static void removeAttributeReader(String name) { readers.remove(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Attribute readAttribute(DataInputStream file, ConstantPool constant_pool) throws IOException, ClassFormatException {
/*     */     AttributeReader r;
/* 159 */     byte tag = -1;
/*     */ 
/*     */     
/* 162 */     int name_index = file.readUnsignedShort();
/* 163 */     ConstantUtf8 c = (ConstantUtf8)constant_pool.getConstant(name_index, (byte)
/* 164 */         1);
/* 165 */     String name = c.getBytes();
/*     */ 
/*     */     
/* 168 */     int length = file.readInt();
/*     */ 
/*     */     
/* 171 */     for (byte i = 0; i < 12; i = (byte)(i + 1)) {
/* 172 */       if (name.equals(Constants.ATTRIBUTE_NAMES[i])) {
/* 173 */         tag = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     switch (tag) {
/*     */       case -1:
/* 181 */         r = (AttributeReader)readers.get(name);
/*     */         
/* 183 */         if (r != null) {
/* 184 */           return r.createAttribute(name_index, length, file, constant_pool);
/*     */         }
/* 186 */         return new Unknown(name_index, length, file, constant_pool);
/*     */       
/*     */       case 1:
/* 189 */         return new ConstantValue(name_index, length, file, constant_pool);
/*     */       
/*     */       case 0:
/* 192 */         return new SourceFile(name_index, length, file, constant_pool);
/*     */       
/*     */       case 2:
/* 195 */         return new Code(name_index, length, file, constant_pool);
/*     */       
/*     */       case 3:
/* 198 */         return new ExceptionTable(name_index, length, file, constant_pool);
/*     */       
/*     */       case 4:
/* 201 */         return new LineNumberTable(name_index, length, file, constant_pool);
/*     */       
/*     */       case 5:
/* 204 */         return new LocalVariableTable(name_index, length, file, constant_pool);
/*     */       
/*     */       case 6:
/* 207 */         return new InnerClasses(name_index, length, file, constant_pool);
/*     */       
/*     */       case 7:
/* 210 */         return new Synthetic(name_index, length, file, constant_pool);
/*     */       
/*     */       case 8:
/* 213 */         return new Deprecated(name_index, length, file, constant_pool);
/*     */       
/*     */       case 9:
/* 216 */         return new PMGClass(name_index, length, file, constant_pool);
/*     */       
/*     */       case 10:
/* 219 */         return new Signature(name_index, length, file, constant_pool);
/*     */       
/*     */       case 11:
/* 222 */         return new StackMap(name_index, length, file, constant_pool);
/*     */     } 
/*     */     
/* 225 */     throw new IllegalStateException("Ooops! default case reached.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 232 */   public final int getLength() { return this.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public final void setLength(int length) { this.length = length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public final void setNameIndex(int name_index) { this.name_index = name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public final int getNameIndex() { return this.name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   public final byte getTag() { return this.tag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public final ConstantPool getConstantPool() { return this.constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public final void setConstantPool(ConstantPool constant_pool) { this.constant_pool = constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 280 */     Object o = null;
/*     */     
/*     */     try {
/* 283 */       o = super.clone();
/* 284 */     } catch (CloneNotSupportedException e) {
/* 285 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 288 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Attribute copy(ConstantPool paramConstantPool);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public String toString() { return Constants.ATTRIBUTE_NAMES[this.tag]; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Attribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */