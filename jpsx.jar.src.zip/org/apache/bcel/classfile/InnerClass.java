/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InnerClass
/*     */   implements Cloneable, Node
/*     */ {
/*     */   private int inner_class_index;
/*     */   private int outer_class_index;
/*     */   private int inner_name_index;
/*     */   private int inner_access_flags;
/*     */   
/*  80 */   public InnerClass(InnerClass c) { this(c.getInnerClassIndex(), c.getOuterClassIndex(), c.getInnerNameIndex(), c.getInnerAccessFlags()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   InnerClass(DataInputStream file) throws IOException { this(file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InnerClass(int inner_class_index, int outer_class_index, int inner_name_index, int inner_access_flags) {
/* 103 */     this.inner_class_index = inner_class_index;
/* 104 */     this.outer_class_index = outer_class_index;
/* 105 */     this.inner_name_index = inner_name_index;
/* 106 */     this.inner_access_flags = inner_access_flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void accept(Visitor v) { v.visitInnerClass(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 127 */     file.writeShort(this.inner_class_index);
/* 128 */     file.writeShort(this.outer_class_index);
/* 129 */     file.writeShort(this.inner_name_index);
/* 130 */     file.writeShort(this.inner_access_flags);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 135 */   public final int getInnerAccessFlags() { return this.inner_access_flags; }
/*     */ 
/*     */ 
/*     */   
/* 139 */   public final int getInnerClassIndex() { return this.inner_class_index; }
/*     */ 
/*     */ 
/*     */   
/* 143 */   public final int getInnerNameIndex() { return this.inner_name_index; }
/*     */ 
/*     */ 
/*     */   
/* 147 */   public final int getOuterClassIndex() { return this.outer_class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public final void setInnerAccessFlags(int inner_access_flags) { this.inner_access_flags = inner_access_flags; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public final void setInnerClassIndex(int inner_class_index) { this.inner_class_index = inner_class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public final void setInnerNameIndex(int inner_name_index) { this.inner_name_index = inner_name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public final void setOuterClassIndex(int outer_class_index) { this.outer_class_index = outer_class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 176 */     return "InnerClass(" + this.inner_class_index + ", " + this.outer_class_index + 
/* 177 */       ", " + this.inner_name_index + ", " + this.inner_access_flags + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(ConstantPool constant_pool) {
/* 186 */     String inner_name, outer_class_name, inner_class_name = constant_pool.getConstantString(this.inner_class_index, (byte)
/* 187 */         7);
/* 188 */     inner_class_name = Utility.compactClassName(inner_class_name);
/*     */     
/* 190 */     if (this.outer_class_index != 0) {
/* 191 */       outer_class_name = constant_pool.getConstantString(this.outer_class_index, (byte)
/* 192 */           7);
/* 193 */       outer_class_name = Utility.compactClassName(outer_class_name);
/*     */     } else {
/*     */       
/* 196 */       outer_class_name = "<not a member>";
/*     */     } 
/* 198 */     if (this.inner_name_index != 0) {
/* 199 */       inner_name = ((ConstantUtf8)constant_pool
/* 200 */         .getConstant(this.inner_name_index, (byte)1)).getBytes();
/*     */     } else {
/* 202 */       inner_name = "<anonymous>";
/*     */     } 
/* 204 */     String access = Utility.accessToString(this.inner_access_flags, true);
/* 205 */     access = access.equals("") ? "" : (String.valueOf(access) + " ");
/*     */     
/* 207 */     return "InnerClass:" + access + inner_class_name + 
/* 208 */       "(\"" + outer_class_name + "\", \"" + inner_name + "\")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InnerClass copy() {
/*     */     try {
/* 216 */       return (InnerClass)clone();
/* 217 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 219 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\InnerClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */