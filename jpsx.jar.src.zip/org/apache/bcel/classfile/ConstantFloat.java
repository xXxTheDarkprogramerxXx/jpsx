/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantFloat
/*     */   extends Constant
/*     */   implements ConstantObject
/*     */ {
/*     */   private float bytes;
/*     */   
/*     */   public ConstantFloat(float bytes) {
/*  77 */     super((byte)4);
/*  78 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public ConstantFloat(ConstantFloat c) { this(c.getBytes()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   ConstantFloat(DataInputStream file) throws IOException { this(file.readFloat()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void accept(Visitor v) { v.visitConstantFloat(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 115 */     file.writeByte(this.tag);
/* 116 */     file.writeFloat(this.bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public final float getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public final void setBytes(float bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public final String toString() { return String.valueOf(super.toString()) + "(bytes = " + this.bytes + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public Object getConstantValue(ConstantPool cp) { return new Float(this.bytes); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantFloat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */