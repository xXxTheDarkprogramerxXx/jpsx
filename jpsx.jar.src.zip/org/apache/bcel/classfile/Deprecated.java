/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Deprecated
/*     */   extends Attribute
/*     */ {
/*     */   private byte[] bytes;
/*     */   
/*  77 */   public Deprecated(Deprecated c) { this(c.getNameIndex(), c.getLength(), c.getBytes(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Deprecated(int name_index, int length, byte[] bytes, ConstantPool constant_pool) {
/*  89 */     super((byte)8, name_index, length, constant_pool);
/*  90 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deprecated(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 104 */     this(name_index, length, null, constant_pool);
/*     */     
/* 106 */     if (length > 0) {
/* 107 */       this.bytes = new byte[length];
/* 108 */       file.readFully(this.bytes);
/* 109 */       System.err.println("Deprecated attribute with length > 0");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void accept(Visitor v) { v.visitDeprecated(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 132 */     super.dump(file);
/*     */     
/* 134 */     if (this.length > 0) {
/* 135 */       file.write(this.bytes, 0, this.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 141 */   public final byte[] getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public final void setBytes(byte[] bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public final String toString() { return Constants.ATTRIBUTE_NAMES[8]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/* 161 */     Deprecated c = (Deprecated)clone();
/*     */     
/* 163 */     if (this.bytes != null) {
/* 164 */       c.bytes = (byte[])this.bytes.clone();
/*     */     }
/* 166 */     c.constant_pool = constant_pool;
/* 167 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Deprecated.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */