package org.apache.bcel.classfile;

import java.io.DataInputStream;

public interface AttributeReader {
  Attribute createAttribute(int paramInt1, int paramInt2, DataInputStream paramDataInputStream, ConstantPool paramConstantPool);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\AttributeReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */