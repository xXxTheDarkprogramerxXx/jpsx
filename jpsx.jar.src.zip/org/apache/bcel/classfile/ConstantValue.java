/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantValue
/*     */   extends Attribute
/*     */ {
/*     */   private int constantvalue_index;
/*     */   
/*  78 */   public ConstantValue(ConstantValue c) { this(c.getNameIndex(), c.getLength(), c.getConstantValueIndex(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   ConstantValue(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException { this(name_index, length, file.readUnsignedShort(), constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantValue(int name_index, int length, int constantvalue_index, ConstantPool constant_pool) {
/* 105 */     super((byte)1, name_index, length, constant_pool);
/* 106 */     this.constantvalue_index = constantvalue_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void accept(Visitor v) { v.visitConstantValue(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 127 */     super.dump(file);
/* 128 */     file.writeShort(this.constantvalue_index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public final int getConstantValueIndex() { return this.constantvalue_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public final void setConstantValueIndex(int constantvalue_index) { this.constantvalue_index = constantvalue_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield constant_pool : Lorg/apache/bcel/classfile/ConstantPool;
/*     */     //   4: aload_0
/*     */     //   5: getfield constantvalue_index : I
/*     */     //   8: invokevirtual getConstant : (I)Lorg/apache/bcel/classfile/Constant;
/*     */     //   11: astore_1
/*     */     //   12: aload_1
/*     */     //   13: invokevirtual getTag : ()B
/*     */     //   16: tableswitch default -> 204, 3 -> 128, 4 -> 80, 5 -> 56, 6 -> 104, 7 -> 204, 8 -> 152
/*     */     //   56: new java/lang/StringBuilder
/*     */     //   59: dup
/*     */     //   60: invokespecial <init> : ()V
/*     */     //   63: aload_1
/*     */     //   64: checkcast org/apache/bcel/classfile/ConstantLong
/*     */     //   67: invokevirtual getBytes : ()J
/*     */     //   70: invokevirtual append : (J)Ljava/lang/StringBuilder;
/*     */     //   73: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   76: astore_2
/*     */     //   77: goto -> 228
/*     */     //   80: new java/lang/StringBuilder
/*     */     //   83: dup
/*     */     //   84: invokespecial <init> : ()V
/*     */     //   87: aload_1
/*     */     //   88: checkcast org/apache/bcel/classfile/ConstantFloat
/*     */     //   91: invokevirtual getBytes : ()F
/*     */     //   94: invokevirtual append : (F)Ljava/lang/StringBuilder;
/*     */     //   97: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   100: astore_2
/*     */     //   101: goto -> 228
/*     */     //   104: new java/lang/StringBuilder
/*     */     //   107: dup
/*     */     //   108: invokespecial <init> : ()V
/*     */     //   111: aload_1
/*     */     //   112: checkcast org/apache/bcel/classfile/ConstantDouble
/*     */     //   115: invokevirtual getBytes : ()D
/*     */     //   118: invokevirtual append : (D)Ljava/lang/StringBuilder;
/*     */     //   121: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   124: astore_2
/*     */     //   125: goto -> 228
/*     */     //   128: new java/lang/StringBuilder
/*     */     //   131: dup
/*     */     //   132: invokespecial <init> : ()V
/*     */     //   135: aload_1
/*     */     //   136: checkcast org/apache/bcel/classfile/ConstantInteger
/*     */     //   139: invokevirtual getBytes : ()I
/*     */     //   142: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   145: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   148: astore_2
/*     */     //   149: goto -> 228
/*     */     //   152: aload_1
/*     */     //   153: checkcast org/apache/bcel/classfile/ConstantString
/*     */     //   156: invokevirtual getStringIndex : ()I
/*     */     //   159: istore_3
/*     */     //   160: aload_0
/*     */     //   161: getfield constant_pool : Lorg/apache/bcel/classfile/ConstantPool;
/*     */     //   164: iload_3
/*     */     //   165: iconst_1
/*     */     //   166: invokevirtual getConstant : (IB)Lorg/apache/bcel/classfile/Constant;
/*     */     //   169: astore_1
/*     */     //   170: new java/lang/StringBuilder
/*     */     //   173: dup
/*     */     //   174: ldc '"'
/*     */     //   176: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   179: aload_1
/*     */     //   180: checkcast org/apache/bcel/classfile/ConstantUtf8
/*     */     //   183: invokevirtual getBytes : ()Ljava/lang/String;
/*     */     //   186: invokestatic convertString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   192: ldc '"'
/*     */     //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   197: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   200: astore_2
/*     */     //   201: goto -> 228
/*     */     //   204: new java/lang/IllegalStateException
/*     */     //   207: dup
/*     */     //   208: new java/lang/StringBuilder
/*     */     //   211: dup
/*     */     //   212: ldc 'Type of ConstValue invalid: '
/*     */     //   214: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   217: aload_1
/*     */     //   218: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   221: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   224: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   227: athrow
/*     */     //   228: aload_2
/*     */     //   229: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #146	-> 0
/*     */     //   #152	-> 12
/*     */     //   #153	-> 56
/*     */     //   #154	-> 80
/*     */     //   #155	-> 104
/*     */     //   #156	-> 128
/*     */     //   #158	-> 152
/*     */     //   #159	-> 160
/*     */     //   #160	-> 170
/*     */     //   #161	-> 201
/*     */     //   #164	-> 204
/*     */     //   #167	-> 228
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	230	0	this	Lorg/apache/bcel/classfile/ConstantValue;
/*     */     //   12	218	1	c	Lorg/apache/bcel/classfile/Constant;
/*     */     //   77	3	2	buf	Ljava/lang/String;
/*     */     //   101	3	2	buf	Ljava/lang/String;
/*     */     //   125	3	2	buf	Ljava/lang/String;
/*     */     //   149	3	2	buf	Ljava/lang/String;
/*     */     //   201	3	2	buf	Ljava/lang/String;
/*     */     //   228	2	2	buf	Ljava/lang/String;
/*     */     //   160	44	3	i	I }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/* 174 */     ConstantValue c = (ConstantValue)clone();
/* 175 */     c.constant_pool = constant_pool;
/* 176 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */