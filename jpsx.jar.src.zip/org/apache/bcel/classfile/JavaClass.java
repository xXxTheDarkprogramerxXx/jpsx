/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.bcel.generic.Type;
/*     */ import org.apache.bcel.util.ClassQueue;
/*     */ import org.apache.bcel.util.ClassVector;
/*     */ import org.apache.bcel.util.Repository;
/*     */ import org.apache.bcel.util.SyntheticRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaClass
/*     */   extends AccessFlags
/*     */   implements Cloneable, Node
/*     */ {
/*     */   private String file_name;
/*     */   private String package_name;
/*  83 */   private String source_file_name = "<Unknown>"; private int class_name_index;
/*     */   private int superclass_name_index;
/*     */   private String class_name;
/*     */   private String superclass_name;
/*     */   private int major;
/*     */   private int minor;
/*     */   private ConstantPool constant_pool;
/*     */   private int[] interfaces;
/*     */   private String[] interface_names;
/*     */   private Field[] fields;
/*     */   private Method[] methods;
/*     */   private Attribute[] attributes;
/*  95 */   private byte source = 1;
/*     */   
/*     */   public static final byte HEAP = 1;
/*     */   
/*     */   public static final byte FILE = 2;
/*     */   public static final byte ZIP = 3;
/*     */   static boolean debug = false;
/* 102 */   static char sep = '/';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private Repository repository = SyntheticRepository.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass(int class_name_index, int superclass_name_index, String file_name, int major, int minor, int access_flags, ConstantPool constant_pool, int[] interfaces, Field[] fields, Method[] methods, Attribute[] attributes, byte source) {
/* 143 */     if (interfaces == null)
/* 144 */       interfaces = new int[0]; 
/* 145 */     if (attributes == null)
/* 146 */       this.attributes = new Attribute[0]; 
/* 147 */     if (fields == null)
/* 148 */       fields = new Field[0]; 
/* 149 */     if (methods == null) {
/* 150 */       methods = new Method[0];
/*     */     }
/* 152 */     this.class_name_index = class_name_index;
/* 153 */     this.superclass_name_index = superclass_name_index;
/* 154 */     this.file_name = file_name;
/* 155 */     this.major = major;
/* 156 */     this.minor = minor;
/* 157 */     this.access_flags = access_flags;
/* 158 */     this.constant_pool = constant_pool;
/* 159 */     this.interfaces = interfaces;
/* 160 */     this.fields = fields;
/* 161 */     this.methods = methods;
/* 162 */     this.attributes = attributes;
/* 163 */     this.source = source;
/*     */ 
/*     */     
/* 166 */     for (int i = 0; i < attributes.length; i++) {
/* 167 */       if (attributes[i] instanceof SourceFile) {
/* 168 */         this.source_file_name = ((SourceFile)attributes[i]).getSourceFileName();
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 177 */     this.class_name = constant_pool.getConstantString(class_name_index, (byte)
/* 178 */         7);
/* 179 */     this.class_name = Utility.compactClassName(this.class_name, false);
/*     */     
/* 181 */     int index = this.class_name.lastIndexOf('.');
/* 182 */     if (index < 0) {
/* 183 */       this.package_name = "";
/*     */     } else {
/* 185 */       this.package_name = this.class_name.substring(0, index);
/*     */     } 
/* 187 */     if (superclass_name_index > 0) {
/* 188 */       this.superclass_name = constant_pool.getConstantString(superclass_name_index, (byte)
/* 189 */           7);
/* 190 */       this.superclass_name = Utility.compactClassName(this.superclass_name, false);
/*     */     } else {
/*     */       
/* 193 */       this.superclass_name = "java.lang.Object";
/*     */     } 
/* 195 */     this.interface_names = new String[interfaces.length];
/* 196 */     for (int i = 0; i < interfaces.length; i++) {
/* 197 */       String str = constant_pool.getConstantString(interfaces[i], (byte)7);
/* 198 */       this.interface_names[i] = Utility.compactClassName(str, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public JavaClass(int class_name_index, int superclass_name_index, String file_name, int major, int minor, int access_flags, ConstantPool constant_pool, int[] interfaces, Field[] fields, Method[] methods, Attribute[] attributes) { this(class_name_index, superclass_name_index, file_name, major, minor, access_flags, constant_pool, interfaces, fields, methods, attributes, (byte)1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public void accept(Visitor v) { v.visitJavaClass(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final void Debug(String str) {
/* 247 */     if (debug) {
/* 248 */       System.out.println(str);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(File file) throws IOException {
/* 259 */     String parent = file.getParent();
/*     */     
/* 261 */     if (parent != null) {
/* 262 */       File dir = new File(parent);
/*     */       
/* 264 */       if (dir != null) {
/* 265 */         dir.mkdirs();
/*     */       }
/*     */     } 
/* 268 */     dump(new DataOutputStream(new FileOutputStream(file)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public void dump(String file_name) { dump(new File(file_name)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 286 */     ByteArrayOutputStream s = new ByteArrayOutputStream();
/* 287 */     ds = new DataOutputStream(s);
/*     */ 
/*     */     
/* 290 */     try { dump(ds); }
/* 291 */     catch (IOException e)
/* 292 */     { e.printStackTrace(); }
/*     */     finally { 
/* 294 */       try { ds.close(); } catch (IOException e2) { e2.printStackTrace(); }
/*     */        }
/*     */     
/* 297 */     return s.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public void dump(OutputStream file) throws IOException { dump(new DataOutputStream(file)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream file) throws IOException {
/* 318 */     file.writeInt(-889275714);
/* 319 */     file.writeShort(this.minor);
/* 320 */     file.writeShort(this.major);
/*     */     
/* 322 */     this.constant_pool.dump(file);
/*     */     
/* 324 */     file.writeShort(this.access_flags);
/* 325 */     file.writeShort(this.class_name_index);
/* 326 */     file.writeShort(this.superclass_name_index);
/*     */     
/* 328 */     file.writeShort(this.interfaces.length);
/* 329 */     for (int i = 0; i < this.interfaces.length; i++) {
/* 330 */       file.writeShort(this.interfaces[i]);
/*     */     }
/* 332 */     file.writeShort(this.fields.length);
/* 333 */     for (int i = 0; i < this.fields.length; i++) {
/* 334 */       this.fields[i].dump(file);
/*     */     }
/* 336 */     file.writeShort(this.methods.length);
/* 337 */     for (int i = 0; i < this.methods.length; i++) {
/* 338 */       this.methods[i].dump(file);
/*     */     }
/* 340 */     if (this.attributes != null) {
/* 341 */       file.writeShort(this.attributes.length);
/* 342 */       for (int i = 0; i < this.attributes.length; i++) {
/* 343 */         this.attributes[i].dump(file);
/*     */       }
/*     */     } else {
/* 346 */       file.writeShort(0);
/*     */     } 
/* 348 */     file.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 354 */   public Attribute[] getAttributes() { return this.attributes; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 359 */   public String getClassName() { return this.class_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 364 */   public String getPackageName() { return this.package_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 369 */   public int getClassNameIndex() { return this.class_name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 374 */   public ConstantPool getConstantPool() { return this.constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 381 */   public Field[] getFields() { return this.fields; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 386 */   public String getFileName() { return this.file_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 391 */   public String[] getInterfaceNames() { return this.interface_names; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 396 */   public int[] getInterfaceIndices() { return this.interfaces; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 401 */   public int getMajor() { return this.major; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 406 */   public Method[] getMethods() { return this.methods; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod(Method m) {
/* 413 */     for (int i = 0; i < this.methods.length; i++) {
/* 414 */       Method method = this.methods[i];
/*     */       
/* 416 */       if (m.getName().equals(method.getName()) && 
/* 417 */         m.getModifiers() == method.getModifiers() && 
/* 418 */         Type.getSignature(m).equals(method.getSignature())) {
/* 419 */         return method;
/*     */       }
/*     */     } 
/*     */     
/* 423 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 429 */   public int getMinor() { return this.minor; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 434 */   public String getSourceFileName() { return this.source_file_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 439 */   public String getSuperclassName() { return this.superclass_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 444 */   public int getSuperclassNameIndex() { return this.superclass_name_index; }
/*     */ 
/*     */   
/*     */   static  {
/* 448 */     debug = System.getProperty("JavaClass.debug");
/*     */     
/* 450 */     if (debug != null) {
/* 451 */       JavaClass.debug = (new Boolean(debug)).booleanValue();
/*     */     }
/*     */     
/* 454 */     String sep = System.getProperty("file.separator");
/*     */     
/* 456 */     if (sep != null) {
/*     */       try {
/* 458 */         JavaClass.sep = sep.charAt(0);
/* 459 */       } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   public void setAttributes(Attribute[] attributes) { this.attributes = attributes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 473 */   public void setClassName(String class_name) { this.class_name = class_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 480 */   public void setClassNameIndex(int class_name_index) { this.class_name_index = class_name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 487 */   public void setConstantPool(ConstantPool constant_pool) { this.constant_pool = constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 494 */   public void setFields(Field[] fields) { this.fields = fields; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 501 */   public void setFileName(String file_name) { this.file_name = file_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 508 */   public void setInterfaceNames(String[] interface_names) { this.interface_names = interface_names; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 515 */   public void setInterfaces(int[] interfaces) { this.interfaces = interfaces; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 522 */   public void setMajor(int major) { this.major = major; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 529 */   public void setMethods(Method[] methods) { this.methods = methods; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 536 */   public void setMinor(int minor) { this.minor = minor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 543 */   public void setSourceFileName(String source_file_name) { this.source_file_name = source_file_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 550 */   public void setSuperclassName(String superclass_name) { this.superclass_name = superclass_name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 557 */   public void setSuperclassNameIndex(int superclass_name_index) { this.superclass_name_index = superclass_name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 564 */     String access = Utility.accessToString(this.access_flags, true);
/* 565 */     access = access.equals("") ? "" : (String.valueOf(access) + " ");
/*     */     
/* 567 */     StringBuffer buf = new StringBuffer(String.valueOf(access) + 
/* 568 */         Utility.classOrInterface(this.access_flags) + 
/* 569 */         " " + 
/* 570 */         this.class_name + " extends " + 
/* 571 */         Utility.compactClassName(this.superclass_name, 
/* 572 */           false) + '\n');
/* 573 */     int size = this.interfaces.length;
/*     */     
/* 575 */     if (size > 0) {
/* 576 */       buf.append("implements\t\t");
/*     */       
/* 578 */       for (int i = 0; i < size; i++) {
/* 579 */         buf.append(this.interface_names[i]);
/* 580 */         if (i < size - 1) {
/* 581 */           buf.append(", ");
/*     */         }
/*     */       } 
/* 584 */       buf.append('\n');
/*     */     } 
/*     */     
/* 587 */     buf.append("filename\t\t" + this.file_name + '\n');
/* 588 */     buf.append("compiled from\t\t" + this.source_file_name + '\n');
/* 589 */     buf.append("compiler version\t" + this.major + "." + this.minor + '\n');
/* 590 */     buf.append("access flags\t\t" + this.access_flags + '\n');
/* 591 */     buf.append("constant pool\t\t" + this.constant_pool.getLength() + " entries\n");
/* 592 */     buf.append("ACC_SUPER flag\t\t" + isSuper() + "\n");
/*     */     
/* 594 */     if (this.attributes.length > 0) {
/* 595 */       buf.append("\nAttribute(s):\n");
/* 596 */       for (int i = 0; i < this.attributes.length; i++) {
/* 597 */         buf.append(indent(this.attributes[i]));
/*     */       }
/*     */     } 
/* 600 */     if (this.fields.length > 0) {
/* 601 */       buf.append("\n" + this.fields.length + " fields:\n");
/* 602 */       for (int i = 0; i < this.fields.length; i++) {
/* 603 */         buf.append("\t" + this.fields[i] + '\n');
/*     */       }
/*     */     } 
/* 606 */     if (this.methods.length > 0) {
/* 607 */       buf.append("\n" + this.methods.length + " methods:\n");
/* 608 */       for (int i = 0; i < this.methods.length; i++) {
/* 609 */         buf.append("\t" + this.methods[i] + '\n');
/*     */       }
/*     */     } 
/* 612 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private static final String indent(Object obj) {
/* 616 */     StringTokenizer tok = new StringTokenizer(obj.toString(), "\n");
/* 617 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 619 */     while (tok.hasMoreTokens()) {
/* 620 */       buf.append("\t" + tok.nextToken() + "\n");
/*     */     }
/* 622 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass copy() {
/* 629 */     JavaClass c = null;
/*     */     
/*     */     try {
/* 632 */       c = (JavaClass)clone();
/* 633 */     } catch (CloneNotSupportedException cloneNotSupportedException) {}
/*     */     
/* 635 */     c.constant_pool = this.constant_pool.copy();
/* 636 */     c.interfaces = (int[])this.interfaces.clone();
/* 637 */     c.interface_names = (String[])this.interface_names.clone();
/*     */     
/* 639 */     c.fields = new Field[this.fields.length];
/* 640 */     for (int i = 0; i < this.fields.length; i++) {
/* 641 */       c.fields[i] = this.fields[i].copy(c.constant_pool);
/*     */     }
/* 643 */     c.methods = new Method[this.methods.length];
/* 644 */     for (int i = 0; i < this.methods.length; i++) {
/* 645 */       c.methods[i] = this.methods[i].copy(c.constant_pool);
/*     */     }
/* 647 */     c.attributes = new Attribute[this.attributes.length];
/* 648 */     for (int i = 0; i < this.attributes.length; i++) {
/* 649 */       c.attributes[i] = this.attributes[i].copy(c.constant_pool);
/*     */     }
/* 651 */     return c;
/*     */   }
/*     */ 
/*     */   
/* 655 */   public final boolean isSuper() { return ((this.access_flags & 0x20) != 0); }
/*     */ 
/*     */ 
/*     */   
/* 659 */   public final boolean isClass() { return ((this.access_flags & 0x200) == 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 665 */   public final byte getSource() { return this.source; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 675 */   public Repository getRepository() { return this.repository; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 683 */   public void setRepository(Repository repository) { this.repository = repository; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean instanceOf(JavaClass super_class) {
/* 691 */     if (equals(super_class)) {
/* 692 */       return true;
/*     */     }
/* 694 */     JavaClass[] super_classes = getSuperClasses();
/*     */     
/* 696 */     for (int i = 0; i < super_classes.length; i++) {
/* 697 */       if (super_classes[i].equals(super_class)) {
/* 698 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 702 */     if (super_class.isInterface()) {
/* 703 */       return implementationOf(super_class);
/*     */     }
/*     */     
/* 706 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implementationOf(JavaClass inter) {
/* 713 */     if (!inter.isInterface()) {
/* 714 */       throw new IllegalArgumentException(String.valueOf(inter.getClassName()) + " is no interface");
/*     */     }
/*     */     
/* 717 */     if (equals(inter)) {
/* 718 */       return true;
/*     */     }
/*     */     
/* 721 */     JavaClass[] super_interfaces = getAllInterfaces();
/*     */     
/* 723 */     for (int i = 0; i < super_interfaces.length; i++) {
/* 724 */       if (super_interfaces[i].equals(inter)) {
/* 725 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 729 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass getSuperClass() {
/* 737 */     if ("java.lang.Object".equals(getClassName())) {
/* 738 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 742 */       return this.repository.loadClass(getSuperclassName());
/* 743 */     } catch (ClassNotFoundException e) {
/* 744 */       System.err.println(e);
/* 745 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass[] getSuperClasses() {
/* 754 */     JavaClass clazz = this;
/* 755 */     ClassVector vec = new ClassVector();
/*     */     
/* 757 */     for (clazz = clazz.getSuperClass(); clazz != null; 
/* 758 */       clazz = clazz.getSuperClass())
/*     */     {
/* 760 */       vec.addElement(clazz);
/*     */     }
/*     */     
/* 763 */     return vec.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass[] getInterfaces() {
/* 770 */     String[] interfaces = getInterfaceNames();
/* 771 */     JavaClass[] classes = new JavaClass[interfaces.length];
/*     */     
/*     */     try {
/* 774 */       for (int i = 0; i < interfaces.length; i++) {
/* 775 */         classes[i] = this.repository.loadClass(interfaces[i]);
/*     */       }
/* 777 */     } catch (ClassNotFoundException e) {
/* 778 */       System.err.println(e);
/* 779 */       return null;
/*     */     } 
/*     */     
/* 782 */     return classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass[] getAllInterfaces() {
/* 789 */     ClassQueue queue = new ClassQueue();
/* 790 */     ClassVector vec = new ClassVector();
/*     */     
/* 792 */     queue.enqueue(this);
/*     */     
/* 794 */     while (!queue.empty()) {
/* 795 */       JavaClass clazz = queue.dequeue();
/*     */       
/* 797 */       JavaClass souper = clazz.getSuperClass();
/* 798 */       JavaClass[] interfaces = clazz.getInterfaces();
/*     */       
/* 800 */       if (clazz.isInterface()) {
/* 801 */         vec.addElement(clazz);
/*     */       }
/* 803 */       else if (souper != null) {
/* 804 */         queue.enqueue(souper);
/*     */       } 
/*     */ 
/*     */       
/* 808 */       for (int i = 0; i < interfaces.length; i++) {
/* 809 */         queue.enqueue(interfaces[i]);
/*     */       }
/*     */     } 
/*     */     
/* 813 */     return vec.toArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\JavaClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */