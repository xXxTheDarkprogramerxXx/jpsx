/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConstantCP
/*     */   extends Constant
/*     */ {
/*     */   protected int class_index;
/*     */   protected int name_and_type_index;
/*     */   
/*  77 */   public ConstantCP(ConstantCP c) { this(c.getTag(), c.getClassIndex(), c.getNameAndTypeIndex()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   ConstantCP(byte tag, DataInputStream file) throws IOException { this(tag, file.readUnsignedShort(), file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConstantCP(byte tag, int class_index, int name_and_type_index) {
/*  98 */     super(tag);
/*  99 */     this.class_index = class_index;
/* 100 */     this.name_and_type_index = name_and_type_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 111 */     file.writeByte(this.tag);
/* 112 */     file.writeShort(this.class_index);
/* 113 */     file.writeShort(this.name_and_type_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public final int getClassIndex() { return this.class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public final int getNameAndTypeIndex() { return this.name_and_type_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public final void setClassIndex(int class_index) { this.class_index = class_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public String getClass(ConstantPool cp) { return cp.constantToString(this.class_index, (byte)7); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public final void setNameAndTypeIndex(int name_and_type_index) { this.name_and_type_index = name_and_type_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 151 */     return String.valueOf(super.toString()) + "(class_index = " + this.class_index + 
/* 152 */       ", name_and_type_index = " + this.name_and_type_index + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantCP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */