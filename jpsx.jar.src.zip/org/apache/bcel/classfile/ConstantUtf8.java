/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantUtf8
/*     */   extends Constant
/*     */ {
/*     */   private String bytes;
/*     */   
/*  76 */   public ConstantUtf8(ConstantUtf8 c) { this(c.getBytes()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConstantUtf8(DataInputStream file) throws IOException {
/*  87 */     super((byte)1);
/*     */     
/*  89 */     this.bytes = file.readUTF();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantUtf8(String bytes) {
/*  97 */     super((byte)1);
/*     */     
/*  99 */     if (bytes == null) {
/* 100 */       throw new IllegalArgumentException("bytes must not be null!");
/*     */     }
/* 102 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void accept(Visitor v) { v.visitConstantUtf8(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 124 */     file.writeByte(this.tag);
/* 125 */     file.writeUTF(this.bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public final String getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public final void setBytes(String bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public final String toString() { return String.valueOf(super.toString()) + "(\"" + Utility.replace(this.bytes, "\n", "\\n") + "\")"; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantUtf8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */