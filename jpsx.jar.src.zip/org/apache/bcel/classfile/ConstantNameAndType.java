/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantNameAndType
/*     */   extends Constant
/*     */ {
/*     */   private int name_index;
/*     */   private int signature_index;
/*     */   
/*  78 */   public ConstantNameAndType(ConstantNameAndType c) { this(c.getNameIndex(), c.getSignatureIndex()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   ConstantNameAndType(DataInputStream file) throws IOException { this(file.readUnsignedShort(), file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantNameAndType(int name_index, int signature_index) {
/*  99 */     super((byte)12);
/* 100 */     this.name_index = name_index;
/* 101 */     this.signature_index = signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public void accept(Visitor v) { v.visitConstantNameAndType(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 123 */     file.writeByte(this.tag);
/* 124 */     file.writeShort(this.name_index);
/* 125 */     file.writeShort(this.signature_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public final int getNameIndex() { return this.name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public final String getName(ConstantPool cp) { return cp.constantToString(getNameIndex(), (byte)1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public final int getSignatureIndex() { return this.signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public final String getSignature(ConstantPool cp) { return cp.constantToString(getSignatureIndex(), (byte)1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public final void setNameIndex(int name_index) { this.name_index = name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public final void setSignatureIndex(int signature_index) { this.signature_index = signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 168 */     return String.valueOf(super.toString()) + "(name_index = " + this.name_index + 
/* 169 */       ", signature_index = " + this.signature_index + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantNameAndType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */