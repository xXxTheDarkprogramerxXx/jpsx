/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Unknown
/*     */   extends Attribute
/*     */ {
/*     */   private byte[] bytes;
/*     */   private String name;
/*  81 */   private static HashMap unknown_attributes = new HashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   static Unknown[] getUnknownAttributes() {
/*  86 */     unknowns = new Unknown[unknown_attributes.size()];
/*  87 */     Iterator entries = unknown_attributes.values().iterator();
/*     */     
/*  89 */     for (int i = 0; entries.hasNext(); i++) {
/*  90 */       unknowns[i] = (Unknown)entries.next();
/*     */     }
/*  92 */     unknown_attributes.clear();
/*  93 */     return unknowns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public Unknown(Unknown c) { this(c.getNameIndex(), c.getLength(), c.getBytes(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Unknown(int name_index, int length, byte[] bytes, ConstantPool constant_pool) {
/* 115 */     super((byte)-1, name_index, length, constant_pool);
/* 116 */     this.bytes = bytes;
/*     */     
/* 118 */     this.name = ((ConstantUtf8)constant_pool.getConstant(name_index, (byte)
/* 119 */         1)).getBytes();
/* 120 */     unknown_attributes.put(this.name, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Unknown(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException {
/* 135 */     this(name_index, length, null, constant_pool);
/*     */     
/* 137 */     if (length > 0) {
/* 138 */       this.bytes = new byte[length];
/* 139 */       file.readFully(this.bytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public void accept(Visitor v) { v.visitUnknown(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 161 */     super.dump(file);
/* 162 */     if (this.length > 0) {
/* 163 */       file.write(this.bytes, 0, this.length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 168 */   public final byte[] getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public final String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public final void setBytes(byte[] bytes) { this.bytes = bytes; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/*     */     String hex;
/* 186 */     if (this.length == 0 || this.bytes == null) {
/* 187 */       return "(Unknown attribute " + this.name + ")";
/*     */     }
/*     */     
/* 190 */     if (this.length > 10) {
/* 191 */       byte[] tmp = new byte[10];
/* 192 */       System.arraycopy(this.bytes, 0, tmp, 0, 10);
/* 193 */       hex = String.valueOf(Utility.toHexString(tmp)) + "... (truncated)";
/*     */     } else {
/*     */       
/* 196 */       hex = Utility.toHexString(this.bytes);
/*     */     } 
/* 198 */     return "(Unknown attribute " + this.name + ": " + hex + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute copy(ConstantPool constant_pool) {
/* 205 */     Unknown c = (Unknown)clone();
/*     */     
/* 207 */     if (this.bytes != null) {
/* 208 */       c.bytes = (byte[])this.bytes.clone();
/*     */     }
/* 210 */     c.constant_pool = constant_pool;
/* 211 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Unknown.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */