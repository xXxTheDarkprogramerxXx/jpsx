/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Method
/*     */   extends FieldOrMethod
/*     */ {
/*     */   public Method() {}
/*     */   
/*  80 */   public Method(Method c) { super(c); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   Method(DataInputStream file, ConstantPool constant_pool) throws IOException, ClassFormatException { super(file, constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public Method(int access_flags, int name_index, int signature_index, Attribute[] attributes, ConstantPool constant_pool) { super(access_flags, name_index, signature_index, attributes, constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void accept(Visitor v) { v.visitMethod(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Code getCode() {
/* 123 */     for (int i = 0; i < this.attributes_count; i++) {
/* 124 */       if (this.attributes[i] instanceof Code)
/* 125 */         return (Code)this.attributes[i]; 
/*     */     } 
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ExceptionTable getExceptionTable() {
/* 135 */     for (int i = 0; i < this.attributes_count; i++) {
/* 136 */       if (this.attributes[i] instanceof ExceptionTable)
/* 137 */         return (ExceptionTable)this.attributes[i]; 
/*     */     } 
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LocalVariableTable getLocalVariableTable() {
/* 146 */     Code code = getCode();
/*     */     
/* 148 */     if (code != null) {
/* 149 */       return code.getLocalVariableTable();
/*     */     }
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LineNumberTable getLineNumberTable() {
/* 158 */     Code code = getCode();
/*     */     
/* 160 */     if (code != null) {
/* 161 */       return code.getLineNumberTable();
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 177 */     String access = Utility.accessToString(this.access_flags);
/*     */ 
/*     */     
/* 180 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.signature_index, (byte)
/* 181 */         1);
/* 182 */     String signature = c.getBytes();
/*     */     
/* 184 */     c = (ConstantUtf8)this.constant_pool.getConstant(this.name_index, (byte)1);
/* 185 */     String name = c.getBytes();
/*     */     
/* 187 */     signature = Utility.methodSignatureToString(signature, name, access, true, 
/* 188 */         getLocalVariableTable());
/* 189 */     StringBuffer buf = new StringBuffer(signature);
/*     */     
/* 191 */     for (int i = 0; i < this.attributes_count; i++) {
/* 192 */       Attribute a = this.attributes[i];
/*     */       
/* 194 */       if (!(a instanceof Code) && !(a instanceof ExceptionTable)) {
/* 195 */         buf.append(" [" + a.toString() + "]");
/*     */       }
/*     */     } 
/* 198 */     ExceptionTable e = getExceptionTable();
/* 199 */     if (e != null) {
/* 200 */       String str = e.toString();
/* 201 */       if (!str.equals("")) {
/* 202 */         buf.append("\n\t\tthrows " + str);
/*     */       }
/*     */     } 
/* 205 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public final Method copy(ConstantPool constant_pool) { return (Method)copy_(constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public Type getReturnType() { return Type.getReturnType(getSignature()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public Type[] getArgumentTypes() { return Type.getArgumentTypes(getSignature()); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Method.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */