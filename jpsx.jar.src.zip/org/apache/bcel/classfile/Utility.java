/*      */ package org.apache.bcel.classfile;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.CharArrayWriter;
/*      */ import java.io.FilterReader;
/*      */ import java.io.FilterWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import java.util.zip.GZIPOutputStream;
/*      */ import org.apache.bcel.Constants;
/*      */ import org.apache.bcel.util.ByteSequence;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Utility
/*      */ {
/*   72 */   private static int unwrap(ThreadLocal tl) { return ((Integer)tl.get()).intValue(); }
/*      */ 
/*      */ 
/*      */   
/*   76 */   private static void wrap(ThreadLocal tl, int value) { tl.set(new Integer(value)); }
/*      */ 
/*      */   
/*   79 */   private static ThreadLocal consumed_chars = new ThreadLocal()
/*      */     {
/*   81 */       protected Object initialValue() { return new Integer(false); }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean wide = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int FREE_CHARS = 48;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  105 */   public static final String accessToString(int access_flags) { return accessToString(access_flags, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String accessToString(int access_flags, boolean for_class) {
/*  123 */     StringBuffer buf = new StringBuffer();
/*      */     
/*  125 */     int p = 0;
/*  126 */     for (int i = 0; p < 2048; i++) {
/*  127 */       p = pow2(i);
/*      */       
/*  129 */       if ((access_flags & p) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  135 */         if (!for_class || (p != 32 && p != 512))
/*      */         {
/*      */           
/*  138 */           buf.append(String.valueOf(Constants.ACCESS_NAMES[i]) + " ");
/*      */         }
/*      */       }
/*      */     } 
/*  142 */     return buf.toString().trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  149 */   public static final String classOrInterface(int access_flags) { return ((access_flags & 0x200) != 0) ? "interface" : "class"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String codeToString(byte[] code, ConstantPool constant_pool, int index, int length, boolean verbose) {
/*  170 */     StringBuffer buf = new StringBuffer(code.length * 20);
/*  171 */     ByteSequence stream = new ByteSequence(code);
/*      */     
/*      */     try {
/*  174 */       for (int i = 0; i < index; i++) {
/*  175 */         codeToString(stream, constant_pool, verbose);
/*      */       }
/*  177 */       for (int i = 0; stream.available() > 0; i++) {
/*  178 */         if (length < 0 || i < length) {
/*  179 */           String indices = fillup(String.valueOf(stream.getIndex()) + ":", 6, true, ' ');
/*  180 */           buf.append(String.valueOf(indices) + codeToString(stream, constant_pool, verbose) + '\n');
/*      */         } 
/*      */       } 
/*  183 */     } catch (IOException e) {
/*  184 */       System.out.println(buf.toString());
/*  185 */       e.printStackTrace();
/*  186 */       throw new ClassFormatException("Byte code error: " + e);
/*      */     } 
/*      */     
/*  189 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   public static final String codeToString(byte[] code, ConstantPool constant_pool, int index, int length) { return codeToString(code, constant_pool, index, length, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String codeToString(ByteSequence bytes, ConstantPool constant_pool, boolean verbose) throws IOException {
/*      */     int dimensions, i, nargs, i, offset, offset, jump_table[], jump_table[], match[], constant, vindex, index, index, index, index, index, index, index, index, npairs, high, low;
/*  211 */     short opcode = (short)bytes.readUnsignedByte();
/*  212 */     int default_offset = 0;
/*      */ 
/*      */     
/*  215 */     int no_pad_bytes = 0;
/*  216 */     StringBuffer buf = new StringBuffer(Constants.OPCODE_NAMES[opcode]);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  221 */     if (opcode == 170 || opcode == 171) {
/*  222 */       int remainder = bytes.getIndex() % 4;
/*  223 */       no_pad_bytes = (remainder == 0) ? 0 : (4 - remainder);
/*      */       
/*  225 */       for (int i = 0; i < no_pad_bytes; i++) {
/*      */         byte b;
/*      */         
/*  228 */         if ((b = bytes.readByte()) != 0) {
/*  229 */           System.err.println("Warning: Padding byte != 0 in " + 
/*  230 */               Constants.OPCODE_NAMES[opcode] + ":" + b);
/*      */         }
/*      */       } 
/*      */       
/*  234 */       default_offset = bytes.readInt();
/*      */     } 
/*      */     
/*  237 */     switch (opcode)
/*      */     
/*      */     { 
/*      */       case 170:
/*  241 */         low = bytes.readInt();
/*  242 */         high = bytes.readInt();
/*      */         
/*  244 */         offset = bytes.getIndex() - 12 - no_pad_bytes - 1;
/*  245 */         default_offset += offset;
/*      */         
/*  247 */         buf.append("\tdefault = " + default_offset + ", low = " + low + 
/*  248 */             ", high = " + high + "(");
/*      */         
/*  250 */         jump_table = new int[high - low + 1];
/*  251 */         for (i = 0; i < jump_table.length; i++) {
/*  252 */           jump_table[i] = offset + bytes.readInt();
/*  253 */           buf.append(jump_table[i]);
/*      */           
/*  255 */           if (i < jump_table.length - 1)
/*  256 */             buf.append(", "); 
/*      */         } 
/*  258 */         buf.append(")");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  451 */         return buf.toString();case 171: npairs = bytes.readInt(); offset = bytes.getIndex() - 8 - no_pad_bytes - 1; match = new int[npairs]; jump_table = new int[npairs]; default_offset += offset; buf.append("\tdefault = " + default_offset + ", npairs = " + npairs + " ("); for (i = 0; i < npairs; i++) { match[i] = bytes.readInt(); jump_table[i] = offset + bytes.readInt(); buf.append("(" + match[i] + ", " + jump_table[i] + ")"); if (i < npairs - 1) buf.append(", ");  }  buf.append(")"); return buf.toString();case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161: case 162: case 163: case 164: case 165: case 166: case 167: case 168: case 198: case 199: buf.append("\t\t#" + (bytes.getIndex() - 1 + bytes.readShort())); return buf.toString();case 200: case 201: buf.append("\t\t#" + (bytes.getIndex() - 1 + bytes.readInt())); return buf.toString();case 21: case 22: case 23: case 24: case 25: case 54: case 55: case 56: case 57: case 58: case 169: if (wide) { vindex = bytes.readUnsignedShort(); wide = false; } else { vindex = bytes.readUnsignedByte(); }  buf.append("\t\t%" + vindex); return buf.toString();case 196: wide = true; buf.append("\t(wide)"); return buf.toString();case 188: buf.append("\t\t<" + Constants.TYPE_NAMES[bytes.readByte()] + ">"); return buf.toString();case 178: case 179: case 180: case 181: index = bytes.readUnsignedShort(); buf.append("\t\t" + constant_pool.constantToString(index, (byte)9) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 187: case 192: buf.append("\t");case 193: index = bytes.readUnsignedShort(); buf.append("\t<" + constant_pool.constantToString(index, (byte)7) + ">" + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 182: case 183: case 184: index = bytes.readUnsignedShort(); buf.append("\t" + constant_pool.constantToString(index, (byte)10) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 185: index = bytes.readUnsignedShort(); nargs = bytes.readUnsignedByte(); buf.append("\t" + constant_pool.constantToString(index, (byte)11) + (verbose ? (" (" + index + ")\t") : "") + nargs + "\t" + bytes.readUnsignedByte()); return buf.toString();case 19: case 20: index = bytes.readUnsignedShort(); buf.append("\t\t" + constant_pool.constantToString(index, constant_pool.getConstant(index).getTag()) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 18: index = bytes.readUnsignedByte(); buf.append("\t\t" + constant_pool.constantToString(index, constant_pool.getConstant(index).getTag()) + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 189: index = bytes.readUnsignedShort(); buf.append("\t\t<" + compactClassName(constant_pool.getConstantString(index, (byte)7), false) + ">" + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 197: index = bytes.readUnsignedShort(); dimensions = bytes.readUnsignedByte(); buf.append("\t<" + compactClassName(constant_pool.getConstantString(index, (byte)7), false) + ">\t" + dimensions + (verbose ? (" (" + index + ")") : "")); return buf.toString();case 132: if (wide) { int vindex = bytes.readUnsignedShort(); constant = bytes.readShort(); wide = false; } else { vindex = bytes.readUnsignedByte(); constant = bytes.readByte(); }  buf.append("\t\t%" + vindex + "\t" + constant); return buf.toString(); }  if (Constants.NO_OF_OPERANDS[opcode] > 0) for (int i = 0; i < Constants.TYPE_OF_OPERANDS[opcode].length; i++) { buf.append("\t\t"); switch (Constants.TYPE_OF_OPERANDS[opcode][i]) { case 8: buf.append(bytes.readByte()); break;case 9: buf.append(bytes.readShort()); break;case 10: buf.append(bytes.readInt()); break;default: System.err.println("Unreachable default case reached!"); System.exit(-1); break; }  }   return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  457 */   public static final String codeToString(ByteSequence bytes, ConstantPool constant_pool) throws IOException { return codeToString(bytes, constant_pool, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  468 */   public static final String compactClassName(String str) { return compactClassName(str, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String compactClassName(String str, String prefix, boolean chopit) {
/*  486 */     int len = prefix.length();
/*      */     
/*  488 */     str = str.replace('/', '.');
/*      */     
/*  490 */     if (chopit)
/*      */     {
/*  492 */       if (str.startsWith(prefix) && 
/*  493 */         str.substring(len).indexOf('.') == -1) {
/*  494 */         str = str.substring(len);
/*      */       }
/*      */     }
/*  497 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  511 */   public static final String compactClassName(String str, boolean chopit) { return compactClassName(str, "java.lang.", chopit); }
/*      */ 
/*      */ 
/*      */   
/*  515 */   private static final boolean is_digit(char ch) { return (ch >= '0' && ch <= '9'); }
/*      */ 
/*      */ 
/*      */   
/*  519 */   private static final boolean is_space(char ch) { return !(ch != ' ' && ch != '\t' && ch != '\r' && ch != '\n'); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  526 */   public static final int setBit(int flag, int i) { return flag | pow2(i); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int clearBit(int flag, int i) {
/*  533 */     int bit = pow2(i);
/*  534 */     return ((flag & bit) == 0) ? flag : (flag ^ bit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  541 */   public static final boolean isSet(int flag, int i) { return ((flag & pow2(i)) != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String methodTypeToSignature(String ret, String[] argv) throws ClassFormatException {
/*  555 */     StringBuffer buf = new StringBuffer("(");
/*      */ 
/*      */     
/*  558 */     if (argv != null) {
/*  559 */       for (int i = 0; i < argv.length; i++) {
/*  560 */         String str = getSignature(argv[i]);
/*      */         
/*  562 */         if (str.endsWith("V")) {
/*  563 */           throw new ClassFormatException("Invalid type: " + argv[i]);
/*      */         }
/*  565 */         buf.append(str);
/*      */       } 
/*      */     }
/*  568 */     String str = getSignature(ret);
/*      */     
/*  570 */     buf.append(")" + str);
/*      */     
/*  572 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  583 */   public static final String[] methodSignatureArgumentTypes(String signature) throws ClassFormatException { return methodSignatureArgumentTypes(signature, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] methodSignatureArgumentTypes(String signature, boolean chopit) throws ClassFormatException {
/*  596 */     ArrayList vec = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  601 */       if (signature.charAt(0) != '(') {
/*  602 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*      */       }
/*  604 */       int index = 1;
/*      */       
/*  606 */       while (signature.charAt(index) != ')') {
/*  607 */         vec.add(signatureToString(signature.substring(index), chopit));
/*      */         
/*  609 */         index += unwrap(consumed_chars);
/*      */       } 
/*  611 */     } catch (StringIndexOutOfBoundsException e) {
/*  612 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */     
/*  615 */     String[] types = new String[vec.size()];
/*  616 */     vec.toArray(types);
/*  617 */     return types;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  627 */   public static final String methodSignatureReturnType(String signature) { return methodSignatureReturnType(signature, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String methodSignatureReturnType(String signature, boolean chopit) {
/*      */     String type;
/*      */     try {
/*  644 */       int index = signature.lastIndexOf(')') + 1;
/*  645 */       type = signatureToString(signature.substring(index), chopit);
/*  646 */     } catch (StringIndexOutOfBoundsException e) {
/*  647 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */     
/*  650 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  664 */   public static final String methodSignatureToString(String signature, String name, String access) { return methodSignatureToString(signature, name, access, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  671 */   public static final String methodSignatureToString(String signature, String name, String access, boolean chopit) { return methodSignatureToString(signature, name, access, chopit, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String methodSignatureToString(String signature, String name, String access, boolean chopit, LocalVariableTable vars) throws ClassFormatException {
/*      */     String type;
/*  708 */     StringBuffer buf = new StringBuffer("(");
/*      */ 
/*      */     
/*  711 */     int var_index = (access.indexOf("static") >= 0) ? 0 : 1;
/*      */     
/*      */     try {
/*  714 */       if (signature.charAt(0) != '(') {
/*  715 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*      */       }
/*  717 */       int index = 1;
/*      */       
/*  719 */       while (signature.charAt(index) != ')') {
/*  720 */         String param_type = signatureToString(signature.substring(index), chopit);
/*  721 */         buf.append(param_type);
/*      */         
/*  723 */         if (vars != null) {
/*  724 */           LocalVariable l = vars.getLocalVariable(var_index);
/*      */           
/*  726 */           if (l != null)
/*  727 */             buf.append(" " + l.getName()); 
/*      */         } else {
/*  729 */           buf.append(" arg" + var_index);
/*      */         } 
/*  731 */         if ("double".equals(param_type) || "long".equals(param_type)) {
/*  732 */           var_index += 2;
/*      */         } else {
/*  734 */           var_index++;
/*      */         } 
/*  736 */         buf.append(", ");
/*      */         
/*  738 */         index += unwrap(consumed_chars);
/*      */       } 
/*      */       
/*  741 */       index++;
/*      */ 
/*      */       
/*  744 */       type = signatureToString(signature.substring(index), chopit);
/*      */     }
/*  746 */     catch (StringIndexOutOfBoundsException e) {
/*  747 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */     
/*  750 */     if (buf.length() > 1) {
/*  751 */       buf.setLength(buf.length() - 2);
/*      */     }
/*  753 */     buf.append(")");
/*      */     
/*  755 */     return String.valueOf(access) + ((access.length() > 0) ? " " : "") + 
/*  756 */       type + " " + name + buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  761 */   private static final int pow2(int n) { return 1 << n; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String replace(String str, String old, String new_) {
/*  774 */     StringBuffer buf = new StringBuffer();
/*      */     try {
/*      */       int index;
/*  777 */       if ((index = str.indexOf(old)) != -1) {
/*  778 */         int old_index = 0;
/*      */ 
/*      */         
/*  781 */         while ((index = str.indexOf(old, old_index)) != -1) {
/*  782 */           buf.append(str.substring(old_index, index));
/*  783 */           buf.append(new_);
/*      */           
/*  785 */           old_index = index + old.length();
/*      */         } 
/*      */         
/*  788 */         buf.append(str.substring(old_index));
/*  789 */         str = buf.toString();
/*      */       } 
/*  791 */     } catch (StringIndexOutOfBoundsException e) {
/*  792 */       System.err.println(e);
/*      */     } 
/*      */     
/*  795 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  805 */   public static final String signatureToString(String signature) { return signatureToString(signature, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String signatureToString(String signature, boolean chopit) {
/*  846 */     wrap(Utility.consumed_chars, 1); try {
/*      */       int _temp; int consumed_chars; String type; StringBuffer brackets; int n;
/*      */       int index;
/*  849 */       switch (signature.charAt(0)) { case 'B':
/*  850 */           return "byte";
/*  851 */         case 'C': return "char";
/*  852 */         case 'D': return "double";
/*  853 */         case 'F': return "float";
/*  854 */         case 'I': return "int";
/*  855 */         case 'J': return "long";
/*      */         
/*      */         case 'L':
/*  858 */           index = signature.indexOf(';');
/*      */           
/*  860 */           if (index < 0) {
/*  861 */             throw new ClassFormatException("Invalid signature: " + signature);
/*      */           }
/*      */           
/*  864 */           wrap(Utility.consumed_chars, index + 1);
/*      */           
/*  866 */           return compactClassName(signature.substring(1, index), chopit);
/*      */         
/*      */         case 'S':
/*  869 */           return "short";
/*  870 */         case 'Z': return "boolean";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case '[':
/*  879 */           brackets = new StringBuffer();
/*      */ 
/*      */           
/*  882 */           for (n = 0; signature.charAt(n) == '['; n++) {
/*  883 */             brackets.append("[]");
/*      */           }
/*  885 */           consumed_chars = n;
/*      */ 
/*      */           
/*  888 */           type = signatureToString(signature.substring(n), chopit);
/*      */ 
/*      */ 
/*      */           
/*  892 */           _temp = unwrap(Utility.consumed_chars) + consumed_chars;
/*  893 */           wrap(Utility.consumed_chars, _temp);
/*      */           
/*  895 */           return String.valueOf(type) + brackets.toString();
/*      */         
/*      */         case 'V':
/*  898 */           return "void"; }
/*      */       
/*  900 */       throw new ClassFormatException("Invalid signature: `" + 
/*  901 */           signature + "'");
/*      */     }
/*  903 */     catch (StringIndexOutOfBoundsException e) {
/*  904 */       throw new ClassFormatException("Invalid signature: " + e + ":" + signature);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSignature(String type) {
/*  915 */     StringBuffer buf = new StringBuffer();
/*  916 */     char[] chars = type.toCharArray();
/*  917 */     boolean char_found = false, delim = false;
/*  918 */     int index = -1;
/*      */ 
/*      */     
/*  921 */     for (int i = 0; i < chars.length; i++) {
/*  922 */       switch (chars[i]) { case '\t': case '\n': case '\f': case '\r':
/*      */         case ' ':
/*  924 */           if (char_found) {
/*  925 */             delim = true;
/*      */           }
/*      */           break;
/*      */         case '[':
/*  929 */           if (!char_found) {
/*  930 */             throw new RuntimeException("Illegal type: " + type);
/*      */           }
/*  932 */           index = i;
/*      */           break;
/*      */         
/*      */         default:
/*  936 */           char_found = true;
/*  937 */           if (!delim)
/*  938 */             buf.append(chars[i]); 
/*      */           break; }
/*      */     
/*      */     } 
/*  942 */     int brackets = 0;
/*      */     
/*  944 */     if (index > 0) {
/*  945 */       brackets = countBrackets(type.substring(index));
/*      */     }
/*  947 */     type = buf.toString();
/*  948 */     buf.setLength(0);
/*      */     
/*  950 */     for (int i = 0; i < brackets; i++) {
/*  951 */       buf.append('[');
/*      */     }
/*  953 */     boolean found = false;
/*      */     
/*  955 */     for (int i = 4; i <= 12 && !found; i++) {
/*  956 */       if (Constants.TYPE_NAMES[i].equals(type)) {
/*  957 */         found = true;
/*  958 */         buf.append(Constants.SHORT_TYPE_NAMES[i]);
/*      */       } 
/*      */     } 
/*      */     
/*  962 */     if (!found) {
/*  963 */       buf.append(String.valueOf('L') + type.replace('.', '/') + ';');
/*      */     }
/*  965 */     return buf.toString();
/*      */   }
/*      */   
/*      */   private static int countBrackets(String brackets) {
/*  969 */     char[] chars = brackets.toCharArray();
/*  970 */     int count = 0;
/*  971 */     boolean open = false;
/*      */     
/*  973 */     for (int i = 0; i < chars.length; i++) {
/*  974 */       switch (chars[i]) {
/*      */         case '[':
/*  976 */           if (open)
/*  977 */             throw new RuntimeException("Illegally nested brackets:" + brackets); 
/*  978 */           open = true;
/*      */           break;
/*      */         
/*      */         case ']':
/*  982 */           if (!open)
/*  983 */             throw new RuntimeException("Illegally nested brackets:" + brackets); 
/*  984 */           open = false;
/*  985 */           count++;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/*  993 */     if (open) {
/*  994 */       throw new RuntimeException("Illegally nested brackets:" + brackets);
/*      */     }
/*  996 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte typeOfMethodSignature(String signature) throws ClassFormatException {
/*      */     try {
/* 1012 */       if (signature.charAt(0) != '(') {
/* 1013 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*      */       }
/* 1015 */       int index = signature.lastIndexOf(')') + 1;
/* 1016 */       return typeOfSignature(signature.substring(index));
/* 1017 */     } catch (StringIndexOutOfBoundsException e) {
/* 1018 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte typeOfSignature(String signature) throws ClassFormatException {
/*      */     try {
/* 1033 */       switch (signature.charAt(0)) { case 'B':
/* 1034 */           return 8;
/* 1035 */         case 'C': return 5;
/* 1036 */         case 'D': return 7;
/* 1037 */         case 'F': return 6;
/* 1038 */         case 'I': return 10;
/* 1039 */         case 'J': return 11;
/* 1040 */         case 'L': return 14;
/* 1041 */         case '[': return 13;
/* 1042 */         case 'V': return 12;
/* 1043 */         case 'Z': return 4;
/* 1044 */         case 'S': return 9; }
/*      */       
/* 1046 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     }
/* 1048 */     catch (StringIndexOutOfBoundsException e) {
/* 1049 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static short searchOpcode(String name) {
/* 1056 */     name = name.toLowerCase();
/*      */     
/* 1058 */     for (short i = 0; i < Constants.OPCODE_NAMES.length; i = (short)(i + 1)) {
/* 1059 */       if (Constants.OPCODE_NAMES[i].equals(name))
/* 1060 */         return i; 
/*      */     } 
/* 1062 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1070 */   private static final short byteToShort(byte b) { return (b < 0) ? (short)('Ā' + b) : (short)b; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String toHexString(byte[] bytes) {
/* 1078 */     StringBuffer buf = new StringBuffer();
/*      */     
/* 1080 */     for (int i = 0; i < bytes.length; i++) {
/* 1081 */       short b = byteToShort(bytes[i]);
/* 1082 */       String hex = Integer.toString(b, 16);
/*      */       
/* 1084 */       if (b < 16) {
/* 1085 */         buf.append('0');
/*      */       }
/* 1087 */       buf.append(hex);
/*      */       
/* 1089 */       if (i < bytes.length - 1) {
/* 1090 */         buf.append(' ');
/*      */       }
/*      */     } 
/* 1093 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1107 */   public static final String format(int i, int length, boolean left_justify, char fill) { return fillup(Integer.toString(i), length, left_justify, fill); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String fillup(String str, int length, boolean left_justify, char fill) {
/* 1120 */     int len = length - str.length();
/* 1121 */     char[] buf = new char[(len < 0) ? 0 : len];
/*      */     
/* 1123 */     for (int j = 0; j < buf.length; j++) {
/* 1124 */       buf[j] = fill;
/*      */     }
/* 1126 */     if (left_justify) {
/* 1127 */       return String.valueOf(str) + new String(buf);
/*      */     }
/* 1129 */     return String.valueOf(new String(buf)) + str;
/*      */   }
/*      */ 
/*      */   
/*      */   static final boolean equals(byte[] a, byte[] b) {
/*      */     int size;
/* 1135 */     if ((size = a.length) != b.length) {
/* 1136 */       return false;
/*      */     }
/* 1138 */     for (int i = 0; i < size; i++) {
/* 1139 */       if (a[i] != b[i])
/* 1140 */         return false; 
/*      */     } 
/* 1142 */     return true;
/*      */   }
/*      */ 
/*      */   
/* 1146 */   public static final void printArray(PrintStream out, Object[] obj) { out.println(printArray(obj, true)); }
/*      */ 
/*      */ 
/*      */   
/* 1150 */   public static final void printArray(PrintWriter out, Object[] obj) { out.println(printArray(obj, true)); }
/*      */ 
/*      */ 
/*      */   
/* 1154 */   public static final String printArray(Object[] obj) { return printArray(obj, true); }
/*      */ 
/*      */ 
/*      */   
/* 1158 */   public static final String printArray(Object[] obj, boolean braces) { return printArray(obj, braces, false); }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String printArray(Object[] obj, boolean braces, boolean quote) {
/* 1163 */     if (obj == null) {
/* 1164 */       return null;
/*      */     }
/* 1166 */     StringBuffer buf = new StringBuffer();
/* 1167 */     if (braces) {
/* 1168 */       buf.append('{');
/*      */     }
/* 1170 */     for (int i = 0; i < obj.length; i++) {
/* 1171 */       if (obj[i] != null) {
/* 1172 */         buf.append(String.valueOf(quote ? "\"" : "") + obj[i].toString() + (quote ? "\"" : ""));
/*      */       } else {
/* 1174 */         buf.append("null");
/*      */       } 
/*      */       
/* 1177 */       if (i < obj.length - 1) {
/* 1178 */         buf.append(", ");
/*      */       }
/*      */     } 
/*      */     
/* 1182 */     if (braces) {
/* 1183 */       buf.append('}');
/*      */     }
/* 1185 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJavaIdentifierPart(char ch) {
/* 1191 */     if ((ch < 'a' || ch > 'z') && (
/* 1192 */       ch < 'A' || ch > 'Z') && (
/* 1193 */       ch < '0' || ch > '9') && 
/* 1194 */       ch != '_') return false;
/*      */     
/*      */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encode(byte[] bytes, boolean compress) throws IOException {
/* 1214 */     if (compress) {
/* 1215 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1216 */       GZIPOutputStream gos = new GZIPOutputStream(baos);
/*      */       
/* 1218 */       gos.write(bytes, 0, bytes.length);
/* 1219 */       gos.close();
/* 1220 */       baos.close();
/*      */       
/* 1222 */       bytes = baos.toByteArray();
/*      */     } 
/*      */     
/* 1225 */     CharArrayWriter caw = new CharArrayWriter();
/* 1226 */     JavaWriter jw = new JavaWriter(caw);
/*      */     
/* 1228 */     for (int i = 0; i < bytes.length; i++) {
/* 1229 */       int in = bytes[i] & 0xFF;
/* 1230 */       jw.write(in);
/*      */     } 
/*      */     
/* 1233 */     return caw.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] decode(String s, boolean uncompress) throws IOException {
/* 1242 */     char[] chars = s.toCharArray();
/*      */     
/* 1244 */     CharArrayReader car = new CharArrayReader(chars);
/* 1245 */     JavaReader jr = new JavaReader(car);
/*      */     
/* 1247 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*      */     
/*      */     int ch;
/*      */     
/* 1251 */     while ((ch = jr.read()) >= 0) {
/* 1252 */       bos.write(ch);
/*      */     }
/*      */     
/* 1255 */     bos.close();
/* 1256 */     car.close();
/* 1257 */     jr.close();
/*      */     
/* 1259 */     byte[] bytes = bos.toByteArray();
/*      */     
/* 1261 */     if (uncompress) {
/* 1262 */       GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(bytes));
/*      */       
/* 1264 */       byte[] tmp = new byte[bytes.length * 3];
/* 1265 */       int count = 0;
/*      */       
/*      */       int b;
/* 1268 */       while ((b = gis.read()) >= 0) {
/* 1269 */         tmp[count++] = (byte)b;
/*      */       }
/* 1271 */       bytes = new byte[count];
/* 1272 */       System.arraycopy(tmp, 0, bytes, 0, count);
/*      */     } 
/*      */     
/* 1275 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1280 */   private static int[] CHAR_MAP = new int[48];
/* 1281 */   private static int[] MAP_CHAR = new int[256];
/*      */   private static final char ESCAPE_CHAR = '$';
/*      */   
/*      */   static  {
/* 1285 */     j = 0; int k = 0;
/* 1286 */     for (int i = 65; i <= 90; i++) {
/* 1287 */       CHAR_MAP[j] = i;
/* 1288 */       MAP_CHAR[i] = j;
/* 1289 */       j++;
/*      */     } 
/*      */     
/* 1292 */     for (int i = 103; i <= 122; i++) {
/* 1293 */       CHAR_MAP[j] = i;
/* 1294 */       MAP_CHAR[i] = j;
/* 1295 */       j++;
/*      */     } 
/*      */     
/* 1298 */     CHAR_MAP[j] = 36;
/* 1299 */     MAP_CHAR[36] = j;
/* 1300 */     j++;
/*      */     
/* 1302 */     CHAR_MAP[j] = 95;
/* 1303 */     MAP_CHAR[95] = j;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class JavaReader
/*      */     extends FilterReader
/*      */   {
/* 1311 */     public JavaReader(Reader in) { super(in); }
/*      */ 
/*      */     
/*      */     public int read() throws IOException {
/* 1315 */       int b = this.in.read();
/*      */       
/* 1317 */       if (b != 36) {
/* 1318 */         return b;
/*      */       }
/* 1320 */       int i = this.in.read();
/*      */       
/* 1322 */       if (i < 0) {
/* 1323 */         return -1;
/*      */       }
/* 1325 */       if ((i >= 48 && i <= 57) || (i >= 97 && i <= 102)) {
/* 1326 */         int j = this.in.read();
/*      */         
/* 1328 */         if (j < 0) {
/* 1329 */           return -1;
/*      */         }
/* 1331 */         char[] tmp = { (char)i, (char)j };
/* 1332 */         return Integer.parseInt(new String(tmp), 16);
/*      */       } 
/*      */ 
/*      */       
/* 1336 */       return MAP_CHAR[i];
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int read(char[] cbuf, int off, int len) throws IOException {
/* 1342 */       for (int i = 0; i < len; i++) {
/* 1343 */         cbuf[off + i] = (char)read();
/*      */       }
/* 1345 */       return len;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class JavaWriter
/*      */     extends FilterWriter
/*      */   {
/* 1354 */     public JavaWriter(Writer out) { super(out); }
/*      */ 
/*      */     
/*      */     public void write(int b) throws IOException {
/* 1358 */       if (Utility.isJavaIdentifierPart((char)b) && b != 36) {
/* 1359 */         this.out.write(b);
/*      */       } else {
/* 1361 */         this.out.write(36);
/*      */ 
/*      */         
/* 1364 */         if (b >= 0 && b < 48) {
/* 1365 */           this.out.write(CHAR_MAP[b]);
/*      */         } else {
/* 1367 */           char[] tmp = Integer.toHexString(b).toCharArray();
/*      */           
/* 1369 */           if (tmp.length == 1) {
/* 1370 */             this.out.write(48);
/* 1371 */             this.out.write(tmp[0]);
/*      */           } else {
/* 1373 */             this.out.write(tmp[0]);
/* 1374 */             this.out.write(tmp[1]);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public void write(char[] cbuf, int off, int len) throws IOException {
/* 1381 */       for (int i = 0; i < len; i++) {
/* 1382 */         write(cbuf[off + i]);
/*      */       }
/*      */     }
/*      */     
/* 1386 */     public void write(String str, int off, int len) throws IOException { write(str.toCharArray(), off, len); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String convertString(String label) {
/* 1394 */     char[] ch = label.toCharArray();
/* 1395 */     StringBuffer buf = new StringBuffer();
/*      */     
/* 1397 */     for (int i = 0; i < ch.length; i++) {
/* 1398 */       switch (ch[i]) {
/*      */         case '\n':
/* 1400 */           buf.append("\\n"); break;
/*      */         case '\r':
/* 1402 */           buf.append("\\r"); break;
/*      */         case '"':
/* 1404 */           buf.append("\\\""); break;
/*      */         case '\'':
/* 1406 */           buf.append("\\'"); break;
/*      */         case '\\':
/* 1408 */           buf.append("\\\\"); break;
/*      */         default:
/* 1410 */           buf.append(ch[i]);
/*      */           break;
/*      */       } 
/*      */     } 
/* 1414 */     return buf.toString();
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Utility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */