/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CodeException
/*     */   implements Cloneable, Constants, Node, Serializable
/*     */ {
/*     */   private int start_pc;
/*     */   private int end_pc;
/*     */   private int handler_pc;
/*     */   private int catch_type;
/*     */   
/*  85 */   public CodeException(CodeException c) { this(c.getStartPC(), c.getEndPC(), c.getHandlerPC(), c.getCatchType()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   CodeException(DataInputStream file) throws IOException { this(file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort(), file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeException(int start_pc, int end_pc, int handler_pc, int catch_type) {
/* 112 */     this.start_pc = start_pc;
/* 113 */     this.end_pc = end_pc;
/* 114 */     this.handler_pc = handler_pc;
/* 115 */     this.catch_type = catch_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void accept(Visitor v) { v.visitCodeException(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 136 */     file.writeShort(this.start_pc);
/* 137 */     file.writeShort(this.end_pc);
/* 138 */     file.writeShort(this.handler_pc);
/* 139 */     file.writeShort(this.catch_type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public final int getCatchType() { return this.catch_type; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public final int getEndPC() { return this.end_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public final int getHandlerPC() { return this.handler_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public final int getStartPC() { return this.start_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public final void setCatchType(int catch_type) { this.catch_type = catch_type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public final void setEndPC(int end_pc) { this.end_pc = end_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   public final void setHandlerPC(int handler_pc) { this.handler_pc = handler_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public final void setStartPC(int start_pc) { this.start_pc = start_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 195 */     return "CodeException(start_pc = " + this.start_pc + 
/* 196 */       ", end_pc = " + this.end_pc + 
/* 197 */       ", handler_pc = " + this.handler_pc + ", catch_type = " + this.catch_type + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(ConstantPool cp, boolean verbose) {
/*     */     String str;
/* 206 */     if (this.catch_type == 0) {
/* 207 */       str = "<Any exception>(0)";
/*     */     } else {
/* 209 */       str = String.valueOf(Utility.compactClassName(cp.getConstantString(this.catch_type, (byte)7), false)) + (
/* 210 */         verbose ? ("(" + this.catch_type + ")") : "");
/*     */     } 
/* 212 */     return String.valueOf(this.start_pc) + "\t" + this.end_pc + "\t" + this.handler_pc + "\t" + str;
/*     */   }
/*     */ 
/*     */   
/* 216 */   public final String toString(ConstantPool cp) { return toString(cp, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeException copy() {
/*     */     try {
/* 224 */       return (CodeException)clone();
/* 225 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 227 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\CodeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */