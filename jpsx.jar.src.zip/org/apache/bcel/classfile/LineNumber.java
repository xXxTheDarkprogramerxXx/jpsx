/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LineNumber
/*     */   implements Cloneable, Node, Serializable
/*     */ {
/*     */   private int start_pc;
/*     */   private int line_number;
/*     */   
/*  77 */   public LineNumber(LineNumber c) { this(c.getStartPC(), c.getLineNumber()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   LineNumber(DataInputStream file) throws IOException { this(file.readUnsignedShort(), file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumber(int start_pc, int line_number) {
/*  96 */     this.start_pc = start_pc;
/*  97 */     this.line_number = line_number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void accept(Visitor v) { v.visitLineNumber(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 119 */     file.writeShort(this.start_pc);
/* 120 */     file.writeShort(this.line_number);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public final int getLineNumber() { return this.line_number; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public final int getStartPC() { return this.start_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public final void setLineNumber(int line_number) { this.line_number = line_number; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public final void setStartPC(int start_pc) { this.start_pc = start_pc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public final String toString() { return "LineNumber(" + this.start_pc + ", " + this.line_number + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumber copy() {
/*     */     try {
/* 159 */       return (LineNumber)clone();
/* 160 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 162 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\LineNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */