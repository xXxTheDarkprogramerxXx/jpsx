/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Signature
/*     */   extends Attribute
/*     */ {
/*     */   private int signature_index;
/*     */   
/*  76 */   public Signature(Signature c) { this(c.getNameIndex(), c.getLength(), c.getSignatureIndex(), c.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   Signature(int name_index, int length, DataInputStream file, ConstantPool constant_pool) throws IOException { this(name_index, length, file.readUnsignedShort(), constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Signature(int name_index, int length, int signature_index, ConstantPool constant_pool) {
/* 102 */     super((byte)10, name_index, length, constant_pool);
/* 103 */     this.signature_index = signature_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 114 */     System.err.println("Visiting non-standard Signature object");
/* 115 */     v.visitSignature(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 126 */     super.dump(file);
/* 127 */     file.writeShort(this.signature_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public final int getSignatureIndex() { return this.signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public final void setSignatureIndex(int signature_index) { this.signature_index = signature_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSignature() {
/* 146 */     ConstantUtf8 c = (ConstantUtf8)this.constant_pool.getConstant(this.signature_index, (byte)
/* 147 */         1);
/* 148 */     return c.getBytes();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MyByteArrayInputStream
/*     */     extends ByteArrayInputStream
/*     */   {
/* 155 */     MyByteArrayInputStream(String data) { super(data.getBytes()); }
/* 156 */     final int mark() { return this.pos; }
/* 157 */     final String getData() { return new String(this.buf); }
/* 158 */     final void reset(int p) { this.pos = p; }
/* 159 */     final void unread() { if (this.pos > 0) this.pos--;
/*     */        }
/*     */   }
/*     */   
/* 163 */   private static boolean identStart(int ch) { return !(ch != 84 && ch != 76); }
/*     */ 
/*     */ 
/*     */   
/* 167 */   private static boolean identPart(int ch) { return !(ch != 47 && ch != 59); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void matchIdent(MyByteArrayInputStream in, StringBuffer buf) {
/*     */     int ch;
/* 173 */     if ((ch = in.read()) == -1) {
/* 174 */       throw new RuntimeException("Illegal signature: " + in.getData() + 
/* 175 */           " no ident, reaching EOF");
/*     */     }
/*     */ 
/*     */     
/* 179 */     if (!identStart(ch)) {
/* 180 */       StringBuffer buf2 = new StringBuffer();
/*     */       
/* 182 */       int count = 1;
/* 183 */       while (Character.isJavaIdentifierPart((char)ch)) {
/* 184 */         buf2.append((char)ch);
/* 185 */         count++;
/* 186 */         ch = in.read();
/*     */       } 
/*     */       
/* 189 */       if (ch == 58) {
/* 190 */         in.skip("Ljava/lang/Object".length());
/* 191 */         buf.append(buf2);
/*     */         
/* 193 */         ch = in.read();
/* 194 */         in.unread();
/*     */       } else {
/*     */         
/* 197 */         for (int i = 0; i < count; i++) {
/* 198 */           in.unread();
/*     */         }
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 204 */     StringBuffer buf2 = new StringBuffer();
/* 205 */     ch = in.read();
/*     */     
/*     */     do {
/* 208 */       buf2.append((char)ch);
/* 209 */       ch = in.read();
/*     */     
/*     */     }
/* 212 */     while (ch != -1 && (Character.isJavaIdentifierPart((char)ch) || ch == 47));
/*     */     
/* 214 */     buf.append(buf2.toString().replace('/', '.'));
/*     */ 
/*     */ 
/*     */     
/* 218 */     if (ch != -1) {
/* 219 */       in.unread();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void matchGJIdent(MyByteArrayInputStream in, StringBuffer buf) {
/* 227 */     matchIdent(in, buf);
/*     */     
/* 229 */     int ch = in.read();
/* 230 */     if (ch == 60 || ch == 40) {
/*     */       
/* 232 */       buf.append((char)ch);
/* 233 */       matchGJIdent(in, buf);
/*     */       
/* 235 */       while ((ch = in.read()) != 62 && ch != 41) {
/* 236 */         if (ch == -1) {
/* 237 */           throw new RuntimeException("Illegal signature: " + in.getData() + 
/* 238 */               " reaching EOF");
/*     */         }
/*     */         
/* 241 */         buf.append(", ");
/* 242 */         in.unread();
/* 243 */         matchGJIdent(in, buf);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 248 */       buf.append((char)ch);
/*     */     } else {
/* 250 */       in.unread();
/*     */     } 
/* 252 */     ch = in.read();
/* 253 */     if (identStart(ch))
/* 254 */     { in.unread();
/* 255 */       matchGJIdent(in, buf); }
/* 256 */     else { if (ch == 41) {
/* 257 */         in.unread(); return;
/*     */       } 
/* 259 */       if (ch != 59)
/* 260 */         throw new RuntimeException("Illegal signature: " + in.getData() + " read " + 
/* 261 */             (char)ch);  }
/*     */   
/*     */   }
/*     */   
/*     */   public static String translate(String s) {
/* 266 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 268 */     matchGJIdent(new MyByteArrayInputStream(s), buf);
/*     */     
/* 270 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/* 274 */   public static final boolean isFormalParameterList(String s) { return (s.startsWith("<") && s.indexOf(':') > 0); }
/*     */ 
/*     */ 
/*     */   
/* 278 */   public static final boolean isActualParameterList(String s) { return (s.startsWith("L") && s.endsWith(">;")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 285 */     String s = getSignature();
/*     */     
/* 287 */     return "Signature(" + s + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 294 */   public Attribute copy(ConstantPool constant_pool) { return (Signature)clone(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Signature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */