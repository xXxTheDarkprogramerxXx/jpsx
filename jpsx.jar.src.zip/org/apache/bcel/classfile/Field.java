/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Field
/*     */   extends FieldOrMethod
/*     */ {
/*  73 */   public Field(Field c) { super(c); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   Field(DataInputStream file, ConstantPool constant_pool) throws IOException, ClassFormatException { super(file, constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public Field(int access_flags, int name_index, int signature_index, Attribute[] attributes, ConstantPool constant_pool) { super(access_flags, name_index, signature_index, attributes, constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void accept(Visitor v) { v.visitField(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConstantValue getConstantValue() {
/* 114 */     for (int i = 0; i < this.attributes_count; i++) {
/* 115 */       if (this.attributes[i].getTag() == 1)
/* 116 */         return (ConstantValue)this.attributes[i]; 
/*     */     } 
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 131 */     String access = Utility.accessToString(this.access_flags);
/* 132 */     access = access.equals("") ? "" : (String.valueOf(access) + " ");
/* 133 */     String signature = Utility.signatureToString(getSignature());
/* 134 */     String name = getName();
/*     */     
/* 136 */     StringBuffer buf = new StringBuffer(String.valueOf(access) + signature + " " + name);
/* 137 */     ConstantValue cv = getConstantValue();
/*     */     
/* 139 */     if (cv != null) {
/* 140 */       buf.append(" = " + cv);
/*     */     }
/* 142 */     for (int i = 0; i < this.attributes_count; i++) {
/* 143 */       Attribute a = this.attributes[i];
/*     */       
/* 145 */       if (!(a instanceof ConstantValue)) {
/* 146 */         buf.append(" [" + a.toString() + "]");
/*     */       }
/*     */     } 
/* 149 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public final Field copy(ConstantPool constant_pool) { return (Field)copy_(constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public Type getType() { return Type.getReturnType(getSignature()); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\Field.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */