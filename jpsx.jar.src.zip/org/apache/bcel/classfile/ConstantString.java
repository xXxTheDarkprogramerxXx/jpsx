/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantString
/*     */   extends Constant
/*     */   implements ConstantObject
/*     */ {
/*     */   private int string_index;
/*     */   
/*  76 */   public ConstantString(ConstantString c) { this(c.getStringIndex()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   ConstantString(DataInputStream file) throws IOException { this(file.readUnsignedShort()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantString(int string_index) {
/*  93 */     super((byte)8);
/*  94 */     this.string_index = string_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void accept(Visitor v) { v.visitConstantString(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void dump(DataOutputStream file) throws IOException {
/* 114 */     file.writeByte(this.tag);
/* 115 */     file.writeShort(this.string_index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 120 */   public final int getStringIndex() { return this.string_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public final void setStringIndex(int string_index) { this.string_index = string_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public final String toString() { return String.valueOf(super.toString()) + "(string_index = " + this.string_index + ")"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getConstantValue(ConstantPool cp) {
/* 138 */     Constant c = cp.getConstant(this.string_index, (byte)1);
/* 139 */     return ((ConstantUtf8)c).getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public String getBytes(ConstantPool cp) { return (String)getConstantValue(cp); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */