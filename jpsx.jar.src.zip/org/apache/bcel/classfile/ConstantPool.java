/*     */ package org.apache.bcel.classfile;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.apache.bcel.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantPool
/*     */   implements Cloneable, Node, Serializable
/*     */ {
/*     */   private int constant_pool_count;
/*     */   private Constant[] constant_pool;
/*     */   
/*  82 */   public ConstantPool(Constant[] constant_pool) { setConstantPool(constant_pool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConstantPool(DataInputStream file) throws IOException, ClassFormatException {
/*  96 */     this.constant_pool_count = file.readUnsignedShort();
/*  97 */     this.constant_pool = new Constant[this.constant_pool_count];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     for (int i = 1; i < this.constant_pool_count; i++) {
/* 103 */       this.constant_pool[i] = Constant.readConstant(file);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       byte tag = this.constant_pool[i].getTag();
/* 113 */       if (tag == 6 || tag == 5) {
/* 114 */         i++;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void accept(Visitor v) { v.visitConstantPool(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String constantToString(Constant c) throws ClassFormatException { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokevirtual getTag : ()B
/*     */     //   4: istore #4
/*     */     //   6: iload #4
/*     */     //   8: tableswitch default -> 358, 1 -> 151, 2 -> 358, 3 -> 234, 4 -> 186, 5 -> 210, 6 -> 162, 7 -> 72, 8 -> 102, 9 -> 307, 10 -> 307, 11 -> 307, 12 -> 258
/*     */     //   72: aload_1
/*     */     //   73: checkcast org/apache/bcel/classfile/ConstantClass
/*     */     //   76: invokevirtual getNameIndex : ()I
/*     */     //   79: istore_3
/*     */     //   80: aload_0
/*     */     //   81: iload_3
/*     */     //   82: iconst_1
/*     */     //   83: invokevirtual getConstant : (IB)Lorg/apache/bcel/classfile/Constant;
/*     */     //   86: astore_1
/*     */     //   87: aload_1
/*     */     //   88: checkcast org/apache/bcel/classfile/ConstantUtf8
/*     */     //   91: invokevirtual getBytes : ()Ljava/lang/String;
/*     */     //   94: iconst_0
/*     */     //   95: invokestatic compactClassName : (Ljava/lang/String;Z)Ljava/lang/String;
/*     */     //   98: astore_2
/*     */     //   99: goto -> 383
/*     */     //   102: aload_1
/*     */     //   103: checkcast org/apache/bcel/classfile/ConstantString
/*     */     //   106: invokevirtual getStringIndex : ()I
/*     */     //   109: istore_3
/*     */     //   110: aload_0
/*     */     //   111: iload_3
/*     */     //   112: iconst_1
/*     */     //   113: invokevirtual getConstant : (IB)Lorg/apache/bcel/classfile/Constant;
/*     */     //   116: astore_1
/*     */     //   117: new java/lang/StringBuilder
/*     */     //   120: dup
/*     */     //   121: ldc '"'
/*     */     //   123: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   126: aload_1
/*     */     //   127: checkcast org/apache/bcel/classfile/ConstantUtf8
/*     */     //   130: invokevirtual getBytes : ()Ljava/lang/String;
/*     */     //   133: invokestatic escape : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   139: ldc '"'
/*     */     //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   144: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   147: astore_2
/*     */     //   148: goto -> 383
/*     */     //   151: aload_1
/*     */     //   152: checkcast org/apache/bcel/classfile/ConstantUtf8
/*     */     //   155: invokevirtual getBytes : ()Ljava/lang/String;
/*     */     //   158: astore_2
/*     */     //   159: goto -> 383
/*     */     //   162: new java/lang/StringBuilder
/*     */     //   165: dup
/*     */     //   166: invokespecial <init> : ()V
/*     */     //   169: aload_1
/*     */     //   170: checkcast org/apache/bcel/classfile/ConstantDouble
/*     */     //   173: invokevirtual getBytes : ()D
/*     */     //   176: invokevirtual append : (D)Ljava/lang/StringBuilder;
/*     */     //   179: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   182: astore_2
/*     */     //   183: goto -> 383
/*     */     //   186: new java/lang/StringBuilder
/*     */     //   189: dup
/*     */     //   190: invokespecial <init> : ()V
/*     */     //   193: aload_1
/*     */     //   194: checkcast org/apache/bcel/classfile/ConstantFloat
/*     */     //   197: invokevirtual getBytes : ()F
/*     */     //   200: invokevirtual append : (F)Ljava/lang/StringBuilder;
/*     */     //   203: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   206: astore_2
/*     */     //   207: goto -> 383
/*     */     //   210: new java/lang/StringBuilder
/*     */     //   213: dup
/*     */     //   214: invokespecial <init> : ()V
/*     */     //   217: aload_1
/*     */     //   218: checkcast org/apache/bcel/classfile/ConstantLong
/*     */     //   221: invokevirtual getBytes : ()J
/*     */     //   224: invokevirtual append : (J)Ljava/lang/StringBuilder;
/*     */     //   227: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   230: astore_2
/*     */     //   231: goto -> 383
/*     */     //   234: new java/lang/StringBuilder
/*     */     //   237: dup
/*     */     //   238: invokespecial <init> : ()V
/*     */     //   241: aload_1
/*     */     //   242: checkcast org/apache/bcel/classfile/ConstantInteger
/*     */     //   245: invokevirtual getBytes : ()I
/*     */     //   248: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   251: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   254: astore_2
/*     */     //   255: goto -> 383
/*     */     //   258: new java/lang/StringBuilder
/*     */     //   261: dup
/*     */     //   262: aload_0
/*     */     //   263: aload_1
/*     */     //   264: checkcast org/apache/bcel/classfile/ConstantNameAndType
/*     */     //   267: invokevirtual getNameIndex : ()I
/*     */     //   270: iconst_1
/*     */     //   271: invokevirtual constantToString : (IB)Ljava/lang/String;
/*     */     //   274: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   277: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   280: ldc ' '
/*     */     //   282: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   285: aload_0
/*     */     //   286: aload_1
/*     */     //   287: checkcast org/apache/bcel/classfile/ConstantNameAndType
/*     */     //   290: invokevirtual getSignatureIndex : ()I
/*     */     //   293: iconst_1
/*     */     //   294: invokevirtual constantToString : (IB)Ljava/lang/String;
/*     */     //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   300: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   303: astore_2
/*     */     //   304: goto -> 383
/*     */     //   307: new java/lang/StringBuilder
/*     */     //   310: dup
/*     */     //   311: aload_0
/*     */     //   312: aload_1
/*     */     //   313: checkcast org/apache/bcel/classfile/ConstantCP
/*     */     //   316: invokevirtual getClassIndex : ()I
/*     */     //   319: bipush #7
/*     */     //   321: invokevirtual constantToString : (IB)Ljava/lang/String;
/*     */     //   324: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   327: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   330: ldc '.'
/*     */     //   332: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   335: aload_0
/*     */     //   336: aload_1
/*     */     //   337: checkcast org/apache/bcel/classfile/ConstantCP
/*     */     //   340: invokevirtual getNameAndTypeIndex : ()I
/*     */     //   343: bipush #12
/*     */     //   345: invokevirtual constantToString : (IB)Ljava/lang/String;
/*     */     //   348: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   351: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   354: astore_2
/*     */     //   355: goto -> 383
/*     */     //   358: new java/lang/RuntimeException
/*     */     //   361: dup
/*     */     //   362: new java/lang/StringBuilder
/*     */     //   365: dup
/*     */     //   366: ldc 'Unknown constant type '
/*     */     //   368: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   371: iload #4
/*     */     //   373: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   376: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   379: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   382: athrow
/*     */     //   383: aload_2
/*     */     //   384: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     //   #142	-> 6
/*     */     //   #144	-> 72
/*     */     //   #145	-> 80
/*     */     //   #146	-> 87
/*     */     //   #147	-> 99
/*     */     //   #150	-> 102
/*     */     //   #151	-> 110
/*     */     //   #152	-> 117
/*     */     //   #153	-> 148
/*     */     //   #155	-> 151
/*     */     //   #156	-> 162
/*     */     //   #157	-> 186
/*     */     //   #158	-> 210
/*     */     //   #159	-> 234
/*     */     //   #162	-> 258
/*     */     //   #162	-> 262
/*     */     //   #163	-> 270
/*     */     //   #164	-> 285
/*     */     //   #165	-> 293
/*     */     //   #164	-> 294
/*     */     //   #162	-> 300
/*     */     //   #166	-> 304
/*     */     //   #170	-> 307
/*     */     //   #170	-> 311
/*     */     //   #171	-> 319
/*     */     //   #172	-> 335
/*     */     //   #173	-> 343
/*     */     //   #172	-> 345
/*     */     //   #170	-> 351
/*     */     //   #174	-> 355
/*     */     //   #177	-> 358
/*     */     //   #180	-> 383
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	385	0	this	Lorg/apache/bcel/classfile/ConstantPool;
/*     */     //   0	385	1	c	Lorg/apache/bcel/classfile/Constant;
/*     */     //   99	3	2	str	Ljava/lang/String;
/*     */     //   148	3	2	str	Ljava/lang/String;
/*     */     //   159	3	2	str	Ljava/lang/String;
/*     */     //   183	3	2	str	Ljava/lang/String;
/*     */     //   207	3	2	str	Ljava/lang/String;
/*     */     //   231	3	2	str	Ljava/lang/String;
/*     */     //   255	3	2	str	Ljava/lang/String;
/*     */     //   304	3	2	str	Ljava/lang/String;
/*     */     //   355	3	2	str	Ljava/lang/String;
/*     */     //   383	2	2	str	Ljava/lang/String;
/*     */     //   80	22	3	i	I
/*     */     //   110	41	3	i	I
/*     */     //   6	379	4	tag	B }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String escape(String str) {
/* 184 */     int len = str.length();
/* 185 */     StringBuffer buf = new StringBuffer(len + 5);
/* 186 */     char[] ch = str.toCharArray();
/*     */     
/* 188 */     for (int i = 0; i < len; i++) {
/* 189 */       switch (ch[i]) { case '\n':
/* 190 */           buf.append("\\n"); break;
/* 191 */         case '\r': buf.append("\\r"); break;
/* 192 */         case '\t': buf.append("\\t"); break;
/* 193 */         case '\b': buf.append("\\b"); break;
/* 194 */         case '"': buf.append("\\\""); break;
/* 195 */         default: buf.append(ch[i]);
/*     */           break; }
/*     */     
/*     */     } 
/* 199 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String constantToString(int index, byte tag) throws ClassFormatException {
/* 214 */     Constant c = getConstant(index, tag);
/* 215 */     return constantToString(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream file) throws IOException {
/* 226 */     file.writeShort(this.constant_pool_count);
/*     */     
/* 228 */     for (int i = 1; i < this.constant_pool_count; i++) {
/* 229 */       if (this.constant_pool[i] != null) {
/* 230 */         this.constant_pool[i].dump(file);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant getConstant(int index) {
/* 241 */     if (index >= this.constant_pool.length || index < 0)
/* 242 */       throw new ClassFormatException("Invalid constant pool reference: " + 
/* 243 */           index + ". Constant pool size is: " + 
/* 244 */           this.constant_pool.length); 
/* 245 */     return this.constant_pool[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant getConstant(int index, byte tag) throws ClassFormatException {
/* 263 */     Constant c = getConstant(index);
/*     */     
/* 265 */     if (c == null) {
/* 266 */       throw new ClassFormatException("Constant pool at index " + index + " is null.");
/*     */     }
/* 268 */     if (c.getTag() == tag) {
/* 269 */       return c;
/*     */     }
/* 271 */     throw new ClassFormatException("Expected class `" + Constants.CONSTANT_NAMES[tag] + 
/* 272 */         "' at index " + index + " and got " + c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public Constant[] getConstantPool() { return this.constant_pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConstantString(int index, byte tag) throws ClassFormatException {
/*     */     int i, i;
/* 299 */     Constant c = getConstant(index, tag);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     switch (tag) { case 7:
/* 309 */         i = ((ConstantClass)c).getNameIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 316 */         c = getConstant(i, (byte)1);
/* 317 */         return ((ConstantUtf8)c).getBytes();case 8: i = ((ConstantString)c).getStringIndex(); c = getConstant(i, (byte)1); return ((ConstantUtf8)c).getBytes(); }
/*     */     
/*     */     throw new RuntimeException("getConstantString called with illegal tag " + tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 324 */   public int getLength() { return this.constant_pool_count; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public void setConstant(int index, Constant constant) { this.constant_pool[index] = constant; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConstantPool(Constant[] constant_pool) {
/* 338 */     this.constant_pool = constant_pool;
/* 339 */     this.constant_pool_count = (constant_pool == null) ? 0 : constant_pool.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 345 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 347 */     for (int i = 1; i < this.constant_pool_count; i++) {
/* 348 */       buf.append(String.valueOf(i) + ")" + this.constant_pool[i] + "\n");
/*     */     }
/* 350 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantPool copy() {
/* 357 */     ConstantPool c = null;
/*     */     
/*     */     try {
/* 360 */       c = (ConstantPool)clone();
/* 361 */     } catch (CloneNotSupportedException cloneNotSupportedException) {}
/*     */     
/* 363 */     c.constant_pool = new Constant[this.constant_pool_count];
/*     */     
/* 365 */     for (int i = 1; i < this.constant_pool_count; i++) {
/* 366 */       if (this.constant_pool[i] != null) {
/* 367 */         c.constant_pool[i] = this.constant_pool[i].copy();
/*     */       }
/*     */     } 
/* 370 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\classfile\ConstantPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */