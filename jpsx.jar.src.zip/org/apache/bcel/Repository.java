/*     */ package org.apache.bcel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.util.ClassPath;
/*     */ import org.apache.bcel.util.Repository;
/*     */ import org.apache.bcel.util.SyntheticRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Repository
/*     */ {
/*  74 */   private static Repository _repository = SyntheticRepository.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static Repository getRepository() { return _repository; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static void setRepository(Repository rep) { _repository = rep; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClass lookupClass(String class_name) {
/*     */     try {
/*  96 */       JavaClass clazz = _repository.findClass(class_name);
/*     */       
/*  98 */       if (clazz == null) {
/*  99 */         return _repository.loadClass(class_name);
/*     */       }
/* 101 */       return clazz;
/*     */     } catch (ClassNotFoundException ex) {
/* 103 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClass lookupClass(Class clazz) {
/*     */     
/* 113 */     try { return _repository.loadClass(clazz); }
/* 114 */     catch (ClassNotFoundException ex) { return null; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static ClassPath.ClassFile lookupClassFile(String class_name) {
/*     */     
/* 121 */     try { return ClassPath.SYSTEM_CLASS_PATH.getClassFile(class_name); }
/* 122 */     catch (IOException e) { return null; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 128 */   public static void clearCache() { _repository.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClass addClass(JavaClass clazz) {
/* 137 */     JavaClass old = _repository.findClass(clazz.getClassName());
/* 138 */     _repository.storeClass(clazz);
/* 139 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public static void removeClass(String clazz) { _repository.removeClass(_repository.findClass(clazz)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public static void removeClass(JavaClass clazz) { _repository.removeClass(clazz); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public static JavaClass[] getSuperClasses(JavaClass clazz) { return clazz.getSuperClasses(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClass[] getSuperClasses(String class_name) {
/* 170 */     JavaClass jc = lookupClass(class_name);
/* 171 */     return (jc == null) ? null : getSuperClasses(jc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public static JavaClass[] getInterfaces(JavaClass clazz) { return clazz.getAllInterfaces(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public static JavaClass[] getInterfaces(String class_name) { return getInterfaces(lookupClass(class_name)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public static boolean instanceOf(JavaClass clazz, JavaClass super_class) { return clazz.instanceOf(super_class); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public static boolean instanceOf(String clazz, String super_class) { return instanceOf(lookupClass(clazz), lookupClass(super_class)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public static boolean instanceOf(JavaClass clazz, String super_class) { return instanceOf(clazz, lookupClass(super_class)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public static boolean instanceOf(String clazz, JavaClass super_class) { return instanceOf(lookupClass(clazz), super_class); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public static boolean implementationOf(JavaClass clazz, JavaClass inter) { return clazz.implementationOf(inter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public static boolean implementationOf(String clazz, String inter) { return implementationOf(lookupClass(clazz), lookupClass(inter)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public static boolean implementationOf(JavaClass clazz, String inter) { return implementationOf(clazz, lookupClass(inter)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public static boolean implementationOf(String clazz, JavaClass inter) { return implementationOf(lookupClass(clazz), inter); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\Repository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */