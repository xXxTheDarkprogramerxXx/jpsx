package org.apache.bcel.verifier.exc;

public class LinkingConstraintException extends StructuralCodeConstraintException {}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\exc\LinkingConstraintException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */