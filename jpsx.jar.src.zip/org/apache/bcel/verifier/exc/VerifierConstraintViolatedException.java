/*     */ package org.apache.bcel.verifier.exc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VerifierConstraintViolatedException
/*     */   extends RuntimeException
/*     */ {
/*     */   private String detailMessage;
/*     */   
/*     */   VerifierConstraintViolatedException() {}
/*     */   
/*     */   VerifierConstraintViolatedException(String message) {
/*  84 */     super(message);
/*  85 */     this.detailMessage = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extendMessage(String pre, String post) {
/*  95 */     if (pre == null) pre = ""; 
/*  96 */     if (this.detailMessage == null) this.detailMessage = ""; 
/*  97 */     if (post == null) post = ""; 
/*  98 */     this.detailMessage = String.valueOf(pre) + this.detailMessage + post;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public String getMessage() { return this.detailMessage; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\exc\VerifierConstraintViolatedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */