/*     */ package org.apache.bcel.verifier.exc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AssertionViolatedException
/*     */   extends RuntimeException
/*     */ {
/*     */   private String detailMessage;
/*     */   
/*     */   public AssertionViolatedException() {}
/*     */   
/*     */   public AssertionViolatedException(String message) {
/*  76 */     super(message = "INTERNAL ERROR: " + message);
/*  77 */     this.detailMessage = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extendMessage(String pre, String post) {
/*  85 */     if (pre == null) pre = ""; 
/*  86 */     if (this.detailMessage == null) this.detailMessage = ""; 
/*  87 */     if (post == null) post = ""; 
/*  88 */     this.detailMessage = String.valueOf(pre) + this.detailMessage + post;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public String getMessage() { return this.detailMessage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 102 */     AssertionViolatedException ave = new AssertionViolatedException("Oops!");
/* 103 */     ave.extendMessage("\nFOUND:\n\t", "\nExiting!!\n");
/* 104 */     throw ave;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\exc\AssertionViolatedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */