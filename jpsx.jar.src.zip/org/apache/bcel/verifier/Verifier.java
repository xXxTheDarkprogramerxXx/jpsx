/*     */ package org.apache.bcel.verifier;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.verifier.statics.Pass1Verifier;
/*     */ import org.apache.bcel.verifier.statics.Pass2Verifier;
/*     */ import org.apache.bcel.verifier.statics.Pass3aVerifier;
/*     */ import org.apache.bcel.verifier.structurals.Pass3bVerifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Verifier
/*     */ {
/*     */   private final String classname;
/*     */   private Pass1Verifier p1v;
/*     */   private Pass2Verifier p2v;
/*     */   private HashMap p3avs;
/*     */   private HashMap p3bvs;
/*     */   
/*     */   public VerificationResult doPass1() {
/*  98 */     if (this.p1v == null) {
/*  99 */       this.p1v = new Pass1Verifier(this);
/*     */     }
/* 101 */     return this.p1v.verify();
/*     */   }
/*     */ 
/*     */   
/*     */   public VerificationResult doPass2() {
/* 106 */     if (this.p2v == null) {
/* 107 */       this.p2v = new Pass2Verifier(this);
/*     */     }
/* 109 */     return this.p2v.verify();
/*     */   }
/*     */ 
/*     */   
/*     */   public VerificationResult doPass3a(int method_no) {
/* 114 */     String key = Integer.toString(method_no);
/*     */     
/* 116 */     Pass3aVerifier p3av = (Pass3aVerifier)this.p3avs.get(key);
/* 117 */     if (this.p3avs.get(key) == null) {
/* 118 */       p3av = new Pass3aVerifier(this, method_no);
/* 119 */       this.p3avs.put(key, p3av);
/*     */     } 
/* 121 */     return p3av.verify();
/*     */   }
/*     */ 
/*     */   
/*     */   public VerificationResult doPass3b(int method_no) {
/* 126 */     String key = Integer.toString(method_no);
/*     */     
/* 128 */     Pass3bVerifier p3bv = (Pass3bVerifier)this.p3bvs.get(key);
/* 129 */     if (this.p3bvs.get(key) == null) {
/* 130 */       p3bv = new Pass3bVerifier(this, method_no);
/* 131 */       this.p3bvs.put(key, p3bv);
/*     */     } 
/* 133 */     return p3bv.verify();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Verifier(String fully_qualified_classname) {
/*     */     this.p3avs = new HashMap();
/*     */     this.p3bvs = new HashMap();
/* 143 */     this.classname = fully_qualified_classname;
/* 144 */     flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public final String getClassName() { return this.classname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 165 */     this.p1v = null;
/* 166 */     this.p2v = null;
/* 167 */     this.p3avs.clear();
/* 168 */     this.p3bvs.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMessages() {
/* 176 */     ArrayList messages = new ArrayList();
/*     */     
/* 178 */     if (this.p1v != null) {
/* 179 */       String[] p1m = this.p1v.getMessages();
/* 180 */       for (int i = 0; i < p1m.length; i++) {
/* 181 */         messages.add("Pass 1: " + p1m[i]);
/*     */       }
/*     */     } 
/* 184 */     if (this.p2v != null) {
/* 185 */       String[] p2m = this.p2v.getMessages();
/* 186 */       for (int i = 0; i < p2m.length; i++) {
/* 187 */         messages.add("Pass 2: " + p2m[i]);
/*     */       }
/*     */     } 
/* 190 */     Iterator p3as = this.p3avs.values().iterator();
/* 191 */     while (p3as.hasNext()) {
/* 192 */       Pass3aVerifier pv = (Pass3aVerifier)p3as.next();
/* 193 */       String[] p3am = pv.getMessages();
/* 194 */       int meth = pv.getMethodNo();
/* 195 */       for (int i = 0; i < p3am.length; i++) {
/* 196 */         messages.add("Pass 3a, method " + meth + 
/* 197 */             " ('" + 
/*     */             
/* 199 */             Repository.lookupClass(this.classname)
/* 200 */             .getMethods()[meth] + 
/* 201 */             "'): " + p3am[i]);
/*     */       }
/*     */     } 
/* 204 */     Iterator p3bs = this.p3bvs.values().iterator();
/* 205 */     while (p3bs.hasNext()) {
/* 206 */       Pass3bVerifier pv = (Pass3bVerifier)p3bs.next();
/* 207 */       String[] p3bm = pv.getMessages();
/* 208 */       int meth = pv.getMethodNo();
/* 209 */       for (int i = 0; i < p3bm.length; i++) {
/* 210 */         messages.add("Pass 3b, method " + meth + 
/* 211 */             " ('" + 
/*     */             
/* 213 */             Repository.lookupClass(this.classname)
/* 214 */             .getMethods()[meth] + 
/* 215 */             "'): " + p3bm[i]);
/*     */       }
/*     */     } 
/*     */     
/* 219 */     String[] ret = new String[messages.size()];
/* 220 */     for (int i = 0; i < messages.size(); i++) {
/* 221 */       ret[i] = (String)messages.get(i);
/*     */     }
/*     */     
/* 224 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 238 */     System.out.println("JustIce by Enver Haase, (C) 2001-2002.\n<http://bcel.sourceforge.net>\n<http://jakarta.apache.org/bcel>\n");
/* 239 */     for (int k = 0; k < args.length; k++) {
/*     */       
/* 241 */       if (args[k].endsWith(".class")) {
/* 242 */         int dotclasspos = args[k].lastIndexOf(".class");
/* 243 */         if (dotclasspos != -1) args[k] = args[k].substring(0, dotclasspos);
/*     */       
/*     */       } 
/* 246 */       args[k] = args[k].replace('/', '.');
/*     */       
/* 248 */       System.out.println("Now verifying: " + args[k] + "\n");
/*     */       
/* 250 */       Verifier v = VerifierFactory.getVerifier(args[k]);
/*     */ 
/*     */       
/* 253 */       VerificationResult vr = v.doPass1();
/* 254 */       System.out.println("Pass 1:\n" + vr);
/*     */       
/* 256 */       vr = v.doPass2();
/* 257 */       System.out.println("Pass 2:\n" + vr);
/*     */       
/* 259 */       if (vr == VerificationResult.VR_OK) {
/* 260 */         JavaClass jc = 
/* 261 */           Repository.lookupClass(args[k]);
/* 262 */         for (int i = 0; i < jc.getMethods().length; i++) {
/* 263 */           vr = v.doPass3a(i);
/* 264 */           System.out.println("Pass 3a, method number " + i + " ['" + jc.getMethods()[i] + "']:\n" + vr);
/*     */           
/* 266 */           vr = v.doPass3b(i);
/* 267 */           System.out.println("Pass 3b, method number " + i + " ['" + jc.getMethods()[i] + "']:\n" + vr);
/*     */         } 
/*     */       } 
/*     */       
/* 271 */       System.out.println("Warnings:");
/* 272 */       String[] warnings = v.getMessages();
/* 273 */       if (warnings.length == 0) System.out.println("<none>"); 
/* 274 */       for (int j = 0; j < warnings.length; j++) {
/* 275 */         System.out.println(warnings[j]);
/*     */       }
/*     */       
/* 278 */       System.out.println("\n");
/*     */ 
/*     */       
/* 281 */       v.flush();
/* 282 */       Repository.clearCache();
/* 283 */       System.gc();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\Verifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */