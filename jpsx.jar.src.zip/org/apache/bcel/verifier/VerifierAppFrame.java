/*     */ package org.apache.bcel.verifier;
/*     */ 
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VerifierAppFrame
/*     */   extends JFrame
/*     */ {
/*     */   JPanel contentPane;
/*     */   JSplitPane jSplitPane1;
/*     */   JPanel jPanel1;
/*     */   JPanel jPanel2;
/*     */   JSplitPane jSplitPane2;
/*     */   JPanel jPanel3;
/*     */   JList classNamesJList;
/*     */   GridLayout gridLayout1;
/*     */   JPanel messagesPanel;
/*     */   GridLayout gridLayout2;
/*     */   JMenuBar jMenuBar1;
/*     */   JMenu jMenu1;
/*     */   JScrollPane jScrollPane1;
/*     */   JScrollPane messagesScrollPane;
/*     */   JScrollPane jScrollPane3;
/*     */   GridLayout gridLayout4;
/*     */   JScrollPane jScrollPane4;
/*     */   CardLayout cardLayout1;
/*     */   private String JUSTICE_VERSION;
/*     */   private String current_class;
/*     */   GridLayout gridLayout3;
/*     */   JTextPane pass1TextPane;
/*     */   JTextPane pass2TextPane;
/*     */   JTextPane messagesTextPane;
/*     */   JMenuItem newFileMenuItem;
/*     */   JSplitPane jSplitPane3;
/*     */   JSplitPane jSplitPane4;
/*     */   JScrollPane jScrollPane2;
/*     */   JScrollPane jScrollPane5;
/*     */   JScrollPane jScrollPane6;
/*     */   JScrollPane jScrollPane7;
/*     */   JList pass3aJList;
/*     */   JList pass3bJList;
/*     */   JTextPane pass3aTextPane;
/*     */   JTextPane pass3bTextPane;
/*     */   JMenu jMenu2;
/*     */   JMenuItem whatisMenuItem;
/*     */   JMenuItem aboutMenuItem;
/*     */   
/*     */   public VerifierAppFrame() {
/*  75 */     this.jSplitPane1 = new JSplitPane();
/*  76 */     this.jPanel1 = new JPanel();
/*  77 */     this.jPanel2 = new JPanel();
/*  78 */     this.jSplitPane2 = new JSplitPane();
/*  79 */     this.jPanel3 = new JPanel();
/*  80 */     this.classNamesJList = new JList();
/*  81 */     this.gridLayout1 = new GridLayout();
/*  82 */     this.messagesPanel = new JPanel();
/*  83 */     this.gridLayout2 = new GridLayout();
/*  84 */     this.jMenuBar1 = new JMenuBar();
/*  85 */     this.jMenu1 = new JMenu();
/*  86 */     this.jScrollPane1 = new JScrollPane();
/*  87 */     this.messagesScrollPane = new JScrollPane();
/*  88 */     this.jScrollPane3 = new JScrollPane();
/*  89 */     this.gridLayout4 = new GridLayout();
/*  90 */     this.jScrollPane4 = new JScrollPane();
/*  91 */     this.cardLayout1 = new CardLayout();
/*     */     
/*  93 */     this.JUSTICE_VERSION = "JustIce by Enver Haase";
/*     */     
/*  95 */     this.gridLayout3 = new GridLayout();
/*  96 */     this.pass1TextPane = new JTextPane();
/*  97 */     this.pass2TextPane = new JTextPane();
/*  98 */     this.messagesTextPane = new JTextPane();
/*  99 */     this.newFileMenuItem = new JMenuItem();
/* 100 */     this.jSplitPane3 = new JSplitPane();
/* 101 */     this.jSplitPane4 = new JSplitPane();
/* 102 */     this.jScrollPane2 = new JScrollPane();
/* 103 */     this.jScrollPane5 = new JScrollPane();
/* 104 */     this.jScrollPane6 = new JScrollPane();
/* 105 */     this.jScrollPane7 = new JScrollPane();
/* 106 */     this.pass3aJList = new JList();
/* 107 */     this.pass3bJList = new JList();
/* 108 */     this.pass3aTextPane = new JTextPane();
/* 109 */     this.pass3bTextPane = new JTextPane();
/* 110 */     this.jMenu2 = new JMenu();
/* 111 */     this.whatisMenuItem = new JMenuItem();
/* 112 */     this.aboutMenuItem = new JMenuItem();
/*     */ 
/*     */ 
/*     */     
/* 116 */     enableEvents(64L);
/*     */     try {
/* 118 */       jbInit();
/*     */     }
/* 120 */     catch (Exception e) {
/* 121 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void jbInit() {
/* 127 */     this.contentPane = (JPanel)getContentPane();
/* 128 */     this.contentPane.setLayout(this.cardLayout1);
/* 129 */     setJMenuBar(this.jMenuBar1);
/* 130 */     setSize(new Dimension('˄', 'ǃ'));
/* 131 */     setTitle("JustIce");
/* 132 */     this.jPanel1.setMinimumSize(new Dimension(100, 100));
/* 133 */     this.jPanel1.setPreferredSize(new Dimension(100, 100));
/* 134 */     this.jPanel1.setLayout(this.gridLayout1);
/* 135 */     this.jSplitPane2.setOrientation(0);
/* 136 */     this.jPanel2.setLayout(this.gridLayout2);
/* 137 */     this.jPanel3.setMinimumSize(new Dimension('È', 100));
/* 138 */     this.jPanel3.setPreferredSize(new Dimension('Ɛ', 'Ɛ'));
/* 139 */     this.jPanel3.setLayout(this.gridLayout4);
/* 140 */     this.messagesPanel.setMinimumSize(new Dimension(100, 100));
/* 141 */     this.messagesPanel.setLayout(this.gridLayout3);
/* 142 */     this.jPanel2.setMinimumSize(new Dimension('È', 100));
/* 143 */     this.jMenu1.setText("File");
/*     */     
/* 145 */     this.jScrollPane1.getViewport().setBackground(Color.red);
/* 146 */     this.messagesScrollPane.getViewport().setBackground(Color.red);
/* 147 */     this.messagesScrollPane.setPreferredSize(new Dimension(10, 10));
/* 148 */     this.classNamesJList.addListSelectionListener(new ListSelectionListener() {
/*     */           public void valueChanged(ListSelectionEvent e) {
/* 150 */             VerifierAppFrame.this.classNamesJList_valueChanged(e);
/*     */           }
/*     */         });
/* 153 */     this.classNamesJList.setSelectionMode(0);
/* 154 */     this.jScrollPane3.setBorder(BorderFactory.createLineBorder(Color.black));
/* 155 */     this.jScrollPane3.setPreferredSize(new Dimension(100, 100));
/* 156 */     this.gridLayout4.setRows(4);
/* 157 */     this.gridLayout4.setColumns(1);
/* 158 */     this.gridLayout4.setHgap(1);
/* 159 */     this.jScrollPane4.setBorder(BorderFactory.createLineBorder(Color.black));
/* 160 */     this.jScrollPane4.setPreferredSize(new Dimension(100, 100));
/* 161 */     this.pass1TextPane.setBorder(BorderFactory.createRaisedBevelBorder());
/* 162 */     this.pass1TextPane.setToolTipText("");
/* 163 */     this.pass1TextPane.setEditable(false);
/* 164 */     this.pass2TextPane.setBorder(BorderFactory.createRaisedBevelBorder());
/* 165 */     this.pass2TextPane.setEditable(false);
/* 166 */     this.messagesTextPane.setBorder(BorderFactory.createRaisedBevelBorder());
/* 167 */     this.messagesTextPane.setEditable(false);
/* 168 */     this.newFileMenuItem.setText("New...");
/* 169 */     this.newFileMenuItem.setAccelerator(KeyStroke.getKeyStroke(78, 2, true));
/* 170 */     this.newFileMenuItem.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 172 */             VerifierAppFrame.this.newFileMenuItem_actionPerformed(e);
/*     */           }
/*     */         });
/* 175 */     this.pass3aTextPane.setEditable(false);
/* 176 */     this.pass3bTextPane.setEditable(false);
/* 177 */     this.pass3aJList.addListSelectionListener(new ListSelectionListener() {
/*     */           public void valueChanged(ListSelectionEvent e) {
/* 179 */             VerifierAppFrame.this.pass3aJList_valueChanged(e);
/*     */           }
/*     */         });
/* 182 */     this.pass3bJList.addListSelectionListener(new ListSelectionListener() {
/*     */           public void valueChanged(ListSelectionEvent e) {
/* 184 */             VerifierAppFrame.this.pass3bJList_valueChanged(e);
/*     */           }
/*     */         });
/* 187 */     this.jMenu2.setText("Help");
/* 188 */     this.whatisMenuItem.setText("What is...");
/* 189 */     this.whatisMenuItem.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 191 */             VerifierAppFrame.this.whatisMenuItem_actionPerformed(e);
/*     */           }
/*     */         });
/* 194 */     this.aboutMenuItem.setText("About");
/* 195 */     this.aboutMenuItem.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 197 */             VerifierAppFrame.this.aboutMenuItem_actionPerformed(e);
/*     */           }
/*     */         });
/* 200 */     this.jSplitPane2.add(this.messagesPanel, "bottom");
/* 201 */     this.messagesPanel.add(this.messagesScrollPane, null);
/* 202 */     this.messagesScrollPane.getViewport().add(this.messagesTextPane, null);
/* 203 */     this.jSplitPane2.add(this.jPanel3, "top");
/* 204 */     this.jPanel3.add(this.jScrollPane3, null);
/* 205 */     this.jScrollPane3.getViewport().add(this.pass1TextPane, null);
/* 206 */     this.jPanel3.add(this.jScrollPane4, null);
/* 207 */     this.jPanel3.add(this.jSplitPane3, null);
/* 208 */     this.jSplitPane3.add(this.jScrollPane2, "left");
/* 209 */     this.jScrollPane2.getViewport().add(this.pass3aJList, null);
/* 210 */     this.jSplitPane3.add(this.jScrollPane5, "right");
/* 211 */     this.jScrollPane5.getViewport().add(this.pass3aTextPane, null);
/* 212 */     this.jPanel3.add(this.jSplitPane4, null);
/* 213 */     this.jSplitPane4.add(this.jScrollPane6, "left");
/* 214 */     this.jScrollPane6.getViewport().add(this.pass3bJList, null);
/* 215 */     this.jSplitPane4.add(this.jScrollPane7, "right");
/* 216 */     this.jScrollPane7.getViewport().add(this.pass3bTextPane, null);
/* 217 */     this.jScrollPane4.getViewport().add(this.pass2TextPane, null);
/* 218 */     this.jSplitPane1.add(this.jPanel2, "top");
/* 219 */     this.jPanel2.add(this.jScrollPane1, null);
/* 220 */     this.jSplitPane1.add(this.jPanel1, "bottom");
/* 221 */     this.jPanel1.add(this.jSplitPane2, null);
/* 222 */     this.jScrollPane1.getViewport().add(this.classNamesJList, null);
/* 223 */     this.jMenuBar1.add(this.jMenu1);
/* 224 */     this.jMenuBar1.add(this.jMenu2);
/* 225 */     this.contentPane.add(this.jSplitPane1, "jSplitPane1");
/* 226 */     this.jMenu1.add(this.newFileMenuItem);
/* 227 */     this.jMenu2.add(this.whatisMenuItem);
/* 228 */     this.jMenu2.add(this.aboutMenuItem);
/* 229 */     this.jSplitPane2.setDividerLocation(300);
/* 230 */     this.jSplitPane3.setDividerLocation(150);
/* 231 */     this.jSplitPane4.setDividerLocation(150);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processWindowEvent(WindowEvent e) {
/* 236 */     super.processWindowEvent(e);
/* 237 */     if (e.getID() == 201) {
/* 238 */       System.exit(0);
/*     */     }
/*     */   }
/*     */   
/*     */   void classNamesJList_valueChanged(ListSelectionEvent e) {
/* 243 */     if (e.getValueIsAdjusting())
/* 244 */       return;  this.current_class = this.classNamesJList.getSelectedValue().toString();
/* 245 */     verify();
/* 246 */     this.classNamesJList.setSelectedValue(this.current_class, true);
/*     */   }
/*     */   
/*     */   private void verify() {
/* 250 */     setTitle("PLEASE WAIT");
/*     */     
/* 252 */     Verifier v = VerifierFactory.getVerifier(this.current_class);
/* 253 */     v.flush();
/*     */ 
/*     */ 
/*     */     
/* 257 */     VerificationResult vr = v.doPass1();
/* 258 */     if (vr.getStatus() == 2) {
/* 259 */       this.pass1TextPane.setText(vr.getMessage());
/* 260 */       this.pass1TextPane.setBackground(Color.red);
/*     */       
/* 262 */       this.pass2TextPane.setText("");
/* 263 */       this.pass2TextPane.setBackground(Color.yellow);
/* 264 */       this.pass3aTextPane.setText("");
/* 265 */       this.pass3aJList.setListData(new Object[0]);
/* 266 */       this.pass3aTextPane.setBackground(Color.yellow);
/*     */       
/* 268 */       this.pass3bTextPane.setText("");
/* 269 */       this.pass3bJList.setListData(new Object[0]);
/* 270 */       this.pass3bTextPane.setBackground(Color.yellow);
/*     */     }
/*     */     else {
/*     */       
/* 274 */       this.pass1TextPane.setBackground(Color.green);
/* 275 */       this.pass1TextPane.setText(vr.getMessage());
/*     */       
/* 277 */       vr = v.doPass2();
/* 278 */       if (vr.getStatus() == 2) {
/* 279 */         this.pass2TextPane.setText(vr.getMessage());
/* 280 */         this.pass2TextPane.setBackground(Color.red);
/*     */         
/* 282 */         this.pass3aTextPane.setText("");
/* 283 */         this.pass3aTextPane.setBackground(Color.yellow);
/* 284 */         this.pass3aJList.setListData(new Object[0]);
/* 285 */         this.pass3bTextPane.setText("");
/* 286 */         this.pass3bTextPane.setBackground(Color.yellow);
/* 287 */         this.pass3bJList.setListData(new Object[0]);
/*     */       } else {
/*     */         
/* 290 */         this.pass2TextPane.setText(vr.getMessage());
/* 291 */         this.pass2TextPane.setBackground(Color.green);
/*     */         
/* 293 */         JavaClass jc = Repository.lookupClass(this.current_class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 301 */         String[] methodnames = new String[jc.getMethods().length];
/* 302 */         for (int i = 0; i < jc.getMethods().length; i++) {
/* 303 */           methodnames[i] = jc.getMethods()[i].toString().replace('\n', ' ').replace('\t', ' ');
/*     */         }
/* 305 */         this.pass3aJList.setListData(methodnames);
/* 306 */         this.pass3aJList.setSelectionInterval(0, jc.getMethods().length - 1);
/* 307 */         this.pass3bJList.setListData(methodnames);
/* 308 */         this.pass3bJList.setSelectionInterval(0, jc.getMethods().length - 1);
/*     */       } 
/*     */     } 
/*     */     
/* 312 */     String[] msgs = v.getMessages();
/* 313 */     this.messagesTextPane.setBackground((msgs.length == 0) ? Color.green : Color.yellow);
/* 314 */     String allmsgs = "";
/* 315 */     for (int i = 0; i < msgs.length; i++) {
/* 316 */       msgs[i] = msgs[i].replace('\n', ' ');
/* 317 */       allmsgs = String.valueOf(allmsgs) + msgs[i] + "\n\n";
/*     */     } 
/* 319 */     this.messagesTextPane.setText(allmsgs);
/*     */     
/* 321 */     setTitle(String.valueOf(this.current_class) + " - " + this.JUSTICE_VERSION);
/*     */   }
/*     */   
/*     */   void newFileMenuItem_actionPerformed(ActionEvent e) {
/* 325 */     String classname = JOptionPane.showInputDialog("Please enter the fully qualified name of a class or interface to verify:");
/* 326 */     if (classname == null || classname.equals(""))
/* 327 */       return;  VerifierFactory.getVerifier(classname);
/* 328 */     this.classNamesJList.setSelectedValue(classname, true);
/*     */   }
/*     */ 
/*     */   
/*     */   void pass3aJList_valueChanged(ListSelectionEvent e) {
/* 333 */     if (e.getValueIsAdjusting())
/* 334 */       return;  Verifier v = VerifierFactory.getVerifier(this.current_class);
/*     */     
/* 336 */     String all3amsg = "";
/* 337 */     boolean all3aok = true;
/* 338 */     boolean rejected = false;
/* 339 */     for (int i = 0; i < this.pass3aJList.getModel().getSize(); i++) {
/*     */       
/* 341 */       if (this.pass3aJList.isSelectedIndex(i)) {
/* 342 */         VerificationResult vr = v.doPass3a(i);
/*     */         
/* 344 */         if (vr.getStatus() == 2) {
/* 345 */           all3aok = false;
/* 346 */           rejected = true;
/*     */         } 
/* 348 */         all3amsg = String.valueOf(all3amsg) + "Method '" + Repository.lookupClass(v.getClassName()).getMethods()[i] + "': " + vr.getMessage().replace('\n', ' ') + "\n\n";
/*     */       } 
/*     */     } 
/* 351 */     this.pass3aTextPane.setText(all3amsg);
/* 352 */     this.pass3aTextPane.setBackground(all3aok ? Color.green : (rejected ? Color.red : Color.yellow));
/*     */   }
/*     */ 
/*     */   
/*     */   void pass3bJList_valueChanged(ListSelectionEvent e) {
/* 357 */     if (e.getValueIsAdjusting())
/*     */       return; 
/* 359 */     Verifier v = VerifierFactory.getVerifier(this.current_class);
/*     */     
/* 361 */     String all3bmsg = "";
/* 362 */     boolean all3bok = true;
/* 363 */     boolean rejected = false;
/* 364 */     for (int i = 0; i < this.pass3bJList.getModel().getSize(); i++) {
/*     */       
/* 366 */       if (this.pass3bJList.isSelectedIndex(i)) {
/* 367 */         VerificationResult vr = v.doPass3b(i);
/*     */         
/* 369 */         if (vr.getStatus() == 2) {
/* 370 */           all3bok = false;
/* 371 */           rejected = true;
/*     */         } 
/* 373 */         all3bmsg = String.valueOf(all3bmsg) + "Method '" + Repository.lookupClass(v.getClassName()).getMethods()[i] + "': " + vr.getMessage().replace('\n', ' ') + "\n\n";
/*     */       } 
/*     */     } 
/* 376 */     this.pass3bTextPane.setText(all3bmsg);
/* 377 */     this.pass3bTextPane.setBackground(all3bok ? Color.green : (rejected ? Color.red : Color.yellow));
/*     */   }
/*     */ 
/*     */   
/*     */   void aboutMenuItem_actionPerformed(ActionEvent e) {
/* 382 */     JOptionPane.showMessageDialog(this, 
/* 383 */         "JustIce is a Java class file verifier.\nIt was implemented by Enver Haase in 2001, 2002.\n<http://jakarta.apache.org/bcel/index.html>", 
/* 384 */         this.JUSTICE_VERSION, 1);
/*     */   }
/*     */   
/*     */   void whatisMenuItem_actionPerformed(ActionEvent e) {
/* 388 */     JOptionPane.showMessageDialog(this, 
/* 389 */         "The upper four boxes to the right reflect verification passes according to The Java Virtual Machine Specification.\nThese are (in that order): Pass one, Pass two, Pass three (before data flow analysis), Pass three (data flow analysis).\nThe bottom box to the right shows (warning) messages; warnings do not cause a class to be rejected.", 
/* 390 */         this.JUSTICE_VERSION, 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\VerifierAppFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */