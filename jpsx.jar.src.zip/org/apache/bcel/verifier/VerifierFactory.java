/*     */ package org.apache.bcel.verifier;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VerifierFactory
/*     */ {
/*  76 */   private static HashMap hashMap = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private static Vector observers = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Verifier getVerifier(String fully_qualified_classname) {
/*  94 */     fully_qualified_classname = fully_qualified_classname;
/*     */     
/*  96 */     Verifier v = (Verifier)hashMap.get(fully_qualified_classname);
/*  97 */     if (v == null) {
/*  98 */       v = new Verifier(fully_qualified_classname);
/*  99 */       hashMap.put(fully_qualified_classname, v);
/* 100 */       notify(fully_qualified_classname);
/*     */     } 
/*     */     
/* 103 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void notify(String fully_qualified_classname) {
/* 111 */     Iterator i = observers.iterator();
/* 112 */     while (i.hasNext()) {
/* 113 */       VerifierFactoryObserver vfo = (VerifierFactoryObserver)i.next();
/* 114 */       vfo.update(fully_qualified_classname);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Verifier[] getVerifiers() {
/* 126 */     vs = new Verifier[hashMap.values().size()];
/* 127 */     return (Verifier[])hashMap.values().toArray(vs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public static void attach(VerifierFactoryObserver o) { observers.addElement(o); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public static void detach(VerifierFactoryObserver o) { observers.removeElement(o); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\VerifierFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */