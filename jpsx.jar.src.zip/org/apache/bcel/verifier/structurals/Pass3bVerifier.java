/*     */ package org.apache.bcel.verifier.structurals;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import java.util.Vector;
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.generic.ConstantPoolGen;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.JsrInstruction;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.ObjectType;
/*     */ import org.apache.bcel.generic.RET;
/*     */ import org.apache.bcel.generic.ReturnaddressType;
/*     */ import org.apache.bcel.generic.Type;
/*     */ import org.apache.bcel.verifier.PassVerifier;
/*     */ import org.apache.bcel.verifier.VerificationResult;
/*     */ import org.apache.bcel.verifier.Verifier;
/*     */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*     */ import org.apache.bcel.verifier.exc.VerifierConstraintViolatedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Pass3bVerifier
/*     */   extends PassVerifier
/*     */ {
/*     */   private static final boolean DEBUG = true;
/*     */   private Verifier myOwner;
/*     */   private int method_no;
/*     */   
/*     */   private static final class InstructionContextQueue
/*     */   {
/* 100 */     private Vector ics = new Vector();
/* 101 */     private Vector ecs = new Vector();
/*     */     public void add(InstructionContext ic, ArrayList executionChain) {
/* 103 */       this.ics.add(ic);
/* 104 */       this.ecs.add(executionChain);
/*     */     }
/*     */     
/* 107 */     public boolean isEmpty() { return this.ics.isEmpty(); }
/*     */ 
/*     */     
/* 110 */     public void remove() { remove(0); }
/*     */     
/*     */     public void remove(int i) {
/* 113 */       this.ics.remove(i);
/* 114 */       this.ecs.remove(i);
/*     */     }
/*     */     
/* 117 */     public InstructionContext getIC(int i) { return (InstructionContext)this.ics.get(i); }
/*     */ 
/*     */     
/* 120 */     public ArrayList getEC(int i) { return (ArrayList)this.ecs.get(i); }
/*     */ 
/*     */     
/* 123 */     public int size() { return this.ics.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private InstructionContextQueue() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pass3bVerifier(Verifier owner, int method_no) {
/* 142 */     this.myOwner = owner;
/* 143 */     this.method_no = method_no;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void circulationPump(ControlFlowGraph cfg, InstructionContext start, Frame vanillaFrame, InstConstraintVisitor icv, ExecutionVisitor ev) {
/* 154 */     Random random = new Random();
/* 155 */     InstructionContextQueue icq = new InstructionContextQueue(null);
/*     */     
/* 157 */     start.execute(vanillaFrame, new ArrayList(), icv, ev);
/*     */     
/* 159 */     icq.add(start, new ArrayList());
/*     */ 
/*     */     
/* 162 */     while (!icq.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 172 */       InstructionContext u = icq.getIC(0);
/* 173 */       ArrayList ec = icq.getEC(0);
/* 174 */       icq.remove(0);
/*     */ 
/*     */       
/* 177 */       ArrayList oldchain = (ArrayList)ec.clone();
/* 178 */       ArrayList newchain = (ArrayList)ec.clone();
/* 179 */       newchain.add(u);
/*     */       
/* 181 */       if (u.getInstruction().getInstruction() instanceof RET) {
/*     */ 
/*     */ 
/*     */         
/* 185 */         RET ret = (RET)u.getInstruction().getInstruction();
/* 186 */         ReturnaddressType t = (ReturnaddressType)u.getOutFrame(oldchain).getLocals().get(ret.getIndex());
/* 187 */         InstructionContext theSuccessor = cfg.contextOf(t.getTarget());
/*     */ 
/*     */         
/* 190 */         InstructionContext lastJSR = null;
/* 191 */         int skip_jsr = 0;
/* 192 */         for (int ss = oldchain.size() - 1; ss >= 0; ss--) {
/* 193 */           if (skip_jsr < 0) {
/* 194 */             throw new AssertionViolatedException("More RET than JSR in execution chain?!");
/*     */           }
/*     */           
/* 197 */           if (((InstructionContext)oldchain.get(ss)).getInstruction().getInstruction() instanceof JsrInstruction) {
/* 198 */             if (skip_jsr == 0) {
/* 199 */               lastJSR = (InstructionContext)oldchain.get(ss);
/*     */               
/*     */               break;
/*     */             } 
/* 203 */             skip_jsr--;
/*     */           } 
/*     */           
/* 206 */           if (((InstructionContext)oldchain.get(ss)).getInstruction().getInstruction() instanceof RET) {
/* 207 */             skip_jsr++;
/*     */           }
/*     */         } 
/* 210 */         if (lastJSR == null) {
/* 211 */           throw new AssertionViolatedException("RET without a JSR before in ExecutionChain?! EC: '" + oldchain + "'.");
/*     */         }
/* 213 */         JsrInstruction jsr = (JsrInstruction)lastJSR.getInstruction().getInstruction();
/* 214 */         if (theSuccessor != cfg.contextOf(jsr.physicalSuccessor())) {
/* 215 */           throw new AssertionViolatedException("RET '" + u.getInstruction() + "' info inconsistent: jump back to '" + theSuccessor + "' or '" + cfg.contextOf(jsr.physicalSuccessor()) + "'?");
/*     */         }
/*     */         
/* 218 */         if (theSuccessor.execute(u.getOutFrame(oldchain), newchain, icv, ev)) {
/* 219 */           icq.add(theSuccessor, (ArrayList)newchain.clone());
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 225 */         InstructionContext[] succs = u.getSuccessors();
/* 226 */         for (int s = 0; s < succs.length; s++) {
/* 227 */           InstructionContext v = succs[s];
/* 228 */           if (v.execute(u.getOutFrame(oldchain), newchain, icv, ev)) {
/* 229 */             icq.add(v, (ArrayList)newchain.clone());
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 236 */       ExceptionHandler[] exc_hds = u.getExceptionHandlers();
/* 237 */       for (int s = 0; s < exc_hds.length; s++) {
/* 238 */         InstructionContext v = cfg.contextOf(exc_hds[s].getHandlerStart());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 249 */         if (v.execute(new Frame(u.getOutFrame(oldchain).getLocals(), new OperandStack(u.getOutFrame(oldchain).getStack().maxStack(), (exc_hds[s].getExceptionType() == null) ? Type.THROWABLE : exc_hds[s].getExceptionType())), new ArrayList(), icv, ev)) {
/* 250 */           icq.add(v, new ArrayList());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 256 */     InstructionHandle ih = start.getInstruction();
/*     */     do {
/* 258 */       if (!(ih.getInstruction() instanceof org.apache.bcel.generic.ReturnInstruction) || cfg.isDead(ih))
/* 259 */         continue;  InstructionContext ic = cfg.contextOf(ih);
/* 260 */       Frame f = ic.getOutFrame(new ArrayList());
/* 261 */       LocalVariables lvs = f.getLocals();
/* 262 */       for (int i = 0; i < lvs.maxLocals(); i++) {
/* 263 */         if (lvs.get(i) instanceof UninitializedObjectType) {
/* 264 */           addMessage("Warning: ReturnInstruction '" + ic + "' may leave method with an uninitialized object in the local variables array '" + lvs + "'.");
/*     */         }
/*     */       } 
/* 267 */       OperandStack os = f.getStack();
/* 268 */       for (int i = 0; i < os.size(); i++) {
/* 269 */         if (os.peek(i) instanceof UninitializedObjectType) {
/* 270 */           addMessage("Warning: ReturnInstruction '" + ic + "' may leave method with an uninitialized object on the operand stack '" + os + "'.");
/*     */         }
/*     */       }
/*     */     
/* 274 */     } while ((ih = ih.getNext()) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VerificationResult do_verify() {
/* 289 */     if (!this.myOwner.doPass3a(this.method_no).equals(VerificationResult.VR_OK)) {
/* 290 */       return VerificationResult.VR_NOTYET;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 295 */     JavaClass jc = Repository.lookupClass(this.myOwner.getClassName());
/*     */     
/* 297 */     ConstantPoolGen constantPoolGen = new ConstantPoolGen(jc.getConstantPool());
/*     */     
/* 299 */     InstConstraintVisitor icv = new InstConstraintVisitor();
/* 300 */     icv.setConstantPoolGen(constantPoolGen);
/*     */     
/* 302 */     ExecutionVisitor ev = new ExecutionVisitor();
/* 303 */     ev.setConstantPoolGen(constantPoolGen);
/*     */     
/* 305 */     Method[] methods = jc.getMethods();
/*     */ 
/*     */     
/*     */     try {
/* 309 */       MethodGen mg = new MethodGen(methods[this.method_no], this.myOwner.getClassName(), constantPoolGen);
/*     */       
/* 311 */       icv.setMethodGen(mg);
/*     */ 
/*     */       
/* 314 */       if (!mg.isAbstract() && !mg.isNative())
/*     */       {
/* 316 */         ControlFlowGraph cfg = new ControlFlowGraph(mg);
/*     */ 
/*     */         
/* 319 */         Frame f = new Frame(mg.getMaxLocals(), mg.getMaxStack());
/* 320 */         if (!mg.isStatic()) {
/* 321 */           if (mg.getName().equals("<init>")) {
/* 322 */             Frame._this = new UninitializedObjectType(new ObjectType(jc.getClassName()));
/* 323 */             f.getLocals().set(0, Frame._this);
/*     */           } else {
/*     */             
/* 326 */             Frame._this = null;
/* 327 */             f.getLocals().set(0, new ObjectType(jc.getClassName()));
/*     */           } 
/*     */         }
/* 330 */         Type[] argtypes = mg.getArgumentTypes();
/* 331 */         int twoslotoffset = 0;
/* 332 */         for (int j = 0; j < argtypes.length; j++) {
/* 333 */           if (argtypes[j] == Type.SHORT || argtypes[j] == Type.BYTE || argtypes[j] == Type.CHAR || argtypes[j] == Type.BOOLEAN) {
/* 334 */             argtypes[j] = Type.INT;
/*     */           }
/* 336 */           f.getLocals().set(twoslotoffset + j + (mg.isStatic() ? 0 : 1), argtypes[j]);
/* 337 */           if (argtypes[j].getSize() == 2) {
/* 338 */             twoslotoffset++;
/* 339 */             f.getLocals().set(twoslotoffset + j + (mg.isStatic() ? 0 : 1), Type.UNKNOWN);
/*     */           } 
/*     */         } 
/* 342 */         circulationPump(cfg, cfg.contextOf(mg.getInstructionList().getStart()), f, icv, ev);
/*     */       }
/*     */     
/* 345 */     } catch (VerifierConstraintViolatedException ce) {
/* 346 */       ce.extendMessage("Constraint violated in method '" + methods[this.method_no] + "':\n", "");
/* 347 */       return new VerificationResult(2, ce.getMessage());
/*     */     }
/* 349 */     catch (RuntimeException re) {
/*     */ 
/*     */       
/* 352 */       StringWriter sw = new StringWriter();
/* 353 */       PrintWriter pw = new PrintWriter(sw);
/* 354 */       re.printStackTrace(pw);
/*     */       
/* 356 */       throw new AssertionViolatedException("Some RuntimeException occured while verify()ing class '" + jc.getClassName() + "', method '" + methods[this.method_no] + "'. Original RuntimeException's stack trace:\n---\n" + sw + "---\n");
/*     */     } 
/* 358 */     return VerificationResult.VR_OK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 363 */   public int getMethodNo() { return this.method_no; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\Pass3bVerifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */