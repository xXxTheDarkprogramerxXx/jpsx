package org.apache.bcel.verifier.structurals;

import org.apache.bcel.generic.InstructionHandle;

public interface Subroutine {
  InstructionHandle[] getEnteringJsrInstructions();
  
  InstructionHandle getLeavingRET();
  
  InstructionHandle[] getInstructions();
  
  boolean contains(InstructionHandle paramInstructionHandle);
  
  int[] getAccessedLocalsIndices();
  
  int[] getRecursivelyAccessedLocalsIndices();
  
  Subroutine[] subSubs();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\Subroutine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */