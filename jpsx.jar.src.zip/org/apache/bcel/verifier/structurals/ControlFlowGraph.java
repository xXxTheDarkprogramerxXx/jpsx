/*     */ package org.apache.bcel.verifier.structurals;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.bcel.generic.BranchInstruction;
/*     */ import org.apache.bcel.generic.GotoInstruction;
/*     */ import org.apache.bcel.generic.Instruction;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.JsrInstruction;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.Select;
/*     */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*     */ import org.apache.bcel.verifier.exc.StructuralCodeConstraintException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlFlowGraph
/*     */ {
/*     */   private final MethodGen method_gen;
/*     */   private final Subroutines subroutines;
/*     */   private final ExceptionHandlers exceptionhandlers;
/*     */   private Hashtable instructionContexts;
/*     */   
/*     */   private class InstructionContextImpl
/*     */     implements InstructionContext
/*     */   {
/*     */     private int TAG;
/*     */     private InstructionHandle instruction;
/*     */     private HashMap inFrames;
/*     */     private HashMap outFrames;
/* 104 */     private ArrayList executionPredecessors = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InstructionContextImpl(InstructionHandle inst) {
/* 111 */       if (inst == null) throw new AssertionViolatedException("Cannot instantiate InstructionContextImpl from NULL.");
/*     */       
/* 113 */       this.instruction = inst;
/* 114 */       this.inFrames = new HashMap();
/* 115 */       this.outFrames = new HashMap();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 120 */     public int getTag() { return this.TAG; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     public void setTag(int tag) { this.TAG = tag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     public ExceptionHandler[] getExceptionHandlers() { return ControlFlowGraph.this.exceptionhandlers.getExceptionHandlers(getInstruction()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Frame getOutFrame(ArrayList execChain) {
/* 139 */       this.executionPredecessors = execChain;
/*     */ 
/*     */ 
/*     */       
/* 143 */       InstructionContext jsr = lastExecutionJSR();
/*     */       
/* 145 */       Frame org = (Frame)this.outFrames.get(jsr);
/*     */       
/* 147 */       if (org == null) {
/* 148 */         throw new AssertionViolatedException("outFrame not set! This:\n" + this + "\nExecutionChain: " + getExecutionChain() + "\nOutFrames: '" + this.outFrames + "'.");
/*     */       }
/* 150 */       return org.getClone();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean execute(Frame inFrame, ArrayList execPreds, InstConstraintVisitor icv, ExecutionVisitor ev) {
/* 170 */       this.executionPredecessors = (ArrayList)execPreds.clone();
/*     */ 
/*     */       
/* 173 */       if (lastExecutionJSR() == null && ControlFlowGraph.this.subroutines.subroutineOf(getInstruction()) != ControlFlowGraph.this.subroutines.getTopLevel()) {
/* 174 */         throw new AssertionViolatedException("Huh?! Am I '" + this + "' part of a subroutine or not?");
/*     */       }
/* 176 */       if (lastExecutionJSR() != null && ControlFlowGraph.this.subroutines.subroutineOf(getInstruction()) == ControlFlowGraph.this.subroutines.getTopLevel()) {
/* 177 */         throw new AssertionViolatedException("Huh?! Am I '" + this + "' part of a subroutine or not?");
/*     */       }
/*     */       
/* 180 */       Frame inF = (Frame)this.inFrames.get(lastExecutionJSR());
/* 181 */       if (inF == null) {
/* 182 */         this.inFrames.put(lastExecutionJSR(), inFrame);
/* 183 */         inF = inFrame;
/*     */       } else {
/*     */         
/* 186 */         if (inF.equals(inFrame)) {
/* 187 */           return false;
/*     */         }
/* 189 */         if (!mergeInFrames(inFrame)) {
/* 190 */           return false;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       Frame workingFrame = inF.getClone();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 203 */         icv.setFrame(workingFrame);
/* 204 */         getInstruction().accept(icv);
/*     */       }
/* 206 */       catch (StructuralCodeConstraintException ce) {
/* 207 */         ce.extendMessage("", "\nInstructionHandle: " + getInstruction() + "\n");
/* 208 */         ce.extendMessage("", "\nExecution Frame:\n" + workingFrame);
/* 209 */         extendMessageWithFlow(ce);
/* 210 */         throw ce;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       ev.setFrame(workingFrame);
/* 217 */       getInstruction().accept(ev);
/*     */       
/* 219 */       this.outFrames.put(lastExecutionJSR(), workingFrame);
/*     */       
/* 221 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     public String toString() { return String.valueOf(getInstruction().toString(false)) + "\t[InstructionContext]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean mergeInFrames(Frame inFrame) {
/* 242 */       Frame inF = (Frame)this.inFrames.get(lastExecutionJSR());
/* 243 */       OperandStack oldstack = inF.getStack().getClone();
/* 244 */       LocalVariables oldlocals = inF.getLocals().getClone();
/*     */       try {
/* 246 */         inF.getStack().merge(inFrame.getStack());
/* 247 */         inF.getLocals().merge(inFrame.getLocals());
/*     */       }
/* 249 */       catch (StructuralCodeConstraintException sce) {
/* 250 */         extendMessageWithFlow(sce);
/* 251 */         throw sce;
/*     */       } 
/* 253 */       if (oldstack.equals(inF.getStack()) && 
/* 254 */         oldlocals.equals(inF.getLocals())) {
/* 255 */         return false;
/*     */       }
/*     */       
/* 258 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String getExecutionChain() {
/* 268 */       String s = toString();
/* 269 */       for (int i = this.executionPredecessors.size() - 1; i >= 0; i--) {
/* 270 */         s = this.executionPredecessors.get(i) + "\n" + s;
/*     */       }
/* 272 */       return s;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void extendMessageWithFlow(StructuralCodeConstraintException e) {
/* 282 */       String s = "Execution flow:\n";
/* 283 */       e.extendMessage("", String.valueOf(s) + getExecutionChain());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 290 */     public InstructionHandle getInstruction() { return this.instruction; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private InstructionContextImpl lastExecutionJSR() {
/* 302 */       int size = this.executionPredecessors.size();
/* 303 */       int retcount = 0;
/*     */       
/* 305 */       for (int i = size - 1; i >= 0; i--) {
/* 306 */         InstructionContextImpl current = (InstructionContextImpl)this.executionPredecessors.get(i);
/* 307 */         Instruction currentlast = current.getInstruction().getInstruction();
/* 308 */         if (currentlast instanceof org.apache.bcel.generic.RET) retcount++;
/*     */         
/* 310 */         retcount--;
/* 311 */         if (currentlast instanceof JsrInstruction && retcount == -1) return current;
/*     */       
/*     */       } 
/* 314 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 319 */     public InstructionContext[] getSuccessors() { return ControlFlowGraph.this.contextsOf(_getSuccessors()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private InstructionHandle[] _getSuccessors() {
/* 330 */       InstructionHandle[] empty = new InstructionHandle[0];
/* 331 */       InstructionHandle[] single = new InstructionHandle[1];
/* 332 */       InstructionHandle[] pair = new InstructionHandle[2];
/*     */       
/* 334 */       Instruction inst = getInstruction().getInstruction();
/*     */       
/* 336 */       if (inst instanceof org.apache.bcel.generic.RET) {
/* 337 */         Subroutine s = ControlFlowGraph.this.subroutines.subroutineOf(getInstruction());
/* 338 */         if (s == null) {
/* 339 */           throw new AssertionViolatedException("Asking for successors of a RET in dead code?!");
/*     */         }
/*     */         
/* 342 */         throw new AssertionViolatedException("DID YOU REALLY WANT TO ASK FOR RET'S SUCCS?");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 354 */       if (inst instanceof org.apache.bcel.generic.ReturnInstruction) {
/* 355 */         return empty;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 360 */       if (inst instanceof org.apache.bcel.generic.ATHROW) {
/* 361 */         return empty;
/*     */       }
/*     */ 
/*     */       
/* 365 */       if (inst instanceof JsrInstruction) {
/* 366 */         single[0] = ((JsrInstruction)inst).getTarget();
/* 367 */         return single;
/*     */       } 
/*     */       
/* 370 */       if (inst instanceof GotoInstruction) {
/* 371 */         single[0] = ((GotoInstruction)inst).getTarget();
/* 372 */         return single;
/*     */       } 
/*     */       
/* 375 */       if (inst instanceof BranchInstruction) {
/* 376 */         if (inst instanceof Select) {
/*     */ 
/*     */           
/* 379 */           InstructionHandle[] matchTargets = ((Select)inst).getTargets();
/* 380 */           InstructionHandle[] ret = new InstructionHandle[matchTargets.length + 1];
/* 381 */           ret[0] = ((Select)inst).getTarget();
/* 382 */           System.arraycopy(matchTargets, 0, ret, 1, matchTargets.length);
/* 383 */           return ret;
/*     */         } 
/*     */         
/* 386 */         pair[0] = getInstruction().getNext();
/* 387 */         pair[1] = ((BranchInstruction)inst).getTarget();
/* 388 */         return pair;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 393 */       single[0] = getInstruction().getNext();
/* 394 */       return single;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlowGraph(MethodGen method_gen) {
/* 409 */     this.instructionContexts = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 415 */     this.subroutines = new Subroutines(method_gen);
/* 416 */     this.exceptionhandlers = new ExceptionHandlers(method_gen);
/*     */     
/* 418 */     InstructionHandle[] instructionhandles = method_gen.getInstructionList().getInstructionHandles();
/* 419 */     for (int i = 0; i < instructionhandles.length; i++) {
/* 420 */       this.instructionContexts.put(instructionhandles[i], new InstructionContextImpl(instructionhandles[i]));
/*     */     }
/*     */     
/* 423 */     this.method_gen = method_gen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionContext contextOf(InstructionHandle inst) {
/* 430 */     InstructionContext ic = (InstructionContext)this.instructionContexts.get(inst);
/* 431 */     if (ic == null) {
/* 432 */       throw new AssertionViolatedException("InstructionContext requested for an InstructionHandle that's not known!");
/*     */     }
/* 434 */     return ic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionContext[] contextsOf(InstructionHandle[] insts) {
/* 442 */     InstructionContext[] ret = new InstructionContext[insts.length];
/* 443 */     for (int i = 0; i < insts.length; i++) {
/* 444 */       ret[i] = contextOf(insts[i]);
/*     */     }
/* 446 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionContext[] getInstructionContexts() {
/* 455 */     InstructionContext[] ret = new InstructionContext[this.instructionContexts.values().size()];
/* 456 */     return (InstructionContext[])this.instructionContexts.values().toArray(ret);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 464 */   public boolean isDead(InstructionHandle i) { return this.instructionContexts.containsKey(i); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\ControlFlowGraph.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */