/*     */ package org.apache.bcel.verifier.structurals;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.apache.bcel.generic.ObjectType;
/*     */ import org.apache.bcel.generic.ReferenceType;
/*     */ import org.apache.bcel.generic.Type;
/*     */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*     */ import org.apache.bcel.verifier.exc.StructuralCodeConstraintException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OperandStack
/*     */ {
/*     */   private ArrayList stack;
/*     */   private int maxStack;
/*     */   
/*     */   public OperandStack(int maxStack) {
/*  72 */     this.stack = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     this.maxStack = maxStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OperandStack(int maxStack, ObjectType obj) {
/*     */     this.stack = new ArrayList();
/*  89 */     this.maxStack = maxStack;
/*  90 */     push(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object clone() {
/*  98 */     OperandStack newstack = new OperandStack(this.maxStack);
/*  99 */     newstack.stack = (ArrayList)this.stack.clone();
/* 100 */     return newstack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void clear() { this.stack = new ArrayList(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 116 */     if (!(o instanceof OperandStack)) return false; 
/* 117 */     OperandStack s = (OperandStack)o;
/* 118 */     return this.stack.equals(s.stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public OperandStack getClone() { return (OperandStack)clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public boolean isEmpty() { return this.stack.isEmpty(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public int maxStack() { return this.maxStack; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public Type peek() { return peek(0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public Type peek(int i) { return (Type)this.stack.get(size() - i - 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public Type pop() { return (Type)this.stack.remove(size() - 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type pop(int i) {
/* 171 */     for (int j = 0; j < i; j++) {
/* 172 */       pop();
/*     */     }
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void push(Type type) {
/* 181 */     if (type == null) throw new AssertionViolatedException("Cannot push NULL onto OperandStack."); 
/* 182 */     if (type == Type.BOOLEAN || type == Type.CHAR || type == Type.BYTE || type == Type.SHORT) {
/* 183 */       throw new AssertionViolatedException("The OperandStack does not know about '" + type + "'; use Type.INT instead.");
/*     */     }
/* 185 */     if (slotsUsed() >= this.maxStack) {
/* 186 */       throw new AssertionViolatedException("OperandStack too small, should have thrown proper Exception elsewhere. Stack: " + this);
/*     */     }
/* 188 */     this.stack.add(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   int size() { return this.stack.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int slotsUsed() {
/* 207 */     int slots = 0;
/* 208 */     for (int i = 0; i < this.stack.size(); i++) {
/* 209 */       slots += peek(i).getSize();
/*     */     }
/* 211 */     return slots;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 218 */     String s = "Slots used: " + slotsUsed() + " MaxStack: " + this.maxStack + ".\n";
/* 219 */     for (int i = 0; i < size(); i++) {
/* 220 */       s = String.valueOf(s) + peek(i) + " (Size: " + peek(i).getSize() + ")\n";
/*     */     }
/* 222 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(OperandStack s) {
/* 231 */     if (slotsUsed() != s.slotsUsed() || size() != s.size()) {
/* 232 */       throw new StructuralCodeConstraintException("Cannot merge stacks of different size:\nOperandStack A:\n" + this + "\nOperandStack B:\n" + s);
/*     */     }
/* 234 */     for (int i = 0; i < size(); i++) {
/*     */ 
/*     */       
/* 237 */       if (!(this.stack.get(i) instanceof UninitializedObjectType) && s.stack.get(i) instanceof UninitializedObjectType) {
/* 238 */         throw new StructuralCodeConstraintException("Backwards branch with an uninitialized object on the stack detected.");
/*     */       }
/*     */ 
/*     */       
/* 242 */       if (!this.stack.get(i).equals(s.stack.get(i)) && this.stack.get(i) instanceof UninitializedObjectType && !(s.stack.get(i) instanceof UninitializedObjectType)) {
/* 243 */         throw new StructuralCodeConstraintException("Backwards branch with an uninitialized object on the stack detected.");
/*     */       }
/*     */       
/* 246 */       if (this.stack.get(i) instanceof UninitializedObjectType && 
/* 247 */         !(s.stack.get(i) instanceof UninitializedObjectType)) {
/* 248 */         this.stack.set(i, ((UninitializedObjectType)this.stack.get(i)).getInitialized());
/*     */       }
/*     */       
/* 251 */       if (!this.stack.get(i).equals(s.stack.get(i))) {
/* 252 */         if (this.stack.get(i) instanceof ReferenceType && 
/* 253 */           s.stack.get(i) instanceof ReferenceType) {
/* 254 */           this.stack.set(i, ((ReferenceType)this.stack.get(i)).getFirstCommonSuperclass((ReferenceType)s.stack.get(i)));
/*     */         } else {
/*     */           
/* 257 */           throw new StructuralCodeConstraintException("Cannot merge stacks of different types:\nStack A:\n" + this + "\nStack B:\n" + s);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeObject(UninitializedObjectType u) {
/* 268 */     for (int i = 0; i < this.stack.size(); i++) {
/* 269 */       if (this.stack.get(i) == u)
/* 270 */         this.stack.set(i, u.getInitialized()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\OperandStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */