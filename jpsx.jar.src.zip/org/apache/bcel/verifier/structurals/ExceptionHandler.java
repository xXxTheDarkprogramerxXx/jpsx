/*    */ package org.apache.bcel.verifier.structurals;
/*    */ 
/*    */ import org.apache.bcel.generic.InstructionHandle;
/*    */ import org.apache.bcel.generic.ObjectType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionHandler
/*    */ {
/*    */   private ObjectType catchtype;
/*    */   private InstructionHandle handlerpc;
/*    */   
/*    */   ExceptionHandler(ObjectType catch_type, InstructionHandle handler_pc) {
/* 76 */     this.catchtype = catch_type;
/* 77 */     this.handlerpc = handler_pc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 84 */   public ObjectType getExceptionType() { return this.catchtype; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 91 */   public InstructionHandle getHandlerStart() { return this.handlerpc; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\ExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */