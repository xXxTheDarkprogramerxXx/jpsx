/*      */ package org.apache.bcel.verifier.structurals;
/*      */ import org.apache.bcel.Repository;
/*      */ import org.apache.bcel.classfile.Constant;
/*      */ import org.apache.bcel.classfile.Field;
/*      */ import org.apache.bcel.classfile.JavaClass;
/*      */ import org.apache.bcel.generic.AALOAD;
/*      */ import org.apache.bcel.generic.AASTORE;
/*      */ import org.apache.bcel.generic.ArrayType;
/*      */ import org.apache.bcel.generic.BALOAD;
/*      */ import org.apache.bcel.generic.BASTORE;
/*      */ import org.apache.bcel.generic.BasicType;
/*      */ import org.apache.bcel.generic.CASTORE;
/*      */ import org.apache.bcel.generic.CHECKCAST;
/*      */ import org.apache.bcel.generic.CPInstruction;
/*      */ import org.apache.bcel.generic.ConstantPoolGen;
/*      */ import org.apache.bcel.generic.DADD;
/*      */ import org.apache.bcel.generic.DALOAD;
/*      */ import org.apache.bcel.generic.DASTORE;
/*      */ import org.apache.bcel.generic.DDIV;
/*      */ import org.apache.bcel.generic.DMUL;
/*      */ import org.apache.bcel.generic.DREM;
/*      */ import org.apache.bcel.generic.DUP2_X1;
/*      */ import org.apache.bcel.generic.DUP_X1;
/*      */ import org.apache.bcel.generic.DUP_X2;
/*      */ import org.apache.bcel.generic.FADD;
/*      */ import org.apache.bcel.generic.FALOAD;
/*      */ import org.apache.bcel.generic.FASTORE;
/*      */ import org.apache.bcel.generic.FMUL;
/*      */ import org.apache.bcel.generic.FSUB;
/*      */ import org.apache.bcel.generic.FieldInstruction;
/*      */ import org.apache.bcel.generic.GETFIELD;
/*      */ import org.apache.bcel.generic.IADD;
/*      */ import org.apache.bcel.generic.IALOAD;
/*      */ import org.apache.bcel.generic.IAND;
/*      */ import org.apache.bcel.generic.IASTORE;
/*      */ import org.apache.bcel.generic.IDIV;
/*      */ import org.apache.bcel.generic.IFNONNULL;
/*      */ import org.apache.bcel.generic.IF_ACMPEQ;
/*      */ import org.apache.bcel.generic.IF_ACMPNE;
/*      */ import org.apache.bcel.generic.IF_ICMPLE;
/*      */ import org.apache.bcel.generic.IF_ICMPLT;
/*      */ import org.apache.bcel.generic.IINC;
/*      */ import org.apache.bcel.generic.IMUL;
/*      */ import org.apache.bcel.generic.INSTANCEOF;
/*      */ import org.apache.bcel.generic.INVOKEINTERFACE;
/*      */ import org.apache.bcel.generic.INVOKESPECIAL;
/*      */ import org.apache.bcel.generic.INVOKESTATIC;
/*      */ import org.apache.bcel.generic.INVOKEVIRTUAL;
/*      */ import org.apache.bcel.generic.IOR;
/*      */ import org.apache.bcel.generic.IREM;
/*      */ import org.apache.bcel.generic.ISHL;
/*      */ import org.apache.bcel.generic.ISHR;
/*      */ import org.apache.bcel.generic.IUSHR;
/*      */ import org.apache.bcel.generic.Instruction;
/*      */ import org.apache.bcel.generic.LADD;
/*      */ import org.apache.bcel.generic.LALOAD;
/*      */ import org.apache.bcel.generic.LAND;
/*      */ import org.apache.bcel.generic.LASTORE;
/*      */ import org.apache.bcel.generic.LDC;
/*      */ import org.apache.bcel.generic.LDIV;
/*      */ import org.apache.bcel.generic.LMUL;
/*      */ import org.apache.bcel.generic.LOR;
/*      */ import org.apache.bcel.generic.LREM;
/*      */ import org.apache.bcel.generic.LSHL;
/*      */ import org.apache.bcel.generic.LSHR;
/*      */ import org.apache.bcel.generic.LoadClass;
/*      */ import org.apache.bcel.generic.LoadInstruction;
/*      */ import org.apache.bcel.generic.LocalVariableInstruction;
/*      */ import org.apache.bcel.generic.MONITORENTER;
/*      */ import org.apache.bcel.generic.MULTIANEWARRAY;
/*      */ import org.apache.bcel.generic.NEW;
/*      */ import org.apache.bcel.generic.ObjectType;
/*      */ import org.apache.bcel.generic.PUTFIELD;
/*      */ import org.apache.bcel.generic.PUTSTATIC;
/*      */ import org.apache.bcel.generic.RET;
/*      */ import org.apache.bcel.generic.ReferenceType;
/*      */ import org.apache.bcel.generic.ReturnInstruction;
/*      */ import org.apache.bcel.generic.SALOAD;
/*      */ import org.apache.bcel.generic.SASTORE;
/*      */ import org.apache.bcel.generic.SWAP;
/*      */ import org.apache.bcel.generic.StoreInstruction;
/*      */ import org.apache.bcel.generic.Type;
/*      */ import org.apache.bcel.verifier.VerificationResult;
/*      */ import org.apache.bcel.verifier.Verifier;
/*      */ import org.apache.bcel.verifier.VerifierFactory;
/*      */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*      */ 
/*      */ public class InstConstraintVisitor extends EmptyVisitor implements Visitor {
/*   89 */   private static ObjectType GENERIC_ARRAY = new ObjectType("org.apache.bcel.verifier.structurals.GenericArray");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   private Frame frame = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   private ConstantPoolGen cpg = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   private MethodGen mg = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private OperandStack stack() { return this.frame.getStack(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   private LocalVariables locals() { return this.frame.getLocals(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void constraintViolated(Instruction violator, String description) {
/*  144 */     String fq_classname = violator.getClass().getName();
/*  145 */     throw new StructuralCodeConstraintException("Instruction " + fq_classname.substring(fq_classname.lastIndexOf('.') + 1) + " constraint violated: " + description);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   public void setFrame(Frame f) { this.frame = f; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   public void setConstantPoolGen(ConstantPoolGen cpg) { this.cpg = cpg; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   public void setMethodGen(MethodGen mg) { this.mg = mg; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void indexOfInt(Instruction o, Type index) {
/*  183 */     if (!index.equals(Type.INT)) {
/*  184 */       constraintViolated(o, "The 'index' is not of type int but of type " + index + ".");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void referenceTypeIsInitialized(Instruction o, ReferenceType r) {
/*  194 */     if (r instanceof UninitializedObjectType) {
/*  195 */       constraintViolated(o, "Working on an uninitialized object '" + r + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void valueOfInt(Instruction o, Type value) {
/*  201 */     if (!value.equals(Type.INT)) {
/*  202 */       constraintViolated(o, "The 'value' is not of type int but of type " + value + ".");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean arrayrefOfArrayType(Instruction o, Type arrayref) {
/*  211 */     if (!(arrayref instanceof ArrayType) && !arrayref.equals(Type.NULL))
/*  212 */       constraintViolated(o, "The 'arrayref' does not refer to an array but is of type " + arrayref + "."); 
/*  213 */     return arrayref instanceof ArrayType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _visitStackAccessor(Instruction o) {
/*  235 */     int consume = o.consumeStack(this.cpg);
/*  236 */     if (consume > stack().slotsUsed()) {
/*  237 */       constraintViolated(o, "Cannot consume " + consume + " stack slots: only " + stack().slotsUsed() + " slot(s) left on stack!\nStack:\n" + stack());
/*      */     }
/*      */     
/*  240 */     int produce = o.produceStack(this.cpg) - o.consumeStack(this.cpg);
/*  241 */     if (produce + stack().slotsUsed() > stack().maxStack()) {
/*  242 */       constraintViolated(o, "Cannot produce " + produce + " stack slots: only " + (stack().maxStack() - stack().slotsUsed()) + " free stack slot(s) left.\nStack:\n" + stack());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLoadClass(LoadClass o) {
/*  257 */     ObjectType t = o.getLoadClassType(this.cpg);
/*  258 */     if (t != null) {
/*  259 */       Verifier v = VerifierFactory.getVerifier(t.getClassName());
/*  260 */       VerificationResult vr = v.doPass2();
/*  261 */       if (vr.getStatus() != 1) {
/*  262 */         constraintViolated((Instruction)o, "Class '" + o.getLoadClassType(this.cpg).getClassName() + "' is referenced, but cannot be loaded and resolved: '" + vr + "'.");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  271 */   public void visitStackConsumer(StackConsumer o) { _visitStackAccessor((Instruction)o); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  278 */   public void visitStackProducer(StackProducer o) { _visitStackAccessor((Instruction)o); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitCPInstruction(CPInstruction o) {
/*  291 */     int idx = o.getIndex();
/*  292 */     if (idx < 0 || idx >= this.cpg.getSize()) {
/*  293 */       throw new AssertionViolatedException("Huh?! Constant pool index of instruction '" + o + "' illegal? Pass 3a should have checked this!");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFieldInstruction(FieldInstruction o) {
/*  305 */     Constant c = this.cpg.getConstant(o.getIndex());
/*  306 */     if (!(c instanceof org.apache.bcel.classfile.ConstantFieldref)) {
/*  307 */       constraintViolated(o, "Index '" + o.getIndex() + "' should refer to a CONSTANT_Fieldref_info structure, but refers to '" + c + "'.");
/*      */     }
/*      */     
/*  310 */     Type t = o.getType(this.cpg);
/*  311 */     if (t instanceof ObjectType) {
/*  312 */       String name = ((ObjectType)t).getClassName();
/*  313 */       Verifier v = VerifierFactory.getVerifier(name);
/*  314 */       VerificationResult vr = v.doPass2();
/*  315 */       if (vr.getStatus() != 1) {
/*  316 */         constraintViolated(o, "Class '" + name + "' is referenced, but cannot be loaded and resolved: '" + vr + "'.");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitInvokeInstruction(InvokeInstruction o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  335 */   public void visitStackInstruction(StackInstruction o) { _visitStackAccessor(o); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLocalVariableInstruction(LocalVariableInstruction o) {
/*  343 */     if (locals().maxLocals() <= ((o.getType(this.cpg).getSize() == 1) ? o.getIndex() : (o.getIndex() + 1))) {
/*  344 */       constraintViolated(o, "The 'index' is not a valid index into the local variable array.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLoadInstruction(LoadInstruction o) {
/*  355 */     if (locals().get(o.getIndex()) == Type.UNKNOWN) {
/*  356 */       constraintViolated(o, "Read-Access on local variable " + o.getIndex() + " with unknown content.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  362 */     if (o.getType(this.cpg).getSize() == 2 && 
/*  363 */       locals().get(o.getIndex() + true) != Type.UNKNOWN) {
/*  364 */       constraintViolated(o, "Reading a two-locals value from local variables " + o.getIndex() + " and " + (o.getIndex() + 1) + " where the latter one is destroyed.");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  369 */     if (!(o instanceof ALOAD)) {
/*  370 */       if (locals().get(o.getIndex()) != o.getType(this.cpg)) {
/*  371 */         constraintViolated(o, "Local Variable type and LOADing Instruction type mismatch: Local Variable: '" + locals().get(o.getIndex()) + "'; Instruction type: '" + o.getType(this.cpg) + "'.");
/*      */       
/*      */       }
/*      */     }
/*  375 */     else if (!(locals().get(o.getIndex()) instanceof ReferenceType)) {
/*  376 */       constraintViolated(o, "Local Variable type and LOADing Instruction type mismatch: Local Variable: '" + locals().get(o.getIndex()) + "'; Instruction expects a ReferenceType.");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  383 */     if (stack().maxStack() - stack().slotsUsed() < o.getType(this.cpg).getSize()) {
/*  384 */       constraintViolated(o, "Not enough free stack slots to load a '" + o.getType(this.cpg) + "' onto the OperandStack.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitStoreInstruction(StoreInstruction o) {
/*  394 */     if (stack().isEmpty()) {
/*  395 */       constraintViolated(o, "Cannot STORE: Stack to read from is empty.");
/*      */     }
/*      */     
/*  398 */     if (!(o instanceof ASTORE)) {
/*  399 */       if (stack().peek() != o.getType(this.cpg)) {
/*  400 */         constraintViolated(o, "Stack top type and STOREing Instruction type mismatch: Stack top: '" + stack().peek() + "'; Instruction type: '" + o.getType(this.cpg) + "'.");
/*      */       }
/*      */     } else {
/*      */       
/*  404 */       Type stacktop = stack().peek();
/*  405 */       if (!(stacktop instanceof ReferenceType) && !(stacktop instanceof ReturnaddressType)) {
/*  406 */         constraintViolated(o, "Stack top type and STOREing Instruction type mismatch: Stack top: '" + stack().peek() + "'; Instruction expects a ReferenceType or a ReturnadressType.");
/*      */       }
/*  408 */       if (stacktop instanceof ReferenceType) {
/*  409 */         referenceTypeIsInitialized(o, (ReferenceType)stacktop);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitReturnInstruction(ReturnInstruction o) {
/*  418 */     if (o instanceof RETURN) {
/*      */       return;
/*      */     }
/*  421 */     if (o instanceof ARETURN) {
/*  422 */       if (stack().peek() == Type.NULL) {
/*      */         return;
/*      */       }
/*      */       
/*  426 */       if (!(stack().peek() instanceof ReferenceType)) {
/*  427 */         constraintViolated(o, "Reference type expected on top of stack, but is: '" + stack().peek() + "'.");
/*      */       }
/*  429 */       referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  439 */       BasicType basicType = this.mg.getType();
/*  440 */       if (basicType == Type.BOOLEAN || 
/*  441 */         basicType == Type.BYTE || 
/*  442 */         basicType == Type.SHORT || 
/*  443 */         basicType == Type.CHAR) {
/*  444 */         basicType = Type.INT;
/*      */       }
/*  446 */       if (!basicType.equals(stack().peek())) {
/*  447 */         constraintViolated(o, "Current method has return type of '" + this.mg.getType() + "' expecting a '" + basicType + "' on top of the stack. But stack top is a '" + stack().peek() + "'.");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitAALOAD(AALOAD o) {
/*  460 */     Type arrayref = stack().peek(1);
/*  461 */     Type index = stack().peek(0);
/*      */     
/*  463 */     indexOfInt(o, index);
/*  464 */     if (arrayrefOfArrayType(o, arrayref)) {
/*  465 */       if (!(((ArrayType)arrayref).getElementType() instanceof ReferenceType)) {
/*  466 */         constraintViolated(o, "The 'arrayref' does not refer to an array with elements of a ReferenceType but to an array of " + ((ArrayType)arrayref).getElementType() + ".");
/*      */       }
/*  468 */       referenceTypeIsInitialized(o, (ReferenceType)((ArrayType)arrayref).getElementType());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitAASTORE(AASTORE o) {
/*  476 */     Type arrayref = stack().peek(2);
/*  477 */     Type index = stack().peek(1);
/*  478 */     Type value = stack().peek(0);
/*      */     
/*  480 */     indexOfInt(o, index);
/*  481 */     if (!(value instanceof ReferenceType)) {
/*  482 */       constraintViolated(o, "The 'value' is not of a ReferenceType but of type " + value + ".");
/*      */     } else {
/*  484 */       referenceTypeIsInitialized(o, (ReferenceType)value);
/*      */     } 
/*      */ 
/*      */     
/*  488 */     if (arrayrefOfArrayType(o, arrayref)) {
/*  489 */       if (!(((ArrayType)arrayref).getElementType() instanceof ReferenceType)) {
/*  490 */         constraintViolated(o, "The 'arrayref' does not refer to an array with elements of a ReferenceType but to an array of " + ((ArrayType)arrayref).getElementType() + ".");
/*      */       }
/*  492 */       if (!((ReferenceType)value).isAssignmentCompatibleWith((ReferenceType)((ArrayType)arrayref).getElementType())) {
/*  493 */         constraintViolated(o, "The type of 'value' ('" + value + "') is not assignment compatible to the components of the array 'arrayref' refers to. ('" + ((ArrayType)arrayref).getElementType() + "')");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitACONST_NULL(ACONST_NULL o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitALOAD(ALOAD o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitANEWARRAY(ANEWARRAY o) {
/*  518 */     if (!stack().peek().equals(Type.INT)) {
/*  519 */       constraintViolated(o, "The 'count' at the stack top is not of type '" + Type.INT + "' but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitARETURN(ARETURN o) {
/*  528 */     if (!(stack().peek() instanceof ReferenceType)) {
/*  529 */       constraintViolated(o, "The 'objectref' at the stack top is not of a ReferenceType but of type '" + stack().peek() + "'.");
/*      */     }
/*  531 */     ReferenceType objectref = (ReferenceType)stack().peek();
/*  532 */     referenceTypeIsInitialized(o, objectref);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitARRAYLENGTH(ARRAYLENGTH o) {
/*  546 */     Type arrayref = stack().peek(0);
/*  547 */     arrayrefOfArrayType(o, arrayref);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitASTORE(ASTORE o) {
/*  554 */     if (!(stack().peek() instanceof ReferenceType) && !(stack().peek() instanceof ReturnaddressType)) {
/*  555 */       constraintViolated(o, "The 'objectref' is not of a ReferenceType or of ReturnaddressType but of " + stack().peek() + ".");
/*      */     }
/*  557 */     if (stack().peek() instanceof ReferenceType) {
/*  558 */       referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitATHROW(ATHROW o) {
/*  568 */     if (!(stack().peek() instanceof ObjectType) && !stack().peek().equals(Type.NULL)) {
/*  569 */       constraintViolated(o, "The 'objectref' is not of an (initialized) ObjectType but of type " + stack().peek() + ".");
/*      */     }
/*      */ 
/*      */     
/*  573 */     if (stack().peek().equals(Type.NULL))
/*      */       return; 
/*  575 */     ObjectType exc = (ObjectType)stack().peek();
/*  576 */     ObjectType throwable = (ObjectType)Type.getType("Ljava/lang/Throwable;");
/*  577 */     if (!exc.subclassOf(throwable) && !exc.equals(throwable)) {
/*  578 */       constraintViolated(o, "The 'objectref' is not of class Throwable or of a subclass of Throwable, but of '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitBALOAD(BALOAD o) {
/*  586 */     Type arrayref = stack().peek(1);
/*  587 */     Type index = stack().peek(0);
/*  588 */     indexOfInt(o, index);
/*  589 */     if (arrayrefOfArrayType(o, arrayref) && 
/*  590 */       !((ArrayType)arrayref).getElementType().equals(Type.BOOLEAN) && 
/*  591 */       !((ArrayType)arrayref).getElementType().equals(Type.BYTE)) {
/*  592 */       constraintViolated(o, "The 'arrayref' does not refer to an array with elements of a Type.BYTE or Type.BOOLEAN but to an array of '" + ((ArrayType)arrayref).getElementType() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitBASTORE(BASTORE o) {
/*  601 */     Type arrayref = stack().peek(2);
/*  602 */     Type index = stack().peek(1);
/*  603 */     Type value = stack().peek(0);
/*      */     
/*  605 */     indexOfInt(o, index);
/*  606 */     valueOfInt(o, value);
/*  607 */     if (arrayrefOfArrayType(o, arrayref) && 
/*  608 */       !((ArrayType)arrayref).getElementType().equals(Type.BOOLEAN) && 
/*  609 */       !((ArrayType)arrayref).getElementType().equals(Type.BYTE)) {
/*  610 */       constraintViolated(o, "The 'arrayref' does not refer to an array with elements of a Type.BYTE or Type.BOOLEAN but to an array of '" + ((ArrayType)arrayref).getElementType() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitBIPUSH(BIPUSH o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  625 */   public void visitBREAKPOINT(BREAKPOINT o) { throw new AssertionViolatedException("In this JustIce verification pass there should not occur an illegal instruction such as BREAKPOINT."); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitCALOAD(CALOAD o) {
/*  632 */     Type arrayref = stack().peek(1);
/*  633 */     Type index = stack().peek(0);
/*      */     
/*  635 */     indexOfInt(o, index);
/*  636 */     arrayrefOfArrayType(o, arrayref);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitCASTORE(CASTORE o) {
/*  643 */     Type arrayref = stack().peek(2);
/*  644 */     Type index = stack().peek(1);
/*  645 */     Type value = stack().peek(0);
/*      */     
/*  647 */     indexOfInt(o, index);
/*  648 */     valueOfInt(o, value);
/*  649 */     if (arrayrefOfArrayType(o, arrayref) && 
/*  650 */       !((ArrayType)arrayref).getElementType().equals(Type.CHAR)) {
/*  651 */       constraintViolated(o, "The 'arrayref' does not refer to an array with elements of type char but to an array of type " + ((ArrayType)arrayref).getElementType() + ".");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitCHECKCAST(CHECKCAST o) {
/*  661 */     Type objectref = stack().peek(0);
/*  662 */     if (!(objectref instanceof ReferenceType)) {
/*  663 */       constraintViolated(o, "The 'objectref' is not of a ReferenceType but of type " + objectref + ".");
/*      */     } else {
/*      */       
/*  666 */       referenceTypeIsInitialized(o, (ReferenceType)objectref);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  671 */     Constant c = this.cpg.getConstant(o.getIndex());
/*  672 */     if (!(c instanceof org.apache.bcel.classfile.ConstantClass)) {
/*  673 */       constraintViolated(o, "The Constant at 'index' is not a ConstantClass, but '" + c + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitD2F(D2F o) {
/*  681 */     if (stack().peek() != Type.DOUBLE) {
/*  682 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitD2I(D2I o) {
/*  690 */     if (stack().peek() != Type.DOUBLE) {
/*  691 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitD2L(D2L o) {
/*  699 */     if (stack().peek() != Type.DOUBLE) {
/*  700 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDADD(DADD o) {
/*  708 */     if (stack().peek() != Type.DOUBLE) {
/*  709 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  711 */     if (stack().peek(true) != Type.DOUBLE) {
/*  712 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDALOAD(DALOAD o) {
/*  720 */     indexOfInt(o, stack().peek());
/*  721 */     if (stack().peek(true) == Type.NULL) {
/*      */       return;
/*      */     }
/*  724 */     if (!(stack().peek(1) instanceof ArrayType)) {
/*  725 */       constraintViolated(o, "Stack next-to-top must be of type double[] but is '" + stack().peek(1) + "'.");
/*      */     }
/*  727 */     Type t = ((ArrayType)stack().peek(1)).getBasicType();
/*  728 */     if (t != Type.DOUBLE) {
/*  729 */       constraintViolated(o, "Stack next-to-top must be of type double[] but is '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDASTORE(DASTORE o) {
/*  737 */     if (stack().peek() != Type.DOUBLE) {
/*  738 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  740 */     indexOfInt(o, stack().peek(1));
/*  741 */     if (stack().peek(2) == Type.NULL) {
/*      */       return;
/*      */     }
/*  744 */     if (!(stack().peek(2) instanceof ArrayType)) {
/*  745 */       constraintViolated(o, "Stack next-to-next-to-top must be of type double[] but is '" + stack().peek(2) + "'.");
/*      */     }
/*  747 */     Type t = ((ArrayType)stack().peek(2)).getBasicType();
/*  748 */     if (t != Type.DOUBLE) {
/*  749 */       constraintViolated(o, "Stack next-to-next-to-top must be of type double[] but is '" + stack().peek(2) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDCMPG(DCMPG o) {
/*  757 */     if (stack().peek() != Type.DOUBLE) {
/*  758 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  760 */     if (stack().peek(true) != Type.DOUBLE) {
/*  761 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDCMPL(DCMPL o) {
/*  769 */     if (stack().peek() != Type.DOUBLE) {
/*  770 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  772 */     if (stack().peek(true) != Type.DOUBLE) {
/*  773 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDCONST(DCONST o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDDIV(DDIV o) {
/*  788 */     if (stack().peek() != Type.DOUBLE) {
/*  789 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  791 */     if (stack().peek(true) != Type.DOUBLE) {
/*  792 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDLOAD(DLOAD o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDMUL(DMUL o) {
/*  809 */     if (stack().peek() != Type.DOUBLE) {
/*  810 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  812 */     if (stack().peek(true) != Type.DOUBLE) {
/*  813 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDNEG(DNEG o) {
/*  821 */     if (stack().peek() != Type.DOUBLE) {
/*  822 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDREM(DREM o) {
/*  830 */     if (stack().peek() != Type.DOUBLE) {
/*  831 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  833 */     if (stack().peek(true) != Type.DOUBLE) {
/*  834 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDRETURN(DRETURN o) {
/*  842 */     if (stack().peek() != Type.DOUBLE) {
/*  843 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDSTORE(DSTORE o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDSUB(DSUB o) {
/*  860 */     if (stack().peek() != Type.DOUBLE) {
/*  861 */       constraintViolated(o, "The value at the stack top is not of type 'double', but of type '" + stack().peek() + "'.");
/*      */     }
/*  863 */     if (stack().peek(true) != Type.DOUBLE) {
/*  864 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'double', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDUP(DUP o) {
/*  872 */     if (stack().peek().getSize() != 1) {
/*  873 */       constraintViolated(o, "Won't DUP type on stack top '" + stack().peek() + "' because it must occupy exactly one slot, not '" + stack().peek().getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDUP_X1(DUP_X1 o) {
/*  881 */     if (stack().peek().getSize() != 1) {
/*  882 */       constraintViolated(o, "Type on stack top '" + stack().peek() + "' should occupy exactly one slot, not '" + stack().peek().getSize() + "'.");
/*      */     }
/*  884 */     if (stack().peek(1).getSize() != 1) {
/*  885 */       constraintViolated(o, "Type on stack next-to-top '" + stack().peek(1) + "' should occupy exactly one slot, not '" + stack().peek(1).getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDUP_X2(DUP_X2 o) {
/*  893 */     if (stack().peek().getSize() != 1) {
/*  894 */       constraintViolated(o, "Stack top type must be of size 1, but is '" + stack().peek() + "' of size '" + stack().peek().getSize() + "'.");
/*      */     }
/*  896 */     if (stack().peek(1).getSize() == 2) {
/*      */       return;
/*      */     }
/*      */     
/*  900 */     if (stack().peek(2).getSize() != 1) {
/*  901 */       constraintViolated(o, "If stack top's size is 1 and stack next-to-top's size is 1, stack next-to-next-to-top's size must also be 1, but is: '" + stack().peek(2) + "' of size '" + stack().peek(2).getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDUP2(DUP2 o) {
/*  910 */     if (stack().peek().getSize() == 2) {
/*      */       return;
/*      */     }
/*      */     
/*  914 */     if (stack().peek(1).getSize() != 1) {
/*  915 */       constraintViolated(o, "If stack top's size is 1, then stack next-to-top's size must also be 1. But it is '" + stack().peek(1) + "' of size '" + stack().peek(1).getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDUP2_X1(DUP2_X1 o) {
/*  924 */     if (stack().peek().getSize() == 2) {
/*  925 */       if (stack().peek(1).getSize() != 1) {
/*  926 */         constraintViolated(o, "If stack top's size is 2, then stack next-to-top's size must be 1. But it is '" + stack().peek(1) + "' of size '" + stack().peek(1).getSize() + "'.");
/*      */       } else {
/*      */         
/*      */         return;
/*      */       } 
/*      */     } else {
/*      */       
/*  933 */       if (stack().peek(1).getSize() != 1) {
/*  934 */         constraintViolated(o, "If stack top's size is 1, then stack next-to-top's size must also be 1. But it is '" + stack().peek(1) + "' of size '" + stack().peek(1).getSize() + "'.");
/*      */       }
/*  936 */       if (stack().peek(2).getSize() != 1) {
/*  937 */         constraintViolated(o, "If stack top's size is 1, then stack next-to-next-to-top's size must also be 1. But it is '" + stack().peek(2) + "' of size '" + stack().peek(2).getSize() + "'.");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitDUP2_X2(DUP2_X2 o) {
/*  947 */     if (stack().peek(0).getSize() == 2) {
/*  948 */       if (stack().peek(1).getSize() == 2) {
/*      */         return;
/*      */       }
/*      */       
/*  952 */       if (stack().peek(2).getSize() != 1) {
/*  953 */         constraintViolated(o, "If stack top's size is 2 and stack-next-to-top's size is 1, then stack next-to-next-to-top's size must also be 1. But it is '" + stack().peek(2) + "' of size '" + stack().peek(2).getSize() + "'.");
/*      */       }
/*      */       else {
/*      */         
/*      */         return;
/*      */       }
/*      */     
/*      */     }
/*  961 */     else if (stack().peek(1).getSize() == 1) {
/*  962 */       if (stack().peek(2).getSize() == 2) {
/*      */         return;
/*      */       }
/*      */       
/*  966 */       if (stack().peek(3).getSize() == 1) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  972 */     constraintViolated(o, "The operand sizes on the stack do not match any of the four forms of usage of this instruction.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitF2D(F2D o) {
/*  979 */     if (stack().peek() != Type.FLOAT) {
/*  980 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitF2I(F2I o) {
/*  988 */     if (stack().peek() != Type.FLOAT) {
/*  989 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitF2L(F2L o) {
/*  997 */     if (stack().peek() != Type.FLOAT) {
/*  998 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFADD(FADD o) {
/* 1006 */     if (stack().peek() != Type.FLOAT) {
/* 1007 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1009 */     if (stack().peek(true) != Type.FLOAT) {
/* 1010 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFALOAD(FALOAD o) {
/* 1018 */     indexOfInt(o, stack().peek());
/* 1019 */     if (stack().peek(true) == Type.NULL) {
/*      */       return;
/*      */     }
/* 1022 */     if (!(stack().peek(1) instanceof ArrayType)) {
/* 1023 */       constraintViolated(o, "Stack next-to-top must be of type float[] but is '" + stack().peek(1) + "'.");
/*      */     }
/* 1025 */     Type t = ((ArrayType)stack().peek(1)).getBasicType();
/* 1026 */     if (t != Type.FLOAT) {
/* 1027 */       constraintViolated(o, "Stack next-to-top must be of type float[] but is '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFASTORE(FASTORE o) {
/* 1035 */     if (stack().peek() != Type.FLOAT) {
/* 1036 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1038 */     indexOfInt(o, stack().peek(1));
/* 1039 */     if (stack().peek(2) == Type.NULL) {
/*      */       return;
/*      */     }
/* 1042 */     if (!(stack().peek(2) instanceof ArrayType)) {
/* 1043 */       constraintViolated(o, "Stack next-to-next-to-top must be of type float[] but is '" + stack().peek(2) + "'.");
/*      */     }
/* 1045 */     Type t = ((ArrayType)stack().peek(2)).getBasicType();
/* 1046 */     if (t != Type.FLOAT) {
/* 1047 */       constraintViolated(o, "Stack next-to-next-to-top must be of type float[] but is '" + stack().peek(2) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFCMPG(FCMPG o) {
/* 1055 */     if (stack().peek() != Type.FLOAT) {
/* 1056 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1058 */     if (stack().peek(true) != Type.FLOAT) {
/* 1059 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFCMPL(FCMPL o) {
/* 1067 */     if (stack().peek() != Type.FLOAT) {
/* 1068 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1070 */     if (stack().peek(true) != Type.FLOAT) {
/* 1071 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFCONST(FCONST o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFDIV(FDIV o) {
/* 1086 */     if (stack().peek() != Type.FLOAT) {
/* 1087 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1089 */     if (stack().peek(true) != Type.FLOAT) {
/* 1090 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFLOAD(FLOAD o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFMUL(FMUL o) {
/* 1107 */     if (stack().peek() != Type.FLOAT) {
/* 1108 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1110 */     if (stack().peek(true) != Type.FLOAT) {
/* 1111 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFNEG(FNEG o) {
/* 1119 */     if (stack().peek() != Type.FLOAT) {
/* 1120 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFREM(FREM o) {
/* 1128 */     if (stack().peek() != Type.FLOAT) {
/* 1129 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1131 */     if (stack().peek(true) != Type.FLOAT) {
/* 1132 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFRETURN(FRETURN o) {
/* 1140 */     if (stack().peek() != Type.FLOAT) {
/* 1141 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFSTORE(FSTORE o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitFSUB(FSUB o) {
/* 1158 */     if (stack().peek() != Type.FLOAT) {
/* 1159 */       constraintViolated(o, "The value at the stack top is not of type 'float', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1161 */     if (stack().peek(true) != Type.FLOAT) {
/* 1162 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'float', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitGETFIELD(GETFIELD o) {
/* 1170 */     Type objectref = stack().peek();
/* 1171 */     if (!(objectref instanceof ObjectType) && objectref != Type.NULL) {
/* 1172 */       constraintViolated(o, "Stack top should be an object reference that's not an array reference, but is '" + objectref + "'.");
/*      */     }
/*      */     
/* 1175 */     String field_name = o.getFieldName(this.cpg);
/*      */     
/* 1177 */     JavaClass jc = Repository.lookupClass(o.getClassType(this.cpg).getClassName());
/* 1178 */     Field[] fields = jc.getFields();
/* 1179 */     Field f = null;
/* 1180 */     for (int i = 0; i < fields.length; i++) {
/* 1181 */       if (fields[i].getName().equals(field_name)) {
/* 1182 */         f = fields[i];
/*      */         break;
/*      */       } 
/*      */     } 
/* 1186 */     if (f == null) {
/* 1187 */       throw new AssertionViolatedException("Field not found?!?");
/*      */     }
/*      */     
/* 1190 */     if (f.isProtected()) {
/* 1191 */       ObjectType classtype = o.getClassType(this.cpg);
/* 1192 */       ObjectType curr = new ObjectType(this.mg.getClassName());
/*      */       
/* 1194 */       if (classtype.equals(curr) || 
/* 1195 */         curr.subclassOf(classtype)) {
/* 1196 */         Type t = stack().peek();
/* 1197 */         if (t == Type.NULL) {
/*      */           return;
/*      */         }
/* 1200 */         if (!(t instanceof ObjectType)) {
/* 1201 */           constraintViolated(o, "The 'objectref' must refer to an object that's not an array. Found instead: '" + t + "'.");
/*      */         }
/* 1203 */         ObjectType objreftype = (ObjectType)t;
/* 1204 */         if (!objreftype.equals(curr)) {
/* 1205 */           objreftype.subclassOf(curr);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1215 */     if (f.isStatic()) {
/* 1216 */       constraintViolated(o, "Referenced field '" + f + "' is static which it shouldn't be.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitGETSTATIC(GETSTATIC o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitGOTO(GOTO o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitGOTO_W(GOTO_W o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitI2B(I2B o) {
/* 1245 */     if (stack().peek() != Type.INT) {
/* 1246 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitI2C(I2C o) {
/* 1254 */     if (stack().peek() != Type.INT) {
/* 1255 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitI2D(I2D o) {
/* 1263 */     if (stack().peek() != Type.INT) {
/* 1264 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitI2F(I2F o) {
/* 1272 */     if (stack().peek() != Type.INT) {
/* 1273 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitI2L(I2L o) {
/* 1281 */     if (stack().peek() != Type.INT) {
/* 1282 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitI2S(I2S o) {
/* 1290 */     if (stack().peek() != Type.INT) {
/* 1291 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIADD(IADD o) {
/* 1299 */     if (stack().peek() != Type.INT) {
/* 1300 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1302 */     if (stack().peek(true) != Type.INT) {
/* 1303 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIALOAD(IALOAD o) {
/* 1311 */     indexOfInt(o, stack().peek());
/* 1312 */     if (stack().peek(true) == Type.NULL) {
/*      */       return;
/*      */     }
/* 1315 */     if (!(stack().peek(1) instanceof ArrayType)) {
/* 1316 */       constraintViolated(o, "Stack next-to-top must be of type int[] but is '" + stack().peek(1) + "'.");
/*      */     }
/* 1318 */     Type t = ((ArrayType)stack().peek(1)).getBasicType();
/* 1319 */     if (t != Type.INT) {
/* 1320 */       constraintViolated(o, "Stack next-to-top must be of type int[] but is '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIAND(IAND o) {
/* 1328 */     if (stack().peek() != Type.INT) {
/* 1329 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1331 */     if (stack().peek(true) != Type.INT) {
/* 1332 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIASTORE(IASTORE o) {
/* 1340 */     if (stack().peek() != Type.INT) {
/* 1341 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1343 */     indexOfInt(o, stack().peek(1));
/* 1344 */     if (stack().peek(2) == Type.NULL) {
/*      */       return;
/*      */     }
/* 1347 */     if (!(stack().peek(2) instanceof ArrayType)) {
/* 1348 */       constraintViolated(o, "Stack next-to-next-to-top must be of type int[] but is '" + stack().peek(2) + "'.");
/*      */     }
/* 1350 */     Type t = ((ArrayType)stack().peek(2)).getBasicType();
/* 1351 */     if (t != Type.INT) {
/* 1352 */       constraintViolated(o, "Stack next-to-next-to-top must be of type int[] but is '" + stack().peek(2) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitICONST(ICONST o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIDIV(IDIV o) {
/* 1367 */     if (stack().peek() != Type.INT) {
/* 1368 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1370 */     if (stack().peek(true) != Type.INT) {
/* 1371 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ACMPEQ(IF_ACMPEQ o) {
/* 1379 */     if (!(stack().peek() instanceof ReferenceType)) {
/* 1380 */       constraintViolated(o, "The value at the stack top is not of a ReferenceType, but of type '" + stack().peek() + "'.");
/*      */     }
/* 1382 */     referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */     
/* 1384 */     if (!(stack().peek(1) instanceof ReferenceType)) {
/* 1385 */       constraintViolated(o, "The value at the stack next-to-top is not of a ReferenceType, but of type '" + stack().peek(1) + "'.");
/*      */     }
/* 1387 */     referenceTypeIsInitialized(o, (ReferenceType)stack().peek(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ACMPNE(IF_ACMPNE o) {
/* 1395 */     if (!(stack().peek() instanceof ReferenceType)) {
/* 1396 */       constraintViolated(o, "The value at the stack top is not of a ReferenceType, but of type '" + stack().peek() + "'.");
/* 1397 */       referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */     } 
/* 1399 */     if (!(stack().peek(1) instanceof ReferenceType)) {
/* 1400 */       constraintViolated(o, "The value at the stack next-to-top is not of a ReferenceType, but of type '" + stack().peek(1) + "'.");
/* 1401 */       referenceTypeIsInitialized(o, (ReferenceType)stack().peek(1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ICMPEQ(IF_ICMPEQ o) {
/* 1409 */     if (stack().peek() != Type.INT) {
/* 1410 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1412 */     if (stack().peek(true) != Type.INT) {
/* 1413 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ICMPGE(IF_ICMPGE o) {
/* 1421 */     if (stack().peek() != Type.INT) {
/* 1422 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1424 */     if (stack().peek(true) != Type.INT) {
/* 1425 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ICMPGT(IF_ICMPGT o) {
/* 1433 */     if (stack().peek() != Type.INT) {
/* 1434 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1436 */     if (stack().peek(true) != Type.INT) {
/* 1437 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ICMPLE(IF_ICMPLE o) {
/* 1445 */     if (stack().peek() != Type.INT) {
/* 1446 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1448 */     if (stack().peek(true) != Type.INT) {
/* 1449 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ICMPLT(IF_ICMPLT o) {
/* 1457 */     if (stack().peek() != Type.INT) {
/* 1458 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1460 */     if (stack().peek(true) != Type.INT) {
/* 1461 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIF_ICMPNE(IF_ICMPNE o) {
/* 1469 */     if (stack().peek() != Type.INT) {
/* 1470 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1472 */     if (stack().peek(true) != Type.INT) {
/* 1473 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFEQ(IFEQ o) {
/* 1481 */     if (stack().peek() != Type.INT) {
/* 1482 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFGE(IFGE o) {
/* 1490 */     if (stack().peek() != Type.INT) {
/* 1491 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFGT(IFGT o) {
/* 1499 */     if (stack().peek() != Type.INT) {
/* 1500 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFLE(IFLE o) {
/* 1508 */     if (stack().peek() != Type.INT) {
/* 1509 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFLT(IFLT o) {
/* 1517 */     if (stack().peek() != Type.INT) {
/* 1518 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFNE(IFNE o) {
/* 1526 */     if (stack().peek() != Type.INT) {
/* 1527 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFNONNULL(IFNONNULL o) {
/* 1535 */     if (!(stack().peek() instanceof ReferenceType)) {
/* 1536 */       constraintViolated(o, "The value at the stack top is not of a ReferenceType, but of type '" + stack().peek() + "'.");
/*      */     }
/* 1538 */     referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIFNULL(IFNULL o) {
/* 1545 */     if (!(stack().peek() instanceof ReferenceType)) {
/* 1546 */       constraintViolated(o, "The value at the stack top is not of a ReferenceType, but of type '" + stack().peek() + "'.");
/*      */     }
/* 1548 */     referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIINC(IINC o) {
/* 1556 */     if (locals().maxLocals() <= ((o.getType(this.cpg).getSize() == 1) ? o.getIndex() : (o.getIndex() + 1))) {
/* 1557 */       constraintViolated(o, "The 'index' is not a valid index into the local variable array.");
/*      */     }
/*      */     
/* 1560 */     indexOfInt(o, locals().get(o.getIndex()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitILOAD(ILOAD o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1574 */   public void visitIMPDEP1(IMPDEP1 o) { throw new AssertionViolatedException("In this JustIce verification pass there should not occur an illegal instruction such as IMPDEP1."); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1581 */   public void visitIMPDEP2(IMPDEP2 o) { throw new AssertionViolatedException("In this JustIce verification pass there should not occur an illegal instruction such as IMPDEP2."); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIMUL(IMUL o) {
/* 1588 */     if (stack().peek() != Type.INT) {
/* 1589 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1591 */     if (stack().peek(true) != Type.INT) {
/* 1592 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitINEG(INEG o) {
/* 1600 */     if (stack().peek() != Type.INT) {
/* 1601 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitINSTANCEOF(INSTANCEOF o) {
/* 1610 */     Type objectref = stack().peek(0);
/* 1611 */     if (!(objectref instanceof ReferenceType)) {
/* 1612 */       constraintViolated(o, "The 'objectref' is not of a ReferenceType but of type " + objectref + ".");
/*      */     } else {
/*      */       
/* 1615 */       referenceTypeIsInitialized(o, (ReferenceType)objectref);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1620 */     Constant c = this.cpg.getConstant(o.getIndex());
/* 1621 */     if (!(c instanceof org.apache.bcel.classfile.ConstantClass)) {
/* 1622 */       constraintViolated(o, "The Constant at 'index' is not a ConstantClass, but '" + c + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitINVOKEINTERFACE(INVOKEINTERFACE o) {
/* 1632 */     int count = o.getCount();
/* 1633 */     if (count == 0) {
/* 1634 */       constraintViolated(o, "The 'count' argument must not be 0.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1642 */     Type t = o.getType(this.cpg);
/* 1643 */     if (t instanceof ObjectType) {
/* 1644 */       String name = ((ObjectType)t).getClassName();
/* 1645 */       Verifier v = VerifierFactory.getVerifier(name);
/* 1646 */       VerificationResult vr = v.doPass2();
/* 1647 */       if (vr.getStatus() != 1) {
/* 1648 */         constraintViolated(o, "Class '" + name + "' is referenced, but cannot be loaded and resolved: '" + vr + "'.");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1653 */     Type[] argtypes = o.getArgumentTypes(this.cpg);
/* 1654 */     int nargs = argtypes.length;
/*      */     
/* 1656 */     for (int i = nargs - 1; i >= 0; i--) {
/* 1657 */       Type fromStack = stack().peek(nargs - 1 - i);
/* 1658 */       BasicType basicType = argtypes[i];
/* 1659 */       if (basicType == Type.BOOLEAN || 
/* 1660 */         basicType == Type.BYTE || 
/* 1661 */         basicType == Type.CHAR || 
/* 1662 */         basicType == Type.SHORT) {
/* 1663 */         basicType = Type.INT;
/*      */       }
/* 1665 */       if (!fromStack.equals(basicType) && (
/* 1666 */         !(fromStack instanceof ReferenceType) || !(basicType instanceof ReferenceType)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1676 */         constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack.");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1681 */     Type objref = stack().peek(nargs);
/* 1682 */     if (objref == Type.NULL) {
/*      */       return;
/*      */     }
/* 1685 */     if (!(objref instanceof ReferenceType)) {
/* 1686 */       constraintViolated(o, "Expecting a reference type as 'objectref' on the stack, not a '" + objref + "'.");
/*      */     }
/* 1688 */     referenceTypeIsInitialized(o, (ReferenceType)objref);
/* 1689 */     if (!(objref instanceof ObjectType)) {
/* 1690 */       if (!(objref instanceof ArrayType)) {
/* 1691 */         constraintViolated(o, "Expecting an ObjectType as 'objectref' on the stack, not a '" + objref + "'.");
/*      */       } else {
/*      */         
/* 1694 */         ObjectType objectType = GENERIC_ARRAY;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1706 */     int counted_count = 1;
/* 1707 */     for (int i = 0; i < nargs; i++) {
/* 1708 */       counted_count += argtypes[i].getSize();
/*      */     }
/* 1710 */     if (count != counted_count) {
/* 1711 */       constraintViolated(o, "The 'count' argument should probably read '" + counted_count + "' but is '" + count + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitINVOKESPECIAL(INVOKESPECIAL o) {
/* 1720 */     if (o.getMethodName(this.cpg).equals("<init>") && !(stack().peek(o.getArgumentTypes(this.cpg).length) instanceof UninitializedObjectType)) {
/* 1721 */       constraintViolated(o, "Possibly initializing object twice. A valid instruction sequence must not have an uninitialized object on the operand stack or in a local variable during a backwards branch, or in a local variable in code protected by an exception handler. Please see The Java Virtual Machine Specification, Second Edition, 4.9.4 (pages 147 and 148) for details.");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1726 */     Type t = o.getType(this.cpg);
/* 1727 */     if (t instanceof ObjectType) {
/* 1728 */       String name = ((ObjectType)t).getClassName();
/* 1729 */       Verifier v = VerifierFactory.getVerifier(name);
/* 1730 */       VerificationResult vr = v.doPass2();
/* 1731 */       if (vr.getStatus() != 1) {
/* 1732 */         constraintViolated(o, "Class '" + name + "' is referenced, but cannot be loaded and resolved: '" + vr + "'.");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1737 */     Type[] argtypes = o.getArgumentTypes(this.cpg);
/* 1738 */     int nargs = argtypes.length;
/*      */     
/* 1740 */     for (int i = nargs - 1; i >= 0; i--) {
/* 1741 */       Type fromStack = stack().peek(nargs - 1 - i);
/* 1742 */       BasicType basicType = argtypes[i];
/* 1743 */       if (basicType == Type.BOOLEAN || 
/* 1744 */         basicType == Type.BYTE || 
/* 1745 */         basicType == Type.CHAR || 
/* 1746 */         basicType == Type.SHORT) {
/* 1747 */         basicType = Type.INT;
/*      */       }
/* 1749 */       if (!fromStack.equals(basicType)) {
/* 1750 */         if (fromStack instanceof ReferenceType && basicType instanceof ReferenceType) {
/* 1751 */           ReferenceType rFromStack = (ReferenceType)fromStack;
/* 1752 */           ReferenceType rFromDesc = (ReferenceType)basicType;
/*      */ 
/*      */           
/* 1755 */           if (!rFromStack.isAssignmentCompatibleWith(rFromDesc)) {
/* 1756 */             constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack (which is not assignment compatible).");
/*      */           }
/*      */         } else {
/*      */           
/* 1760 */           constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack.");
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1765 */     ObjectType objectType = stack().peek(nargs);
/* 1766 */     if (objectType == Type.NULL) {
/*      */       return;
/*      */     }
/* 1769 */     if (!(objectType instanceof ReferenceType)) {
/* 1770 */       constraintViolated(o, "Expecting a reference type as 'objectref' on the stack, not a '" + objectType + "'.");
/*      */     }
/* 1772 */     String objref_classname = null;
/* 1773 */     if (!o.getMethodName(this.cpg).equals("<init>")) {
/* 1774 */       referenceTypeIsInitialized(o, (ReferenceType)objectType);
/* 1775 */       if (!(objectType instanceof ObjectType)) {
/* 1776 */         if (!(objectType instanceof ArrayType)) {
/* 1777 */           constraintViolated(o, "Expecting an ObjectType as 'objectref' on the stack, not a '" + objectType + "'.");
/*      */         } else {
/*      */           
/* 1780 */           objectType = GENERIC_ARRAY;
/*      */         } 
/*      */       }
/*      */       
/* 1784 */       objref_classname = ((ObjectType)objectType).getClassName();
/*      */     } else {
/*      */       
/* 1787 */       if (!(objectType instanceof UninitializedObjectType)) {
/* 1788 */         constraintViolated(o, "Expecting an UninitializedObjectType as 'objectref' on the stack, not a '" + objectType + "'. Otherwise, you couldn't invoke a method since an array has no methods (not to speak of a return address).");
/*      */       }
/* 1790 */       objref_classname = ((UninitializedObjectType)objectType).getInitialized().getClassName();
/*      */     } 
/*      */ 
/*      */     
/* 1794 */     String theClass = o.getClassName(this.cpg);
/* 1795 */     if (!Repository.instanceOf(objref_classname, theClass)) {
/* 1796 */       constraintViolated(o, "The 'objref' item '" + objectType + "' does not implement '" + theClass + "' as expected.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitINVOKESTATIC(INVOKESTATIC o) {
/* 1807 */     Type t = o.getType(this.cpg);
/* 1808 */     if (t instanceof ObjectType) {
/* 1809 */       String name = ((ObjectType)t).getClassName();
/* 1810 */       Verifier v = VerifierFactory.getVerifier(name);
/* 1811 */       VerificationResult vr = v.doPass2();
/* 1812 */       if (vr.getStatus() != 1) {
/* 1813 */         constraintViolated(o, "Class '" + name + "' is referenced, but cannot be loaded and resolved: '" + vr + "'.");
/*      */       }
/*      */     } 
/*      */     
/* 1817 */     Type[] argtypes = o.getArgumentTypes(this.cpg);
/* 1818 */     int nargs = argtypes.length;
/*      */     
/* 1820 */     for (int i = nargs - 1; i >= 0; i--) {
/* 1821 */       Type fromStack = stack().peek(nargs - 1 - i);
/* 1822 */       BasicType basicType = argtypes[i];
/* 1823 */       if (basicType == Type.BOOLEAN || 
/* 1824 */         basicType == Type.BYTE || 
/* 1825 */         basicType == Type.CHAR || 
/* 1826 */         basicType == Type.SHORT) {
/* 1827 */         basicType = Type.INT;
/*      */       }
/* 1829 */       if (!fromStack.equals(basicType)) {
/* 1830 */         if (fromStack instanceof ReferenceType && basicType instanceof ReferenceType) {
/* 1831 */           ReferenceType rFromStack = (ReferenceType)fromStack;
/* 1832 */           ReferenceType rFromDesc = (ReferenceType)basicType;
/*      */ 
/*      */           
/* 1835 */           if (!rFromStack.isAssignmentCompatibleWith(rFromDesc)) {
/* 1836 */             constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack (which is not assignment compatible).");
/*      */           }
/*      */         } else {
/*      */           
/* 1840 */           constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack.");
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitINVOKEVIRTUAL(INVOKEVIRTUAL o) {
/* 1852 */     Type t = o.getType(this.cpg);
/* 1853 */     if (t instanceof ObjectType) {
/* 1854 */       String name = ((ObjectType)t).getClassName();
/* 1855 */       Verifier v = VerifierFactory.getVerifier(name);
/* 1856 */       VerificationResult vr = v.doPass2();
/* 1857 */       if (vr.getStatus() != 1) {
/* 1858 */         constraintViolated(o, "Class '" + name + "' is referenced, but cannot be loaded and resolved: '" + vr + "'.");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1863 */     Type[] argtypes = o.getArgumentTypes(this.cpg);
/* 1864 */     int nargs = argtypes.length;
/*      */     
/* 1866 */     for (int i = nargs - 1; i >= 0; i--) {
/* 1867 */       Type fromStack = stack().peek(nargs - 1 - i);
/* 1868 */       BasicType basicType = argtypes[i];
/* 1869 */       if (basicType == Type.BOOLEAN || 
/* 1870 */         basicType == Type.BYTE || 
/* 1871 */         basicType == Type.CHAR || 
/* 1872 */         basicType == Type.SHORT) {
/* 1873 */         basicType = Type.INT;
/*      */       }
/* 1875 */       if (!fromStack.equals(basicType)) {
/* 1876 */         if (fromStack instanceof ReferenceType && basicType instanceof ReferenceType) {
/* 1877 */           ReferenceType rFromStack = (ReferenceType)fromStack;
/* 1878 */           ReferenceType rFromDesc = (ReferenceType)basicType;
/*      */ 
/*      */           
/* 1881 */           if (!rFromStack.isAssignmentCompatibleWith(rFromDesc)) {
/* 1882 */             constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack (which is not assignment compatible).");
/*      */           }
/*      */         } else {
/*      */           
/* 1886 */           constraintViolated(o, "Expecting a '" + basicType + "' but found a '" + fromStack + "' on the stack.");
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1891 */     ObjectType objectType = stack().peek(nargs);
/* 1892 */     if (objectType == Type.NULL) {
/*      */       return;
/*      */     }
/* 1895 */     if (!(objectType instanceof ReferenceType)) {
/* 1896 */       constraintViolated(o, "Expecting a reference type as 'objectref' on the stack, not a '" + objectType + "'.");
/*      */     }
/* 1898 */     referenceTypeIsInitialized(o, (ReferenceType)objectType);
/* 1899 */     if (!(objectType instanceof ObjectType)) {
/* 1900 */       if (!(objectType instanceof ArrayType)) {
/* 1901 */         constraintViolated(o, "Expecting an ObjectType as 'objectref' on the stack, not a '" + objectType + "'.");
/*      */       } else {
/*      */         
/* 1904 */         objectType = GENERIC_ARRAY;
/*      */       } 
/*      */     }
/*      */     
/* 1908 */     String objref_classname = ((ObjectType)objectType).getClassName();
/*      */     
/* 1910 */     String theClass = o.getClassName(this.cpg);
/*      */     
/* 1912 */     if (!Repository.instanceOf(objref_classname, theClass)) {
/* 1913 */       constraintViolated(o, "The 'objref' item '" + objectType + "' does not implement '" + theClass + "' as expected.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIOR(IOR o) {
/* 1921 */     if (stack().peek() != Type.INT) {
/* 1922 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1924 */     if (stack().peek(true) != Type.INT) {
/* 1925 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIREM(IREM o) {
/* 1933 */     if (stack().peek() != Type.INT) {
/* 1934 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1936 */     if (stack().peek(true) != Type.INT) {
/* 1937 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIRETURN(IRETURN o) {
/* 1945 */     if (stack().peek() != Type.INT) {
/* 1946 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitISHL(ISHL o) {
/* 1954 */     if (stack().peek() != Type.INT) {
/* 1955 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1957 */     if (stack().peek(true) != Type.INT) {
/* 1958 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitISHR(ISHR o) {
/* 1966 */     if (stack().peek() != Type.INT) {
/* 1967 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1969 */     if (stack().peek(true) != Type.INT) {
/* 1970 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitISTORE(ISTORE o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitISUB(ISUB o) {
/* 1987 */     if (stack().peek() != Type.INT) {
/* 1988 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 1990 */     if (stack().peek(true) != Type.INT) {
/* 1991 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIUSHR(IUSHR o) {
/* 1999 */     if (stack().peek() != Type.INT) {
/* 2000 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2002 */     if (stack().peek(true) != Type.INT) {
/* 2003 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitIXOR(IXOR o) {
/* 2011 */     if (stack().peek() != Type.INT) {
/* 2012 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2014 */     if (stack().peek(true) != Type.INT) {
/* 2015 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'int', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitJSR(JSR o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitJSR_W(JSR_W o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitL2D(L2D o) {
/* 2037 */     if (stack().peek() != Type.LONG) {
/* 2038 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitL2F(L2F o) {
/* 2046 */     if (stack().peek() != Type.LONG) {
/* 2047 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitL2I(L2I o) {
/* 2055 */     if (stack().peek() != Type.LONG) {
/* 2056 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLADD(LADD o) {
/* 2064 */     if (stack().peek() != Type.LONG) {
/* 2065 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2067 */     if (stack().peek(true) != Type.LONG) {
/* 2068 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLALOAD(LALOAD o) {
/* 2076 */     indexOfInt(o, stack().peek());
/* 2077 */     if (stack().peek(true) == Type.NULL) {
/*      */       return;
/*      */     }
/* 2080 */     if (!(stack().peek(1) instanceof ArrayType)) {
/* 2081 */       constraintViolated(o, "Stack next-to-top must be of type long[] but is '" + stack().peek(1) + "'.");
/*      */     }
/* 2083 */     Type t = ((ArrayType)stack().peek(1)).getBasicType();
/* 2084 */     if (t != Type.LONG) {
/* 2085 */       constraintViolated(o, "Stack next-to-top must be of type long[] but is '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLAND(LAND o) {
/* 2093 */     if (stack().peek() != Type.LONG) {
/* 2094 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2096 */     if (stack().peek(true) != Type.LONG) {
/* 2097 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLASTORE(LASTORE o) {
/* 2105 */     if (stack().peek() != Type.LONG) {
/* 2106 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2108 */     indexOfInt(o, stack().peek(1));
/* 2109 */     if (stack().peek(2) == Type.NULL) {
/*      */       return;
/*      */     }
/* 2112 */     if (!(stack().peek(2) instanceof ArrayType)) {
/* 2113 */       constraintViolated(o, "Stack next-to-next-to-top must be of type long[] but is '" + stack().peek(2) + "'.");
/*      */     }
/* 2115 */     Type t = ((ArrayType)stack().peek(2)).getBasicType();
/* 2116 */     if (t != Type.LONG) {
/* 2117 */       constraintViolated(o, "Stack next-to-next-to-top must be of type long[] but is '" + stack().peek(2) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLCMP(LCMP o) {
/* 2125 */     if (stack().peek() != Type.LONG) {
/* 2126 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2128 */     if (stack().peek(true) != Type.LONG) {
/* 2129 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLCONST(LCONST o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLDC(LDC o) {
/* 2146 */     Constant c = this.cpg.getConstant(o.getIndex());
/* 2147 */     if (!(c instanceof org.apache.bcel.classfile.ConstantInteger) && 
/* 2148 */       !(c instanceof org.apache.bcel.classfile.ConstantFloat) && 
/* 2149 */       !(c instanceof org.apache.bcel.classfile.ConstantString)) {
/* 2150 */       constraintViolated(o, "Referenced constant should be a CONSTANT_Integer, a CONSTANT_Float or a CONSTANT_String, but is '" + c + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLDC_W(LDC_W o) {
/* 2160 */     Constant c = this.cpg.getConstant(o.getIndex());
/* 2161 */     if (!(c instanceof org.apache.bcel.classfile.ConstantInteger) && 
/* 2162 */       !(c instanceof org.apache.bcel.classfile.ConstantFloat) && 
/* 2163 */       !(c instanceof org.apache.bcel.classfile.ConstantString)) {
/* 2164 */       constraintViolated(o, "Referenced constant should be a CONSTANT_Integer, a CONSTANT_Float or a CONSTANT_String, but is '" + c + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLDC2_W(LDC2_W o) {
/* 2174 */     Constant c = this.cpg.getConstant(o.getIndex());
/* 2175 */     if (!(c instanceof org.apache.bcel.classfile.ConstantLong) && 
/* 2176 */       !(c instanceof org.apache.bcel.classfile.ConstantDouble)) {
/* 2177 */       constraintViolated(o, "Referenced constant should be a CONSTANT_Integer, a CONSTANT_Float or a CONSTANT_String, but is '" + c + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLDIV(LDIV o) {
/* 2185 */     if (stack().peek() != Type.LONG) {
/* 2186 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2188 */     if (stack().peek(true) != Type.LONG) {
/* 2189 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLLOAD(LLOAD o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLMUL(LMUL o) {
/* 2206 */     if (stack().peek() != Type.LONG) {
/* 2207 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2209 */     if (stack().peek(true) != Type.LONG) {
/* 2210 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLNEG(LNEG o) {
/* 2218 */     if (stack().peek() != Type.LONG) {
/* 2219 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLOOKUPSWITCH(LOOKUPSWITCH o) {
/* 2227 */     if (stack().peek() != Type.INT) {
/* 2228 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLOR(LOR o) {
/* 2237 */     if (stack().peek() != Type.LONG) {
/* 2238 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2240 */     if (stack().peek(true) != Type.LONG) {
/* 2241 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLREM(LREM o) {
/* 2249 */     if (stack().peek() != Type.LONG) {
/* 2250 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2252 */     if (stack().peek(true) != Type.LONG) {
/* 2253 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLRETURN(LRETURN o) {
/* 2261 */     if (stack().peek() != Type.LONG) {
/* 2262 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLSHL(LSHL o) {
/* 2270 */     if (stack().peek() != Type.INT) {
/* 2271 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2273 */     if (stack().peek(true) != Type.LONG) {
/* 2274 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLSHR(LSHR o) {
/* 2282 */     if (stack().peek() != Type.INT) {
/* 2283 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2285 */     if (stack().peek(true) != Type.LONG) {
/* 2286 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLSTORE(LSTORE o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLSUB(LSUB o) {
/* 2303 */     if (stack().peek() != Type.LONG) {
/* 2304 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2306 */     if (stack().peek(true) != Type.LONG) {
/* 2307 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLUSHR(LUSHR o) {
/* 2315 */     if (stack().peek() != Type.INT) {
/* 2316 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2318 */     if (stack().peek(true) != Type.LONG) {
/* 2319 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitLXOR(LXOR o) {
/* 2327 */     if (stack().peek() != Type.LONG) {
/* 2328 */       constraintViolated(o, "The value at the stack top is not of type 'long', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2330 */     if (stack().peek(true) != Type.LONG) {
/* 2331 */       constraintViolated(o, "The value at the stack next-to-top is not of type 'long', but of type '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitMONITORENTER(MONITORENTER o) {
/* 2339 */     if (!(stack().peek() instanceof ReferenceType)) {
/* 2340 */       constraintViolated(o, "The stack top should be of a ReferenceType, but is '" + stack().peek() + "'.");
/*      */     }
/* 2342 */     referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitMONITOREXIT(MONITOREXIT o) {
/* 2349 */     if (!(stack().peek() instanceof ReferenceType)) {
/* 2350 */       constraintViolated(o, "The stack top should be of a ReferenceType, but is '" + stack().peek() + "'.");
/*      */     }
/* 2352 */     referenceTypeIsInitialized(o, (ReferenceType)stack().peek());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitMULTIANEWARRAY(MULTIANEWARRAY o) {
/* 2359 */     int dimensions = o.getDimensions();
/*      */     
/* 2361 */     for (int i = 0; i < dimensions; i++) {
/* 2362 */       if (stack().peek(i) != Type.INT) {
/* 2363 */         constraintViolated(o, "The '" + dimensions + "' upper stack types should be 'int' but aren't.");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitNEW(NEW o) {
/* 2377 */     Type t = o.getType(this.cpg);
/* 2378 */     if (!(t instanceof ReferenceType)) {
/* 2379 */       throw new AssertionViolatedException("NEW.getType() returning a non-reference type?!");
/*      */     }
/* 2381 */     if (!(t instanceof ObjectType)) {
/* 2382 */       constraintViolated(o, "Expecting a class type (ObjectType) to work on. Found: '" + t + "'.");
/*      */     }
/* 2384 */     ObjectType obj = (ObjectType)t;
/*      */ 
/*      */     
/* 2387 */     if (!obj.referencesClass()) {
/* 2388 */       constraintViolated(o, "Expecting a class type (ObjectType) to work on. Found: '" + obj + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitNEWARRAY(NEWARRAY o) {
/* 2396 */     if (stack().peek() != Type.INT) {
/* 2397 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitNOP(NOP o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitPOP(POP o) {
/* 2412 */     if (stack().peek().getSize() != 1) {
/* 2413 */       constraintViolated(o, "Stack top size should be 1 but stack top is '" + stack().peek() + "' of size '" + stack().peek().getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitPOP2(POP2 o) {
/* 2421 */     if (stack().peek().getSize() != 2) {
/* 2422 */       constraintViolated(o, "Stack top size should be 2 but stack top is '" + stack().peek() + "' of size '" + stack().peek().getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitPUTFIELD(PUTFIELD o) {
/* 2431 */     Type objectref = stack().peek(1);
/* 2432 */     if (!(objectref instanceof ObjectType) && objectref != Type.NULL) {
/* 2433 */       constraintViolated(o, "Stack next-to-top should be an object reference that's not an array reference, but is '" + objectref + "'.");
/*      */     }
/*      */     
/* 2436 */     String field_name = o.getFieldName(this.cpg);
/*      */     
/* 2438 */     JavaClass jc = Repository.lookupClass(o.getClassType(this.cpg).getClassName());
/* 2439 */     Field[] fields = jc.getFields();
/* 2440 */     Field f = null;
/* 2441 */     for (int i = 0; i < fields.length; i++) {
/* 2442 */       if (fields[i].getName().equals(field_name)) {
/* 2443 */         f = fields[i];
/*      */         break;
/*      */       } 
/*      */     } 
/* 2447 */     if (f == null) {
/* 2448 */       throw new AssertionViolatedException("Field not found?!?");
/*      */     }
/*      */     
/* 2451 */     Type value = stack().peek();
/* 2452 */     Type t = Type.getType(f.getSignature());
/* 2453 */     BasicType basicType = t;
/* 2454 */     if (basicType == Type.BOOLEAN || 
/* 2455 */       basicType == Type.BYTE || 
/* 2456 */       basicType == Type.CHAR || 
/* 2457 */       basicType == Type.SHORT) {
/* 2458 */       basicType = Type.INT;
/*      */     }
/* 2460 */     if (t instanceof ReferenceType) {
/* 2461 */       ReferenceType rvalue = null;
/* 2462 */       if (value instanceof ReferenceType) {
/* 2463 */         rvalue = (ReferenceType)value;
/* 2464 */         referenceTypeIsInitialized(o, rvalue);
/*      */       } else {
/*      */         
/* 2467 */         constraintViolated(o, "The stack top type '" + value + "' is not of a reference type as expected.");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2472 */       if (!rvalue.isAssignmentCompatibleWith(basicType)) {
/* 2473 */         constraintViolated(o, "The stack top type '" + value + "' is not assignment compatible with '" + basicType + "'.");
/*      */       
/*      */       }
/*      */     }
/* 2477 */     else if (basicType != value) {
/* 2478 */       constraintViolated(o, "The stack top type '" + value + "' is not of type '" + basicType + "' as expected.");
/*      */     } 
/*      */ 
/*      */     
/* 2482 */     if (f.isProtected()) {
/* 2483 */       ObjectType classtype = o.getClassType(this.cpg);
/* 2484 */       ObjectType curr = new ObjectType(this.mg.getClassName());
/*      */       
/* 2486 */       if (classtype.equals(curr) || 
/* 2487 */         curr.subclassOf(classtype)) {
/* 2488 */         Type tp = stack().peek(1);
/* 2489 */         if (tp == Type.NULL) {
/*      */           return;
/*      */         }
/* 2492 */         if (!(tp instanceof ObjectType)) {
/* 2493 */           constraintViolated(o, "The 'objectref' must refer to an object that's not an array. Found instead: '" + tp + "'.");
/*      */         }
/* 2495 */         ObjectType objreftype = (ObjectType)tp;
/* 2496 */         if (!objreftype.equals(curr) && 
/* 2497 */           !objreftype.subclassOf(curr)) {
/* 2498 */           constraintViolated(o, "The referenced field has the ACC_PROTECTED modifier, and it's a member of the current class or a superclass of the current class. However, the referenced object type '" + stack().peek() + "' is not the current class or a subclass of the current class.");
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2504 */     if (f.isStatic()) {
/* 2505 */       constraintViolated(o, "Referenced field '" + f + "' is static which it shouldn't be.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitPUTSTATIC(PUTSTATIC o) {
/* 2513 */     String field_name = o.getFieldName(this.cpg);
/* 2514 */     JavaClass jc = Repository.lookupClass(o.getClassType(this.cpg).getClassName());
/* 2515 */     Field[] fields = jc.getFields();
/* 2516 */     Field f = null;
/* 2517 */     for (int i = 0; i < fields.length; i++) {
/* 2518 */       if (fields[i].getName().equals(field_name)) {
/* 2519 */         f = fields[i];
/*      */         break;
/*      */       } 
/*      */     } 
/* 2523 */     if (f == null) {
/* 2524 */       throw new AssertionViolatedException("Field not found?!?");
/*      */     }
/* 2526 */     Type value = stack().peek();
/* 2527 */     Type t = Type.getType(f.getSignature());
/* 2528 */     BasicType basicType = t;
/* 2529 */     if (basicType == Type.BOOLEAN || 
/* 2530 */       basicType == Type.BYTE || 
/* 2531 */       basicType == Type.CHAR || 
/* 2532 */       basicType == Type.SHORT) {
/* 2533 */       basicType = Type.INT;
/*      */     }
/* 2535 */     if (t instanceof ReferenceType) {
/* 2536 */       ReferenceType rvalue = null;
/* 2537 */       if (value instanceof ReferenceType) {
/* 2538 */         rvalue = (ReferenceType)value;
/* 2539 */         referenceTypeIsInitialized(o, rvalue);
/*      */       } else {
/*      */         
/* 2542 */         constraintViolated(o, "The stack top type '" + value + "' is not of a reference type as expected.");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2547 */       if (!rvalue.isAssignmentCompatibleWith(basicType)) {
/* 2548 */         constraintViolated(o, "The stack top type '" + value + "' is not assignment compatible with '" + basicType + "'.");
/*      */       
/*      */       }
/*      */     }
/* 2552 */     else if (basicType != value) {
/* 2553 */       constraintViolated(o, "The stack top type '" + value + "' is not of type '" + basicType + "' as expected.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitRET(RET o) {
/* 2564 */     if (!(locals().get(o.getIndex()) instanceof ReturnaddressType)) {
/* 2565 */       constraintViolated(o, "Expecting a ReturnaddressType in local variable " + o.getIndex() + ".");
/*      */     }
/* 2567 */     if (locals().get(o.getIndex()) == ReturnaddressType.NO_TARGET) {
/* 2568 */       throw new AssertionViolatedException("Oops: RET expecting a target!");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitRETURN(RETURN o) {
/* 2578 */     if (this.mg.getName().equals("<init>") && 
/* 2579 */       Frame._this != null && !this.mg.getClassName().equals(Type.OBJECT.getClassName())) {
/* 2580 */       constraintViolated(o, "Leaving a constructor that itself did not call a constructor.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitSALOAD(SALOAD o) {
/* 2589 */     indexOfInt(o, stack().peek());
/* 2590 */     if (stack().peek(true) == Type.NULL) {
/*      */       return;
/*      */     }
/* 2593 */     if (!(stack().peek(1) instanceof ArrayType)) {
/* 2594 */       constraintViolated(o, "Stack next-to-top must be of type short[] but is '" + stack().peek(1) + "'.");
/*      */     }
/* 2596 */     Type t = ((ArrayType)stack().peek(1)).getBasicType();
/* 2597 */     if (t != Type.SHORT) {
/* 2598 */       constraintViolated(o, "Stack next-to-top must be of type short[] but is '" + stack().peek(1) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitSASTORE(SASTORE o) {
/* 2606 */     if (stack().peek() != Type.INT) {
/* 2607 */       constraintViolated(o, "The value at the stack top is not of type 'int', but of type '" + stack().peek() + "'.");
/*      */     }
/* 2609 */     indexOfInt(o, stack().peek(1));
/* 2610 */     if (stack().peek(2) == Type.NULL) {
/*      */       return;
/*      */     }
/* 2613 */     if (!(stack().peek(2) instanceof ArrayType)) {
/* 2614 */       constraintViolated(o, "Stack next-to-next-to-top must be of type short[] but is '" + stack().peek(2) + "'.");
/*      */     }
/* 2616 */     Type t = ((ArrayType)stack().peek(2)).getBasicType();
/* 2617 */     if (t != Type.SHORT) {
/* 2618 */       constraintViolated(o, "Stack next-to-next-to-top must be of type short[] but is '" + stack().peek(2) + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitSIPUSH(SIPUSH o) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitSWAP(SWAP o) {
/* 2633 */     if (stack().peek().getSize() != 1) {
/* 2634 */       constraintViolated(o, "The value at the stack top is not of size '1', but of size '" + stack().peek().getSize() + "'.");
/*      */     }
/* 2636 */     if (stack().peek(1).getSize() != 1) {
/* 2637 */       constraintViolated(o, "The value at the stack next-to-top is not of size '1', but of size '" + stack().peek(1).getSize() + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2645 */   public void visitTABLESWITCH(TABLESWITCH o) { indexOfInt(o, stack().peek()); }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\InstConstraintVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */