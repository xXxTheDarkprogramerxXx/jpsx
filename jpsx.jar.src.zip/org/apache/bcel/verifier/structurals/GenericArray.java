package org.apache.bcel.verifier.structurals;

import java.io.Serializable;

public class GenericArray implements Cloneable, Serializable {}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\GenericArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */