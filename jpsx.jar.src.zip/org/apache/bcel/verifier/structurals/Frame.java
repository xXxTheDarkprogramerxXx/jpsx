/*     */ package org.apache.bcel.verifier.structurals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Frame
/*     */ {
/*     */   protected static UninitializedObjectType _this;
/*     */   private LocalVariables locals;
/*     */   private OperandStack stack;
/*     */   
/*     */   public Frame(int maxLocals, int maxStack) {
/*  93 */     this.locals = new LocalVariables(maxLocals);
/*  94 */     this.stack = new OperandStack(maxStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Frame(LocalVariables locals, OperandStack stack) {
/* 101 */     this.locals = locals;
/* 102 */     this.stack = stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   protected Object clone() { return new Frame(this.locals.getClone(), this.stack.getClone()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public Frame getClone() { return (Frame)clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public LocalVariables getLocals() { return this.locals; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public OperandStack getStack() { return this.stack; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 138 */     if (!(o instanceof Frame)) return false; 
/* 139 */     Frame f = (Frame)o;
/* 140 */     return (this.stack.equals(f.stack) && this.locals.equals(f.locals));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     s = "Local Variables:\n";
/* 148 */     s = String.valueOf(s) + this.locals;
/* 149 */     s = String.valueOf(s) + "OperandStack:\n";
/* 150 */     return String.valueOf(s) + this.stack;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\Frame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */