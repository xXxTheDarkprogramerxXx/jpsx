/*    */ package org.apache.bcel.verifier.structurals;
/*    */ 
/*    */ import org.apache.bcel.Constants;
/*    */ import org.apache.bcel.generic.ObjectType;
/*    */ import org.apache.bcel.generic.ReferenceType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UninitializedObjectType
/*    */   extends ReferenceType
/*    */   implements Constants
/*    */ {
/*    */   private ObjectType initialized;
/*    */   
/*    */   public UninitializedObjectType(ObjectType t) {
/* 75 */     super((byte)15, "<UNINITIALIZED OBJECT OF TYPE '" + t.getClassName() + "'>");
/* 76 */     this.initialized = t;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 84 */   public ObjectType getInitialized() { return this.initialized; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 94 */     if (!(o instanceof UninitializedObjectType)) return false; 
/* 95 */     return this.initialized.equals(((UninitializedObjectType)o).initialized);
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\structurals\UninitializedObjectType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */