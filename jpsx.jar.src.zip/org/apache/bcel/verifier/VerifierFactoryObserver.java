package org.apache.bcel.verifier;

public interface VerifierFactoryObserver {
  void update(String paramString);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\VerifierFactoryObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */