/*     */ package org.apache.bcel.verifier;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.event.ListDataEvent;
/*     */ import javax.swing.event.ListDataListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VerifierFactoryListModel
/*     */   implements VerifierFactoryObserver, ListModel
/*     */ {
/*     */   private ArrayList listeners;
/*     */   private TreeSet cache;
/*     */   
/*     */   public VerifierFactoryListModel() {
/*  67 */     this.listeners = new ArrayList();
/*     */     
/*  69 */     this.cache = new TreeSet();
/*     */ 
/*     */     
/*  72 */     VerifierFactory.attach(this);
/*  73 */     update(null);
/*     */   }
/*     */   
/*     */   public void update(String s) {
/*  77 */     int size = this.listeners.size();
/*     */     
/*  79 */     Verifier[] verifiers = VerifierFactory.getVerifiers();
/*  80 */     int num_of_verifiers = verifiers.length;
/*  81 */     this.cache.clear();
/*  82 */     for (int i = 0; i < num_of_verifiers; i++) {
/*  83 */       this.cache.add(verifiers[i].getClassName());
/*     */     }
/*     */     
/*  86 */     for (int i = 0; i < size; i++) {
/*  87 */       ListDataEvent e = new ListDataEvent(this, false, false, num_of_verifiers - 1);
/*  88 */       ((ListDataListener)this.listeners.get(i)).contentsChanged(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  93 */   public void addListDataListener(ListDataListener l) { this.listeners.add(l); }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void removeListDataListener(ListDataListener l) { this.listeners.remove(l); }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public int getSize() { return this.cache.size(); }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public Object getElementAt(int index) { return this.cache.toArray()[index]; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\VerifierFactoryListModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */