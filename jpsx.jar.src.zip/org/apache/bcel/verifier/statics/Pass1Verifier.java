/*     */ package org.apache.bcel.verifier.statics;
/*     */ 
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.verifier.PassVerifier;
/*     */ import org.apache.bcel.verifier.VerificationResult;
/*     */ import org.apache.bcel.verifier.Verifier;
/*     */ import org.apache.bcel.verifier.exc.LoadingException;
/*     */ import org.apache.bcel.verifier.exc.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Pass1Verifier
/*     */   extends PassVerifier
/*     */ {
/*     */   private JavaClass jc;
/*     */   private Verifier myOwner;
/*     */   
/*     */   private JavaClass getJavaClass() {
/*  87 */     if (this.jc == null) {
/*  88 */       this.jc = Repository.lookupClass(this.myOwner.getClassName());
/*     */     }
/*  90 */     return this.jc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public Pass1Verifier(Verifier owner) { this.myOwner = owner; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VerificationResult do_verify() {
/*     */     JavaClass jc;
/*     */     try {
/* 163 */       jc = getJavaClass();
/*     */       
/* 165 */       if (jc != null)
/*     */       {
/* 167 */         if (!this.myOwner.getClassName().equals(jc.getClassName()))
/*     */         {
/*     */           
/* 170 */           throw new LoadingException("Wrong name: the internal name of the .class file '" + jc.getClassName() + "' does not match the file's name '" + this.myOwner.getClassName() + "'.");
/*     */         
/*     */         }
/*     */       }
/*     */     }
/* 175 */     catch (LoadingException e) {
/* 176 */       return new VerificationResult(2, e.getMessage());
/*     */     }
/* 178 */     catch (ClassFormatError e) {
/*     */       
/* 180 */       return new VerificationResult(2, e.getMessage());
/*     */     }
/* 182 */     catch (RuntimeException e) {
/*     */ 
/*     */       
/* 185 */       return new VerificationResult(2, "Parsing via BCEL did not succeed. " + e.getClass().getName() + " occured:\n" + Utility.getStackTrace(e));
/*     */     } 
/*     */     
/* 188 */     if (jc != null) {
/* 189 */       return VerificationResult.VR_OK;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 194 */     return new VerificationResult(2, "Repository.lookup() failed. FILE NOT FOUND?");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public String[] getMessages() { return super.getMessages(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\Pass1Verifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */