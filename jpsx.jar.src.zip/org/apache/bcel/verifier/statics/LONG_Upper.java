/*    */ package org.apache.bcel.verifier.statics;
/*    */ 
/*    */ import org.apache.bcel.generic.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LONG_Upper
/*    */   extends Type
/*    */ {
/* 68 */   private static LONG_Upper singleInstance = new LONG_Upper();
/*    */ 
/*    */ 
/*    */   
/* 72 */   private LONG_Upper() { super((byte)15, "Long_Upper"); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public static LONG_Upper theInstance() { return singleInstance; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\LONG_Upper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */