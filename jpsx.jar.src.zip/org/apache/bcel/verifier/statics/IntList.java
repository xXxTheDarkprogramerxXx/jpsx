/*    */ package org.apache.bcel.verifier.statics;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntList
/*    */ {
/* 70 */   private ArrayList theList = new ArrayList();
/*    */ 
/*    */ 
/*    */   
/* 74 */   void add(int i) { this.theList.add(new Integer(i)); }
/*    */ 
/*    */   
/*    */   boolean contains(int i) {
/* 78 */     Integer[] ints = new Integer[this.theList.size()];
/* 79 */     this.theList.toArray(ints);
/* 80 */     for (int j = 0; j < ints.length; j++) {
/* 81 */       if (i == ints[j].intValue()) return true; 
/*    */     } 
/* 83 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\IntList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */