/*     */ package org.apache.bcel.verifier.statics;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import org.apache.bcel.generic.Type;
/*     */ import org.apache.bcel.verifier.exc.LocalVariableInfoInconsistentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariableInfo
/*     */ {
/*  73 */   private Hashtable types = new Hashtable();
/*     */   
/*  75 */   private Hashtable names = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private void setName(int offset, String name) { this.names.put(Integer.toString(offset), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private void setType(int offset, Type t) { this.types.put(Integer.toString(offset), t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public Type getType(int offset) { return (Type)this.types.get(Integer.toString(offset)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public String getName(int offset) { return (String)this.names.get(Integer.toString(offset)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String name, int startpc, int length, Type t) throws LocalVariableInfoInconsistentException {
/* 120 */     for (int i = startpc; i <= startpc + length; i++) {
/* 121 */       add(i, name, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void add(int offset, String name, Type t) throws LocalVariableInfoInconsistentException {
/* 131 */     if (getName(offset) != null && 
/* 132 */       !getName(offset).equals(name)) {
/* 133 */       throw new LocalVariableInfoInconsistentException("At bytecode offset '" + offset + "' a local variable has two different names: '" + getName(offset) + "' and '" + name + "'.");
/*     */     }
/*     */     
/* 136 */     if (getType(offset) != null && 
/* 137 */       !getType(offset).equals(t)) {
/* 138 */       throw new LocalVariableInfoInconsistentException("At bytecode offset '" + offset + "' a local variable has two different types: '" + getType(offset) + "' and '" + t + "'.");
/*     */     }
/*     */     
/* 141 */     setName(offset, name);
/* 142 */     setType(offset, t);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\LocalVariableInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */