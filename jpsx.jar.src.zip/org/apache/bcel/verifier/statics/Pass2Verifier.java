/*      */ package org.apache.bcel.verifier.statics;
/*      */ 
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import org.apache.bcel.Constants;
/*      */ import org.apache.bcel.Repository;
/*      */ import org.apache.bcel.classfile.Attribute;
/*      */ import org.apache.bcel.classfile.Code;
/*      */ import org.apache.bcel.classfile.CodeException;
/*      */ import org.apache.bcel.classfile.Constant;
/*      */ import org.apache.bcel.classfile.ConstantClass;
/*      */ import org.apache.bcel.classfile.ConstantDouble;
/*      */ import org.apache.bcel.classfile.ConstantFieldref;
/*      */ import org.apache.bcel.classfile.ConstantFloat;
/*      */ import org.apache.bcel.classfile.ConstantInteger;
/*      */ import org.apache.bcel.classfile.ConstantInterfaceMethodref;
/*      */ import org.apache.bcel.classfile.ConstantLong;
/*      */ import org.apache.bcel.classfile.ConstantMethodref;
/*      */ import org.apache.bcel.classfile.ConstantNameAndType;
/*      */ import org.apache.bcel.classfile.ConstantPool;
/*      */ import org.apache.bcel.classfile.ConstantString;
/*      */ import org.apache.bcel.classfile.ConstantUtf8;
/*      */ import org.apache.bcel.classfile.ConstantValue;
/*      */ import org.apache.bcel.classfile.Deprecated;
/*      */ import org.apache.bcel.classfile.DescendingVisitor;
/*      */ import org.apache.bcel.classfile.EmptyVisitor;
/*      */ import org.apache.bcel.classfile.ExceptionTable;
/*      */ import org.apache.bcel.classfile.Field;
/*      */ import org.apache.bcel.classfile.InnerClass;
/*      */ import org.apache.bcel.classfile.InnerClasses;
/*      */ import org.apache.bcel.classfile.JavaClass;
/*      */ import org.apache.bcel.classfile.LineNumber;
/*      */ import org.apache.bcel.classfile.LineNumberTable;
/*      */ import org.apache.bcel.classfile.LocalVariable;
/*      */ import org.apache.bcel.classfile.LocalVariableTable;
/*      */ import org.apache.bcel.classfile.Method;
/*      */ import org.apache.bcel.classfile.Node;
/*      */ import org.apache.bcel.classfile.SourceFile;
/*      */ import org.apache.bcel.classfile.Synthetic;
/*      */ import org.apache.bcel.classfile.Unknown;
/*      */ import org.apache.bcel.classfile.Visitor;
/*      */ import org.apache.bcel.generic.ArrayType;
/*      */ import org.apache.bcel.generic.ObjectType;
/*      */ import org.apache.bcel.generic.Type;
/*      */ import org.apache.bcel.verifier.PassVerifier;
/*      */ import org.apache.bcel.verifier.VerificationResult;
/*      */ import org.apache.bcel.verifier.Verifier;
/*      */ import org.apache.bcel.verifier.VerifierFactory;
/*      */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*      */ import org.apache.bcel.verifier.exc.ClassConstraintException;
/*      */ import org.apache.bcel.verifier.exc.LocalVariableInfoInconsistentException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Pass2Verifier
/*      */   extends PassVerifier
/*      */   implements Constants
/*      */ {
/*      */   private LocalVariablesInfo[] localVariablesInfos;
/*      */   private Verifier myOwner;
/*      */   
/*  100 */   public Pass2Verifier(Verifier owner) { this.myOwner = owner; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalVariablesInfo getLocalVariablesInfo(int method_nr) {
/*  113 */     if (verify() != VerificationResult.VR_OK) return null; 
/*  114 */     if (method_nr < 0 || method_nr >= this.localVariablesInfos.length) {
/*  115 */       throw new AssertionViolatedException("Method number out of range.");
/*      */     }
/*  117 */     return this.localVariablesInfos[method_nr];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VerificationResult do_verify() {
/*  143 */     VerificationResult vr1 = this.myOwner.doPass1();
/*  144 */     if (vr1.equals(VerificationResult.VR_OK)) {
/*      */ 
/*      */ 
/*      */       
/*  148 */       this.localVariablesInfos = new LocalVariablesInfo[Repository.lookupClass(this.myOwner.getClassName()).getMethods().length];
/*      */       
/*  150 */       VerificationResult vr = VerificationResult.VR_OK;
/*      */       try {
/*  152 */         constant_pool_entries_satisfy_static_constraints();
/*  153 */         field_and_method_refs_are_valid();
/*  154 */         every_class_has_an_accessible_superclass();
/*  155 */         final_methods_are_not_overridden();
/*      */       }
/*  157 */       catch (ClassConstraintException cce) {
/*  158 */         vr = new VerificationResult(2, cce.getMessage());
/*      */       } 
/*  160 */       return vr;
/*      */     } 
/*      */     
/*  163 */     return VerificationResult.VR_NOTYET;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void every_class_has_an_accessible_superclass() {
/*  180 */     HashSet hs = new HashSet();
/*  181 */     JavaClass jc = Repository.lookupClass(this.myOwner.getClassName());
/*  182 */     int supidx = -1;
/*      */     
/*  184 */     while (supidx != 0) {
/*  185 */       supidx = jc.getSuperclassNameIndex();
/*      */       
/*  187 */       if (supidx == 0) {
/*  188 */         if (jc != Repository.lookupClass(Type.OBJECT.getClassName())) {
/*  189 */           throw new ClassConstraintException("Superclass of '" + jc.getClassName() + "' missing but not " + Type.OBJECT.getClassName() + " itself!");
/*      */         }
/*      */         continue;
/*      */       } 
/*  193 */       String supername = jc.getSuperclassName();
/*  194 */       if (!hs.add(supername)) {
/*  195 */         throw new ClassConstraintException("Circular superclass hierarchy detected.");
/*      */       }
/*  197 */       Verifier v = VerifierFactory.getVerifier(supername);
/*  198 */       VerificationResult vr = v.doPass1();
/*      */       
/*  200 */       if (vr != VerificationResult.VR_OK) {
/*  201 */         throw new ClassConstraintException("Could not load in ancestor class '" + supername + "'.");
/*      */       }
/*  203 */       jc = Repository.lookupClass(supername);
/*      */       
/*  205 */       if (jc.isFinal()) {
/*  206 */         throw new ClassConstraintException("Ancestor class '" + supername + "' has the FINAL access modifier and must therefore not be subclassed.");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void final_methods_are_not_overridden() {
/*  224 */     HashMap hashmap = new HashMap();
/*  225 */     JavaClass jc = Repository.lookupClass(this.myOwner.getClassName());
/*      */     
/*  227 */     int supidx = -1;
/*  228 */     while (supidx != 0) {
/*  229 */       supidx = jc.getSuperclassNameIndex();
/*      */       
/*  231 */       Method[] methods = jc.getMethods();
/*  232 */       for (int i = 0; i < methods.length; i++) {
/*  233 */         String name_and_sig = String.valueOf(methods[i].getName()) + methods[i].getSignature();
/*      */         
/*  235 */         if (hashmap.containsKey(name_and_sig)) {
/*  236 */           if (methods[i].isFinal()) {
/*  237 */             throw new ClassConstraintException("Method '" + name_and_sig + "' in class '" + hashmap.get(name_and_sig) + "' overrides the final (not-overridable) definition in class '" + jc.getClassName() + "'.");
/*      */           }
/*      */           
/*  240 */           if (!methods[i].isStatic()) {
/*  241 */             hashmap.put(name_and_sig, jc.getClassName());
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  246 */         else if (!methods[i].isStatic()) {
/*  247 */           hashmap.put(name_and_sig, jc.getClassName());
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  252 */       jc = Repository.lookupClass(jc.getSuperclassName());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  267 */   private void constant_pool_entries_satisfy_static_constraints() { JavaClass jc = Repository.lookupClass(this.myOwner.getClassName()); }
/*      */ 
/*      */   
/*      */   private class CPESSC_Visitor
/*      */     extends EmptyVisitor
/*      */     implements Visitor
/*      */   {
/*      */     private Class CONST_Class;
/*      */     
/*      */     private Class CONST_String;
/*      */     
/*      */     private Class CONST_Integer;
/*      */     
/*      */     private Class CONST_Float;
/*      */     
/*      */     private Class CONST_Long;
/*      */     
/*      */     private Class CONST_Double;
/*      */     
/*      */     private Class CONST_NameAndType;
/*      */     
/*      */     private Class CONST_Utf8;
/*      */     private final JavaClass jc;
/*      */     private final ConstantPool cp;
/*      */     private final int cplen;
/*      */     private DescendingVisitor carrier;
/*      */     private HashSet field_names;
/*      */     private HashSet field_names_and_desc;
/*      */     private HashSet method_names_and_desc;
/*      */     
/*      */     private CPESSC_Visitor(JavaClass _jc) {
/*  298 */       this.field_names = new HashSet();
/*  299 */       this.field_names_and_desc = new HashSet();
/*  300 */       this.method_names_and_desc = new HashSet();
/*      */ 
/*      */       
/*  303 */       this.jc = _jc;
/*  304 */       this.cp = _jc.getConstantPool();
/*  305 */       this.cplen = this.cp.getLength();
/*      */       
/*  307 */       this.CONST_Class = ConstantClass.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  313 */       this.CONST_String = ConstantString.class;
/*  314 */       this.CONST_Integer = ConstantInteger.class;
/*  315 */       this.CONST_Float = ConstantFloat.class;
/*  316 */       this.CONST_Long = ConstantLong.class;
/*  317 */       this.CONST_Double = ConstantDouble.class;
/*  318 */       this.CONST_NameAndType = ConstantNameAndType.class;
/*  319 */       this.CONST_Utf8 = ConstantUtf8.class;
/*      */       
/*  321 */       this.carrier = new DescendingVisitor(_jc, this);
/*  322 */       this.carrier.visit();
/*      */     }
/*      */     
/*      */     private void checkIndex(Node referrer, int index, Class shouldbe) {
/*  326 */       if (index < 0 || index >= this.cplen)
/*  327 */         throw new ClassConstraintException("Invalid index '" + index + "' used by '" + 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1333 */             Pass2Verifier.tostring(referrer) + "'.");  Constant c = this.cp.getConstant(index); if (!shouldbe.isInstance(c)) throw new ClassCastException("Illegal constant '" + Pass2Verifier.tostring(c) + "' at index '" + index + "'. '" + Pass2Verifier.tostring(referrer) + "' expects a '" + shouldbe + "'.");  } public void visitJavaClass(JavaClass obj) { Attribute[] atts = obj.getAttributes(); boolean foundSourceFile = false; boolean foundInnerClasses = false; boolean hasInnerClass = (new Pass2Verifier.InnerClassDetector(Pass2Verifier.this, this.jc)).innerClassReferenced(); for (int i = 0; i < atts.length; i++) { if (!(atts[i] instanceof SourceFile) && !(atts[i] instanceof Deprecated) && !(atts[i] instanceof InnerClasses) && !(atts[i] instanceof Synthetic)) Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[i]) + "' as an attribute of the ClassFile structure '" + Pass2Verifier.tostring(obj) + "' is unknown and will therefore be ignored.");  if (atts[i] instanceof SourceFile) if (!foundSourceFile) { foundSourceFile = true; } else { throw new ClassConstraintException("A ClassFile structure (like '" + Pass2Verifier.tostring(obj) + "') may have no more than one SourceFile attribute."); }   if (atts[i] instanceof InnerClasses) { if (!foundInnerClasses) { foundInnerClasses = true; } else if (hasInnerClass) { throw new ClassConstraintException("A Classfile structure (like '" + Pass2Verifier.tostring(obj) + "') must have exactly one InnerClasses attribute if at least one Inner Class is referenced (which is the case). More than one InnerClasses attribute was found."); }  if (!hasInnerClass) Pass2Verifier.this.addMessage("No referenced Inner Class found, but InnerClasses attribute '" + Pass2Verifier.tostring(atts[i]) + "' found. Strongly suggest removal of that attribute.");  }  }  if (hasInnerClass && !foundInnerClasses) Pass2Verifier.this.addMessage("A Classfile structure (like '" + Pass2Verifier.tostring(obj) + "') must have exactly one InnerClasses attribute if at least one Inner Class is referenced (which is the case). No InnerClasses attribute was found.");  } public void visitConstantClass(ConstantClass obj) { if (obj.getTag() != 7) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); } public void visitConstantFieldref(ConstantFieldref obj) { if (obj.getTag() != 9) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  checkIndex(obj, obj.getClassIndex(), this.CONST_Class); checkIndex(obj, obj.getNameAndTypeIndex(), this.CONST_NameAndType); } public void visitConstantMethodref(ConstantMethodref obj) { if (obj.getTag() != 10) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  checkIndex(obj, obj.getClassIndex(), this.CONST_Class); checkIndex(obj, obj.getNameAndTypeIndex(), this.CONST_NameAndType); } public void visitConstantInterfaceMethodref(ConstantInterfaceMethodref obj) { if (obj.getTag() != 11) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  checkIndex(obj, obj.getClassIndex(), this.CONST_Class); checkIndex(obj, obj.getNameAndTypeIndex(), this.CONST_NameAndType); } public void visitConstantString(ConstantString obj) { if (obj.getTag() != 8) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  checkIndex(obj, obj.getStringIndex(), this.CONST_Utf8); } public void visitConstantInteger(ConstantInteger obj) { if (obj.getTag() != 3) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  } public void visitConstantFloat(ConstantFloat obj) { if (obj.getTag() != 4) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  } public void visitConstantLong(ConstantLong obj) { if (obj.getTag() != 5) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  } public void visitConstantDouble(ConstantDouble obj) { if (obj.getTag() != 6) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  } public void visitConstantNameAndType(ConstantNameAndType obj) { if (obj.getTag() != 12) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); checkIndex(obj, obj.getSignatureIndex(), this.CONST_Utf8); } public void visitConstantUtf8(ConstantUtf8 obj) { if (obj.getTag() != 1) throw new ClassConstraintException("Wrong constant tag in '" + Pass2Verifier.tostring(obj) + "'.");  } public void visitField(Field obj) { if (this.jc.isClass()) { int maxone = 0; if (obj.isPrivate()) maxone++;  if (obj.isProtected()) maxone++;  if (obj.isPublic()) maxone++;  if (maxone > 1) throw new ClassConstraintException("Field '" + Pass2Verifier.tostring(obj) + "' must only have at most one of its ACC_PRIVATE, ACC_PROTECTED, ACC_PUBLIC modifiers set.");  if (obj.isFinal() && obj.isVolatile()) throw new ClassConstraintException("Field '" + Pass2Verifier.tostring(obj) + "' must only have at most one of its ACC_FINAL, ACC_VOLATILE modifiers set.");  } else { if (!obj.isPublic()) throw new ClassConstraintException("Interface field '" + Pass2Verifier.tostring(obj) + "' must have the ACC_PUBLIC modifier set but hasn't!");  if (!obj.isStatic()) throw new ClassConstraintException("Interface field '" + Pass2Verifier.tostring(obj) + "' must have the ACC_STATIC modifier set but hasn't!");  if (!obj.isFinal()) throw new ClassConstraintException("Interface field '" + Pass2Verifier.tostring(obj) + "' must have the ACC_FINAL modifier set but hasn't!");  }  if ((obj.getAccessFlags() & 0xFFFFFF20) > 0) Pass2Verifier.this.addMessage("Field '" + Pass2Verifier.tostring(obj) + "' has access flag(s) other than ACC_PUBLIC, ACC_PRIVATE, ACC_PROTECTED, ACC_STATIC, ACC_FINAL, ACC_VOLATILE, ACC_TRANSIENT set (ignored).");  checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = obj.getName(); if (!Pass2Verifier.validFieldName(name)) throw new ClassConstraintException("Field '" + Pass2Verifier.tostring(obj) + "' has illegal name '" + obj.getName() + "'.");  checkIndex(obj, obj.getSignatureIndex(), this.CONST_Utf8); String sig = ((ConstantUtf8)this.cp.getConstant(obj.getSignatureIndex())).getBytes(); try { Type.getType(sig); } catch (ClassFormatError cfe) { throw new ClassConstraintException("Illegal descriptor (==signature) '" + sig + "' used by '" + Pass2Verifier.tostring(obj) + "'."); }  String nameanddesc = String.valueOf(name) + sig; if (this.field_names_and_desc.contains(nameanddesc)) throw new ClassConstraintException("No two fields (like '" + Pass2Verifier.tostring(obj) + "') are allowed have same names and descriptors!");  if (this.field_names.contains(name)) Pass2Verifier.this.addMessage("More than one field of name '" + name + "' detected (but with different type descriptors). This is very unusual.");  this.field_names_and_desc.add(nameanddesc); this.field_names.add(name); Attribute[] atts = obj.getAttributes(); for (int i = 0; i < atts.length; i++) { if (!(atts[i] instanceof ConstantValue) && !(atts[i] instanceof Synthetic) && !(atts[i] instanceof Deprecated)) Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[i]) + "' as an attribute of Field '" + Pass2Verifier.tostring(obj) + "' is unknown and will therefore be ignored.");  if (!(atts[i] instanceof ConstantValue)) Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[i]) + "' as an attribute of Field '" + Pass2Verifier.tostring(obj) + "' is not a ConstantValue and is therefore only of use for debuggers and such.");  }  } public void visitMethod(Method obj) { Type ts[], t; checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = obj.getName(); if (!Pass2Verifier.validMethodName(name, true)) throw new ClassConstraintException("Method '" + Pass2Verifier.tostring(obj) + "' has illegal name '" + name + "'.");  checkIndex(obj, obj.getSignatureIndex(), this.CONST_Utf8); String sig = ((ConstantUtf8)this.cp.getConstant(obj.getSignatureIndex())).getBytes(); try { t = Type.getReturnType(sig); ts = Type.getArgumentTypes(sig); } catch (ClassFormatError cfe) { throw new ClassConstraintException("Illegal descriptor (==signature) '" + sig + "' used by Method '" + Pass2Verifier.tostring(obj) + "'."); }  Type act = t; if (act instanceof ArrayType) act = ((ArrayType)act).getBasicType();  if (act instanceof ObjectType) { Verifier v = VerifierFactory.getVerifier(((ObjectType)act).getClassName()); VerificationResult vr = v.doPass1(); if (vr != VerificationResult.VR_OK) throw new ClassConstraintException("Method '" + Pass2Verifier.tostring(obj) + "' has a return type that does not pass verification pass 1: '" + vr + "'.");  }  for (int i = 0; i < ts.length; i++) { act = ts[i]; if (act instanceof ArrayType) act = ((ArrayType)act).getBasicType();  if (act instanceof ObjectType) { Verifier v = VerifierFactory.getVerifier(((ObjectType)act).getClassName()); VerificationResult vr = v.doPass1(); if (vr != VerificationResult.VR_OK) throw new ClassConstraintException("Method '" + Pass2Verifier.tostring(obj) + "' has an argument type that does not pass verification pass 1: '" + vr + "'.");  }  }  if (name.equals("<clinit>") && ts.length != 0) throw new ClassConstraintException("Method '" + Pass2Verifier.tostring(obj) + "' has illegal name '" + name + "'. It's name resembles the class or interface initialization method which it isn't because of its arguments (==descriptor).");  if (this.jc.isClass()) { int maxone = 0; if (obj.isPrivate()) maxone++;  if (obj.isProtected()) maxone++;  if (obj.isPublic()) maxone++;  if (maxone > 1) throw new ClassConstraintException("Method '" + Pass2Verifier.tostring(obj) + "' must only have at most one of its ACC_PRIVATE, ACC_PROTECTED, ACC_PUBLIC modifiers set.");  if (obj.isAbstract()) { if (obj.isFinal()) throw new ClassConstraintException("Abstract method '" + Pass2Verifier.tostring(obj) + "' must not have the ACC_FINAL modifier set.");  if (obj.isNative()) throw new ClassConstraintException("Abstract method '" + Pass2Verifier.tostring(obj) + "' must not have the ACC_NATIVE modifier set.");  if (obj.isPrivate()) throw new ClassConstraintException("Abstract method '" + Pass2Verifier.tostring(obj) + "' must not have the ACC_PRIVATE modifier set.");  if (obj.isStatic()) throw new ClassConstraintException("Abstract method '" + Pass2Verifier.tostring(obj) + "' must not have the ACC_STATIC modifier set.");  if (obj.isStrictfp()) throw new ClassConstraintException("Abstract method '" + Pass2Verifier.tostring(obj) + "' must not have the ACC_STRICT modifier set.");  if (obj.isSynchronized()) throw new ClassConstraintException("Abstract method '" + Pass2Verifier.tostring(obj) + "' must not have the ACC_SYNCHRONIZED modifier set.");  }  } else if (!name.equals("<clinit>")) { if (!obj.isPublic()) throw new ClassConstraintException("Interface method '" + Pass2Verifier.tostring(obj) + "' must have the ACC_PUBLIC modifier set but hasn't!");  if (!obj.isAbstract()) throw new ClassConstraintException("Interface method '" + Pass2Verifier.tostring(obj) + "' must have the ACC_STATIC modifier set but hasn't!");  if (obj.isPrivate() || obj.isProtected() || obj.isStatic() || obj.isFinal() || obj.isSynchronized() || obj.isNative() || obj.isStrictfp()) throw new ClassConstraintException("Interface method '" + Pass2Verifier.tostring(obj) + "' must not have any of the ACC_PRIVATE, ACC_PROTECTED, ACC_STATIC, ACC_FINAL, ACC_SYNCHRONIZED, ACC_NATIVE, ACC_ABSTRACT, ACC_STRICT modifiers set.");  }  if (name.equals("<init>")) if (obj.isStatic() || obj.isFinal() || obj.isSynchronized() || obj.isNative() || obj.isAbstract()) throw new ClassConstraintException("Instance initialization method '" + Pass2Verifier.tostring(obj) + "' must not have any of the ACC_STATIC, ACC_FINAL, ACC_SYNCHRONIZED, ACC_NATIVE, ACC_ABSTRACT modifiers set.");   if (name.equals("<clinit>")) { if ((obj.getAccessFlags() & 0xFFFFF7FF) > 0) Pass2Verifier.this.addMessage("Class or interface initialization method '" + Pass2Verifier.tostring(obj) + "' has superfluous access modifier(s) set: everything but ACC_STRICT is ignored.");  if (obj.isAbstract()) throw new ClassConstraintException("Class or interface initialization method '" + Pass2Verifier.tostring(obj) + "' must not be abstract. This contradicts the Java Language Specification, Second Edition (which omits this constraint) but is common practice of existing verifiers.");  }  if ((obj.getAccessFlags() & 0xFFFFF2C0) > 0) Pass2Verifier.this.addMessage("Method '" + Pass2Verifier.tostring(obj) + "' has access flag(s) other than ACC_PUBLIC, ACC_PRIVATE, ACC_PROTECTED, ACC_STATIC, ACC_FINAL, ACC_SYNCHRONIZED, ACC_NATIVE, ACC_ABSTRACT, ACC_STRICT set (ignored).");  String nameanddesc = String.valueOf(name) + sig; if (this.method_names_and_desc.contains(nameanddesc)) throw new ClassConstraintException("No two methods (like '" + Pass2Verifier.tostring(obj) + "') are allowed have same names and desciptors!");  this.method_names_and_desc.add(nameanddesc); Attribute[] atts = obj.getAttributes(); int num_code_atts = 0; for (int i = 0; i < atts.length; i++) { if (!(atts[i] instanceof Code) && !(atts[i] instanceof ExceptionTable) && !(atts[i] instanceof Synthetic) && !(atts[i] instanceof Deprecated)) Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[i]) + "' as an attribute of Method '" + Pass2Verifier.tostring(obj) + "' is unknown and will therefore be ignored.");  if (!(atts[i] instanceof Code) && !(atts[i] instanceof ExceptionTable)) Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[i]) + "' as an attribute of Method '" + Pass2Verifier.tostring(obj) + "' is neither Code nor Exceptions and is therefore only of use for debuggers and such.");  if (atts[i] instanceof Code && (obj.isNative() || obj.isAbstract())) throw new ClassConstraintException("Native or abstract methods like '" + Pass2Verifier.tostring(obj) + "' must not have a Code attribute like '" + Pass2Verifier.tostring(atts[i]) + "'.");  if (atts[i] instanceof Code) num_code_atts++;  }  if (!obj.isNative() && !obj.isAbstract() && num_code_atts != 1) throw new ClassConstraintException("Non-native, non-abstract methods like '" + Pass2Verifier.tostring(obj) + "' must have exactly one Code attribute (found: " + num_code_atts + ").");  } public void visitSourceFile(SourceFile obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("SourceFile")) throw new ClassConstraintException("The SourceFile attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'SourceFile' but '" + name + "'.");  checkIndex(obj, obj.getSourceFileIndex(), this.CONST_Utf8); String sourcefilename = ((ConstantUtf8)this.cp.getConstant(obj.getSourceFileIndex())).getBytes(); String sourcefilenamelc = sourcefilename.toLowerCase(); if (sourcefilename.indexOf('/') != -1 || sourcefilename.indexOf('\\') != -1 || sourcefilename.indexOf(':') != -1 || sourcefilenamelc.lastIndexOf(".java") == -1) Pass2Verifier.this.addMessage("SourceFile attribute '" + Pass2Verifier.tostring(obj) + "' has a funny name: remember not to confuse certain parsers working on javap's output. Also, this name ('" + sourcefilename + "') is considered an unqualified (simple) file name only.");  } public void visitDeprecated(Deprecated obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("Deprecated")) throw new ClassConstraintException("The Deprecated attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'Deprecated' but '" + name + "'.");  } public void visitSynthetic(Synthetic obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("Synthetic")) throw new ClassConstraintException("The Synthetic attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'Synthetic' but '" + name + "'.");  } public void visitInnerClasses(InnerClasses obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("InnerClasses")) throw new ClassConstraintException("The InnerClasses attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'InnerClasses' but '" + name + "'.");  InnerClass[] ics = obj.getInnerClasses(); for (int i = 0; i < ics.length; i++) { checkIndex(obj, ics[i].getInnerClassIndex(), this.CONST_Class); int outer_idx = ics[i].getOuterClassIndex(); if (outer_idx != 0) checkIndex(obj, outer_idx, this.CONST_Class);  int innername_idx = ics[i].getInnerNameIndex(); if (innername_idx != 0) checkIndex(obj, innername_idx, this.CONST_Utf8);  int acc = ics[i].getInnerAccessFlags(); acc &= 0xFFFFF9E0; if (acc != 0) Pass2Verifier.this.addMessage("Unknown access flag for inner class '" + Pass2Verifier.tostring(ics[i]) + "' set (InnerClasses attribute '" + Pass2Verifier.tostring(obj) + "').");  }  } public void visitConstantValue(ConstantValue obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("ConstantValue")) throw new ClassConstraintException("The ConstantValue attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'ConstantValue' but '" + name + "'.");  Object pred = this.carrier.predecessor(); if (pred instanceof Field) { Field f = (Field)pred; Type field_type = Type.getType(((ConstantUtf8)this.cp.getConstant(f.getSignatureIndex())).getBytes()); int index = obj.getConstantValueIndex(); if (index < 0 || index >= this.cplen) throw new ClassConstraintException("Invalid index '" + index + "' used by '" + Pass2Verifier.tostring(obj) + "'.");  Constant c = this.cp.getConstant(index); if (this.CONST_Long.isInstance(c) && field_type.equals(Type.LONG)) return;  if (this.CONST_Float.isInstance(c) && field_type.equals(Type.FLOAT)) return;  if (this.CONST_Double.isInstance(c) && field_type.equals(Type.DOUBLE)) return;  if (this.CONST_Integer.isInstance(c) && (field_type.equals(Type.INT) || field_type.equals(Type.SHORT) || field_type.equals(Type.CHAR) || field_type.equals(Type.BYTE) || field_type.equals(Type.BOOLEAN))) return;  if (this.CONST_String.isInstance(c) && field_type.equals(Type.STRING)) return;  throw new ClassConstraintException("Illegal type of ConstantValue '" + obj + "' embedding Constant '" + c + "'. It is referenced by field '" + Pass2Verifier.tostring(f) + "' expecting a different type: '" + field_type + "'."); }  } public void visitCode(Code obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("Code")) throw new ClassConstraintException("The Code attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'Code' but '" + name + "'.");  Method m = null; if (!(this.carrier.predecessor() instanceof Method)) { Pass2Verifier.this.addMessage("Code attribute '" + Pass2Verifier.tostring(obj) + "' is not declared in a method_info structure but in '" + this.carrier.predecessor() + "'. Ignored."); return; }  m = (Method)this.carrier.predecessor(); if (obj.getCode().length == 0) throw new ClassConstraintException("Code array of Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + m + "') must not be empty.");  CodeException[] exc_table = obj.getExceptionTable(); for (int i = 0; i < exc_table.length; i++) { int exc_index = exc_table[i].getCatchType(); if (exc_index != 0) { checkIndex(obj, exc_index, this.CONST_Class); ConstantClass cc = (ConstantClass)this.cp.getConstant(exc_index); checkIndex(cc, cc.getNameIndex(), this.CONST_Utf8); String cname = ((ConstantUtf8)this.cp.getConstant(cc.getNameIndex())).getBytes().replace('/', '.'); Verifier v = VerifierFactory.getVerifier(cname); VerificationResult vr = v.doPass1(); if (vr != VerificationResult.VR_OK) throw new ClassConstraintException("Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + m + "') has an exception_table entry '" + Pass2Verifier.tostring(exc_table[i]) + "' that references '" + cname + "' as an Exception but it does not pass verification pass 1: " + vr);  JavaClass e = Repository.lookupClass(cname); JavaClass t = Repository.lookupClass(Type.THROWABLE.getClassName()); JavaClass o = Repository.lookupClass(Type.OBJECT.getClassName()); while (e != o && e != t) { v = VerifierFactory.getVerifier(e.getSuperclassName()); vr = v.doPass1(); if (vr != VerificationResult.VR_OK) throw new ClassConstraintException("Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + m + "') has an exception_table entry '" + Pass2Verifier.tostring(exc_table[i]) + "' that references '" + cname + "' as an Exception but '" + e.getSuperclassName() + "' in the ancestor hierachy does not pass verification pass 1: " + vr);  e = Repository.lookupClass(e.getSuperclassName()); }  if (e != t) throw new ClassConstraintException("Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + m + "') has an exception_table entry '" + Pass2Verifier.tostring(exc_table[i]) + "' that references '" + cname + "' as an Exception but it is not a subclass of '" + t.getClassName() + "'.");  }  }  int method_number = -1; Method[] ms = Repository.lookupClass(Pass2Verifier.this.myOwner.getClassName()).getMethods(); for (int mn = 0; mn < ms.length; mn++) { if (m == ms[mn]) { method_number = mn; break; }  }  if (method_number < 0) throw new AssertionViolatedException("Could not find a known BCEL Method object in the corresponding BCEL JavaClass object.");  Pass2Verifier.this.localVariablesInfos[method_number] = new LocalVariablesInfo(obj.getMaxLocals()); int num_of_lvt_attribs = 0; Attribute[] atts = obj.getAttributes(); for (int a = 0; a < atts.length; a++) { if (!(atts[a] instanceof LineNumberTable) && !(atts[a] instanceof LocalVariableTable)) { Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[a]) + "' as an attribute of Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + m + "') is unknown and will therefore be ignored."); } else { Pass2Verifier.this.addMessage("Attribute '" + Pass2Verifier.tostring(atts[a]) + "' as an attribute of Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + m + "') will effectively be ignored and is only useful for debuggers and such."); }  if (atts[a] instanceof LocalVariableTable) { LocalVariableTable lvt = (LocalVariableTable)atts[a]; checkIndex(lvt, lvt.getNameIndex(), this.CONST_Utf8); String lvtname = ((ConstantUtf8)this.cp.getConstant(lvt.getNameIndex())).getBytes(); if (!lvtname.equals("LocalVariableTable")) throw new ClassConstraintException("The LocalVariableTable attribute '" + Pass2Verifier.tostring(lvt) + "' is not correctly named 'LocalVariableTable' but '" + lvtname + "'.");  Code code = obj; LocalVariable[] localvariables = lvt.getLocalVariableTable(); for (int i = 0; i < localvariables.length; i++) { Type t; checkIndex(lvt, localvariables[i].getNameIndex(), this.CONST_Utf8); String localname = ((ConstantUtf8)this.cp.getConstant(localvariables[i].getNameIndex())).getBytes(); if (!Pass2Verifier.validJavaIdentifier(localname)) throw new ClassConstraintException("LocalVariableTable '" + Pass2Verifier.tostring(lvt) + "' references a local variable by the name '" + localname + "' which is not a legal Java simple name.");  checkIndex(lvt, localvariables[i].getSignatureIndex(), this.CONST_Utf8); String localsig = ((ConstantUtf8)this.cp.getConstant(localvariables[i].getSignatureIndex())).getBytes(); try { t = Type.getType(localsig); } catch (ClassFormatError cfe) { throw new ClassConstraintException("Illegal descriptor (==signature) '" + localsig + "' used by LocalVariable '" + Pass2Verifier.tostring(localvariables[i]) + "' referenced by '" + Pass2Verifier.tostring(lvt) + "'."); }  int localindex = localvariables[i].getIndex(); if (((t == Type.LONG || t == Type.DOUBLE) ? (localindex + 1) : localindex) >= code.getMaxLocals()) throw new ClassConstraintException("LocalVariableTable attribute '" + Pass2Verifier.tostring(lvt) + "' references a LocalVariable '" + Pass2Verifier.tostring(localvariables[i]) + "' with an index that exceeds the surrounding Code attribute's max_locals value of '" + code.getMaxLocals() + "'.");  try { Pass2Verifier.this.localVariablesInfos[method_number].add(localindex, localname, localvariables[i].getStartPC(), localvariables[i].getLength(), t); } catch (LocalVariableInfoInconsistentException lviie) { throw new ClassConstraintException("Conflicting information in LocalVariableTable '" + Pass2Verifier.tostring(lvt) + "' found in Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + Pass2Verifier.tostring(m) + "'). " + lviie.getMessage()); }  }  num_of_lvt_attribs++; if (num_of_lvt_attribs > obj.getMaxLocals()) throw new ClassConstraintException("Number of LocalVariableTable attributes of Code attribute '" + Pass2Verifier.tostring(obj) + "' (method '" + Pass2Verifier.tostring(m) + "') exceeds number of local variable slots '" + obj.getMaxLocals() + "' ('There may be no more than one LocalVariableTable attribute per local variable in the Code attribute.').");  }  }  } public void visitExceptionTable(ExceptionTable obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("Exceptions")) throw new ClassConstraintException("The Exceptions attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'Exceptions' but '" + name + "'.");  int[] exc_indices = obj.getExceptionIndexTable(); for (int i = 0; i < exc_indices.length; i++) { checkIndex(obj, exc_indices[i], this.CONST_Class); ConstantClass cc = (ConstantClass)this.cp.getConstant(exc_indices[i]); checkIndex(cc, cc.getNameIndex(), this.CONST_Utf8); String cname = ((ConstantUtf8)this.cp.getConstant(cc.getNameIndex())).getBytes().replace('/', '.'); Verifier v = VerifierFactory.getVerifier(cname); VerificationResult vr = v.doPass1(); if (vr != VerificationResult.VR_OK) throw new ClassConstraintException("Exceptions attribute '" + Pass2Verifier.tostring(obj) + "' references '" + cname + "' as an Exception but it does not pass verification pass 1: " + vr);  JavaClass e = Repository.lookupClass(cname); JavaClass t = Repository.lookupClass(Type.THROWABLE.getClassName()); JavaClass o = Repository.lookupClass(Type.OBJECT.getClassName()); while (e != o && e != t) { v = VerifierFactory.getVerifier(e.getSuperclassName()); vr = v.doPass1(); if (vr != VerificationResult.VR_OK) throw new ClassConstraintException("Exceptions attribute '" + Pass2Verifier.tostring(obj) + "' references '" + cname + "' as an Exception but '" + e.getSuperclassName() + "' in the ancestor hierachy does not pass verification pass 1: " + vr);  e = Repository.lookupClass(e.getSuperclassName()); }  if (e != t) throw new ClassConstraintException("Exceptions attribute '" + Pass2Verifier.tostring(obj) + "' references '" + cname + "' as an Exception but it is not a subclass of '" + t.getClassName() + "'.");  }  } public void visitLineNumberTable(LineNumberTable obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); String name = ((ConstantUtf8)this.cp.getConstant(obj.getNameIndex())).getBytes(); if (!name.equals("LineNumberTable")) throw new ClassConstraintException("The LineNumberTable attribute '" + Pass2Verifier.tostring(obj) + "' is not correctly named 'LineNumberTable' but '" + name + "'.");  } public void visitLocalVariableTable(LocalVariableTable obj) {} public void visitUnknown(Unknown obj) { checkIndex(obj, obj.getNameIndex(), this.CONST_Utf8); Pass2Verifier.this.addMessage("Unknown attribute '" + Pass2Verifier.tostring(obj) + "'. This attribute is not known in any context!"); } public void visitLocalVariable(LocalVariable obj) {} public void visitCodeException(CodeException obj) {} public void visitConstantPool(ConstantPool obj) {} public void visitInnerClass(InnerClass obj) {} public void visitLineNumber(LineNumber obj) {} } private void field_and_method_refs_are_valid() { JavaClass jc = Repository.lookupClass(this.myOwner.getClassName()); DescendingVisitor v = new DescendingVisitor(jc, new FAMRAV_Visitor(this, jc, null)); v.visit(); } private class FAMRAV_Visitor extends EmptyVisitor implements Visitor { private final ConstantPool cp; public void visitConstantFieldref(ConstantFieldref obj) { if (obj.getTag() != 9) throw new ClassConstraintException("ConstantFieldref '" + Pass2Verifier.tostring(obj) + "' has wrong tag!");  int name_and_type_index = obj.getNameAndTypeIndex(); ConstantNameAndType cnat = (ConstantNameAndType)this.cp.getConstant(name_and_type_index); String name = ((ConstantUtf8)this.cp.getConstant(cnat.getNameIndex())).getBytes(); if (!Pass2Verifier.validFieldName(name)) throw new ClassConstraintException("Invalid field name '" + name + "' referenced by '" + Pass2Verifier.tostring(obj) + "'.");  int class_index = obj.getClassIndex(); ConstantClass cc = (ConstantClass)this.cp.getConstant(class_index); String className = ((ConstantUtf8)this.cp.getConstant(cc.getNameIndex())).getBytes(); if (!Pass2Verifier.validClassName(className)) throw new ClassConstraintException("Illegal class name '" + className + "' used by '" + Pass2Verifier.tostring(obj) + "'.");  String sig = ((ConstantUtf8)this.cp.getConstant(cnat.getSignatureIndex())).getBytes(); try { Type.getType(sig); } catch (ClassFormatError cfe) { throw new ClassConstraintException("Illegal descriptor (==signature) '" + sig + "' used by '" + Pass2Verifier.tostring(obj) + "'."); }  } private FAMRAV_Visitor(JavaClass _jc) { this.cp = _jc.getConstantPool(); } public void visitConstantMethodref(ConstantMethodref obj) { if (obj.getTag() != 10) throw new ClassConstraintException("ConstantMethodref '" + Pass2Verifier.tostring(obj) + "' has wrong tag!");  int name_and_type_index = obj.getNameAndTypeIndex(); ConstantNameAndType cnat = (ConstantNameAndType)this.cp.getConstant(name_and_type_index); String name = ((ConstantUtf8)this.cp.getConstant(cnat.getNameIndex())).getBytes(); if (!Pass2Verifier.validClassMethodName(name)) throw new ClassConstraintException("Invalid (non-interface) method name '" + name + "' referenced by '" + Pass2Verifier.tostring(obj) + "'.");  int class_index = obj.getClassIndex(); ConstantClass cc = (ConstantClass)this.cp.getConstant(class_index); String className = ((ConstantUtf8)this.cp.getConstant(cc.getNameIndex())).getBytes(); if (!Pass2Verifier.validClassName(className)) throw new ClassConstraintException("Illegal class name '" + className + "' used by '" + Pass2Verifier.tostring(obj) + "'.");  String sig = ((ConstantUtf8)this.cp.getConstant(cnat.getSignatureIndex())).getBytes(); try { Type t = Type.getReturnType(sig); if (name.equals("<init>") && t != Type.VOID) throw new ClassConstraintException("Instance initialization method must have VOID return type.");  } catch (ClassFormatError cfe) { throw new ClassConstraintException("Illegal descriptor (==signature) '" + sig + "' used by '" + Pass2Verifier.tostring(obj) + "'."); }  } public void visitConstantInterfaceMethodref(ConstantInterfaceMethodref obj) { if (obj.getTag() != 11) throw new ClassConstraintException("ConstantInterfaceMethodref '" + Pass2Verifier.tostring(obj) + "' has wrong tag!");  int name_and_type_index = obj.getNameAndTypeIndex(); ConstantNameAndType cnat = (ConstantNameAndType)this.cp.getConstant(name_and_type_index); String name = ((ConstantUtf8)this.cp.getConstant(cnat.getNameIndex())).getBytes(); if (!Pass2Verifier.validInterfaceMethodName(name)) throw new ClassConstraintException("Invalid (interface) method name '" + name + "' referenced by '" + Pass2Verifier.tostring(obj) + "'.");  int class_index = obj.getClassIndex(); ConstantClass cc = (ConstantClass)this.cp.getConstant(class_index); String className = ((ConstantUtf8)this.cp.getConstant(cc.getNameIndex())).getBytes(); if (!Pass2Verifier.validClassName(className)) throw new ClassConstraintException("Illegal class name '" + className + "' used by '" + Pass2Verifier.tostring(obj) + "'.");  String sig = ((ConstantUtf8)this.cp.getConstant(cnat.getSignatureIndex())).getBytes(); try { Type t = Type.getReturnType(sig); if (name.equals("<clinit>") && t != Type.VOID) Pass2Verifier.this.addMessage("Class or interface initialization method '<clinit>' usually has VOID return type instead of '" + t + "'. Note this is really not a requirement of The Java Virtual Machine Specification, Second Edition.");  } catch (ClassFormatError cfe) { throw new ClassConstraintException("Illegal descriptor (==signature) '" + sig + "' used by '" + Pass2Verifier.tostring(obj) + "'."); }  } } private static final boolean validClassName(String name) { return true; } private static boolean validMethodName(String name, boolean allowStaticInit) { if (validJavaLangMethodName(name)) return true;  if (allowStaticInit) return !(!name.equals("<init>") && !name.equals("<clinit>"));  return name.equals("<init>"); } private static boolean validClassMethodName(String name) { return validMethodName(name, false); } private static boolean validJavaLangMethodName(String name) { if (!Character.isJavaIdentifierStart(name.charAt(0))) return false;  for (int i = 1; i < name.length(); i++) { if (!Character.isJavaIdentifierPart(name.charAt(i))) return false;  }  return true; }
/* 1334 */   private static String tostring(Node n) { return (new StringRepresentation(n)).toString(); }
/*      */   
/*      */   private static boolean validInterfaceMethodName(String name) {
/*      */     if (name.startsWith("<"))
/*      */       return false; 
/*      */     return validJavaLangMethodName(name);
/*      */   }
/*      */   
/*      */   private static boolean validJavaIdentifier(String name) {
/*      */     if (!Character.isJavaIdentifierStart(name.charAt(0)))
/*      */       return false; 
/*      */     for (int i = 1; i < name.length(); i++) {
/*      */       if (!Character.isJavaIdentifierPart(name.charAt(i)))
/*      */         return false; 
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private static boolean validFieldName(String name) { return validJavaIdentifier(name); }
/*      */   
/*      */   private class InnerClassDetector extends EmptyVisitor {
/*      */     private boolean hasInnerClass = false;
/*      */     private JavaClass jc;
/*      */     private ConstantPool cp;
/*      */     
/*      */     private InnerClassDetector() {}
/*      */     
/*      */     public InnerClassDetector(JavaClass _jc) {
/*      */       this.jc = _jc;
/*      */       this.cp = this.jc.getConstantPool();
/*      */       (new DescendingVisitor(this.jc, this)).visit();
/*      */     }
/*      */     
/*      */     public boolean innerClassReferenced() { return this.hasInnerClass; }
/*      */     
/*      */     public void visitConstantClass(ConstantClass obj) {
/*      */       Constant c = this.cp.getConstant(obj.getNameIndex());
/*      */       String classname = ((ConstantUtf8)c).getBytes();
/*      */       if (c instanceof ConstantUtf8 && classname.startsWith(String.valueOf(this.jc.getClassName().replace('.', '/')) + "$"))
/*      */         this.hasInnerClass = true; 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\Pass2Verifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */