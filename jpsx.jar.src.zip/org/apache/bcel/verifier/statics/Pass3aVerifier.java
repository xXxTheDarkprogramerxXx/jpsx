/*      */ package org.apache.bcel.verifier.statics;
/*      */ 
/*      */ import org.apache.bcel.Repository;
/*      */ import org.apache.bcel.classfile.Attribute;
/*      */ import org.apache.bcel.classfile.Code;
/*      */ import org.apache.bcel.classfile.CodeException;
/*      */ import org.apache.bcel.classfile.Constant;
/*      */ import org.apache.bcel.classfile.ConstantClass;
/*      */ import org.apache.bcel.classfile.ConstantInterfaceMethodref;
/*      */ import org.apache.bcel.classfile.ConstantMethodref;
/*      */ import org.apache.bcel.classfile.ConstantNameAndType;
/*      */ import org.apache.bcel.classfile.ConstantUtf8;
/*      */ import org.apache.bcel.classfile.Field;
/*      */ import org.apache.bcel.classfile.JavaClass;
/*      */ import org.apache.bcel.classfile.LineNumber;
/*      */ import org.apache.bcel.classfile.LineNumberTable;
/*      */ import org.apache.bcel.classfile.LocalVariable;
/*      */ import org.apache.bcel.classfile.LocalVariableTable;
/*      */ import org.apache.bcel.classfile.Method;
/*      */ import org.apache.bcel.generic.ALOAD;
/*      */ import org.apache.bcel.generic.ANEWARRAY;
/*      */ import org.apache.bcel.generic.ASTORE;
/*      */ import org.apache.bcel.generic.ArrayType;
/*      */ import org.apache.bcel.generic.CHECKCAST;
/*      */ import org.apache.bcel.generic.ConstantPoolGen;
/*      */ import org.apache.bcel.generic.DLOAD;
/*      */ import org.apache.bcel.generic.DSTORE;
/*      */ import org.apache.bcel.generic.EmptyVisitor;
/*      */ import org.apache.bcel.generic.FLOAD;
/*      */ import org.apache.bcel.generic.FSTORE;
/*      */ import org.apache.bcel.generic.FieldInstruction;
/*      */ import org.apache.bcel.generic.GETSTATIC;
/*      */ import org.apache.bcel.generic.IINC;
/*      */ import org.apache.bcel.generic.ILOAD;
/*      */ import org.apache.bcel.generic.INSTANCEOF;
/*      */ import org.apache.bcel.generic.INVOKEINTERFACE;
/*      */ import org.apache.bcel.generic.INVOKESPECIAL;
/*      */ import org.apache.bcel.generic.INVOKESTATIC;
/*      */ import org.apache.bcel.generic.INVOKEVIRTUAL;
/*      */ import org.apache.bcel.generic.ISTORE;
/*      */ import org.apache.bcel.generic.Instruction;
/*      */ import org.apache.bcel.generic.InstructionHandle;
/*      */ import org.apache.bcel.generic.InstructionList;
/*      */ import org.apache.bcel.generic.InvokeInstruction;
/*      */ import org.apache.bcel.generic.JsrInstruction;
/*      */ import org.apache.bcel.generic.LDC;
/*      */ import org.apache.bcel.generic.LDC2_W;
/*      */ import org.apache.bcel.generic.LLOAD;
/*      */ import org.apache.bcel.generic.LOOKUPSWITCH;
/*      */ import org.apache.bcel.generic.LSTORE;
/*      */ import org.apache.bcel.generic.LoadClass;
/*      */ import org.apache.bcel.generic.MULTIANEWARRAY;
/*      */ import org.apache.bcel.generic.NEW;
/*      */ import org.apache.bcel.generic.NEWARRAY;
/*      */ import org.apache.bcel.generic.ObjectType;
/*      */ import org.apache.bcel.generic.PUTSTATIC;
/*      */ import org.apache.bcel.generic.RET;
/*      */ import org.apache.bcel.generic.TABLESWITCH;
/*      */ import org.apache.bcel.generic.Type;
/*      */ import org.apache.bcel.verifier.PassVerifier;
/*      */ import org.apache.bcel.verifier.VerificationResult;
/*      */ import org.apache.bcel.verifier.Verifier;
/*      */ import org.apache.bcel.verifier.VerifierFactory;
/*      */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*      */ import org.apache.bcel.verifier.exc.ClassConstraintException;
/*      */ import org.apache.bcel.verifier.exc.InvalidMethodException;
/*      */ import org.apache.bcel.verifier.exc.StaticCodeConstraintException;
/*      */ import org.apache.bcel.verifier.exc.StaticCodeInstructionConstraintException;
/*      */ import org.apache.bcel.verifier.exc.StaticCodeInstructionOperandConstraintException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Pass3aVerifier
/*      */   extends PassVerifier
/*      */ {
/*      */   private Verifier myOwner;
/*      */   private int method_no;
/*      */   InstructionList instructionList;
/*      */   Code code;
/*      */   
/*      */   public Pass3aVerifier(Verifier owner, int method_no) {
/*   93 */     this.myOwner = owner;
/*   94 */     this.method_no = method_no;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VerificationResult do_verify() {
/*  115 */     if (this.myOwner.doPass2().equals(VerificationResult.VR_OK)) {
/*      */ 
/*      */       
/*  118 */       JavaClass jc = Repository.lookupClass(this.myOwner.getClassName());
/*  119 */       Method[] methods = jc.getMethods();
/*  120 */       if (this.method_no >= methods.length) {
/*  121 */         throw new InvalidMethodException("METHOD DOES NOT EXIST!");
/*      */       }
/*  123 */       Method method = methods[this.method_no];
/*  124 */       this.code = method.getCode();
/*      */ 
/*      */       
/*  127 */       if (method.isAbstract() || method.isNative()) {
/*  128 */         return VerificationResult.VR_OK;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  141 */         this.instructionList = new InstructionList(method.getCode().getCode());
/*      */       }
/*  143 */       catch (RuntimeException re) {
/*  144 */         return new VerificationResult(2, "Bad bytecode in the code array of the Code attribute of method '" + method + "'.");
/*      */       } 
/*      */       
/*  147 */       this.instructionList.setPositions(true);
/*      */ 
/*      */       
/*  150 */       vr = VerificationResult.VR_OK;
/*      */       try {
/*  152 */         delayedPass2Checks();
/*      */       }
/*  154 */       catch (ClassConstraintException cce) {
/*  155 */         return new VerificationResult(2, cce.getMessage());
/*      */       } 
/*      */       
/*      */       try {
/*  159 */         pass3StaticInstructionChecks();
/*  160 */         pass3StaticInstructionOperandsChecks();
/*      */       }
/*  162 */       catch (StaticCodeConstraintException scce) {
/*  163 */         vr = new VerificationResult(2, scce.getMessage());
/*      */       } 
/*  165 */       return vr;
/*      */     } 
/*      */     
/*  168 */     return VerificationResult.VR_NOTYET;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void delayedPass2Checks() {
/*  183 */     int[] instructionPositions = this.instructionList.getInstructionPositions();
/*  184 */     int codeLength = this.code.getCode().length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     LineNumberTable lnt = this.code.getLineNumberTable();
/*  190 */     if (lnt != null) {
/*  191 */       LineNumber[] lineNumbers = lnt.getLineNumberTable();
/*  192 */       IntList offsets = new IntList();
/*  193 */       for (int i = 0; i < lineNumbers.length; i++) {
/*  194 */         int j = 0; while (true) { if (j >= instructionPositions.length)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  207 */             throw new ClassConstraintException("Code attribute '" + this.code + "' has a LineNumberTable attribute '" + this.code.getLineNumberTable() + "' referring to a code offset ('" + lineNumbers[i].getStartPC() + "') that does not exist."); }  int offset = lineNumbers[i].getStartPC(); if (instructionPositions[j] == offset) {
/*      */             if (offsets.contains(offset)) {
/*      */               addMessage("LineNumberTable attribute '" + this.code.getLineNumberTable() + "' refers to the same code offset ('" + offset + "') more than once which is violating the semantics [but is sometimes produced by IBM's 'jikes' compiler]."); break;
/*      */             }  offsets.add(offset); break;
/*      */           } 
/*      */           j++; }
/*      */       
/*      */       } 
/*      */     } 
/*  216 */     Attribute[] atts = this.code.getAttributes();
/*  217 */     for (int a = 0; a < atts.length; a++) {
/*  218 */       if (atts[a] instanceof LocalVariableTable) {
/*  219 */         LocalVariableTable lvt = (LocalVariableTable)atts[a];
/*  220 */         if (lvt != null) {
/*  221 */           LocalVariable[] localVariables = lvt.getLocalVariableTable();
/*  222 */           for (int i = 0; i < localVariables.length; i++) {
/*  223 */             int startpc = localVariables[i].getStartPC();
/*  224 */             int length = localVariables[i].getLength();
/*      */             
/*  226 */             if (!contains(instructionPositions, startpc)) {
/*  227 */               throw new ClassConstraintException("Code attribute '" + this.code + "' has a LocalVariableTable attribute '" + this.code.getLocalVariableTable() + "' referring to a code offset ('" + startpc + "') that does not exist.");
/*      */             }
/*  229 */             if (!contains(instructionPositions, startpc + length) && startpc + length != codeLength) {
/*  230 */               throw new ClassConstraintException("Code attribute '" + this.code + "' has a LocalVariableTable attribute '" + this.code.getLocalVariableTable() + "' referring to a code offset start_pc+length ('" + (startpc + length) + "') that does not exist.");
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  243 */     CodeException[] exceptionTable = this.code.getExceptionTable();
/*  244 */     for (int i = 0; i < exceptionTable.length; i++) {
/*  245 */       int startpc = exceptionTable[i].getStartPC();
/*  246 */       int endpc = exceptionTable[i].getEndPC();
/*  247 */       int handlerpc = exceptionTable[i].getHandlerPC();
/*  248 */       if (startpc >= endpc) {
/*  249 */         throw new ClassConstraintException("Code attribute '" + this.code + "' has an exception_table entry '" + exceptionTable[i] + "' that has its start_pc ('" + startpc + "') not smaller than its end_pc ('" + endpc + "').");
/*      */       }
/*  251 */       if (!contains(instructionPositions, startpc)) {
/*  252 */         throw new ClassConstraintException("Code attribute '" + this.code + "' has an exception_table entry '" + exceptionTable[i] + "' that has a non-existant bytecode offset as its start_pc ('" + startpc + "').");
/*      */       }
/*  254 */       if (!contains(instructionPositions, endpc) && endpc != codeLength) {
/*  255 */         throw new ClassConstraintException("Code attribute '" + this.code + "' has an exception_table entry '" + exceptionTable[i] + "' that has a non-existant bytecode offset as its end_pc ('" + startpc + "') [that is also not equal to code_length ('" + codeLength + "')].");
/*      */       }
/*  257 */       if (!contains(instructionPositions, handlerpc)) {
/*  258 */         throw new ClassConstraintException("Code attribute '" + this.code + "' has an exception_table entry '" + exceptionTable[i] + "' that has a non-existant bytecode offset as its handler_pc ('" + handlerpc + "').");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void pass3StaticInstructionChecks() {
/*  277 */     if (this.code.getCode().length >= 65536) {
/*  278 */       throw new StaticCodeInstructionConstraintException("Code array in code attribute '" + this.code + "' too big: must be smaller than 65536 bytes.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  296 */     InstructionHandle ih = this.instructionList.getStart();
/*  297 */     while (ih != null) {
/*  298 */       Instruction i = ih.getInstruction();
/*  299 */       if (i instanceof org.apache.bcel.generic.IMPDEP1) {
/*  300 */         throw new StaticCodeInstructionConstraintException("IMPDEP1 must not be in the code, it is an illegal instruction for _internal_ JVM use!");
/*      */       }
/*  302 */       if (i instanceof org.apache.bcel.generic.IMPDEP2) {
/*  303 */         throw new StaticCodeInstructionConstraintException("IMPDEP2 must not be in the code, it is an illegal instruction for _internal_ JVM use!");
/*      */       }
/*  305 */       if (i instanceof org.apache.bcel.generic.BREAKPOINT) {
/*  306 */         throw new StaticCodeInstructionConstraintException("BREAKPOINT must not be in the code, it is an illegal instruction for _internal_ JVM use!");
/*      */       }
/*  308 */       ih = ih.getNext();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  315 */     Instruction last = this.instructionList.getEnd().getInstruction();
/*  316 */     if (!(last instanceof org.apache.bcel.generic.ReturnInstruction) && 
/*  317 */       !(last instanceof RET) && 
/*  318 */       !(last instanceof org.apache.bcel.generic.GotoInstruction) && 
/*  319 */       !(last instanceof org.apache.bcel.generic.ATHROW)) {
/*  320 */       throw new StaticCodeInstructionConstraintException("Execution must not fall off the bottom of the code array. This constraint is enforced statically as some existing verifiers do - so it may be a false alarm if the last instruction is not reachable.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void pass3StaticInstructionOperandsChecks() {
/*  344 */     ConstantPoolGen cpg = new ConstantPoolGen(Repository.lookupClass(this.myOwner.getClassName()).getConstantPool());
/*  345 */     InstOperandConstraintVisitor v = new InstOperandConstraintVisitor(cpg);
/*      */ 
/*      */     
/*  348 */     InstructionHandle ih = this.instructionList.getStart();
/*  349 */     while (ih != null) {
/*  350 */       Instruction i = ih.getInstruction();
/*      */ 
/*      */       
/*  353 */       if (i instanceof JsrInstruction) {
/*  354 */         InstructionHandle target = ((JsrInstruction)i).getTarget();
/*  355 */         if (target == this.instructionList.getStart()) {
/*  356 */           throw new StaticCodeInstructionOperandConstraintException("Due to JustIce's clear definition of subroutines, no JSR or JSR_W may have a top-level instruction (such as the very first instruction, which is targeted by instruction '" + ih + "' as its target.");
/*      */         }
/*  358 */         if (!(target.getInstruction() instanceof ASTORE)) {
/*  359 */           throw new StaticCodeInstructionOperandConstraintException("Due to JustIce's clear definition of subroutines, no JSR or JSR_W may target anything else than an ASTORE instruction. Instruction '" + ih + "' targets '" + target + "'.");
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  364 */       ih.accept(v);
/*      */       
/*  366 */       ih = ih.getNext();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean contains(int[] ints, int i) {
/*  373 */     for (int j = 0; j < ints.length; j++) {
/*  374 */       if (ints[j] == i) return true; 
/*      */     } 
/*  376 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  381 */   public int getMethodNo() { return this.method_no; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class InstOperandConstraintVisitor
/*      */     extends EmptyVisitor
/*      */   {
/*      */     private ConstantPoolGen cpg;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  394 */     InstOperandConstraintVisitor(ConstantPoolGen cpg) { this.cpg = cpg; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  402 */     private int max_locals() { return Repository.lookupClass(Pass3aVerifier.this.myOwner.getClassName()).getMethods()[Pass3aVerifier.this.method_no].getCode().getMaxLocals(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  409 */     private void constraintViolated(Instruction i, String message) { throw new StaticCodeInstructionOperandConstraintException("Instruction " + i + " constraint violated: " + message); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void indexValid(Instruction i, int idx) {
/*  417 */       if (idx < 0 || idx >= this.cpg.getSize()) {
/*  418 */         constraintViolated(i, "Illegal constant pool index '" + idx + "'.");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitLoadClass(LoadClass o) {
/*  430 */       ObjectType t = o.getLoadClassType(this.cpg);
/*  431 */       if (t != null) {
/*  432 */         Verifier v = VerifierFactory.getVerifier(t.getClassName());
/*  433 */         VerificationResult vr = v.doPass1();
/*  434 */         if (vr.getStatus() != 1) {
/*  435 */           constraintViolated((Instruction)o, "Class '" + o.getLoadClassType(this.cpg).getClassName() + "' is referenced, but cannot be loaded: '" + vr + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitLDC(LDC o) {
/*  450 */       indexValid(o, o.getIndex());
/*  451 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  452 */       if (!(c instanceof org.apache.bcel.classfile.ConstantInteger) && 
/*  453 */         !(c instanceof org.apache.bcel.classfile.ConstantFloat) && 
/*  454 */         !(c instanceof org.apache.bcel.classfile.ConstantString)) {
/*  455 */         constraintViolated(o, "Operand of LDC or LDC_W must be one of CONSTANT_Integer, CONSTANT_Float or CONSTANT_String, but is '" + c + "'.");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitLDC2_W(LDC2_W o) {
/*  462 */       indexValid(o, o.getIndex());
/*  463 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  464 */       if (!(c instanceof org.apache.bcel.classfile.ConstantLong) && 
/*  465 */         !(c instanceof org.apache.bcel.classfile.ConstantDouble)) {
/*  466 */         constraintViolated(o, "Operand of LDC2_W must be CONSTANT_Long or CONSTANT_Double, but is '" + c + "'.");
/*      */       }
/*      */       try {
/*  469 */         indexValid(o, o.getIndex() + 1);
/*      */       }
/*  471 */       catch (StaticCodeInstructionOperandConstraintException e) {
/*  472 */         throw new AssertionViolatedException("OOPS: Does not BCEL handle that? LDC2_W operand has a problem.");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitFieldInstruction(FieldInstruction o) {
/*  479 */       indexValid(o, o.getIndex());
/*  480 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  481 */       if (!(c instanceof org.apache.bcel.classfile.ConstantFieldref)) {
/*  482 */         constraintViolated(o, "Indexing a constant that's not a CONSTANT_Fieldref but a '" + c + "'.");
/*      */       }
/*      */       
/*  485 */       String field_name = o.getFieldName(this.cpg);
/*      */       
/*  487 */       JavaClass jc = Repository.lookupClass(o.getClassType(this.cpg).getClassName());
/*  488 */       Field[] fields = jc.getFields();
/*  489 */       Field f = null;
/*  490 */       for (int i = 0; i < fields.length; i++) {
/*  491 */         if (fields[i].getName().equals(field_name)) {
/*  492 */           f = fields[i];
/*      */           break;
/*      */         } 
/*      */       } 
/*  496 */       if (f == null) {
/*      */         
/*  498 */         constraintViolated(o, "Referenced field '" + field_name + "' does not exist in class '" + jc.getClassName() + "'.");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  503 */         Type f_type = Type.getType(f.getSignature());
/*  504 */         Type o_type = o.getType(this.cpg);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  509 */         if (!f_type.equals(o_type)) {
/*  510 */           constraintViolated(o, "Referenced field '" + field_name + "' has type '" + f_type + "' instead of '" + o_type + "' as expected.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitInvokeInstruction(InvokeInstruction o) {
/*  518 */       indexValid(o, o.getIndex());
/*  519 */       if (o instanceof INVOKEVIRTUAL || 
/*  520 */         o instanceof INVOKESPECIAL || 
/*  521 */         o instanceof INVOKESTATIC) {
/*  522 */         Constant c = this.cpg.getConstant(o.getIndex());
/*  523 */         if (!(c instanceof ConstantMethodref)) {
/*  524 */           constraintViolated(o, "Indexing a constant that's not a CONSTANT_Methodref but a '" + c + "'.");
/*      */         }
/*      */         else {
/*      */           
/*  528 */           ConstantNameAndType cnat = (ConstantNameAndType)this.cpg.getConstant(((ConstantMethodref)c).getNameAndTypeIndex());
/*  529 */           ConstantUtf8 cutf8 = (ConstantUtf8)this.cpg.getConstant(cnat.getNameIndex());
/*  530 */           if (cutf8.getBytes().equals("<init>") && !(o instanceof INVOKESPECIAL)) {
/*  531 */             constraintViolated(o, "Only INVOKESPECIAL is allowed to invoke instance initialization methods.");
/*      */           }
/*  533 */           if (!cutf8.getBytes().equals("<init>") && cutf8.getBytes().startsWith("<")) {
/*  534 */             constraintViolated(o, "No method with a name beginning with '<' other than the instance initialization methods may be called by the method invocation instructions.");
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/*  539 */         Constant c = this.cpg.getConstant(o.getIndex());
/*  540 */         if (!(c instanceof ConstantInterfaceMethodref)) {
/*  541 */           constraintViolated(o, "Indexing a constant that's not a CONSTANT_InterfaceMethodref but a '" + c + "'.");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  549 */         ConstantNameAndType cnat = (ConstantNameAndType)this.cpg.getConstant(((ConstantInterfaceMethodref)c).getNameAndTypeIndex());
/*  550 */         String name = ((ConstantUtf8)this.cpg.getConstant(cnat.getNameIndex())).getBytes();
/*  551 */         if (name.equals("<init>")) {
/*  552 */           constraintViolated(o, "Method to invoke must not be '<init>'.");
/*      */         }
/*  554 */         if (name.equals("<clinit>")) {
/*  555 */           constraintViolated(o, "Method to invoke must not be '<clinit>'.");
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  561 */       Type t = o.getReturnType(this.cpg);
/*  562 */       if (t instanceof ArrayType) {
/*  563 */         t = ((ArrayType)t).getBasicType();
/*      */       }
/*  565 */       if (t instanceof ObjectType) {
/*  566 */         Verifier v = VerifierFactory.getVerifier(((ObjectType)t).getClassName());
/*  567 */         VerificationResult vr = v.doPass2();
/*  568 */         if (vr.getStatus() != 1) {
/*  569 */           constraintViolated(o, "Return type class/interface could not be verified successfully: '" + vr.getMessage() + "'.");
/*      */         }
/*      */       } 
/*      */       
/*  573 */       Type[] ts = o.getArgumentTypes(this.cpg);
/*  574 */       for (int i = 0; i < ts.length; i++) {
/*  575 */         t = ts[i];
/*  576 */         if (t instanceof ArrayType) {
/*  577 */           t = ((ArrayType)t).getBasicType();
/*      */         }
/*  579 */         if (t instanceof ObjectType) {
/*  580 */           Verifier v = VerifierFactory.getVerifier(((ObjectType)t).getClassName());
/*  581 */           VerificationResult vr = v.doPass2();
/*  582 */           if (vr.getStatus() != 1) {
/*  583 */             constraintViolated(o, "Argument type class/interface could not be verified successfully: '" + vr.getMessage() + "'.");
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitINSTANCEOF(INSTANCEOF o) {
/*  592 */       indexValid(o, o.getIndex());
/*  593 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  594 */       if (!(c instanceof ConstantClass)) {
/*  595 */         constraintViolated(o, "Expecting a CONSTANT_Class operand, but found a '" + c + "'.");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitCHECKCAST(CHECKCAST o) {
/*  601 */       indexValid(o, o.getIndex());
/*  602 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  603 */       if (!(c instanceof ConstantClass)) {
/*  604 */         constraintViolated(o, "Expecting a CONSTANT_Class operand, but found a '" + c + "'.");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitNEW(NEW o) {
/*  610 */       indexValid(o, o.getIndex());
/*  611 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  612 */       if (!(c instanceof ConstantClass)) {
/*  613 */         constraintViolated(o, "Expecting a CONSTANT_Class operand, but found a '" + c + "'.");
/*      */       } else {
/*      */         
/*  616 */         ConstantUtf8 cutf8 = (ConstantUtf8)this.cpg.getConstant(((ConstantClass)c).getNameIndex());
/*  617 */         Type t = Type.getType("L" + cutf8.getBytes() + ";");
/*  618 */         if (t instanceof ArrayType) {
/*  619 */           constraintViolated(o, "NEW must not be used to create an array.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitMULTIANEWARRAY(MULTIANEWARRAY o) {
/*  627 */       indexValid(o, o.getIndex());
/*  628 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  629 */       if (!(c instanceof ConstantClass)) {
/*  630 */         constraintViolated(o, "Expecting a CONSTANT_Class operand, but found a '" + c + "'.");
/*      */       }
/*  632 */       int dimensions2create = o.getDimensions();
/*  633 */       if (dimensions2create < 1) {
/*  634 */         constraintViolated(o, "Number of dimensions to create must be greater than zero.");
/*      */       }
/*  636 */       Type t = o.getType(this.cpg);
/*  637 */       if (t instanceof ArrayType) {
/*  638 */         int dimensions = ((ArrayType)t).getDimensions();
/*  639 */         if (dimensions < dimensions2create) {
/*  640 */           constraintViolated(o, "Not allowed to create array with more dimensions ('+dimensions2create+') than the one referenced by the CONSTANT_Class '" + t + "'.");
/*      */         }
/*      */       } else {
/*      */         
/*  644 */         constraintViolated(o, "Expecting a CONSTANT_Class referencing an array type. [Constraint not found in The Java Virtual Machine Specification, Second Edition, 4.8.1]");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitANEWARRAY(ANEWARRAY o) {
/*  650 */       indexValid(o, o.getIndex());
/*  651 */       Constant c = this.cpg.getConstant(o.getIndex());
/*  652 */       if (!(c instanceof ConstantClass)) {
/*  653 */         constraintViolated(o, "Expecting a CONSTANT_Class operand, but found a '" + c + "'.");
/*      */       }
/*  655 */       Type t = o.getType(this.cpg);
/*  656 */       if (t instanceof ArrayType) {
/*  657 */         int dimensions = ((ArrayType)t).getDimensions();
/*  658 */         if (dimensions >= 255) {
/*  659 */           constraintViolated(o, "Not allowed to create an array with more than 255 dimensions.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitNEWARRAY(NEWARRAY o) {
/*  666 */       byte t = o.getTypecode();
/*  667 */       if (t != 4 && 
/*  668 */         t != 5 && 
/*  669 */         t != 6 && 
/*  670 */         t != 7 && 
/*  671 */         t != 8 && 
/*  672 */         t != 9 && 
/*  673 */         t != 10 && 
/*  674 */         t != 11) {
/*  675 */         constraintViolated(o, "Illegal type code '+t+' for 'atype' operand.");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitILOAD(ILOAD o) {
/*  681 */       int idx = o.getIndex();
/*  682 */       if (idx < 0) {
/*  683 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  686 */         int maxminus1 = max_locals() - 1;
/*  687 */         if (idx > maxminus1) {
/*  688 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitFLOAD(FLOAD o) {
/*  695 */       int idx = o.getIndex();
/*  696 */       if (idx < 0) {
/*  697 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  700 */         int maxminus1 = max_locals() - 1;
/*  701 */         if (idx > maxminus1) {
/*  702 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitALOAD(ALOAD o) {
/*  709 */       int idx = o.getIndex();
/*  710 */       if (idx < 0) {
/*  711 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  714 */         int maxminus1 = max_locals() - 1;
/*  715 */         if (idx > maxminus1) {
/*  716 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitISTORE(ISTORE o) {
/*  723 */       int idx = o.getIndex();
/*  724 */       if (idx < 0) {
/*  725 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  728 */         int maxminus1 = max_locals() - 1;
/*  729 */         if (idx > maxminus1) {
/*  730 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitFSTORE(FSTORE o) {
/*  737 */       int idx = o.getIndex();
/*  738 */       if (idx < 0) {
/*  739 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  742 */         int maxminus1 = max_locals() - 1;
/*  743 */         if (idx > maxminus1) {
/*  744 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitASTORE(ASTORE o) {
/*  751 */       int idx = o.getIndex();
/*  752 */       if (idx < 0) {
/*  753 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  756 */         int maxminus1 = max_locals() - 1;
/*  757 */         if (idx > maxminus1) {
/*  758 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitIINC(IINC o) {
/*  765 */       int idx = o.getIndex();
/*  766 */       if (idx < 0) {
/*  767 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  770 */         int maxminus1 = max_locals() - 1;
/*  771 */         if (idx > maxminus1) {
/*  772 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitRET(RET o) {
/*  779 */       int idx = o.getIndex();
/*  780 */       if (idx < 0) {
/*  781 */         constraintViolated(o, "Index '" + idx + "' must be non-negative.");
/*      */       } else {
/*      */         
/*  784 */         int maxminus1 = max_locals() - 1;
/*  785 */         if (idx > maxminus1) {
/*  786 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-1 '" + maxminus1 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitLLOAD(LLOAD o) {
/*  793 */       int idx = o.getIndex();
/*  794 */       if (idx < 0) {
/*  795 */         constraintViolated(o, "Index '" + idx + "' must be non-negative. [Constraint by JustIce as an analogon to the single-slot xLOAD/xSTORE instructions; may not happen anyway.]");
/*      */       } else {
/*      */         
/*  798 */         int maxminus2 = max_locals() - 2;
/*  799 */         if (idx > maxminus2) {
/*  800 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-2 '" + maxminus2 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitDLOAD(DLOAD o) {
/*  807 */       int idx = o.getIndex();
/*  808 */       if (idx < 0) {
/*  809 */         constraintViolated(o, "Index '" + idx + "' must be non-negative. [Constraint by JustIce as an analogon to the single-slot xLOAD/xSTORE instructions; may not happen anyway.]");
/*      */       } else {
/*      */         
/*  812 */         int maxminus2 = max_locals() - 2;
/*  813 */         if (idx > maxminus2) {
/*  814 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-2 '" + maxminus2 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitLSTORE(LSTORE o) {
/*  821 */       int idx = o.getIndex();
/*  822 */       if (idx < 0) {
/*  823 */         constraintViolated(o, "Index '" + idx + "' must be non-negative. [Constraint by JustIce as an analogon to the single-slot xLOAD/xSTORE instructions; may not happen anyway.]");
/*      */       } else {
/*      */         
/*  826 */         int maxminus2 = max_locals() - 2;
/*  827 */         if (idx > maxminus2) {
/*  828 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-2 '" + maxminus2 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitDSTORE(DSTORE o) {
/*  835 */       int idx = o.getIndex();
/*  836 */       if (idx < 0) {
/*  837 */         constraintViolated(o, "Index '" + idx + "' must be non-negative. [Constraint by JustIce as an analogon to the single-slot xLOAD/xSTORE instructions; may not happen anyway.]");
/*      */       } else {
/*      */         
/*  840 */         int maxminus2 = max_locals() - 2;
/*  841 */         if (idx > maxminus2) {
/*  842 */           constraintViolated(o, "Index '" + idx + "' must not be greater than max_locals-2 '" + maxminus2 + "'.");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitLOOKUPSWITCH(LOOKUPSWITCH o) {
/*  849 */       int[] matchs = o.getMatchs();
/*  850 */       int max = Integer.MIN_VALUE;
/*  851 */       for (int i = 0; i < matchs.length; i++) {
/*  852 */         if (matchs[i] == max && i != 0) {
/*  853 */           constraintViolated(o, "Match '" + matchs[i] + "' occurs more than once.");
/*      */         }
/*  855 */         if (matchs[i] < max) {
/*  856 */           constraintViolated(o, "Lookup table must be sorted but isn't.");
/*      */         } else {
/*      */           
/*  859 */           max = matchs[i];
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitTABLESWITCH(TABLESWITCH o) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitPUTSTATIC(PUTSTATIC o) {
/*  872 */       String field_name = o.getFieldName(this.cpg);
/*  873 */       JavaClass jc = Repository.lookupClass(o.getClassType(this.cpg).getClassName());
/*  874 */       Field[] fields = jc.getFields();
/*  875 */       Field f = null;
/*  876 */       for (int i = 0; i < fields.length; i++) {
/*  877 */         if (fields[i].getName().equals(field_name)) {
/*  878 */           f = fields[i];
/*      */           break;
/*      */         } 
/*      */       } 
/*  882 */       if (f == null) {
/*  883 */         throw new AssertionViolatedException("Field not found?!?");
/*      */       }
/*      */       
/*  886 */       if (f.isFinal() && 
/*  887 */         !Pass3aVerifier.this.myOwner.getClassName().equals(o.getClassType(this.cpg).getClassName())) {
/*  888 */         constraintViolated(o, "Referenced field '" + f + "' is final and must therefore be declared in the current class '" + Pass3aVerifier.this.myOwner.getClassName() + "' which is not the case: it is declared in '" + o.getClassType(this.cpg).getClassName() + "'.");
/*      */       }
/*      */ 
/*      */       
/*  892 */       if (!f.isStatic()) {
/*  893 */         constraintViolated(o, "Referenced field '" + f + "' is not static which it should be.");
/*      */       }
/*      */       
/*  896 */       String meth_name = Repository.lookupClass(Pass3aVerifier.this.myOwner.getClassName()).getMethods()[Pass3aVerifier.this.method_no].getName();
/*      */ 
/*      */       
/*  899 */       if (!jc.isClass() && !meth_name.equals("<clinit>")) {
/*  900 */         constraintViolated(o, "Interface field '" + f + "' must be set in a '" + "<clinit>" + "' method.");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitGETSTATIC(GETSTATIC o) {
/*  906 */       String field_name = o.getFieldName(this.cpg);
/*  907 */       JavaClass jc = Repository.lookupClass(o.getClassType(this.cpg).getClassName());
/*  908 */       Field[] fields = jc.getFields();
/*  909 */       Field f = null;
/*  910 */       for (int i = 0; i < fields.length; i++) {
/*  911 */         if (fields[i].getName().equals(field_name)) {
/*  912 */           f = fields[i];
/*      */           break;
/*      */         } 
/*      */       } 
/*  916 */       if (f == null) {
/*  917 */         throw new AssertionViolatedException("Field not found?!?");
/*      */       }
/*      */       
/*  920 */       if (!f.isStatic()) {
/*  921 */         constraintViolated(o, "Referenced field '" + f + "' is not static which it should be.");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitINVOKEINTERFACE(INVOKEINTERFACE o) {
/*  941 */       String classname = o.getClassName(this.cpg);
/*  942 */       JavaClass jc = Repository.lookupClass(classname);
/*  943 */       Method[] ms = jc.getMethods();
/*  944 */       Method m = null;
/*  945 */       for (int i = 0; i < ms.length; i++) {
/*  946 */         if (ms[i].getName().equals(o.getMethodName(this.cpg)) && 
/*  947 */           Type.getReturnType(ms[i].getSignature()).equals(o.getReturnType(this.cpg)) && 
/*  948 */           objarrayequals(Type.getArgumentTypes(ms[i].getSignature()), o.getArgumentTypes(this.cpg))) {
/*  949 */           m = ms[i];
/*      */           break;
/*      */         } 
/*      */       } 
/*  953 */       if (m == null) {
/*  954 */         constraintViolated(o, "Referenced method '" + o.getMethodName(this.cpg) + "' with expected signature not found in class '" + jc.getClassName() + "'. The native verfier does allow the method to be declared in some superinterface, which the Java Virtual Machine Specification, Second Edition does not.");
/*      */       }
/*  956 */       if (jc.isClass()) {
/*  957 */         constraintViolated(o, "Referenced class '" + jc.getClassName() + "' is a class, but not an interface as expected.");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitINVOKESPECIAL(INVOKESPECIAL o) {
/*  967 */       String classname = o.getClassName(this.cpg);
/*  968 */       JavaClass jc = Repository.lookupClass(classname);
/*  969 */       Method[] ms = jc.getMethods();
/*  970 */       Method m = null;
/*  971 */       for (int i = 0; i < ms.length; i++) {
/*  972 */         if (ms[i].getName().equals(o.getMethodName(this.cpg)) && 
/*  973 */           Type.getReturnType(ms[i].getSignature()).equals(o.getReturnType(this.cpg)) && 
/*  974 */           objarrayequals(Type.getArgumentTypes(ms[i].getSignature()), o.getArgumentTypes(this.cpg))) {
/*  975 */           m = ms[i];
/*      */           break;
/*      */         } 
/*      */       } 
/*  979 */       if (m == null) {
/*  980 */         constraintViolated(o, "Referenced method '" + o.getMethodName(this.cpg) + "' with expected signature not found in class '" + jc.getClassName() + "'. The native verfier does allow the method to be declared in some superclass or implemented interface, which the Java Virtual Machine Specification, Second Edition does not.");
/*      */       }
/*      */       
/*  983 */       JavaClass current = Repository.lookupClass(Pass3aVerifier.this.myOwner.getClassName());
/*  984 */       if (current.isSuper())
/*      */       {
/*  986 */         if (Repository.instanceOf(current, jc) && !current.equals(jc))
/*      */         {
/*  988 */           if (!o.getMethodName(this.cpg).equals("<init>")) {
/*      */ 
/*      */             
/*  991 */             int supidx = -1;
/*      */             
/*  993 */             Method meth = null;
/*  994 */             while (supidx != 0) {
/*  995 */               supidx = current.getSuperclassNameIndex();
/*  996 */               current = Repository.lookupClass(current.getSuperclassName());
/*      */               
/*  998 */               Method[] meths = current.getMethods();
/*  999 */               for (int i = 0; i < meths.length; i++) {
/* 1000 */                 if (meths[i].getName().equals(o.getMethodName(this.cpg)) && 
/* 1001 */                   Type.getReturnType(meths[i].getSignature()).equals(o.getReturnType(this.cpg)) && 
/* 1002 */                   objarrayequals(Type.getArgumentTypes(meths[i].getSignature()), o.getArgumentTypes(this.cpg))) {
/* 1003 */                   meth = meths[i];
/*      */                   break;
/*      */                 } 
/*      */               } 
/* 1007 */               if (meth != null)
/*      */                 break; 
/* 1009 */             }  if (meth == null) {
/* 1010 */               constraintViolated(o, "ACC_SUPER special lookup procedure not successful: method '" + o.getMethodName(this.cpg) + "' with proper signature not declared in superclass hierarchy.");
/*      */             }
/*      */           } 
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitINVOKESTATIC(INVOKESTATIC o) {
/* 1025 */       String classname = o.getClassName(this.cpg);
/* 1026 */       JavaClass jc = Repository.lookupClass(classname);
/* 1027 */       Method[] ms = jc.getMethods();
/* 1028 */       Method m = null;
/* 1029 */       for (int i = 0; i < ms.length; i++) {
/* 1030 */         if (ms[i].getName().equals(o.getMethodName(this.cpg)) && 
/* 1031 */           Type.getReturnType(ms[i].getSignature()).equals(o.getReturnType(this.cpg)) && 
/* 1032 */           objarrayequals(Type.getArgumentTypes(ms[i].getSignature()), o.getArgumentTypes(this.cpg))) {
/* 1033 */           m = ms[i];
/*      */           break;
/*      */         } 
/*      */       } 
/* 1037 */       if (m == null) {
/* 1038 */         constraintViolated(o, "Referenced method '" + o.getMethodName(this.cpg) + "' with expected signature not found in class '" + jc.getClassName() + "'. The native verifier possibly allows the method to be declared in some superclass or implemented interface, which the Java Virtual Machine Specification, Second Edition does not.");
/*      */       }
/*      */       
/* 1041 */       if (!m.isStatic()) {
/* 1042 */         constraintViolated(o, "Referenced method '" + o.getMethodName(this.cpg) + "' has ACC_STATIC unset.");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void visitINVOKEVIRTUAL(INVOKEVIRTUAL o) {
/* 1054 */       String classname = o.getClassName(this.cpg);
/* 1055 */       JavaClass jc = Repository.lookupClass(classname);
/* 1056 */       Method[] ms = jc.getMethods();
/* 1057 */       Method m = null;
/* 1058 */       for (int i = 0; i < ms.length; i++) {
/* 1059 */         if (ms[i].getName().equals(o.getMethodName(this.cpg)) && 
/* 1060 */           Type.getReturnType(ms[i].getSignature()).equals(o.getReturnType(this.cpg)) && 
/* 1061 */           objarrayequals(Type.getArgumentTypes(ms[i].getSignature()), o.getArgumentTypes(this.cpg))) {
/* 1062 */           m = ms[i];
/*      */           break;
/*      */         } 
/*      */       } 
/* 1066 */       if (m == null) {
/* 1067 */         constraintViolated(o, "Referenced method '" + o.getMethodName(this.cpg) + "' with expected signature not found in class '" + jc.getClassName() + "'. The native verfier does allow the method to be declared in some superclass or implemented interface, which the Java Virtual Machine Specification, Second Edition does not.");
/*      */       }
/* 1069 */       if (!jc.isClass()) {
/* 1070 */         constraintViolated(o, "Referenced class '" + jc.getClassName() + "' is an interface, but not a class as expected.");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean objarrayequals(Object[] o, Object[] p) {
/* 1084 */       if (o.length != p.length) {
/* 1085 */         return false;
/*      */       }
/*      */       
/* 1088 */       for (int i = 0; i < o.length; i++) {
/* 1089 */         if (!o[i].equals(p[i])) {
/* 1090 */           return false;
/*      */         }
/*      */       } 
/*      */       
/* 1094 */       return true;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\Pass3aVerifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */