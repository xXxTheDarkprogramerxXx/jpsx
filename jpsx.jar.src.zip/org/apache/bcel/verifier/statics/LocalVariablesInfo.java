/*     */ package org.apache.bcel.verifier.statics;
/*     */ 
/*     */ import org.apache.bcel.generic.Type;
/*     */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*     */ import org.apache.bcel.verifier.exc.LocalVariableInfoInconsistentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariablesInfo
/*     */ {
/*     */   private LocalVariableInfo[] localVariableInfos;
/*     */   
/*     */   LocalVariablesInfo(int max_locals) {
/*  75 */     this.localVariableInfos = new LocalVariableInfo[max_locals];
/*  76 */     for (int i = 0; i < max_locals; i++) {
/*  77 */       this.localVariableInfos[i] = new LocalVariableInfo();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalVariableInfo getLocalVariableInfo(int slot) {
/*  83 */     if (slot < 0 || slot >= this.localVariableInfos.length) {
/*  84 */       throw new AssertionViolatedException("Slot number for local variable information out of range.");
/*     */     }
/*  86 */     return this.localVariableInfos[slot];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int slot, String name, int startpc, int length, Type t) throws LocalVariableInfoInconsistentException {
/*  98 */     if (slot < 0 || slot >= this.localVariableInfos.length) {
/*  99 */       throw new AssertionViolatedException("Slot number for local variable information out of range.");
/*     */     }
/*     */     
/* 102 */     this.localVariableInfos[slot].add(name, startpc, length, t);
/* 103 */     if (t == Type.LONG) this.localVariableInfos[slot + 1].add(name, startpc, length, LONG_Upper.theInstance()); 
/* 104 */     if (t == Type.DOUBLE) this.localVariableInfos[slot + 1].add(name, startpc, length, DOUBLE_Upper.theInstance()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\LocalVariablesInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */