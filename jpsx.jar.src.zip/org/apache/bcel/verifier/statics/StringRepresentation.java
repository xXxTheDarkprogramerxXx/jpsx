/*     */ package org.apache.bcel.verifier.statics;
/*     */ 
/*     */ import org.apache.bcel.classfile.Code;
/*     */ import org.apache.bcel.classfile.CodeException;
/*     */ import org.apache.bcel.classfile.ConstantClass;
/*     */ import org.apache.bcel.classfile.ConstantDouble;
/*     */ import org.apache.bcel.classfile.ConstantFieldref;
/*     */ import org.apache.bcel.classfile.ConstantFloat;
/*     */ import org.apache.bcel.classfile.ConstantInteger;
/*     */ import org.apache.bcel.classfile.ConstantInterfaceMethodref;
/*     */ import org.apache.bcel.classfile.ConstantLong;
/*     */ import org.apache.bcel.classfile.ConstantMethodref;
/*     */ import org.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.ConstantString;
/*     */ import org.apache.bcel.classfile.ConstantUtf8;
/*     */ import org.apache.bcel.classfile.ConstantValue;
/*     */ import org.apache.bcel.classfile.Deprecated;
/*     */ import org.apache.bcel.classfile.EmptyVisitor;
/*     */ import org.apache.bcel.classfile.ExceptionTable;
/*     */ import org.apache.bcel.classfile.Field;
/*     */ import org.apache.bcel.classfile.InnerClass;
/*     */ import org.apache.bcel.classfile.InnerClasses;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.LineNumber;
/*     */ import org.apache.bcel.classfile.LineNumberTable;
/*     */ import org.apache.bcel.classfile.LocalVariable;
/*     */ import org.apache.bcel.classfile.LocalVariableTable;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.Node;
/*     */ import org.apache.bcel.classfile.Signature;
/*     */ import org.apache.bcel.classfile.SourceFile;
/*     */ import org.apache.bcel.classfile.StackMap;
/*     */ import org.apache.bcel.classfile.Synthetic;
/*     */ import org.apache.bcel.classfile.Unknown;
/*     */ import org.apache.bcel.classfile.Visitor;
/*     */ import org.apache.bcel.verifier.exc.AssertionViolatedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringRepresentation
/*     */   extends EmptyVisitor
/*     */   implements Visitor
/*     */ {
/*     */   private String tostring;
/*     */   private Node n;
/*     */   
/*     */   public StringRepresentation(Node n) {
/*  87 */     this.n = n;
/*  88 */     n.accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     if (this.tostring == null) throw new AssertionViolatedException("Please adapt '" + getClass() + "' to deal with objects of class '" + this.n.getClass() + "'."); 
/* 100 */     return this.tostring;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toString(Node obj) {
/*     */     String ret;
/*     */     try {
/* 110 */       ret = obj.toString();
/*     */     }
/* 112 */     catch (RuntimeException e) {
/* 113 */       String s = obj.getClass().getName();
/* 114 */       s = s.substring(s.lastIndexOf(".") + 1);
/* 115 */       ret = "<<" + s + ">>";
/*     */     }
/* 117 */     catch (ClassFormatError e) {
/* 118 */       String s = obj.getClass().getName();
/* 119 */       s = s.substring(s.lastIndexOf(".") + 1);
/* 120 */       ret = "<<" + s + ">>";
/*     */     } 
/* 122 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void visitCode(Code obj) { this.tostring = "<CODE>"; }
/*     */ 
/*     */   
/* 135 */   public void visitCodeException(CodeException obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 138 */   public void visitConstantClass(ConstantClass obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 141 */   public void visitConstantDouble(ConstantDouble obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 144 */   public void visitConstantFieldref(ConstantFieldref obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 147 */   public void visitConstantFloat(ConstantFloat obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 150 */   public void visitConstantInteger(ConstantInteger obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 153 */   public void visitConstantInterfaceMethodref(ConstantInterfaceMethodref obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 156 */   public void visitConstantLong(ConstantLong obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 159 */   public void visitConstantMethodref(ConstantMethodref obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 162 */   public void visitConstantNameAndType(ConstantNameAndType obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 165 */   public void visitConstantPool(ConstantPool obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 168 */   public void visitConstantString(ConstantString obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 171 */   public void visitConstantUtf8(ConstantUtf8 obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 174 */   public void visitConstantValue(ConstantValue obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 177 */   public void visitDeprecated(Deprecated obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 180 */   public void visitExceptionTable(ExceptionTable obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 183 */   public void visitField(Field obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 186 */   public void visitInnerClass(InnerClass obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 189 */   public void visitInnerClasses(InnerClasses obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 192 */   public void visitJavaClass(JavaClass obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 195 */   public void visitLineNumber(LineNumber obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 198 */   public void visitLineNumberTable(LineNumberTable obj) { this.tostring = "<LineNumberTable: " + toString(obj) + ">"; }
/*     */ 
/*     */   
/* 201 */   public void visitLocalVariable(LocalVariable obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 204 */   public void visitLocalVariableTable(LocalVariableTable obj) { this.tostring = "<LocalVariableTable: " + toString(obj) + ">"; }
/*     */ 
/*     */   
/* 207 */   public void visitMethod(Method obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 210 */   public void visitSignature(Signature obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 213 */   public void visitSourceFile(SourceFile obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 216 */   public void visitStackMap(StackMap obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 219 */   public void visitSynthetic(Synthetic obj) { this.tostring = toString(obj); }
/*     */ 
/*     */   
/* 222 */   public void visitUnknown(Unknown obj) { this.tostring = toString(obj); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\verifier\statics\StringRepresentation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */