/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.ExceptionConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GETFIELD
/*     */   extends FieldInstruction
/*     */   implements ExceptionThrower, StackConsumer, StackProducer
/*     */ {
/*     */   GETFIELD() {}
/*     */   
/*  78 */   public GETFIELD(int index) { super((short)180, index); }
/*     */ 
/*     */   
/*  81 */   public int produceStack(ConstantPoolGen cpg) { return getFieldSize(cpg); }
/*     */   
/*     */   public Class[] getExceptions() {
/*  84 */     Class[] cs = new Class[2 + ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length];
/*     */     
/*  86 */     System.arraycopy(ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION, 0, 
/*  87 */         cs, 0, ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length);
/*     */     
/*  89 */     cs[ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length + 1] = 
/*  90 */       ExceptionConstants.INCOMPATIBLE_CLASS_CHANGE_ERROR;
/*  91 */     cs[ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length] = 
/*  92 */       ExceptionConstants.NULL_POINTER_EXCEPTION;
/*     */     
/*  94 */     return cs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 107 */     v.visitExceptionThrower(this);
/* 108 */     v.visitStackConsumer(this);
/* 109 */     v.visitStackProducer(this);
/* 110 */     v.visitTypedInstruction(this);
/* 111 */     v.visitLoadClass(this);
/* 112 */     v.visitCPInstruction(this);
/* 113 */     v.visitFieldOrMethod(this);
/* 114 */     v.visitFieldInstruction(this);
/* 115 */     v.visitGETFIELD(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\GETFIELD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */