/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.bcel.classfile.LocalVariable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariableGen
/*     */   implements InstructionTargeter, NamedAndTyped, Cloneable, Serializable
/*     */ {
/*     */   private int index;
/*     */   private String name;
/*     */   private Type type;
/*     */   private InstructionHandle start;
/*     */   private InstructionHandle end;
/*     */   
/*     */   public LocalVariableGen(int index, String name, Type type, InstructionHandle start, InstructionHandle end) {
/*  92 */     if (index < 0 || index > 65535) {
/*  93 */       throw new ClassGenException("Invalid index index: " + index);
/*     */     }
/*  95 */     this.name = name;
/*  96 */     this.type = type;
/*  97 */     this.index = index;
/*  98 */     setStart(start);
/*  99 */     setEnd(end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariable getLocalVariable(ConstantPoolGen cp) {
/* 118 */     int start_pc = this.start.getPosition();
/* 119 */     int length = this.end.getPosition() - start_pc;
/*     */     
/* 121 */     if (length > 0) {
/* 122 */       length += this.end.getInstruction().getLength();
/*     */     }
/* 124 */     int name_index = cp.addUtf8(this.name);
/* 125 */     int signature_index = cp.addUtf8(this.type.getSignature());
/*     */     
/* 127 */     return new LocalVariable(start_pc, length, name_index, 
/* 128 */         signature_index, this.index, cp.getConstantPool());
/*     */   }
/*     */   
/* 131 */   public void setIndex(int index) { this.index = index; }
/* 132 */   public int getIndex() { return this.index; }
/* 133 */   public void setName(String name) { this.name = name; }
/* 134 */   public String getName() { return this.name; }
/* 135 */   public void setType(Type type) { this.type = type; }
/* 136 */   public Type getType() { return this.type; }
/*     */   
/* 138 */   public InstructionHandle getStart() { return this.start; }
/* 139 */   public InstructionHandle getEnd() { return this.end; }
/*     */   
/*     */   public void setStart(InstructionHandle start) {
/* 142 */     BranchInstruction.notifyTarget(this.start, start, this);
/* 143 */     this.start = start;
/*     */   }
/*     */   
/*     */   public void setEnd(InstructionHandle end) {
/* 147 */     BranchInstruction.notifyTarget(this.end, end, this);
/* 148 */     this.end = end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 156 */     boolean targeted = false;
/*     */     
/* 158 */     if (this.start == old_ih) {
/* 159 */       targeted = true;
/* 160 */       setStart(new_ih);
/*     */     } 
/*     */     
/* 163 */     if (this.end == old_ih) {
/* 164 */       targeted = true;
/* 165 */       setEnd(new_ih);
/*     */     } 
/*     */     
/* 168 */     if (!targeted) {
/* 169 */       throw new ClassGenException("Not targeting " + old_ih + ", but {" + this.start + ", " + 
/* 170 */           this.end + "}");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public boolean containsTarget(InstructionHandle ih) { return !(this.start != ih && this.end != ih); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 185 */     if (!(o instanceof LocalVariableGen)) {
/* 186 */       return false;
/*     */     }
/* 188 */     LocalVariableGen l = (LocalVariableGen)o;
/* 189 */     return (l.index == this.index && l.start == this.start && l.end == this.end);
/*     */   }
/*     */ 
/*     */   
/* 193 */   public String toString() { return "LocalVariableGen(" + this.name + ", " + this.type + ", " + this.start + ", " + this.end + ")"; }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 198 */       return super.clone();
/* 199 */     } catch (CloneNotSupportedException e) {
/* 200 */       System.err.println(e);
/* 201 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\LocalVariableGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */