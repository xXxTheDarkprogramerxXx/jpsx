/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsrInstruction
/*     */   extends BranchInstruction
/*     */   implements UnconditionalBranch, TypedInstruction, StackProducer
/*     */ {
/*  67 */   JsrInstruction(short opcode, InstructionHandle target) { super(opcode, target); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JsrInstruction() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public Type getType(ConstantPoolGen cp) { return new ReturnaddressType(physicalSuccessor()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionHandle physicalSuccessor() {
/*  94 */     InstructionHandle ih = this.target;
/*     */ 
/*     */     
/*  97 */     while (ih.getPrev() != null) {
/*  98 */       ih = ih.getPrev();
/*     */     }
/*     */     
/* 101 */     while (ih.getInstruction() != this) {
/* 102 */       ih = ih.getNext();
/*     */     }
/* 104 */     InstructionHandle toThis = ih;
/*     */     
/* 106 */     while (ih != null) {
/* 107 */       ih = ih.getNext();
/* 108 */       if (ih != null && ih.getInstruction() == this) {
/* 109 */         throw new RuntimeException("physicalSuccessor() called on a shared JsrInstruction.");
/*     */       }
/*     */     } 
/*     */     
/* 113 */     return toThis.getNext();
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\JsrInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */