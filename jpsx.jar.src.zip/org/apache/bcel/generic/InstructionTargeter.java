package org.apache.bcel.generic;

public interface InstructionTargeter {
  boolean containsTarget(InstructionHandle paramInstructionHandle);
  
  void updateTarget(InstructionHandle paramInstructionHandle1, InstructionHandle paramInstructionHandle2);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\InstructionTargeter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */