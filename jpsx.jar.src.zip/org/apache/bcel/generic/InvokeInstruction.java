/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.Constant;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InvokeInstruction
/*     */   extends FieldOrMethod
/*     */   implements ExceptionThrower, TypedInstruction, StackConsumer, StackProducer
/*     */ {
/*     */   InvokeInstruction() {}
/*     */   
/*  78 */   protected InvokeInstruction(short opcode, int index) { super(opcode, index); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(ConstantPool cp) {
/*  85 */     Constant c = cp.getConstant(this.index);
/*  86 */     StringTokenizer tok = new StringTokenizer(cp.constantToString(c));
/*     */     
/*  88 */     return String.valueOf(Constants.OPCODE_NAMES[this.opcode]) + " " + 
/*  89 */       tok.nextToken().replace('.', '/') + tok.nextToken();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int consumeStack(ConstantPoolGen cpg) {
/*     */     int sum;
/*  98 */     String signature = getSignature(cpg);
/*  99 */     Type[] args = Type.getArgumentTypes(signature);
/*     */ 
/*     */     
/* 102 */     if (this.opcode == 184) {
/* 103 */       sum = 0;
/*     */     } else {
/* 105 */       sum = 1;
/*     */     } 
/* 107 */     int n = args.length;
/* 108 */     for (int i = 0; i < n; i++) {
/* 109 */       sum += args[i].getSize();
/*     */     }
/* 111 */     return sum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public int produceStack(ConstantPoolGen cpg) { return getReturnType(cpg).getSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Type getType(ConstantPoolGen cpg) { return getReturnType(cpg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public String getMethodName(ConstantPoolGen cpg) { return getName(cpg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public Type getReturnType(ConstantPoolGen cpg) { return Type.getReturnType(getSignature(cpg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public Type[] getArgumentTypes(ConstantPoolGen cpg) { return Type.getArgumentTypes(getSignature(cpg)); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\InvokeInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */