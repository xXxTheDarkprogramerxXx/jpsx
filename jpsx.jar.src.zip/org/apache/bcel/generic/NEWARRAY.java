/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.ExceptionConstants;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NEWARRAY
/*     */   extends Instruction
/*     */   implements AllocationInstruction, ExceptionThrower, StackProducer
/*     */ {
/*     */   private byte type;
/*     */   
/*     */   NEWARRAY() {}
/*     */   
/*     */   public NEWARRAY(byte type) {
/*  78 */     super((short)188, (short)2);
/*  79 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*  83 */   public NEWARRAY(BasicType type) { this(type.getType()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  91 */     out.writeByte(this.opcode);
/*  92 */     out.writeByte(this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public final byte getTypecode() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public final Type getType() { return new ArrayType(BasicType.getType(this.type), true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public String toString(boolean verbose) { return String.valueOf(super.toString(verbose)) + " " + Constants.TYPE_NAMES[this.type]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {
/* 118 */     this.type = bytes.readByte();
/* 119 */     this.length = 2;
/*     */   }
/*     */ 
/*     */   
/* 123 */   public Class[] getExceptions() { return new Class[] { ExceptionConstants.NEGATIVE_ARRAY_SIZE_EXCEPTION }; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 135 */     v.visitAllocationInstruction(this);
/* 136 */     v.visitExceptionThrower(this);
/* 137 */     v.visitStackProducer(this);
/* 138 */     v.visitNEWARRAY(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\NEWARRAY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */