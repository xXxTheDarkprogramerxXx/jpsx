/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import org.apache.bcel.classfile.Constant;
/*     */ import org.apache.bcel.classfile.ConstantCP;
/*     */ import org.apache.bcel.classfile.ConstantClass;
/*     */ import org.apache.bcel.classfile.ConstantDouble;
/*     */ import org.apache.bcel.classfile.ConstantFieldref;
/*     */ import org.apache.bcel.classfile.ConstantFloat;
/*     */ import org.apache.bcel.classfile.ConstantInteger;
/*     */ import org.apache.bcel.classfile.ConstantInterfaceMethodref;
/*     */ import org.apache.bcel.classfile.ConstantLong;
/*     */ import org.apache.bcel.classfile.ConstantMethodref;
/*     */ import org.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.ConstantString;
/*     */ import org.apache.bcel.classfile.ConstantUtf8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantPoolGen
/*     */   implements Serializable
/*     */ {
/*  76 */   protected int size = 1024;
/*  77 */   protected Constant[] constants = new Constant[this.size];
/*  78 */   protected int index = 1;
/*     */   private static final String METHODREF_DELIM = ":";
/*     */   private static final String IMETHODREF_DELIM = "#";
/*     */   private static final String FIELDREF_DELIM = "&";
/*     */   private static final String NAT_DELIM = "%";
/*     */   
/*     */   private static class Index implements Serializable {
/*     */     int index;
/*     */     
/*  87 */     Index(int i) { this.index = i; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantPoolGen(Constant[] cs) {
/*  96 */     if (cs.length > this.size) {
/*  97 */       this.size = cs.length;
/*  98 */       this.constants = new Constant[this.size];
/*     */     } 
/*     */     
/* 101 */     System.arraycopy(cs, 0, this.constants, 0, cs.length);
/*     */     
/* 103 */     if (cs.length > 0) {
/* 104 */       this.index = cs.length;
/*     */     }
/* 106 */     for (int i = 1; i < this.index; i++) {
/* 107 */       Constant c = this.constants[i];
/*     */       
/* 109 */       if (c instanceof ConstantString) {
/* 110 */         ConstantString s = (ConstantString)c;
/* 111 */         ConstantUtf8 u8 = (ConstantUtf8)this.constants[s.getStringIndex()];
/*     */         
/* 113 */         this.string_table.put(u8.getBytes(), new Index(i));
/* 114 */       } else if (c instanceof ConstantClass) {
/* 115 */         ConstantClass s = (ConstantClass)c;
/* 116 */         ConstantUtf8 u8 = (ConstantUtf8)this.constants[s.getNameIndex()];
/*     */         
/* 118 */         this.class_table.put(u8.getBytes(), new Index(i));
/* 119 */       } else if (c instanceof ConstantNameAndType) {
/* 120 */         ConstantNameAndType n = (ConstantNameAndType)c;
/* 121 */         ConstantUtf8 u8 = (ConstantUtf8)this.constants[n.getNameIndex()];
/* 122 */         ConstantUtf8 u8_2 = (ConstantUtf8)this.constants[n.getSignatureIndex()];
/*     */         
/* 124 */         this.n_a_t_table.put(String.valueOf(u8.getBytes()) + "%" + u8_2.getBytes(), new Index(i));
/* 125 */       } else if (c instanceof ConstantUtf8) {
/* 126 */         ConstantUtf8 u = (ConstantUtf8)c;
/*     */         
/* 128 */         this.utf8_table.put(u.getBytes(), new Index(i));
/* 129 */       } else if (c instanceof ConstantCP) {
/* 130 */         ConstantCP m = (ConstantCP)c;
/* 131 */         ConstantClass clazz = (ConstantClass)this.constants[m.getClassIndex()];
/* 132 */         ConstantNameAndType n = (ConstantNameAndType)this.constants[m.getNameAndTypeIndex()];
/*     */         
/* 134 */         ConstantUtf8 u8 = (ConstantUtf8)this.constants[clazz.getNameIndex()];
/* 135 */         String class_name = u8.getBytes().replace('/', '.');
/*     */         
/* 137 */         u8 = (ConstantUtf8)this.constants[n.getNameIndex()];
/* 138 */         String method_name = u8.getBytes();
/*     */         
/* 140 */         u8 = (ConstantUtf8)this.constants[n.getSignatureIndex()];
/* 141 */         String signature = u8.getBytes();
/*     */         
/* 143 */         String delim = ":";
/*     */         
/* 145 */         if (c instanceof ConstantInterfaceMethodref) {
/* 146 */           delim = "#";
/* 147 */         } else if (c instanceof ConstantFieldref) {
/* 148 */           delim = "&";
/*     */         } 
/* 150 */         this.cp_table.put(String.valueOf(class_name) + delim + method_name + delim + signature, new Index(i));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public ConstantPoolGen(ConstantPool cp) { this(cp.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantPoolGen() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adjustSize() {
/* 170 */     if (this.index + 3 >= this.size) {
/* 171 */       Constant[] cs = this.constants;
/*     */       
/* 173 */       this.size *= 2;
/* 174 */       this.constants = new Constant[this.size];
/* 175 */       System.arraycopy(cs, 0, this.constants, 0, this.index);
/*     */     } 
/*     */   }
/*     */   
/* 179 */   private HashMap string_table = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupString(String str) {
/* 188 */     Index index = (Index)this.string_table.get(str);
/* 189 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addString(String str) {
/*     */     int ret;
/* 201 */     if ((ret = lookupString(str)) != -1) {
/* 202 */       return ret;
/*     */     }
/* 204 */     int utf8 = addUtf8(str);
/*     */     
/* 206 */     adjustSize();
/*     */     
/* 208 */     ConstantString s = new ConstantString(utf8);
/*     */     
/* 210 */     ret = this.index;
/* 211 */     this.constants[this.index++] = s;
/*     */     
/* 213 */     this.string_table.put(str, new Index(ret));
/*     */     
/* 215 */     return ret;
/*     */   }
/*     */   
/* 218 */   private HashMap class_table = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupClass(String str) {
/* 227 */     Index index = (Index)this.class_table.get(str.replace('.', '/'));
/* 228 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int addClass_(String clazz) {
/*     */     int ret;
/* 234 */     if ((ret = lookupClass(clazz)) != -1) {
/* 235 */       return ret;
/*     */     }
/* 237 */     adjustSize();
/*     */     
/* 239 */     ConstantClass c = new ConstantClass(addUtf8(clazz));
/*     */     
/* 241 */     ret = this.index;
/* 242 */     this.constants[this.index++] = c;
/*     */     
/* 244 */     this.class_table.put(clazz, new Index(ret));
/*     */     
/* 246 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   public int addClass(String str) { return addClass_(str.replace('.', '/')); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   public int addClass(ObjectType type) { return addClass(type.getClassName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public int addArrayClass(ArrayType type) { return addClass_(type.getSignature()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupInteger(int n) {
/* 287 */     for (int i = 1; i < this.index; i++) {
/* 288 */       if (this.constants[i] instanceof ConstantInteger) {
/* 289 */         ConstantInteger c = (ConstantInteger)this.constants[i];
/*     */         
/* 291 */         if (c.getBytes() == n) {
/* 292 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 296 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addInteger(int n) {
/*     */     int ret;
/* 308 */     if ((ret = lookupInteger(n)) != -1) {
/* 309 */       return ret;
/*     */     }
/* 311 */     adjustSize();
/*     */     
/* 313 */     ret = this.index;
/* 314 */     this.constants[this.index++] = new ConstantInteger(n);
/*     */     
/* 316 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupFloat(float n) {
/* 326 */     int bits = Float.floatToIntBits(n);
/*     */     
/* 328 */     for (int i = 1; i < this.index; i++) {
/* 329 */       if (this.constants[i] instanceof ConstantFloat) {
/* 330 */         ConstantFloat c = (ConstantFloat)this.constants[i];
/*     */         
/* 332 */         if (Float.floatToIntBits(c.getBytes()) == bits) {
/* 333 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 337 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addFloat(float n) {
/*     */     int ret;
/* 349 */     if ((ret = lookupFloat(n)) != -1) {
/* 350 */       return ret;
/*     */     }
/* 352 */     adjustSize();
/*     */     
/* 354 */     ret = this.index;
/* 355 */     this.constants[this.index++] = new ConstantFloat(n);
/*     */     
/* 357 */     return ret;
/*     */   }
/*     */   
/* 360 */   private HashMap utf8_table = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupUtf8(String n) {
/* 369 */     Index index = (Index)this.utf8_table.get(n);
/*     */     
/* 371 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addUtf8(String n) {
/*     */     int ret;
/* 383 */     if ((ret = lookupUtf8(n)) != -1) {
/* 384 */       return ret;
/*     */     }
/* 386 */     adjustSize();
/*     */     
/* 388 */     ret = this.index;
/* 389 */     this.constants[this.index++] = new ConstantUtf8(n);
/*     */     
/* 391 */     this.utf8_table.put(n, new Index(ret));
/*     */     
/* 393 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupLong(long n) {
/* 403 */     for (int i = 1; i < this.index; i++) {
/* 404 */       if (this.constants[i] instanceof ConstantLong) {
/* 405 */         ConstantLong c = (ConstantLong)this.constants[i];
/*     */         
/* 407 */         if (c.getBytes() == n) {
/* 408 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 412 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addLong(long n) {
/*     */     int ret;
/* 424 */     if ((ret = lookupLong(n)) != -1) {
/* 425 */       return ret;
/*     */     }
/* 427 */     adjustSize();
/*     */     
/* 429 */     ret = this.index;
/* 430 */     this.constants[this.index] = new ConstantLong(n);
/* 431 */     this.index += 2;
/*     */     
/* 433 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupDouble(double n) {
/* 443 */     long bits = Double.doubleToLongBits(n);
/*     */     
/* 445 */     for (int i = 1; i < this.index; i++) {
/* 446 */       if (this.constants[i] instanceof ConstantDouble) {
/* 447 */         ConstantDouble c = (ConstantDouble)this.constants[i];
/*     */         
/* 449 */         if (Double.doubleToLongBits(c.getBytes()) == bits) {
/* 450 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 454 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addDouble(double n) {
/*     */     int ret;
/* 466 */     if ((ret = lookupDouble(n)) != -1) {
/* 467 */       return ret;
/*     */     }
/* 469 */     adjustSize();
/*     */     
/* 471 */     ret = this.index;
/* 472 */     this.constants[this.index] = new ConstantDouble(n);
/* 473 */     this.index += 2;
/*     */     
/* 475 */     return ret;
/*     */   }
/*     */   
/* 478 */   private HashMap n_a_t_table = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupNameAndType(String name, String signature) {
/* 488 */     Index index = (Index)this.n_a_t_table.get(String.valueOf(name) + "%" + signature);
/* 489 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addNameAndType(String name, String signature) {
/*     */     int ret;
/* 503 */     if ((ret = lookupNameAndType(name, signature)) != -1) {
/* 504 */       return ret;
/*     */     }
/* 506 */     adjustSize();
/*     */     
/* 508 */     int name_index = addUtf8(name);
/* 509 */     int signature_index = addUtf8(signature);
/* 510 */     ret = this.index;
/* 511 */     this.constants[this.index++] = new ConstantNameAndType(name_index, signature_index);
/*     */     
/* 513 */     this.n_a_t_table.put(String.valueOf(name) + "%" + signature, new Index(ret));
/* 514 */     return ret;
/*     */   }
/*     */   
/* 517 */   private HashMap cp_table = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupMethodref(String class_name, String method_name, String signature) {
/* 528 */     Index index = (Index)this.cp_table.get(String.valueOf(class_name) + ":" + method_name + 
/* 529 */         ":" + signature);
/* 530 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */   
/*     */   public int lookupMethodref(MethodGen method) {
/* 534 */     return lookupMethodref(method.getClassName(), method.getName(), 
/* 535 */         method.getSignature());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addMethodref(String class_name, String method_name, String signature) {
/*     */     int ret;
/* 548 */     if ((ret = lookupMethodref(class_name, method_name, signature)) != -1) {
/* 549 */       return ret;
/*     */     }
/* 551 */     adjustSize();
/*     */     
/* 553 */     int name_and_type_index = addNameAndType(method_name, signature);
/* 554 */     int class_index = addClass(class_name);
/* 555 */     ret = this.index;
/* 556 */     this.constants[this.index++] = new ConstantMethodref(class_index, name_and_type_index);
/*     */     
/* 558 */     this.cp_table.put(String.valueOf(class_name) + ":" + method_name + 
/* 559 */         ":" + signature, new Index(ret));
/*     */     
/* 561 */     return ret;
/*     */   }
/*     */   
/*     */   public int addMethodref(MethodGen method) {
/* 565 */     return addMethodref(method.getClassName(), method.getName(), 
/* 566 */         method.getSignature());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupInterfaceMethodref(String class_name, String method_name, String signature) {
/* 578 */     Index index = (Index)this.cp_table.get(String.valueOf(class_name) + "#" + method_name + 
/* 579 */         "#" + signature);
/* 580 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */   
/*     */   public int lookupInterfaceMethodref(MethodGen method) {
/* 584 */     return lookupInterfaceMethodref(method.getClassName(), method.getName(), 
/* 585 */         method.getSignature());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addInterfaceMethodref(String class_name, String method_name, String signature) {
/*     */     int ret;
/* 598 */     if ((ret = lookupInterfaceMethodref(class_name, method_name, signature)) != -1) {
/* 599 */       return ret;
/*     */     }
/* 601 */     adjustSize();
/*     */     
/* 603 */     int class_index = addClass(class_name);
/* 604 */     int name_and_type_index = addNameAndType(method_name, signature);
/* 605 */     ret = this.index;
/* 606 */     this.constants[this.index++] = new ConstantInterfaceMethodref(class_index, name_and_type_index);
/*     */     
/* 608 */     this.cp_table.put(String.valueOf(class_name) + "#" + method_name + 
/* 609 */         "#" + signature, new Index(ret));
/*     */     
/* 611 */     return ret;
/*     */   }
/*     */   
/*     */   public int addInterfaceMethodref(MethodGen method) {
/* 615 */     return addInterfaceMethodref(method.getClassName(), method.getName(), 
/* 616 */         method.getSignature());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookupFieldref(String class_name, String field_name, String signature) {
/* 628 */     Index index = (Index)this.cp_table.get(String.valueOf(class_name) + "&" + field_name + 
/* 629 */         "&" + signature);
/* 630 */     return (index != null) ? index.index : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addFieldref(String class_name, String field_name, String signature) {
/*     */     int ret;
/* 644 */     if ((ret = lookupFieldref(class_name, field_name, signature)) != -1) {
/* 645 */       return ret;
/*     */     }
/* 647 */     adjustSize();
/*     */     
/* 649 */     int class_index = addClass(class_name);
/* 650 */     int name_and_type_index = addNameAndType(field_name, signature);
/* 651 */     ret = this.index;
/* 652 */     this.constants[this.index++] = new ConstantFieldref(class_index, name_and_type_index);
/*     */     
/* 654 */     this.cp_table.put(String.valueOf(class_name) + "&" + field_name + "&" + signature, new Index(ret));
/*     */     
/* 656 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 663 */   public Constant getConstant(int i) { return this.constants[i]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 671 */   public void setConstant(int i, Constant c) { this.constants[i] = c; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 677 */   public ConstantPool getConstantPool() { return new ConstantPool(this.constants); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 684 */   public int getSize() { return this.index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstantPool getFinalConstantPool() {
/* 691 */     Constant[] cs = new Constant[this.index];
/*     */     
/* 693 */     System.arraycopy(this.constants, 0, cs, 0, this.index);
/*     */     
/* 695 */     return new ConstantPool(cs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 702 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 704 */     for (int i = 1; i < this.index; i++) {
/* 705 */       buf.append(String.valueOf(i) + ")" + this.constants[i] + "\n");
/*     */     }
/* 707 */     return buf.toString(); } public int addConstant(Constant c, ConstantPoolGen cp) { String signature, name, class_name; ConstantUtf8 u8, u8_2; ConstantNameAndType n; ConstantUtf8 u8, u8; ConstantClass clazz;
/*     */     ConstantUtf8 u8;
/*     */     ConstantNameAndType n;
/*     */     ConstantClass s;
/*     */     ConstantString s;
/*     */     ConstantCP m;
/* 713 */     Constant[] constants = cp.getConstantPool().getConstantPool();
/*     */     
/* 715 */     switch (c.getTag()) {
/*     */       case 8:
/* 717 */         s = (ConstantString)c;
/* 718 */         u8 = (ConstantUtf8)constants[s.getStringIndex()];
/*     */         
/* 720 */         return addString(u8.getBytes());
/*     */ 
/*     */       
/*     */       case 7:
/* 724 */         s = (ConstantClass)c;
/* 725 */         u8 = (ConstantUtf8)constants[s.getNameIndex()];
/*     */         
/* 727 */         return addClass(u8.getBytes());
/*     */ 
/*     */       
/*     */       case 12:
/* 731 */         n = (ConstantNameAndType)c;
/* 732 */         u8 = (ConstantUtf8)constants[n.getNameIndex()];
/* 733 */         u8_2 = (ConstantUtf8)constants[n.getSignatureIndex()];
/*     */         
/* 735 */         return addNameAndType(u8.getBytes(), u8_2.getBytes());
/*     */ 
/*     */       
/*     */       case 1:
/* 739 */         return addUtf8(((ConstantUtf8)c).getBytes());
/*     */       
/*     */       case 6:
/* 742 */         return addDouble(((ConstantDouble)c).getBytes());
/*     */       
/*     */       case 4:
/* 745 */         return addFloat(((ConstantFloat)c).getBytes());
/*     */       
/*     */       case 5:
/* 748 */         return addLong(((ConstantLong)c).getBytes());
/*     */       
/*     */       case 3:
/* 751 */         return addInteger(((ConstantInteger)c).getBytes());
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/* 755 */         m = (ConstantCP)c;
/* 756 */         clazz = (ConstantClass)constants[m.getClassIndex()];
/* 757 */         n = (ConstantNameAndType)constants[m.getNameAndTypeIndex()];
/* 758 */         u8 = (ConstantUtf8)constants[clazz.getNameIndex()];
/* 759 */         class_name = u8.getBytes().replace('/', '.');
/*     */         
/* 761 */         u8 = (ConstantUtf8)constants[n.getNameIndex()];
/* 762 */         name = u8.getBytes();
/*     */         
/* 764 */         u8 = (ConstantUtf8)constants[n.getSignatureIndex()];
/* 765 */         signature = u8.getBytes();
/*     */         
/* 767 */         switch (c.getTag()) {
/*     */           case 11:
/* 769 */             return addInterfaceMethodref(class_name, name, signature);
/*     */           
/*     */           case 10:
/* 772 */             return addMethodref(class_name, name, signature);
/*     */           
/*     */           case 9:
/* 775 */             return addFieldref(class_name, name, signature);
/*     */         } 
/*     */         
/* 778 */         throw new RuntimeException("Unknown constant type " + c);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 783 */     throw new RuntimeException("Unknown constant type " + c); }
/*     */ 
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\ConstantPoolGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */