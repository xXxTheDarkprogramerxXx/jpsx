package org.apache.bcel.generic;

public interface UnconditionalBranch {}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\UnconditionalBranch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */