/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SIPUSH
/*     */   extends Instruction
/*     */   implements ConstantPushInstruction
/*     */ {
/*     */   private short b;
/*     */   
/*     */   SIPUSH() {}
/*     */   
/*     */   public SIPUSH(short b) {
/*  77 */     super((short)17, (short)3);
/*  78 */     this.b = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  85 */     super.dump(out);
/*  86 */     out.writeShort(this.b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public String toString(boolean verbose) { return String.valueOf(super.toString(verbose)) + " " + this.b; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {
/* 101 */     this.length = 3;
/* 102 */     this.b = bytes.readShort();
/*     */   }
/*     */   
/* 105 */   public Number getValue() { return new Integer(this.b); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public Type getType(ConstantPoolGen cp) { return Type.SHORT; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 122 */     v.visitPushInstruction(this);
/* 123 */     v.visitStackProducer(this);
/* 124 */     v.visitTypedInstruction(this);
/* 125 */     v.visitConstantPushInstruction(this);
/* 126 */     v.visitSIPUSH(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\SIPUSH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */