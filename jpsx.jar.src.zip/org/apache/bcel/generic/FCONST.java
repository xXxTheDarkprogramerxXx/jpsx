/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FCONST
/*     */   extends Instruction
/*     */   implements ConstantPushInstruction, TypedInstruction
/*     */ {
/*     */   private float value;
/*     */   
/*     */   FCONST() {}
/*     */   
/*     */   public FCONST(float f) {
/*  76 */     super((short)11, (short)1);
/*     */     
/*  78 */     if (f == 0.0D) {
/*  79 */       this.opcode = 11;
/*  80 */     } else if (f == 1.0D) {
/*  81 */       this.opcode = 12;
/*  82 */     } else if (f == 2.0D) {
/*  83 */       this.opcode = 13;
/*     */     } else {
/*  85 */       throw new ClassGenException("FCONST can be used only for 0.0, 1.0 and 2.0: " + f);
/*     */     } 
/*  87 */     this.value = f;
/*     */   }
/*     */   
/*  90 */   public Number getValue() { return new Float(this.value); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public Type getType(ConstantPoolGen cp) { return Type.FLOAT; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 107 */     v.visitPushInstruction(this);
/* 108 */     v.visitStackProducer(this);
/* 109 */     v.visitTypedInstruction(this);
/* 110 */     v.visitConstantPushInstruction(this);
/* 111 */     v.visitFCONST(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\FCONST.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */