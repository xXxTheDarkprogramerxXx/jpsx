/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Instruction
/*     */   implements Cloneable, Serializable
/*     */ {
/*  70 */   protected short length = 1;
/*  71 */   protected short opcode = -1;
/*     */   
/*  73 */   private static InstructionComparator cmp = InstructionComparator.DEFAULT;
/*     */ 
/*     */ 
/*     */   
/*     */   Instruction() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction(short opcode, short length) {
/*  82 */     this.length = length;
/*  83 */     this.opcode = opcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void dump(DataOutputStream out) throws IOException { out.writeByte(this.opcode); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public String getName() { return Constants.OPCODE_NAMES[this.opcode]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 110 */     if (verbose) {
/* 111 */       return String.valueOf(getName()) + "[" + this.opcode + "](" + this.length + ")";
/*     */     }
/* 113 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public String toString() { return toString(true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public String toString(ConstantPool cp) { return toString(false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction copy() {
/* 139 */     Instruction i = null;
/*     */ 
/*     */     
/* 142 */     if (InstructionConstants.INSTRUCTIONS[getOpcode()] != null) {
/* 143 */       i = this;
/*     */     } else {
/*     */       try {
/* 146 */         i = (Instruction)clone();
/* 147 */       } catch (CloneNotSupportedException e) {
/* 148 */         System.err.println(e);
/*     */       } 
/*     */     } 
/*     */     
/* 152 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Instruction readInstruction(ByteSequence bytes) throws IOException {
/*     */     Class clazz;
/* 175 */     boolean wide = false;
/* 176 */     short opcode = (short)bytes.readUnsignedByte();
/* 177 */     Instruction obj = null;
/*     */     
/* 179 */     if (opcode == 196) {
/* 180 */       wide = true;
/* 181 */       opcode = (short)bytes.readUnsignedByte();
/*     */     } 
/*     */     
/* 184 */     if (InstructionConstants.INSTRUCTIONS[opcode] != null) {
/* 185 */       return InstructionConstants.INSTRUCTIONS[opcode];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 193 */       clazz = Class.forName(className(opcode));
/* 194 */     } catch (ClassNotFoundException cnfe) {
/*     */ 
/*     */       
/* 197 */       throw new ClassGenException("Illegal opcode detected.");
/*     */     } 
/*     */     
/*     */     try {
/* 201 */       obj = (Instruction)clazz.newInstance();
/*     */       
/* 203 */       if (wide && !(obj instanceof LocalVariableInstruction) && 
/* 204 */         !(obj instanceof IINC) && 
/* 205 */         !(obj instanceof RET)) {
/* 206 */         throw new Exception("Illegal opcode after wide: " + opcode);
/*     */       }
/* 208 */       obj.setOpcode(opcode);
/* 209 */       obj.initFromFile(bytes, wide);
/*     */     } catch (Exception e) {
/* 211 */       throw new ClassGenException(e.toString());
/*     */     } 
/* 213 */     return obj;
/*     */   }
/*     */   
/*     */   private static final String className(short opcode) {
/* 217 */     String name = Constants.OPCODE_NAMES[opcode].toUpperCase();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     try { int len = name.length();
/* 224 */       char ch1 = name.charAt(len - 2), ch2 = name.charAt(len - 1);
/*     */       
/* 226 */       if (ch1 == '_' && ch2 >= '0' && ch2 <= '5') {
/* 227 */         name = name.substring(0, len - 2);
/*     */       }
/* 229 */       if (name.equals("ICONST_M1"))
/* 230 */         name = "ICONST";  }
/* 231 */     catch (StringIndexOutOfBoundsException e) { System.err.println(e); }
/*     */     
/* 233 */     return "org.apache.bcel.generic." + name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public int consumeStack(ConstantPoolGen cpg) { return Constants.CONSUME_STACK[this.opcode]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   public int produceStack(ConstantPoolGen cpg) { return Constants.PRODUCE_STACK[this.opcode]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public short getOpcode() { return this.opcode; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   public int getLength() { return this.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 271 */   private void setOpcode(short opcode) { this.opcode = opcode; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void accept(Visitor paramVisitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public static InstructionComparator getComparator() { return cmp; }
/*     */ 
/*     */ 
/*     */   
/* 296 */   public static void setComparator(InstructionComparator c) { cmp = c; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object that) {
/* 302 */     return (that instanceof Instruction) ? 
/* 303 */       cmp.equals(this, (Instruction)that) : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\Instruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */