package org.apache.bcel.generic;

public interface VariableLengthInstruction {}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\VariableLengthInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */