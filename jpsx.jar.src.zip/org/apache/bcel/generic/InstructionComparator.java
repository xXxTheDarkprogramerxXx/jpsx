/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface InstructionComparator
/*     */ {
/*  72 */   public static final InstructionComparator DEFAULT = new InstructionComparator() {
/*     */       public boolean equals(Instruction i1, Instruction i2) {
/*  74 */         if (i1.opcode == i2.opcode) {
/*  75 */           if (i1 instanceof Select)
/*  76 */           { InstructionHandle[] t1 = ((Select)i1).getTargets();
/*  77 */             InstructionHandle[] t2 = ((Select)i2).getTargets();
/*     */             
/*  79 */             if (t1.length == t2.length) {
/*  80 */               for (int i = 0; i < t1.length; i++) {
/*  81 */                 if (t1[i] != t2[i]) {
/*  82 */                   return false;
/*     */                 }
/*     */               } 
/*     */               
/*  86 */               return true;
/*     */             }  }
/*  88 */           else { if (i1 instanceof BranchInstruction)
/*  89 */               return (((BranchInstruction)i1).target == 
/*  90 */                 ((BranchInstruction)i2).target); 
/*  91 */             if (i1 instanceof ConstantPushInstruction)
/*  92 */               return ((ConstantPushInstruction)i1).getValue()
/*  93 */                 .equals(((ConstantPushInstruction)i2).getValue()); 
/*  94 */             if (i1 instanceof IndexedInstruction)
/*  95 */               return (((IndexedInstruction)i1).getIndex() == (
/*  96 */                 (IndexedInstruction)i2).getIndex()); 
/*  97 */             if (i1 instanceof NEWARRAY) {
/*  98 */               return (((NEWARRAY)i1).getTypecode() == ((NEWARRAY)i2).getTypecode());
/*     */             }
/* 100 */             return true; }
/*     */         
/*     */         }
/*     */         
/* 104 */         return false;
/*     */       }
/*     */     };
/*     */   
/*     */   boolean equals(Instruction paramInstruction1, Instruction paramInstruction2);
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\InstructionComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */