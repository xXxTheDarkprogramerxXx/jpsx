/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import org.apache.bcel.classfile.Attribute;
/*     */ import org.apache.bcel.classfile.Code;
/*     */ import org.apache.bcel.classfile.CodeException;
/*     */ import org.apache.bcel.classfile.ExceptionTable;
/*     */ import org.apache.bcel.classfile.LineNumber;
/*     */ import org.apache.bcel.classfile.LineNumberTable;
/*     */ import org.apache.bcel.classfile.LocalVariable;
/*     */ import org.apache.bcel.classfile.LocalVariableTable;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodGen
/*     */   extends FieldGenOrMethodGen
/*     */ {
/*     */   private String class_name;
/*     */   private Type[] arg_types;
/*     */   private String[] arg_names;
/*     */   private int max_locals;
/*     */   private int max_stack;
/*     */   private InstructionList il;
/*     */   private boolean strip_attributes;
/*     */   private ArrayList variable_vec;
/*     */   private ArrayList line_number_vec;
/*     */   private ArrayList exception_vec;
/*     */   private ArrayList throws_vec;
/*     */   private ArrayList code_attrs_vec;
/*     */   private ArrayList observers;
/*     */   
/*     */   public MethodGen(int access_flags, Type return_type, Type[] arg_types, String[] arg_names, String method_name, String class_name, InstructionList il, ConstantPoolGen cp) {
/*  86 */     this.variable_vec = new ArrayList();
/*  87 */     this.line_number_vec = new ArrayList();
/*  88 */     this.exception_vec = new ArrayList();
/*  89 */     this.throws_vec = new ArrayList();
/*  90 */     this.code_attrs_vec = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     setAccessFlags(access_flags);
/* 118 */     setType(return_type);
/* 119 */     setArgumentTypes(arg_types);
/* 120 */     setArgumentNames(arg_names);
/* 121 */     setName(method_name);
/* 122 */     setClassName(class_name);
/* 123 */     setInstructionList(il);
/* 124 */     setConstantPool(cp);
/*     */     
/* 126 */     boolean abstract_ = !(!isAbstract() && !isNative());
/* 127 */     InstructionHandle start = null;
/* 128 */     InstructionHandle end = null;
/*     */     
/* 130 */     if (!abstract_) {
/* 131 */       start = il.getStart();
/* 132 */       end = il.getEnd();
/*     */ 
/*     */ 
/*     */       
/* 136 */       if (!isStatic() && class_name != null) {
/* 137 */         addLocalVariable("this", new ObjectType(class_name), start, end);
/*     */       }
/*     */     } 
/*     */     
/* 141 */     if (arg_types != null) {
/* 142 */       int size = arg_types.length;
/*     */       
/* 144 */       for (int i = 0; i < size; i++) {
/* 145 */         if (Type.VOID == arg_types[i]) {
/* 146 */           throw new ClassGenException("'void' is an illegal argument type for a method");
/*     */         }
/*     */       } 
/*     */       
/* 150 */       if (arg_names != null) {
/* 151 */         if (size != arg_names.length)
/* 152 */           throw new ClassGenException("Mismatch in argument array lengths: " + 
/* 153 */               size + " vs. " + arg_names.length); 
/*     */       } else {
/* 155 */         arg_names = new String[size];
/*     */         
/* 157 */         for (int i = 0; i < size; i++) {
/* 158 */           arg_names[i] = "arg" + i;
/*     */         }
/* 160 */         setArgumentNames(arg_names);
/*     */       } 
/*     */       
/* 163 */       if (!abstract_) {
/* 164 */         for (int i = 0; i < size; i++) {
/* 165 */           addLocalVariable(arg_names[i], arg_types[i], start, end);
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodGen(Method m, String class_name, ConstantPoolGen cp) {
/* 184 */     this(m.getAccessFlags(), Type.getReturnType(m.getSignature()), Type.getArgumentTypes(m.getSignature()), null, m.getName(), class_name, ((m.getAccessFlags() & 0x500) == 0) ? new InstructionList(m.getCode().getCode()) : null, cp);
/*     */     
/* 186 */     Attribute[] attributes = m.getAttributes();
/* 187 */     for (int i = 0; i < attributes.length; i++) {
/* 188 */       Attribute a = attributes[i];
/*     */       
/* 190 */       if (a instanceof Code) {
/* 191 */         Code c = (Code)a;
/* 192 */         setMaxStack(c.getMaxStack());
/* 193 */         setMaxLocals(c.getMaxLocals());
/*     */         
/* 195 */         CodeException[] ces = c.getExceptionTable();
/*     */         
/* 197 */         if (ces != null) {
/* 198 */           for (int j = 0; j < ces.length; j++) {
/* 199 */             InstructionHandle end; CodeException ce = ces[j];
/* 200 */             int type = ce.getCatchType();
/* 201 */             ObjectType c_type = null;
/*     */             
/* 203 */             if (type > 0) {
/* 204 */               String cen = m.getConstantPool().getConstantString(type, (byte)7);
/* 205 */               c_type = new ObjectType(cen);
/*     */             } 
/*     */             
/* 208 */             int end_pc = ce.getEndPC();
/* 209 */             int length = m.getCode().getCode().length;
/*     */ 
/*     */ 
/*     */             
/* 213 */             if (length == end_pc) {
/* 214 */               end = this.il.getEnd();
/*     */             } else {
/* 216 */               end = this.il.findHandle(end_pc);
/* 217 */               end = end.getPrev();
/*     */             } 
/*     */             
/* 220 */             addExceptionHandler(this.il.findHandle(ce.getStartPC()), end, 
/* 221 */                 this.il.findHandle(ce.getHandlerPC()), c_type);
/*     */           } 
/*     */         }
/*     */         
/* 225 */         Attribute[] c_attributes = c.getAttributes();
/* 226 */         for (int j = 0; j < c_attributes.length; j++) {
/* 227 */           a = c_attributes[j];
/*     */           
/* 229 */           if (a instanceof LineNumberTable)
/* 230 */           { LineNumber[] ln = ((LineNumberTable)a).getLineNumberTable();
/*     */             
/* 232 */             for (int k = 0; k < ln.length; k++) {
/* 233 */               LineNumber l = ln[k];
/* 234 */               addLineNumber(this.il.findHandle(l.getStartPC()), l.getLineNumber());
/*     */             }  }
/* 236 */           else if (a instanceof LocalVariableTable)
/* 237 */           { LocalVariable[] lv = ((LocalVariableTable)a).getLocalVariableTable();
/*     */             
/* 239 */             removeLocalVariables();
/*     */             
/* 241 */             for (int k = 0; k < lv.length; k++) {
/* 242 */               LocalVariable l = lv[k];
/* 243 */               InstructionHandle start = this.il.findHandle(l.getStartPC());
/* 244 */               InstructionHandle end = this.il.findHandle(l.getStartPC() + l.getLength());
/*     */ 
/*     */               
/* 247 */               if (start == null) {
/* 248 */                 start = this.il.getStart();
/*     */               }
/*     */               
/* 251 */               if (end == null) {
/* 252 */                 end = this.il.getEnd();
/*     */               }
/*     */               
/* 255 */               addLocalVariable(l.getName(), Type.getType(l.getSignature()), 
/* 256 */                   l.getIndex(), start, end);
/*     */             }  }
/*     */           else
/* 259 */           { addCodeAttribute(a); } 
/*     */         } 
/* 261 */       } else if (a instanceof ExceptionTable) {
/* 262 */         String[] names = ((ExceptionTable)a).getExceptionNames();
/* 263 */         for (int j = 0; j < names.length; j++)
/* 264 */           addException(names[j]); 
/*     */       } else {
/* 266 */         addAttribute(a);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariableGen addLocalVariable(String name, Type type, int slot, InstructionHandle start, InstructionHandle end) {
/* 285 */     byte t = type.getType();
/*     */     
/* 287 */     if (t != 16) {
/* 288 */       int add = type.getSize();
/*     */       
/* 290 */       if (slot + add > this.max_locals) {
/* 291 */         this.max_locals = slot + add;
/*     */       }
/* 293 */       LocalVariableGen l = new LocalVariableGen(slot, name, type, start, end);
/*     */       
/*     */       int i;
/* 296 */       if ((i = this.variable_vec.indexOf(l)) >= 0) {
/* 297 */         this.variable_vec.set(i, l);
/*     */       } else {
/* 299 */         this.variable_vec.add(l);
/*     */       } 
/* 301 */       return l;
/*     */     } 
/* 303 */     throw new IllegalArgumentException("Can not use " + type + 
/* 304 */         " as type for local variable");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 324 */   public LocalVariableGen addLocalVariable(String name, Type type, InstructionHandle start, InstructionHandle end) { return addLocalVariable(name, type, this.max_locals, start, end); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   public void removeLocalVariable(LocalVariableGen l) { this.variable_vec.remove(l); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 339 */   public void removeLocalVariables() { this.variable_vec.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void sort(LocalVariableGen[] vars, int l, int r) {
/* 346 */     int i = l, j = r;
/* 347 */     int m = vars[(l + r) / 2].getIndex();
/*     */     
/*     */     while (true) {
/*     */       while (true) {
/* 351 */         if (vars[i].getIndex() >= m)
/* 352 */         { for (; m < vars[j].getIndex(); j--);
/*     */           
/* 354 */           if (i <= j) {
/* 355 */             LocalVariableGen h = vars[i]; vars[i] = vars[j]; vars[j] = h;
/* 356 */             i++; j--;
/*     */           } 
/* 358 */           if (i > j)
/*     */             break;  continue; }  i++;
/* 360 */       }  if (l < j) sort(vars, l, j); 
/* 361 */       if (i < r) sort(vars, i, r);
/*     */       
/*     */       return;
/*     */     } 
/*     */     i++;
/*     */     continue;
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalVariableGen[] getLocalVariables() {
/* 371 */     int size = this.variable_vec.size();
/* 372 */     LocalVariableGen[] lg = new LocalVariableGen[size];
/* 373 */     this.variable_vec.toArray(lg);
/*     */     
/* 375 */     for (int i = 0; i < size; i++) {
/* 376 */       if (lg[i].getStart() == null) {
/* 377 */         lg[i].setStart(this.il.getStart());
/*     */       }
/* 379 */       if (lg[i].getEnd() == null) {
/* 380 */         lg[i].setEnd(this.il.getEnd());
/*     */       }
/*     */     } 
/* 383 */     if (size > 1) {
/* 384 */       sort(lg, 0, size - 1);
/*     */     }
/* 386 */     return lg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariableTable getLocalVariableTable(ConstantPoolGen cp) {
/* 393 */     LocalVariableGen[] lg = getLocalVariables();
/* 394 */     int size = lg.length;
/* 395 */     LocalVariable[] lv = new LocalVariable[size];
/*     */     
/* 397 */     for (int i = 0; i < size; i++) {
/* 398 */       lv[i] = lg[i].getLocalVariable(cp);
/*     */     }
/* 400 */     return new LocalVariableTable(cp.addUtf8("LocalVariableTable"), 
/* 401 */         2 + lv.length * 10, lv, cp.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberGen addLineNumber(InstructionHandle ih, int src_line) {
/* 412 */     LineNumberGen l = new LineNumberGen(ih, src_line);
/* 413 */     this.line_number_vec.add(l);
/* 414 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 421 */   public void removeLineNumber(LineNumberGen l) { this.line_number_vec.remove(l); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 428 */   public void removeLineNumbers() { this.line_number_vec.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberGen[] getLineNumbers() {
/* 435 */     LineNumberGen[] lg = new LineNumberGen[this.line_number_vec.size()];
/* 436 */     this.line_number_vec.toArray(lg);
/* 437 */     return lg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberTable getLineNumberTable(ConstantPoolGen cp) {
/* 444 */     int size = this.line_number_vec.size();
/* 445 */     LineNumber[] ln = new LineNumber[size];
/*     */     
/*     */     try {
/* 448 */       for (int i = 0; i < size; i++)
/* 449 */         ln[i] = ((LineNumberGen)this.line_number_vec.get(i)).getLineNumber(); 
/* 450 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*     */     
/* 452 */     return new LineNumberTable(cp.addUtf8("LineNumberTable"), 
/* 453 */         2 + ln.length * 4, ln, cp.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeExceptionGen addExceptionHandler(InstructionHandle start_pc, InstructionHandle end_pc, InstructionHandle handler_pc, ObjectType catch_type) {
/* 471 */     if (start_pc == null || end_pc == null || handler_pc == null) {
/* 472 */       throw new ClassGenException("Exception handler target is null instruction");
/*     */     }
/* 474 */     CodeExceptionGen c = new CodeExceptionGen(start_pc, end_pc, 
/* 475 */         handler_pc, catch_type);
/* 476 */     this.exception_vec.add(c);
/* 477 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 484 */   public void removeExceptionHandler(CodeExceptionGen c) { this.exception_vec.remove(c); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 491 */   public void removeExceptionHandlers() { this.exception_vec.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeExceptionGen[] getExceptionHandlers() {
/* 498 */     CodeExceptionGen[] cg = new CodeExceptionGen[this.exception_vec.size()];
/* 499 */     this.exception_vec.toArray(cg);
/* 500 */     return cg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeException[] getCodeExceptions() {
/* 507 */     int size = this.exception_vec.size();
/* 508 */     CodeException[] c_exc = new CodeException[size];
/*     */     
/*     */     try {
/* 511 */       for (int i = 0; i < size; i++) {
/* 512 */         CodeExceptionGen c = (CodeExceptionGen)this.exception_vec.get(i);
/* 513 */         c_exc[i] = c.getCodeException(this.cp);
/*     */       } 
/* 515 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*     */     
/* 517 */     return c_exc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 526 */   public void addException(String class_name) { this.throws_vec.add(class_name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 533 */   public void removeException(String c) { this.throws_vec.remove(c); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 540 */   public void removeExceptions() { this.throws_vec.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getExceptions() {
/* 547 */     String[] e = new String[this.throws_vec.size()];
/* 548 */     this.throws_vec.toArray(e);
/* 549 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExceptionTable getExceptionTable(ConstantPoolGen cp) {
/* 556 */     int size = this.throws_vec.size();
/* 557 */     int[] ex = new int[size];
/*     */     
/*     */     try {
/* 560 */       for (int i = 0; i < size; i++)
/* 561 */         ex[i] = cp.addClass((String)this.throws_vec.get(i)); 
/* 562 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*     */     
/* 564 */     return new ExceptionTable(cp.addUtf8("Exceptions"), 
/* 565 */         2 + 2 * size, ex, cp.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 577 */   public void addCodeAttribute(Attribute a) { this.code_attrs_vec.add(a); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 582 */   public void removeCodeAttribute(Attribute a) { this.code_attrs_vec.remove(a); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 588 */   public void removeCodeAttributes() { this.code_attrs_vec.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute[] getCodeAttributes() {
/* 595 */     Attribute[] attributes = new Attribute[this.code_attrs_vec.size()];
/* 596 */     this.code_attrs_vec.toArray(attributes);
/* 597 */     return attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/* 607 */     String signature = getSignature();
/* 608 */     int name_index = this.cp.addUtf8(this.name);
/* 609 */     int signature_index = this.cp.addUtf8(signature);
/*     */ 
/*     */ 
/*     */     
/* 613 */     byte[] byte_code = null;
/*     */     
/* 615 */     if (this.il != null) {
/* 616 */       byte_code = this.il.getByteCode();
/*     */     }
/* 618 */     LineNumberTable lnt = null;
/* 619 */     LocalVariableTable lvt = null;
/*     */ 
/*     */ 
/*     */     
/* 623 */     if (this.variable_vec.size() > 0 && !this.strip_attributes) {
/* 624 */       addCodeAttribute(lvt = getLocalVariableTable(this.cp));
/*     */     }
/* 626 */     if (this.line_number_vec.size() > 0 && !this.strip_attributes) {
/* 627 */       addCodeAttribute(lnt = getLineNumberTable(this.cp));
/*     */     }
/* 629 */     Attribute[] code_attrs = getCodeAttributes();
/*     */ 
/*     */ 
/*     */     
/* 633 */     int attrs_len = 0;
/* 634 */     for (int i = 0; i < code_attrs.length; i++) {
/* 635 */       attrs_len += code_attrs[i].getLength() + 6;
/*     */     }
/* 637 */     CodeException[] c_exc = getCodeExceptions();
/* 638 */     int exc_len = c_exc.length * 8;
/*     */     
/* 640 */     Code code = null;
/*     */     
/* 642 */     if (this.il != null && !isAbstract()) {
/*     */       
/* 644 */       Attribute[] attributes = getAttributes();
/* 645 */       for (int i = 0; i < attributes.length; i++) {
/* 646 */         Attribute a = attributes[i];
/*     */         
/* 648 */         if (a instanceof Code) {
/* 649 */           removeAttribute(a);
/*     */         }
/*     */       } 
/* 652 */       code = new Code(this.cp.addUtf8("Code"), 
/* 653 */           8 + byte_code.length + 
/* 654 */           2 + exc_len + 
/* 655 */           2 + attrs_len, 
/* 656 */           this.max_stack, this.max_locals, 
/* 657 */           byte_code, c_exc, 
/* 658 */           code_attrs, 
/* 659 */           this.cp.getConstantPool());
/*     */       
/* 661 */       addAttribute(code);
/*     */     } 
/*     */     
/* 664 */     ExceptionTable et = null;
/*     */     
/* 666 */     if (this.throws_vec.size() > 0) {
/* 667 */       addAttribute(et = getExceptionTable(this.cp));
/*     */     }
/* 669 */     Method m = new Method(this.access_flags, name_index, signature_index, 
/* 670 */         getAttributes(), this.cp.getConstantPool());
/*     */ 
/*     */     
/* 673 */     if (lvt != null) removeCodeAttribute(lvt); 
/* 674 */     if (lnt != null) removeCodeAttribute(lnt); 
/* 675 */     if (code != null) removeAttribute(code); 
/* 676 */     if (et != null) removeAttribute(et);
/*     */     
/* 678 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeNOPs() {
/* 687 */     if (this.il != null)
/*     */     {
/*     */ 
/*     */       
/* 691 */       for (InstructionHandle ih = this.il.getStart(); ih != null; ih = next) {
/* 692 */         InstructionHandle next = ih.next;
/*     */         
/* 694 */         if (next != null && ih.getInstruction() instanceof NOP) {
/*     */           try {
/* 696 */             this.il.delete(ih);
/* 697 */           } catch (TargetLostException e) {
/* 698 */             InstructionHandle[] targets = e.getTargets();
/*     */             
/* 700 */             for (int i = 0; i < targets.length; i++) {
/* 701 */               InstructionTargeter[] targeters = targets[i].getTargeters();
/*     */               
/* 703 */               for (int j = 0; j < targeters.length; j++) {
/* 704 */                 targeters[j].updateTarget(targets[i], next);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 715 */   public void setMaxLocals(int m) { this.max_locals = m; }
/* 716 */   public int getMaxLocals() { return this.max_locals; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 721 */   public void setMaxStack(int m) { this.max_stack = m; }
/* 722 */   public int getMaxStack() { return this.max_stack; }
/*     */ 
/*     */ 
/*     */   
/* 726 */   public String getClassName() { return this.class_name; }
/* 727 */   public void setClassName(String class_name) { this.class_name = class_name; }
/*     */   
/* 729 */   public void setReturnType(Type return_type) { setType(return_type); }
/* 730 */   public Type getReturnType() { return getType(); }
/*     */   
/* 732 */   public void setArgumentTypes(Type[] arg_types) { this.arg_types = arg_types; }
/* 733 */   public Type[] getArgumentTypes() { return (Type[])this.arg_types.clone(); }
/* 734 */   public void setArgumentType(int i, Type type) { this.arg_types[i] = type; }
/* 735 */   public Type getArgumentType(int i) { return this.arg_types[i]; }
/*     */   
/* 737 */   public void setArgumentNames(String[] arg_names) { this.arg_names = arg_names; }
/* 738 */   public String[] getArgumentNames() { return (String[])this.arg_names.clone(); }
/* 739 */   public void setArgumentName(int i, String name) { this.arg_names[i] = name; }
/* 740 */   public String getArgumentName(int i) { return this.arg_names[i]; }
/*     */   
/* 742 */   public InstructionList getInstructionList() { return this.il; }
/* 743 */   public void setInstructionList(InstructionList il) { this.il = il; }
/*     */ 
/*     */   
/* 746 */   public String getSignature() { return Type.getMethodSignature(this.type, this.arg_types); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxStack() {
/* 753 */     if (this.il != null) {
/* 754 */       this.max_stack = getMaxStack(this.cp, this.il, getExceptionHandlers());
/*     */     } else {
/* 756 */       this.max_stack = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxLocals() {
/* 763 */     if (this.il != null) {
/* 764 */       int max = isStatic() ? 0 : 1;
/*     */       
/* 766 */       if (this.arg_types != null)
/* 767 */         for (int i = 0; i < this.arg_types.length; i++) {
/* 768 */           max += this.arg_types[i].getSize();
/*     */         } 
/* 770 */       for (InstructionHandle ih = this.il.getStart(); ih != null; ih = ih.getNext()) {
/* 771 */         Instruction ins = ih.getInstruction();
/*     */         
/* 773 */         if (ins instanceof LocalVariableInstruction || 
/* 774 */           ins instanceof RET || ins instanceof IINC) {
/*     */           
/* 776 */           int index = ((IndexedInstruction)ins).getIndex() + (
/* 777 */             (TypedInstruction)ins).getType(this.cp).getSize();
/*     */           
/* 779 */           if (index > max) {
/* 780 */             max = index;
/*     */           }
/*     */         } 
/*     */       } 
/* 784 */       this.max_locals = max;
/*     */     } else {
/* 786 */       this.max_locals = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 792 */   public void stripAttributes(boolean flag) { this.strip_attributes = flag; }
/*     */   
/*     */   static final class BranchTarget {
/*     */     InstructionHandle target;
/*     */     int stackDepth;
/*     */     
/*     */     BranchTarget(InstructionHandle target, int stackDepth) {
/* 799 */       this.target = target;
/* 800 */       this.stackDepth = stackDepth;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class BranchStack {
/* 805 */     Stack branchTargets = new Stack();
/* 806 */     Hashtable visitedTargets = new Hashtable();
/*     */     
/*     */     public void push(InstructionHandle target, int stackDepth) {
/* 809 */       if (visited(target)) {
/*     */         return;
/*     */       }
/* 812 */       this.branchTargets.push(visit(target, stackDepth));
/*     */     }
/*     */     
/*     */     public MethodGen.BranchTarget pop() {
/* 816 */       if (!this.branchTargets.empty()) {
/* 817 */         return (MethodGen.BranchTarget)this.branchTargets.pop();
/*     */       }
/*     */ 
/*     */       
/* 821 */       return null;
/*     */     }
/*     */     
/*     */     private final MethodGen.BranchTarget visit(InstructionHandle target, int stackDepth) {
/* 825 */       MethodGen.BranchTarget bt = new MethodGen.BranchTarget(target, stackDepth);
/* 826 */       this.visitedTargets.put(target, bt);
/*     */       
/* 828 */       return bt;
/*     */     }
/*     */ 
/*     */     
/* 832 */     private final boolean visited(InstructionHandle target) { return (this.visitedTargets.get(target) != null); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaxStack(ConstantPoolGen cp, InstructionList il, CodeExceptionGen[] et) {
/* 842 */     BranchStack branchTargets = new BranchStack();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 849 */     for (int i = 0; i < et.length; i++) {
/* 850 */       InstructionHandle handler_pc = et[i].getHandlerPC();
/* 851 */       if (handler_pc != null) {
/* 852 */         branchTargets.push(handler_pc, 1);
/*     */       }
/*     */     } 
/* 855 */     int stackDepth = 0, maxStackDepth = 0;
/* 856 */     InstructionHandle ih = il.getStart();
/*     */     
/* 858 */     while (ih != null) {
/* 859 */       Instruction instruction = ih.getInstruction();
/* 860 */       short opcode = instruction.getOpcode();
/* 861 */       int delta = instruction.produceStack(cp) - instruction.consumeStack(cp);
/*     */       
/* 863 */       stackDepth += delta;
/* 864 */       if (stackDepth > maxStackDepth) {
/* 865 */         maxStackDepth = stackDepth;
/*     */       }
/*     */       
/* 868 */       if (instruction instanceof BranchInstruction) {
/* 869 */         BranchInstruction branch = (BranchInstruction)instruction;
/* 870 */         if (instruction instanceof Select) {
/*     */           
/* 872 */           Select select = (Select)branch;
/* 873 */           InstructionHandle[] targets = select.getTargets();
/* 874 */           for (int i = 0; i < targets.length; i++) {
/* 875 */             branchTargets.push(targets[i], stackDepth);
/*     */           }
/* 877 */           ih = null;
/* 878 */         } else if (!(branch instanceof IfInstruction)) {
/*     */ 
/*     */           
/* 881 */           if (opcode == 168 || opcode == 201)
/* 882 */             branchTargets.push(ih.getNext(), stackDepth - 1); 
/* 883 */           ih = null;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 888 */         branchTargets.push(branch.getTarget(), stackDepth);
/*     */       
/*     */       }
/* 891 */       else if (opcode == 191 || opcode == 169 || (
/* 892 */         opcode >= 172 && opcode <= 177)) {
/* 893 */         ih = null;
/*     */       } 
/*     */       
/* 896 */       if (ih != null) {
/* 897 */         ih = ih.getNext();
/*     */       }
/* 899 */       if (ih == null) {
/* 900 */         BranchTarget bt = branchTargets.pop();
/* 901 */         if (bt != null) {
/* 902 */           ih = bt.target;
/* 903 */           stackDepth = bt.stackDepth;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 908 */     return maxStackDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addObserver(MethodObserver o) {
/* 916 */     if (this.observers == null) {
/* 917 */       this.observers = new ArrayList();
/*     */     }
/* 919 */     this.observers.add(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeObserver(MethodObserver o) {
/* 925 */     if (this.observers != null) {
/* 926 */       this.observers.remove(o);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {
/* 934 */     if (this.observers != null) {
/* 935 */       for (Iterator e = this.observers.iterator(); e.hasNext();) {
/* 936 */         ((MethodObserver)e.next()).notify(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 946 */     String access = Utility.accessToString(this.access_flags);
/* 947 */     String signature = Type.getMethodSignature(this.type, this.arg_types);
/*     */     
/* 949 */     signature = Utility.methodSignatureToString(signature, this.name, access, 
/* 950 */         true, getLocalVariableTable(this.cp));
/*     */     
/* 952 */     StringBuffer buf = new StringBuffer(signature);
/*     */     
/* 954 */     if (this.throws_vec.size() > 0) {
/* 955 */       for (Iterator e = this.throws_vec.iterator(); e.hasNext();) {
/* 956 */         buf.append("\n\t\tthrows " + e.next());
/*     */       }
/*     */     }
/* 959 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodGen copy(String class_name, ConstantPoolGen cp) {
/* 965 */     Method m = ((MethodGen)clone()).getMethod();
/* 966 */     MethodGen mg = new MethodGen(m, class_name, this.cp);
/*     */     
/* 968 */     if (this.cp != cp) {
/* 969 */       mg.setConstantPool(cp);
/* 970 */       mg.getInstructionList().replaceConstantPool(this.cp, cp);
/*     */     } 
/*     */     
/* 973 */     return mg;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\MethodGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */