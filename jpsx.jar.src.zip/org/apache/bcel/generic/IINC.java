/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IINC
/*     */   extends LocalVariableInstruction
/*     */ {
/*     */   private boolean wide;
/*     */   private int c;
/*     */   
/*     */   IINC() {}
/*     */   
/*     */   public IINC(int n, int c) {
/*  82 */     this.opcode = 132;
/*  83 */     this.length = 3;
/*     */     
/*  85 */     setIndex(n);
/*  86 */     setIncrement(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  94 */     if (this.wide) {
/*  95 */       out.writeByte(196);
/*     */     }
/*  97 */     out.writeByte(this.opcode);
/*     */     
/*  99 */     if (this.wide) {
/* 100 */       out.writeShort(this.n);
/* 101 */       out.writeShort(this.c);
/*     */     } else {
/* 103 */       out.writeByte(this.n);
/* 104 */       out.writeByte(this.c);
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void setWide() {
/* 109 */     if (this.wide = !(this.n <= 65535 && 
/* 110 */       Math.abs(this.c) <= 127)) {
/* 111 */       this.length = 6;
/*     */     } else {
/* 113 */       this.length = 3;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {
/* 121 */     this.wide = wide;
/*     */     
/* 123 */     if (wide) {
/* 124 */       this.length = 6;
/* 125 */       this.n = bytes.readUnsignedShort();
/* 126 */       this.c = bytes.readShort();
/*     */     } else {
/* 128 */       this.length = 3;
/* 129 */       this.n = bytes.readUnsignedByte();
/* 130 */       this.c = bytes.readByte();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public String toString(boolean verbose) { return String.valueOf(super.toString(verbose)) + " " + this.c; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIndex(int n) {
/* 145 */     if (n < 0) {
/* 146 */       throw new ClassGenException("Negative index value: " + n);
/*     */     }
/* 148 */     this.n = n;
/* 149 */     setWide();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public final int getIncrement() { return this.c; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIncrement(int c) {
/* 161 */     this.c = c;
/* 162 */     setWide();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public Type getType(ConstantPoolGen cp) { return Type.INT; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 180 */     v.visitLocalVariableInstruction(this);
/* 181 */     v.visitIINC(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\IINC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */