/*    */ package org.apache.bcel.generic;
/*    */ 
/*    */ import org.apache.bcel.ExceptionConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IDIV
/*    */   extends ArithmeticInstruction
/*    */   implements ExceptionThrower
/*    */ {
/* 68 */   public IDIV() { super((short)108); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public Class[] getExceptions() { return new Class[] { ExceptionConstants.ARITHMETIC_EXCEPTION }; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(Visitor v) {
/* 87 */     v.visitExceptionThrower(this);
/* 88 */     v.visitTypedInstruction(this);
/* 89 */     v.visitStackProducer(this);
/* 90 */     v.visitStackConsumer(this);
/* 91 */     v.visitArithmeticInstruction(this);
/* 92 */     v.visitIDIV(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\IDIV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */