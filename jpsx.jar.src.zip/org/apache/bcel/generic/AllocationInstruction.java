package org.apache.bcel.generic;

public interface AllocationInstruction {}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\AllocationInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */