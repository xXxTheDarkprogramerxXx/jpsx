package org.apache.bcel.generic;

public interface NamedAndTyped {
  String getName();
  
  Type getType();
  
  void setName(String paramString);
  
  void setType(Type paramType);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\NamedAndTyped.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */