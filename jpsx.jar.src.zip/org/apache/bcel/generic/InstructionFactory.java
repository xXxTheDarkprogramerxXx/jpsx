/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionFactory
/*     */   implements InstructionConstants, Serializable
/*     */ {
/*     */   protected ClassGen cg;
/*     */   protected ConstantPoolGen cp;
/*     */   
/*     */   public InstructionFactory(ClassGen cg, ConstantPoolGen cp) {
/*  75 */     this.cg = cg;
/*  76 */     this.cp = cp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public InstructionFactory(ClassGen cg) { this(cg, cg.getConstantPool()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public InstructionFactory(ConstantPoolGen cp) { this(null, cp); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvokeInstruction createInvoke(String class_name, String name, Type ret_type, Type[] arg_types, short kind) {
/* 104 */     int index, nargs = 0;
/* 105 */     String signature = Type.getMethodSignature(ret_type, arg_types);
/*     */     
/* 107 */     for (int i = 0; i < arg_types.length; i++) {
/* 108 */       nargs += arg_types[i].getSize();
/*     */     }
/* 110 */     if (kind == 185) {
/* 111 */       index = this.cp.addInterfaceMethodref(class_name, name, signature);
/*     */     } else {
/* 113 */       index = this.cp.addMethodref(class_name, name, signature);
/*     */     } 
/* 115 */     switch (kind) { case 183:
/* 116 */         return new INVOKESPECIAL(index);
/* 117 */       case 182: return new INVOKEVIRTUAL(index);
/* 118 */       case 184: return new INVOKESTATIC(index);
/* 119 */       case 185: return new INVOKEINTERFACE(index, nargs + 1); }
/*     */     
/* 121 */     throw new RuntimeException("Oops: Unknown invoke kind:" + kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionList createPrintln(String s) {
/* 130 */     InstructionList il = new InstructionList();
/* 131 */     int out = this.cp.addFieldref("java.lang.System", "out", 
/* 132 */         "Ljava/io/PrintStream;");
/* 133 */     int println = this.cp.addMethodref("java.io.PrintStream", "println", 
/* 134 */         "(Ljava/lang/String;)V");
/*     */     
/* 136 */     il.append(new GETSTATIC(out));
/* 137 */     il.append(new PUSH(this.cp, s));
/* 138 */     il.append(new INVOKEVIRTUAL(println));
/*     */     
/* 140 */     return il;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createConstant(Object value) {
/*     */     PUSH push;
/* 149 */     if (value instanceof Number) {
/* 150 */       push = new PUSH(this.cp, (Number)value);
/* 151 */     } else if (value instanceof String) {
/* 152 */       push = new PUSH(this.cp, (String)value);
/* 153 */     } else if (value instanceof Boolean) {
/* 154 */       push = new PUSH(this.cp, (Boolean)value);
/* 155 */     } else if (value instanceof Character) {
/* 156 */       push = new PUSH(this.cp, (Character)value);
/*     */     } else {
/* 158 */       throw new ClassGenException("Illegal type: " + value.getClass());
/*     */     } 
/* 160 */     return push.getInstruction();
/*     */   }
/*     */   
/*     */   private static class MethodObject {
/*     */     Type[] arg_types;
/*     */     Type result_type;
/*     */     String[] arg_names;
/*     */     String class_name;
/*     */     String name;
/*     */     int access;
/*     */     
/*     */     MethodObject(String c, String n, Type r, Type[] a, int acc) {
/* 172 */       this.class_name = c;
/* 173 */       this.name = n;
/* 174 */       this.result_type = r;
/* 175 */       this.arg_types = a;
/* 176 */       this.access = acc;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 181 */   private InvokeInstruction createInvoke(MethodObject m, short kind) { return createInvoke(m.class_name, m.name, m.result_type, m.arg_types, kind); }
/*     */ 
/*     */ 
/*     */   
/* 185 */   private static MethodObject[] append_mos = { new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 186 */         new Type[] { Type.STRING }, true), 
/* 187 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 188 */         new Type[] { Type.OBJECT }, true), 
/*     */       
/* 190 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 191 */         new Type[] { Type.BOOLEAN }, true), 
/* 192 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 193 */         new Type[] { Type.CHAR }, true), 
/* 194 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 195 */         new Type[] { Type.FLOAT }, true), 
/* 196 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 197 */         new Type[] { Type.DOUBLE }, true), 
/* 198 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 199 */         new Type[] { Type.INT }, true), 
/* 200 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 201 */         new Type[] { Type.INT }, true), 
/* 202 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 203 */         new Type[] { Type.INT }, true), 
/* 204 */       new MethodObject("java.lang.StringBuffer", "append", Type.STRINGBUFFER, 
/* 205 */         new Type[] { Type.LONG }, true) };
/*     */ 
/*     */   
/*     */   private static final boolean isString(Type type) {
/* 209 */     if (type instanceof ObjectType && (
/* 210 */       (ObjectType)type).getClassName().equals("java.lang.String")) return true; 
/*     */     return false;
/*     */   }
/*     */   public Instruction createAppend(Type type) {
/* 214 */     byte t = type.getType();
/*     */     
/* 216 */     if (isString(type)) {
/* 217 */       return createInvoke(append_mos[0], (short)182);
/*     */     }
/* 219 */     switch (t) {
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/* 228 */         return createInvoke(append_mos[t], (short)182);
/*     */       case 13:
/*     */       case 14:
/* 231 */         return createInvoke(append_mos[1], (short)182);
/*     */     } 
/* 233 */     throw new RuntimeException("Oops: No append for this type? " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInstruction createFieldAccess(String class_name, String name, Type type, short kind) {
/* 247 */     String signature = type.getSignature();
/*     */     
/* 249 */     int index = this.cp.addFieldref(class_name, name, signature);
/*     */     
/* 251 */     switch (kind) { case 180:
/* 252 */         return new GETFIELD(index);
/* 253 */       case 181: return new PUTFIELD(index);
/* 254 */       case 178: return new GETSTATIC(index);
/* 255 */       case 179: return new PUTSTATIC(index); }
/*     */ 
/*     */     
/* 258 */     throw new RuntimeException("Oops: Unknown getfield kind:" + kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   public static Instruction createThis() { return new ALOAD(false); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReturnInstruction createReturn(Type type) {
/* 271 */     switch (type.getType()) { case 13:
/*     */       case 14:
/* 273 */         return ARETURN;
/*     */       case 4: case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 278 */         return IRETURN;
/* 279 */       case 6: return FRETURN;
/* 280 */       case 7: return DRETURN;
/* 281 */       case 11: return LRETURN;
/* 282 */       case 12: return RETURN; }
/*     */ 
/*     */     
/* 285 */     throw new RuntimeException("Invalid type: " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final ArithmeticInstruction createBinaryIntOp(char first, String op) {
/* 290 */     switch (first) { case '-':
/* 291 */         return ISUB;
/* 292 */       case '+': return IADD;
/* 293 */       case '%': return IREM;
/* 294 */       case '*': return IMUL;
/* 295 */       case '/': return IDIV;
/* 296 */       case '&': return IAND;
/* 297 */       case '|': return IOR;
/* 298 */       case '^': return IXOR;
/* 299 */       case '<': return ISHL;
/* 300 */       case '>': return op.equals(">>>") ? IUSHR : 
/* 301 */           ISHR; }
/* 302 */      throw new RuntimeException("Invalid operand " + op);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final ArithmeticInstruction createBinaryLongOp(char first, String op) {
/* 307 */     switch (first) { case '-':
/* 308 */         return LSUB;
/* 309 */       case '+': return LADD;
/* 310 */       case '%': return LREM;
/* 311 */       case '*': return LMUL;
/* 312 */       case '/': return LDIV;
/* 313 */       case '&': return LAND;
/* 314 */       case '|': return LOR;
/* 315 */       case '^': return LXOR;
/* 316 */       case '<': return LSHL;
/* 317 */       case '>': return op.equals(">>>") ? LUSHR : 
/* 318 */           LSHR; }
/* 319 */      throw new RuntimeException("Invalid operand " + op);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final ArithmeticInstruction createBinaryFloatOp(char op) {
/* 324 */     switch (op) { case '-':
/* 325 */         return FSUB;
/* 326 */       case '+': return FADD;
/* 327 */       case '*': return FMUL;
/* 328 */       case '/': return FDIV; }
/* 329 */      throw new RuntimeException("Invalid operand " + op);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final ArithmeticInstruction createBinaryDoubleOp(char op) {
/* 334 */     switch (op) { case '-':
/* 335 */         return DSUB;
/* 336 */       case '+': return DADD;
/* 337 */       case '*': return DMUL;
/* 338 */       case '/': return DDIV; }
/* 339 */      throw new RuntimeException("Invalid operand " + op);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArithmeticInstruction createBinaryOperation(String op, Type type) {
/* 349 */     char first = op.toCharArray()[0];
/*     */     
/* 351 */     switch (type.getType()) { case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 355 */         return createBinaryIntOp(first, op);
/* 356 */       case 11: return createBinaryLongOp(first, op);
/* 357 */       case 6: return createBinaryFloatOp(first);
/* 358 */       case 7: return createBinaryDoubleOp(first); }
/* 359 */      throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackInstruction createPop(int size) {
/* 367 */     return (size == 2) ? POP2 : 
/* 368 */       POP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackInstruction createDup(int size) {
/* 375 */     return (size == 2) ? DUP2 : 
/* 376 */       DUP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackInstruction createDup_2(int size) {
/* 383 */     return (size == 2) ? DUP2_X2 : 
/* 384 */       DUP_X2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackInstruction createDup_1(int size) {
/* 391 */     return (size == 2) ? DUP2_X1 : 
/* 392 */       DUP_X1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalVariableInstruction createStore(Type type, int index) {
/* 399 */     switch (type.getType()) { case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 404 */         return new ISTORE(index);
/* 405 */       case 6: return new FSTORE(index);
/* 406 */       case 7: return new DSTORE(index);
/* 407 */       case 11: return new LSTORE(index);
/*     */       case 13: case 14:
/* 409 */         return new ASTORE(index); }
/* 410 */      throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalVariableInstruction createLoad(Type type, int index) {
/* 418 */     switch (type.getType()) { case 4:
/*     */       case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 423 */         return new ILOAD(index);
/* 424 */       case 6: return new FLOAD(index);
/* 425 */       case 7: return new DLOAD(index);
/* 426 */       case 11: return new LLOAD(index);
/*     */       case 13: case 14:
/* 428 */         return new ALOAD(index); }
/* 429 */      throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayInstruction createArrayLoad(Type type) {
/* 437 */     switch (type.getType()) { case 4:
/*     */       case 8:
/* 439 */         return BALOAD;
/* 440 */       case 5: return CALOAD;
/* 441 */       case 9: return SALOAD;
/* 442 */       case 10: return IALOAD;
/* 443 */       case 6: return FALOAD;
/* 444 */       case 7: return DALOAD;
/* 445 */       case 11: return LALOAD;
/*     */       case 13: case 14:
/* 447 */         return AALOAD; }
/* 448 */      throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayInstruction createArrayStore(Type type) {
/* 456 */     switch (type.getType()) { case 4:
/*     */       case 8:
/* 458 */         return BASTORE;
/* 459 */       case 5: return CASTORE;
/* 460 */       case 9: return SASTORE;
/* 461 */       case 10: return IASTORE;
/* 462 */       case 6: return FASTORE;
/* 463 */       case 7: return DASTORE;
/* 464 */       case 11: return LASTORE;
/*     */       case 13: case 14:
/* 466 */         return AASTORE; }
/* 467 */      throw new RuntimeException("Invalid type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createCast(Type src_type, Type dest_type) {
/* 476 */     if (src_type instanceof BasicType && dest_type instanceof BasicType) {
/* 477 */       byte dest = dest_type.getType();
/* 478 */       byte src = src_type.getType();
/*     */       
/* 480 */       if (dest == 11 && (src == 5 || src == 8 || 
/* 481 */         src == 9)) {
/* 482 */         src = 10;
/*     */       }
/* 484 */       String[] short_names = { "C", "F", "D", "B", "S", "I", "L" };
/*     */       
/* 486 */       String name = "org.apache.bcel.generic." + short_names[src - 5] + 
/* 487 */         "2" + short_names[dest - 5];
/*     */       
/* 489 */       Instruction i = null;
/*     */       try {
/* 491 */         i = (Instruction)Class.forName(name).newInstance();
/* 492 */       } catch (Exception e) {
/* 493 */         throw new RuntimeException("Could not find instruction: " + name);
/*     */       } 
/*     */       
/* 496 */       return i;
/* 497 */     }  if (src_type instanceof ReferenceType && dest_type instanceof ReferenceType) {
/* 498 */       if (dest_type instanceof ArrayType) {
/* 499 */         return new CHECKCAST(this.cp.addArrayClass((ArrayType)dest_type));
/*     */       }
/* 501 */       return new CHECKCAST(this.cp.addClass(((ObjectType)dest_type).getClassName()));
/*     */     } 
/*     */     
/* 504 */     throw new RuntimeException("Can not cast " + src_type + " to " + dest_type);
/*     */   }
/*     */ 
/*     */   
/* 508 */   public GETFIELD createGetField(String class_name, String name, Type t) { return new GETFIELD(this.cp.addFieldref(class_name, name, t.getSignature())); }
/*     */ 
/*     */ 
/*     */   
/* 512 */   public GETSTATIC createGetStatic(String class_name, String name, Type t) { return new GETSTATIC(this.cp.addFieldref(class_name, name, t.getSignature())); }
/*     */ 
/*     */ 
/*     */   
/* 516 */   public PUTFIELD createPutField(String class_name, String name, Type t) { return new PUTFIELD(this.cp.addFieldref(class_name, name, t.getSignature())); }
/*     */ 
/*     */ 
/*     */   
/* 520 */   public PUTSTATIC createPutStatic(String class_name, String name, Type t) { return new PUTSTATIC(this.cp.addFieldref(class_name, name, t.getSignature())); }
/*     */ 
/*     */   
/*     */   public CHECKCAST createCheckCast(ReferenceType t) {
/* 524 */     if (t instanceof ArrayType) {
/* 525 */       return new CHECKCAST(this.cp.addArrayClass((ArrayType)t));
/*     */     }
/* 527 */     return new CHECKCAST(this.cp.addClass((ObjectType)t));
/*     */   }
/*     */   
/*     */   public INSTANCEOF createInstanceOf(ReferenceType t) {
/* 531 */     if (t instanceof ArrayType) {
/* 532 */       return new INSTANCEOF(this.cp.addArrayClass((ArrayType)t));
/*     */     }
/* 534 */     return new INSTANCEOF(this.cp.addClass((ObjectType)t));
/*     */   }
/*     */ 
/*     */   
/* 538 */   public NEW createNew(ObjectType t) { return new NEW(this.cp.addClass(t)); }
/*     */ 
/*     */ 
/*     */   
/* 542 */   public NEW createNew(String s) { return createNew(new ObjectType(s)); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction createNewArray(Type t, short dim) {
/*     */     ArrayType at;
/* 549 */     if (dim == 1) {
/* 550 */       if (t instanceof ObjectType)
/* 551 */         return new ANEWARRAY(this.cp.addClass((ObjectType)t)); 
/* 552 */       if (t instanceof ArrayType) {
/* 553 */         return new ANEWARRAY(this.cp.addArrayClass((ArrayType)t));
/*     */       }
/* 555 */       return new NEWARRAY(((BasicType)t).getType());
/*     */     } 
/*     */ 
/*     */     
/* 559 */     if (t instanceof ArrayType) {
/* 560 */       at = (ArrayType)t;
/*     */     } else {
/* 562 */       at = new ArrayType(t, dim);
/*     */     } 
/* 564 */     return new MULTIANEWARRAY(this.cp.addArrayClass(at), dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instruction createNull(Type type) {
/* 571 */     switch (type.getType()) { case 13:
/*     */       case 14:
/* 573 */         return ACONST_NULL;
/*     */       case 4: case 5:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 578 */         return ICONST_0;
/* 579 */       case 6: return FCONST_0;
/* 580 */       case 7: return DCONST_0;
/* 581 */       case 11: return LCONST_0;
/* 582 */       case 12: return NOP; }
/*     */ 
/*     */     
/* 585 */     throw new RuntimeException("Invalid type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BranchInstruction createBranchInstruction(short opcode, InstructionHandle target) {
/* 593 */     switch (opcode) { case 153:
/* 594 */         return new IFEQ(target);
/* 595 */       case 154: return new IFNE(target);
/* 596 */       case 155: return new IFLT(target);
/* 597 */       case 156: return new IFGE(target);
/* 598 */       case 157: return new IFGT(target);
/* 599 */       case 158: return new IFLE(target);
/* 600 */       case 159: return new IF_ICMPEQ(target);
/* 601 */       case 160: return new IF_ICMPNE(target);
/* 602 */       case 161: return new IF_ICMPLT(target);
/* 603 */       case 162: return new IF_ICMPGE(target);
/* 604 */       case 163: return new IF_ICMPGT(target);
/* 605 */       case 164: return new IF_ICMPLE(target);
/* 606 */       case 165: return new IF_ACMPEQ(target);
/* 607 */       case 166: return new IF_ACMPNE(target);
/* 608 */       case 167: return new GOTO(target);
/* 609 */       case 168: return new JSR(target);
/* 610 */       case 198: return new IFNULL(target);
/* 611 */       case 199: return new IFNONNULL(target);
/* 612 */       case 200: return new GOTO_W(target);
/* 613 */       case 201: return new JSR_W(target); }
/*     */     
/* 615 */     throw new RuntimeException("Invalid opcode: " + opcode);
/*     */   }
/*     */ 
/*     */   
/* 619 */   public void setClassGen(ClassGen c) { this.cg = c; }
/* 620 */   public ClassGen getClassGen() { return this.cg; }
/* 621 */   public void setConstantPool(ConstantPoolGen c) { this.cp = c; }
/* 622 */   public ConstantPoolGen getConstantPool() { return this.cp; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\InstructionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */