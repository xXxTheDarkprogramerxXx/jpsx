/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.apache.bcel.classfile.AccessFlags;
/*     */ import org.apache.bcel.classfile.Attribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldGenOrMethodGen
/*     */   extends AccessFlags
/*     */   implements NamedAndTyped, Cloneable
/*     */ {
/*     */   protected String name;
/*     */   protected Type type;
/*     */   protected ConstantPoolGen cp;
/*  74 */   private ArrayList attribute_vec = new ArrayList();
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/*  79 */     if (type.getType() == 16) {
/*  80 */       throw new IllegalArgumentException("Type can not be " + type);
/*     */     }
/*  82 */     this.type = type;
/*     */   }
/*  84 */   public Type getType() { return this.type; }
/*     */ 
/*     */ 
/*     */   
/*  88 */   public String getName() { return this.name; }
/*  89 */   public void setName(String name) { this.name = name; }
/*     */   
/*  91 */   public ConstantPoolGen getConstantPool() { return this.cp; }
/*  92 */   public void setConstantPool(ConstantPoolGen cp) { this.cp = cp; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public void addAttribute(Attribute a) { this.attribute_vec.add(a); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void removeAttribute(Attribute a) { this.attribute_vec.remove(a); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public void removeAttributes() { this.attribute_vec.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute[] getAttributes() {
/* 118 */     Attribute[] attributes = new Attribute[this.attribute_vec.size()];
/* 119 */     this.attribute_vec.toArray(attributes);
/* 120 */     return attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract String getSignature();
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 129 */       return super.clone();
/* 130 */     } catch (CloneNotSupportedException e) {
/* 131 */       System.err.println(e);
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\FieldGenOrMethodGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */