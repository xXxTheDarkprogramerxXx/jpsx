/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ICONST
/*     */   extends Instruction
/*     */   implements ConstantPushInstruction, TypedInstruction
/*     */ {
/*     */   private int value;
/*     */   
/*     */   ICONST() {}
/*     */   
/*     */   public ICONST(int i) {
/*  76 */     super((short)3, (short)1);
/*     */     
/*  78 */     if (i >= -1 && i <= 5) {
/*  79 */       this.opcode = (short)(3 + i);
/*     */     } else {
/*  81 */       throw new ClassGenException("ICONST can be used only for value between -1 and 5: " + 
/*  82 */           i);
/*  83 */     }  this.value = i;
/*     */   }
/*     */   
/*  86 */   public Number getValue() { return new Integer(this.value); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public Type getType(ConstantPoolGen cp) { return Type.INT; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 103 */     v.visitPushInstruction(this);
/* 104 */     v.visitStackProducer(this);
/* 105 */     v.visitTypedInstruction(this);
/* 106 */     v.visitConstantPushInstruction(this);
/* 107 */     v.visitICONST(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\ICONST.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */