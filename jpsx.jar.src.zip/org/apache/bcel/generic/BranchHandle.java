/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BranchHandle
/*     */   extends InstructionHandle
/*     */ {
/*     */   private BranchInstruction bi;
/*     */   
/*     */   private BranchHandle(BranchInstruction i) {
/*  73 */     super(i);
/*  74 */     this.bi = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private static BranchHandle get(ThreadLocal tl) { return (BranchHandle)tl.get(); }
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static void set(ThreadLocal tl, BranchHandle value) { tl.set(value); }
/*     */ 
/*     */   
/*     */   private static boolean reUse = false;
/*  88 */   private static ThreadLocal tl_bh_list = reUse ? new ThreadLocal() : null;
/*     */ 
/*     */   
/*     */   static final BranchHandle getBranchHandle(BranchInstruction i) {
/*  92 */     if (reUse) {
/*  93 */       BranchHandle bh_list = get(tl_bh_list);
/*  94 */       if (bh_list == null) {
/*  95 */         return new BranchHandle(i);
/*     */       }
/*  97 */       BranchHandle bh = bh_list;
/*  98 */       set(tl_bh_list, (BranchHandle)bh.next);
/*     */       
/* 100 */       bh.setInstruction(i);
/*     */       
/* 102 */       return bh;
/*     */     } 
/*     */     
/* 105 */     return new BranchHandle(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addHandle() {
/* 112 */     if (reUse) {
/* 113 */       this.next = get(tl_bh_list);
/* 114 */       set(tl_bh_list, this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public int getPosition() { return this.bi.position; }
/*     */ 
/*     */   
/* 125 */   void setPosition(int pos) { this.i_position = this.bi.position = pos; }
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 129 */     int x = this.bi.updatePosition(offset, max_offset);
/* 130 */     this.i_position = this.bi.position;
/* 131 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void setTarget(InstructionHandle ih) { this.bi.setTarget(ih); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) { this.bi.updateTarget(old_ih, new_ih); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public InstructionHandle getTarget() { return this.bi.getTarget(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstruction(Instruction i) {
/* 159 */     super.setInstruction(i);
/*     */     
/* 161 */     if (!(i instanceof BranchInstruction)) {
/* 162 */       throw new ClassGenException("Assigning " + i + 
/* 163 */           " to branch handle which is not a branch instruction");
/*     */     }
/* 165 */     this.bi = (BranchInstruction)i;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\BranchHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */