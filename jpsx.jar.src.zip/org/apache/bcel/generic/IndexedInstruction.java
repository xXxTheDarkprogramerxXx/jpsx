package org.apache.bcel.generic;

public interface IndexedInstruction {
  int getIndex();
  
  void setIndex(int paramInt);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\IndexedInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */