/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.bcel.classfile.LineNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineNumberGen
/*     */   implements InstructionTargeter, Cloneable, Serializable
/*     */ {
/*     */   private InstructionHandle ih;
/*     */   private int src_line;
/*     */   
/*     */   public LineNumberGen(InstructionHandle ih, int src_line) {
/*  81 */     setInstruction(ih);
/*  82 */     setSourceLine(src_line);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public boolean containsTarget(InstructionHandle ih) { return (this.ih == ih); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/*  97 */     if (old_ih != this.ih) {
/*  98 */       throw new ClassGenException("Not targeting " + old_ih + ", but " + this.ih + "}");
/*     */     }
/* 100 */     setInstruction(new_ih);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public LineNumber getLineNumber() { return new LineNumber(this.ih.getPosition(), this.src_line); }
/*     */ 
/*     */   
/*     */   public void setInstruction(InstructionHandle ih) {
/* 114 */     BranchInstruction.notifyTarget(this.ih, ih, this);
/*     */     
/* 116 */     this.ih = ih;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 121 */       return super.clone();
/* 122 */     } catch (CloneNotSupportedException e) {
/* 123 */       System.err.println(e);
/* 124 */       return null;
/*     */     } 
/*     */   }
/*     */   
/* 128 */   public InstructionHandle getInstruction() { return this.ih; }
/* 129 */   public void setSourceLine(int src_line) { this.src_line = src_line; }
/* 130 */   public int getSourceLine() { return this.src_line; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\LineNumberGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */