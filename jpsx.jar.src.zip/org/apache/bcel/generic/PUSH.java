/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PUSH
/*     */   implements CompoundInstruction, VariableLengthInstruction, InstructionConstants
/*     */ {
/*     */   private Instruction instruction;
/*     */   
/*     */   public PUSH(ConstantPoolGen cp, int value) {
/*  78 */     if (value >= -1 && value <= 5) {
/*  79 */       this.instruction = INSTRUCTIONS[3 + value];
/*  80 */     } else if (value >= -128 && value <= 127) {
/*  81 */       this.instruction = new BIPUSH((byte)value);
/*  82 */     } else if (value >= -32768 && value <= 32767) {
/*  83 */       this.instruction = new SIPUSH((short)value);
/*     */     } else {
/*  85 */       this.instruction = new LDC(cp.addInteger(value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public PUSH(ConstantPoolGen cp, boolean value) { this.instruction = INSTRUCTIONS[3 + (value ? 1 : 0)]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PUSH(ConstantPoolGen cp, float value) {
/* 101 */     if (value == 0.0D) {
/* 102 */       this.instruction = FCONST_0;
/* 103 */     } else if (value == 1.0D) {
/* 104 */       this.instruction = FCONST_1;
/* 105 */     } else if (value == 2.0D) {
/* 106 */       this.instruction = FCONST_2;
/*     */     } else {
/* 108 */       this.instruction = new LDC(cp.addFloat(value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PUSH(ConstantPoolGen cp, long value) {
/* 116 */     if (value == 0L) {
/* 117 */       this.instruction = LCONST_0;
/* 118 */     } else if (value == 1L) {
/* 119 */       this.instruction = LCONST_1;
/*     */     } else {
/* 121 */       this.instruction = new LDC2_W(cp.addLong(value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PUSH(ConstantPoolGen cp, double value) {
/* 129 */     if (value == 0.0D) {
/* 130 */       this.instruction = DCONST_0;
/* 131 */     } else if (value == 1.0D) {
/* 132 */       this.instruction = DCONST_1;
/*     */     } else {
/* 134 */       this.instruction = new LDC2_W(cp.addDouble(value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PUSH(ConstantPoolGen cp, String value) {
/* 142 */     if (value == null) {
/* 143 */       this.instruction = ACONST_NULL;
/*     */     } else {
/* 145 */       this.instruction = new LDC(cp.addString(value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PUSH(ConstantPoolGen cp, Number value) {
/* 153 */     if (value instanceof Integer || value instanceof Short || value instanceof Byte) {
/* 154 */       this.instruction = (new PUSH(cp, value.intValue())).instruction;
/* 155 */     } else if (value instanceof Double) {
/* 156 */       this.instruction = (new PUSH(cp, value.doubleValue())).instruction;
/* 157 */     } else if (value instanceof Float) {
/* 158 */       this.instruction = (new PUSH(cp, value.floatValue())).instruction;
/* 159 */     } else if (value instanceof Long) {
/* 160 */       this.instruction = (new PUSH(cp, value.longValue())).instruction;
/*     */     } else {
/* 162 */       throw new ClassGenException("What's this: " + value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public PUSH(ConstantPoolGen cp, Character value) { this(cp, value.charValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public PUSH(ConstantPoolGen cp, Boolean value) { this(cp, value.booleanValue()); }
/*     */ 
/*     */ 
/*     */   
/* 182 */   public final InstructionList getInstructionList() { return new InstructionList(this.instruction); }
/*     */ 
/*     */ 
/*     */   
/* 186 */   public final Instruction getInstruction() { return this.instruction; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public String toString() { return String.valueOf(this.instruction.toString()) + " (PUSH)"; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\PUSH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */