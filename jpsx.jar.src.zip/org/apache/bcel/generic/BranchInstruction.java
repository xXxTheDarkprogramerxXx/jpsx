/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BranchInstruction
/*     */   extends Instruction
/*     */   implements InstructionTargeter
/*     */ {
/*     */   protected int index;
/*     */   protected InstructionHandle target;
/*     */   protected int position;
/*     */   
/*     */   BranchInstruction() {}
/*     */   
/*     */   protected BranchInstruction(short opcode, InstructionHandle target) {
/*  85 */     super(opcode, (short)3);
/*  86 */     setTarget(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  94 */     out.writeByte(this.opcode);
/*     */     
/*  96 */     this.index = getTargetOffset();
/*     */     
/*  98 */     if (Math.abs(this.index) >= 32767) {
/*  99 */       throw new ClassGenException("Branch target offset too large for short");
/*     */     }
/* 101 */     out.writeShort(this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getTargetOffset(InstructionHandle target) {
/* 109 */     if (target == null) {
/* 110 */       throw new ClassGenException("Target of " + super.toString(true) + 
/* 111 */           " is invalid null handle");
/*     */     }
/* 113 */     int t = target.getPosition();
/*     */     
/* 115 */     if (t < 0) {
/* 116 */       throw new ClassGenException("Invalid branch target position offset for " + 
/* 117 */           super.toString(true) + ":" + t + ":" + target);
/*     */     }
/* 119 */     return t - this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   protected int getTargetOffset() { return getTargetOffset(this.target); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 138 */     this.position += offset;
/* 139 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: iload_1
/*     */     //   2: invokespecial toString : (Z)Ljava/lang/String;
/*     */     //   5: astore_2
/*     */     //   6: ldc 'null'
/*     */     //   8: astore_3
/*     */     //   9: iload_1
/*     */     //   10: ifeq -> 68
/*     */     //   13: aload_0
/*     */     //   14: getfield target : Lorg/apache/bcel/generic/InstructionHandle;
/*     */     //   17: ifnull -> 106
/*     */     //   20: aload_0
/*     */     //   21: getfield target : Lorg/apache/bcel/generic/InstructionHandle;
/*     */     //   24: invokevirtual getInstruction : ()Lorg/apache/bcel/generic/Instruction;
/*     */     //   27: aload_0
/*     */     //   28: if_acmpne -> 37
/*     */     //   31: ldc '<points to itself>'
/*     */     //   33: astore_3
/*     */     //   34: goto -> 106
/*     */     //   37: aload_0
/*     */     //   38: getfield target : Lorg/apache/bcel/generic/InstructionHandle;
/*     */     //   41: invokevirtual getInstruction : ()Lorg/apache/bcel/generic/Instruction;
/*     */     //   44: ifnonnull -> 53
/*     */     //   47: ldc '<null instruction!!!?>'
/*     */     //   49: astore_3
/*     */     //   50: goto -> 106
/*     */     //   53: aload_0
/*     */     //   54: getfield target : Lorg/apache/bcel/generic/InstructionHandle;
/*     */     //   57: invokevirtual getInstruction : ()Lorg/apache/bcel/generic/Instruction;
/*     */     //   60: iconst_0
/*     */     //   61: invokevirtual toString : (Z)Ljava/lang/String;
/*     */     //   64: astore_3
/*     */     //   65: goto -> 106
/*     */     //   68: aload_0
/*     */     //   69: getfield target : Lorg/apache/bcel/generic/InstructionHandle;
/*     */     //   72: ifnull -> 106
/*     */     //   75: aload_0
/*     */     //   76: aload_0
/*     */     //   77: invokevirtual getTargetOffset : ()I
/*     */     //   80: putfield index : I
/*     */     //   83: new java/lang/StringBuilder
/*     */     //   86: dup
/*     */     //   87: invokespecial <init> : ()V
/*     */     //   90: aload_0
/*     */     //   91: getfield index : I
/*     */     //   94: aload_0
/*     */     //   95: getfield position : I
/*     */     //   98: iadd
/*     */     //   99: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   102: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   105: astore_3
/*     */     //   106: new java/lang/StringBuilder
/*     */     //   109: dup
/*     */     //   110: aload_2
/*     */     //   111: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   114: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   117: ldc ' -> '
/*     */     //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   122: aload_3
/*     */     //   123: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   126: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   129: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #154	-> 0
/*     */     //   #155	-> 6
/*     */     //   #157	-> 9
/*     */     //   #158	-> 13
/*     */     //   #159	-> 20
/*     */     //   #160	-> 31
/*     */     //   #161	-> 37
/*     */     //   #162	-> 47
/*     */     //   #164	-> 53
/*     */     //   #167	-> 68
/*     */     //   #168	-> 75
/*     */     //   #169	-> 83
/*     */     //   #173	-> 106
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	130	0	this	Lorg/apache/bcel/generic/BranchInstruction;
/*     */     //   0	130	1	verbose	Z
/*     */     //   6	124	2	s	Ljava/lang/String;
/*     */     //   9	121	3	t	Ljava/lang/String; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {
/* 186 */     this.length = 3;
/* 187 */     this.index = bytes.readShort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public final int getIndex() { return this.index; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public InstructionHandle getTarget() { return this.target; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(InstructionHandle target) {
/* 205 */     notifyTarget(this.target, target, this);
/* 206 */     this.target = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final void notifyTarget(InstructionHandle old_ih, InstructionHandle new_ih, InstructionTargeter t) {
/* 214 */     if (old_ih != null)
/* 215 */       old_ih.removeTargeter(t); 
/* 216 */     if (new_ih != null) {
/* 217 */       new_ih.addTargeter(t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 225 */     if (this.target == old_ih) {
/* 226 */       setTarget(new_ih);
/*     */     } else {
/* 228 */       throw new ClassGenException("Not targeting " + old_ih + ", but " + this.target);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public boolean containsTarget(InstructionHandle ih) { return (this.target == ih); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 242 */     setTarget(null);
/* 243 */     this.index = -1;
/* 244 */     this.position = -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\BranchInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */