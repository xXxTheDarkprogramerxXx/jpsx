/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.bcel.classfile.ClassFormatException;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Type
/*     */   implements Serializable
/*     */ {
/*     */   protected byte type;
/*     */   protected String signature;
/*  75 */   public static final BasicType VOID = new BasicType(12);
/*  76 */   public static final BasicType BOOLEAN = new BasicType(4);
/*  77 */   public static final BasicType INT = new BasicType(10);
/*  78 */   public static final BasicType SHORT = new BasicType(9);
/*  79 */   public static final BasicType BYTE = new BasicType(8);
/*  80 */   public static final BasicType LONG = new BasicType(11);
/*  81 */   public static final BasicType DOUBLE = new BasicType(7);
/*  82 */   public static final BasicType FLOAT = new BasicType(6);
/*  83 */   public static final BasicType CHAR = new BasicType(5);
/*  84 */   public static final ObjectType OBJECT = new ObjectType("java.lang.Object");
/*  85 */   public static final ObjectType STRING = new ObjectType("java.lang.String");
/*  86 */   public static final ObjectType STRINGBUFFER = new ObjectType("java.lang.StringBuffer");
/*  87 */   public static final ObjectType THROWABLE = new ObjectType("java.lang.Throwable");
/*  88 */   public static final Type[] NO_ARGS = new Type[0];
/*  89 */   public static final ReferenceType NULL = new ReferenceType() {  }
/*  90 */   ; public static final Type UNKNOWN = new Type(15, 
/*  91 */       "<unknown object>") {  }
/*     */   ;
/*     */   protected Type(byte t, String s) {
/*  94 */     this.type = t;
/*  95 */     this.signature = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public String getSignature() { return this.signature; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public byte getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 112 */     switch (this.type) { case 7:
/*     */       case 11:
/* 114 */         return 2;
/* 115 */       case 12: return 0; }
/* 116 */      return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return (equals(NULL) || this.type >= 15) ? this.signature : 
/* 125 */       Utility.signatureToString(this.signature, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMethodSignature(Type return_type, Type[] arg_types) {
/* 137 */     StringBuffer buf = new StringBuffer("(");
/* 138 */     int length = (arg_types == null) ? 0 : arg_types.length;
/*     */     
/* 140 */     for (int i = 0; i < length; i++) {
/* 141 */       buf.append(arg_types[i].getSignature());
/*     */     }
/* 143 */     buf.append(')');
/* 144 */     buf.append(return_type.getSignature());
/*     */     
/* 146 */     return buf.toString();
/*     */   }
/*     */   
/* 149 */   private static ThreadLocal consumed_chars = new ThreadLocal()
/*     */     {
/* 151 */       protected Object initialValue() { return new Integer(false); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 156 */   private static int unwrap(ThreadLocal tl) { return ((Integer)tl.get()).intValue(); }
/*     */ 
/*     */ 
/*     */   
/* 160 */   private static void wrap(ThreadLocal tl, int value) { tl.set(new Integer(value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Type getType(String signature) throws StringIndexOutOfBoundsException {
/* 171 */     byte type = Utility.typeOfSignature(signature);
/*     */     
/* 173 */     if (type <= 12) {
/*     */       
/* 175 */       wrap(consumed_chars, 1);
/* 176 */       return BasicType.getType(type);
/* 177 */     }  if (type == 13) {
/* 178 */       int dim = 0;
/*     */       do {
/* 180 */         dim++;
/* 181 */       } while (signature.charAt(dim) == '[');
/*     */ 
/*     */       
/* 184 */       Type t = getType(signature.substring(dim));
/*     */ 
/*     */ 
/*     */       
/* 188 */       int _temp = unwrap(consumed_chars) + dim;
/* 189 */       wrap(consumed_chars, _temp);
/*     */       
/* 191 */       return new ArrayType(t, dim);
/*     */     } 
/* 193 */     int index = signature.indexOf(';');
/*     */     
/* 195 */     if (index < 0) {
/* 196 */       throw new ClassFormatException("Invalid signature: " + signature);
/*     */     }
/*     */     
/* 199 */     wrap(consumed_chars, index + 1);
/*     */     
/* 201 */     return new ObjectType(signature.substring(1, index).replace('/', '.'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getReturnType(String signature) throws StringIndexOutOfBoundsException {
/*     */     try {
/* 214 */       int index = signature.lastIndexOf(')') + 1;
/* 215 */       return getType(signature.substring(index));
/* 216 */     } catch (StringIndexOutOfBoundsException e) {
/* 217 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type[] getArgumentTypes(String signature) {
/* 227 */     ArrayList vec = new ArrayList();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 232 */       if (signature.charAt(0) != '(') {
/* 233 */         throw new ClassFormatException("Invalid method signature: " + signature);
/*     */       }
/* 235 */       int index = 1;
/*     */       
/* 237 */       while (signature.charAt(index) != ')') {
/* 238 */         vec.add(getType(signature.substring(index)));
/*     */         
/* 240 */         index += unwrap(consumed_chars);
/*     */       } 
/* 242 */     } catch (StringIndexOutOfBoundsException e) {
/* 243 */       throw new ClassFormatException("Invalid method signature: " + signature);
/*     */     } 
/*     */     
/* 246 */     Type[] types = new Type[vec.size()];
/* 247 */     vec.toArray(types);
/* 248 */     return types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getType(Class cl) {
/* 256 */     if (cl == null) {
/* 257 */       throw new IllegalArgumentException("Class must not be null");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (cl.isArray())
/* 264 */       return getType(cl.getName()); 
/* 265 */     if (cl.isPrimitive()) {
/* 266 */       if (cl == int.class)
/* 267 */         return INT; 
/* 268 */       if (cl == void.class)
/* 269 */         return VOID; 
/* 270 */       if (cl == double.class)
/* 271 */         return DOUBLE; 
/* 272 */       if (cl == float.class)
/* 273 */         return FLOAT; 
/* 274 */       if (cl == boolean.class)
/* 275 */         return BOOLEAN; 
/* 276 */       if (cl == byte.class)
/* 277 */         return BYTE; 
/* 278 */       if (cl == short.class)
/* 279 */         return SHORT; 
/* 280 */       if (cl == byte.class)
/* 281 */         return BYTE; 
/* 282 */       if (cl == long.class)
/* 283 */         return LONG; 
/* 284 */       if (cl == char.class) {
/* 285 */         return CHAR;
/*     */       }
/* 287 */       throw new IllegalStateException("Ooops, what primitive type is " + cl);
/*     */     } 
/*     */     
/* 290 */     return new ObjectType(cl.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getSignature(Method meth) {
/* 295 */     StringBuffer sb = new StringBuffer("(");
/* 296 */     Class[] params = meth.getParameterTypes();
/*     */     
/* 298 */     for (int j = 0; j < params.length; j++) {
/* 299 */       sb.append(getType(params[j]).getSignature());
/*     */     }
/*     */     
/* 302 */     sb.append(")");
/* 303 */     sb.append(getType(meth.getReturnType()).getSignature());
/* 304 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\Type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */