/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DCONST
/*     */   extends Instruction
/*     */   implements ConstantPushInstruction, TypedInstruction
/*     */ {
/*     */   private double value;
/*     */   
/*     */   DCONST() {}
/*     */   
/*     */   public DCONST(double f) {
/*  76 */     super((short)14, (short)1);
/*     */     
/*  78 */     if (f == 0.0D) {
/*  79 */       this.opcode = 14;
/*  80 */     } else if (f == 1.0D) {
/*  81 */       this.opcode = 15;
/*     */     } else {
/*  83 */       throw new ClassGenException("DCONST can be used only for 0.0 and 1.0: " + f);
/*     */     } 
/*  85 */     this.value = f;
/*     */   }
/*     */   
/*  88 */   public Number getValue() { return new Double(this.value); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public Type getType(ConstantPoolGen cp) { return Type.DOUBLE; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 105 */     v.visitPushInstruction(this);
/* 106 */     v.visitStackProducer(this);
/* 107 */     v.visitTypedInstruction(this);
/* 108 */     v.visitConstantPushInstruction(this);
/* 109 */     v.visitDCONST(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\DCONST.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */