/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldInstruction
/*     */   extends FieldOrMethod
/*     */   implements TypedInstruction
/*     */ {
/*     */   FieldInstruction() {}
/*     */   
/*  81 */   protected FieldInstruction(short opcode, int index) { super(opcode, index); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(ConstantPool cp) {
/*  88 */     return String.valueOf(Constants.OPCODE_NAMES[this.opcode]) + " " + 
/*  89 */       cp.constantToString(this.index, (byte)9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   protected int getFieldSize(ConstantPoolGen cpg) { return getType(cpg).getSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public Type getType(ConstantPoolGen cpg) { return getFieldType(cpg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public Type getFieldType(ConstantPoolGen cpg) { return Type.getType(getSignature(cpg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public String getFieldName(ConstantPoolGen cpg) { return getName(cpg); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\FieldInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */