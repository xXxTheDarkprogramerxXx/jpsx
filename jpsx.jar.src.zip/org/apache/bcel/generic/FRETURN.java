/*    */ package org.apache.bcel.generic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FRETURN
/*    */   extends ReturnInstruction
/*    */ {
/* 68 */   public FRETURN() { super((short)174); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(Visitor v) {
/* 81 */     v.visitExceptionThrower(this);
/* 82 */     v.visitTypedInstruction(this);
/* 83 */     v.visitStackConsumer(this);
/* 84 */     v.visitReturnInstruction(this);
/* 85 */     v.visitFRETURN(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\FRETURN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */