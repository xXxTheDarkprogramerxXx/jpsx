/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.apache.bcel.classfile.AccessFlags;
/*     */ import org.apache.bcel.classfile.Attribute;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.Field;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.SourceFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassGen
/*     */   extends AccessFlags
/*     */   implements Cloneable
/*     */ {
/*     */   private String class_name;
/*     */   private String super_class_name;
/*     */   private String file_name;
/*     */   private int class_name_index;
/*     */   private int superclass_name_index;
/*     */   private int major;
/*     */   private int minor;
/*     */   private ConstantPoolGen cp;
/*     */   private ArrayList field_vec;
/*     */   private ArrayList method_vec;
/*     */   private ArrayList attribute_vec;
/*     */   private ArrayList interface_vec;
/*     */   private ArrayList observers;
/*     */   
/*     */   public ClassGen(String class_name, String super_class_name, String file_name, int access_flags, String[] interfaces, ConstantPoolGen cp) {
/*  74 */     this.class_name_index = -1; this.superclass_name_index = -1;
/*  75 */     this.major = 45; this.minor = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     this.field_vec = new ArrayList();
/*  81 */     this.method_vec = new ArrayList();
/*  82 */     this.attribute_vec = new ArrayList();
/*  83 */     this.interface_vec = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.class_name = class_name;
/*  97 */     this.super_class_name = super_class_name;
/*  98 */     this.file_name = file_name;
/*  99 */     this.access_flags = access_flags;
/* 100 */     this.cp = cp;
/*     */ 
/*     */     
/* 103 */     if (file_name != null) {
/* 104 */       addAttribute(new SourceFile(cp.addUtf8("SourceFile"), 2, 
/* 105 */             cp.addUtf8(file_name), cp.getConstantPool()));
/*     */     }
/* 107 */     this.class_name_index = cp.addClass(class_name);
/* 108 */     this.superclass_name_index = cp.addClass(super_class_name);
/*     */     
/* 110 */     if (interfaces != null) {
/* 111 */       for (int i = 0; i < interfaces.length; i++) {
/* 112 */         addInterface(interfaces[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public ClassGen(String class_name, String super_class_name, String file_name, int access_flags, String[] interfaces) { this(class_name, super_class_name, file_name, access_flags, interfaces, new ConstantPoolGen()); } public ClassGen(JavaClass clazz) { this.class_name_index = -1;
/*     */     this.superclass_name_index = -1;
/*     */     this.major = 45;
/*     */     this.minor = 3;
/*     */     this.field_vec = new ArrayList();
/*     */     this.method_vec = new ArrayList();
/*     */     this.attribute_vec = new ArrayList();
/*     */     this.interface_vec = new ArrayList();
/* 134 */     this.class_name_index = clazz.getClassNameIndex();
/* 135 */     this.superclass_name_index = clazz.getSuperclassNameIndex();
/* 136 */     this.class_name = clazz.getClassName();
/* 137 */     this.super_class_name = clazz.getSuperclassName();
/* 138 */     this.file_name = clazz.getSourceFileName();
/* 139 */     this.access_flags = clazz.getAccessFlags();
/* 140 */     this.cp = new ConstantPoolGen(clazz.getConstantPool());
/* 141 */     this.major = clazz.getMajor();
/* 142 */     this.minor = clazz.getMinor();
/*     */     
/* 144 */     Attribute[] attributes = clazz.getAttributes();
/* 145 */     Method[] methods = clazz.getMethods();
/* 146 */     Field[] fields = clazz.getFields();
/* 147 */     String[] interfaces = clazz.getInterfaceNames();
/*     */     
/* 149 */     for (int i = 0; i < interfaces.length; i++) {
/* 150 */       addInterface(interfaces[i]);
/*     */     }
/* 152 */     for (int i = 0; i < attributes.length; i++) {
/* 153 */       addAttribute(attributes[i]);
/*     */     }
/* 155 */     for (int i = 0; i < methods.length; i++) {
/* 156 */       addMethod(methods[i]);
/*     */     }
/* 158 */     for (int i = 0; i < fields.length; i++) {
/* 159 */       addField(fields[i]);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass getJavaClass() {
/* 166 */     int[] interfaces = getInterfaces();
/* 167 */     Field[] fields = getFields();
/* 168 */     Method[] methods = getMethods();
/* 169 */     Attribute[] attributes = getAttributes();
/*     */ 
/*     */     
/* 172 */     ConstantPool cp = this.cp.getFinalConstantPool();
/*     */     
/* 174 */     return new JavaClass(this.class_name_index, this.superclass_name_index, 
/* 175 */         this.file_name, this.major, this.minor, this.access_flags, 
/* 176 */         cp, interfaces, fields, methods, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public void addInterface(String name) { this.interface_vec.add(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public void removeInterface(String name) { this.interface_vec.remove(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public int getMajor() { return this.major; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public void setMajor(int major) { this.major = major; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public void setMinor(int minor) { this.minor = minor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public int getMinor() { return this.minor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   public void addAttribute(Attribute a) { this.attribute_vec.add(a); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public void addMethod(Method m) { this.method_vec.add(m); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEmptyConstructor(int access_flags) {
/* 238 */     InstructionList il = new InstructionList();
/* 239 */     il.append(InstructionConstants.THIS);
/* 240 */     il.append(new INVOKESPECIAL(this.cp.addMethodref(this.super_class_name, 
/* 241 */             "<init>", "()V")));
/* 242 */     il.append(InstructionConstants.RETURN);
/*     */     
/* 244 */     MethodGen mg = new MethodGen(access_flags, Type.VOID, Type.NO_ARGS, null, 
/* 245 */         "<init>", this.class_name, il, this.cp);
/* 246 */     mg.setMaxStack(1);
/* 247 */     addMethod(mg.getMethod());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public void addField(Field f) { this.field_vec.add(f); }
/*     */   
/* 256 */   public boolean containsField(Field f) { return this.field_vec.contains(f); }
/*     */ 
/*     */ 
/*     */   
/*     */   public Field containsField(String name) {
/* 261 */     for (Iterator e = this.field_vec.iterator(); e.hasNext(); ) {
/* 262 */       Field f = (Field)e.next();
/* 263 */       if (f.getName().equals(name)) {
/* 264 */         return f;
/*     */       }
/*     */     } 
/* 267 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Method containsMethod(String name, String signature) {
/* 273 */     for (Iterator e = this.method_vec.iterator(); e.hasNext(); ) {
/* 274 */       Method m = (Method)e.next();
/* 275 */       if (m.getName().equals(name) && m.getSignature().equals(signature)) {
/* 276 */         return m;
/*     */       }
/*     */     } 
/* 279 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   public void removeAttribute(Attribute a) { this.attribute_vec.remove(a); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public void removeMethod(Method m) { this.method_vec.remove(m); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceMethod(Method old, Method new_) {
/* 298 */     if (new_ == null) {
/* 299 */       throw new ClassGenException("Replacement method must not be null");
/*     */     }
/* 301 */     int i = this.method_vec.indexOf(old);
/*     */     
/* 303 */     if (i < 0) {
/* 304 */       this.method_vec.add(new_);
/*     */     } else {
/* 306 */       this.method_vec.set(i, new_);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceField(Field old, Field new_) {
/* 313 */     if (new_ == null) {
/* 314 */       throw new ClassGenException("Replacement method must not be null");
/*     */     }
/* 316 */     int i = this.field_vec.indexOf(old);
/*     */     
/* 318 */     if (i < 0) {
/* 319 */       this.field_vec.add(new_);
/*     */     } else {
/* 321 */       this.field_vec.set(i, new_);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 328 */   public void removeField(Field f) { this.field_vec.remove(f); }
/*     */   
/* 330 */   public String getClassName() { return this.class_name; }
/* 331 */   public String getSuperclassName() { return this.super_class_name; }
/* 332 */   public String getFileName() { return this.file_name; }
/*     */   
/*     */   public void setClassName(String name) {
/* 335 */     this.class_name = name.replace('/', '.');
/* 336 */     this.class_name_index = this.cp.addClass(name);
/*     */   }
/*     */   
/*     */   public void setSuperclassName(String name) {
/* 340 */     this.super_class_name = name.replace('/', '.');
/* 341 */     this.superclass_name_index = this.cp.addClass(name);
/*     */   }
/*     */   
/*     */   public Method[] getMethods() {
/* 345 */     Method[] methods = new Method[this.method_vec.size()];
/* 346 */     this.method_vec.toArray(methods);
/* 347 */     return methods;
/*     */   }
/*     */   
/*     */   public void setMethods(Method[] methods) {
/* 351 */     this.method_vec.clear();
/* 352 */     for (int m = 0; m < methods.length; m++) {
/* 353 */       addMethod(methods[m]);
/*     */     }
/*     */   }
/*     */   
/* 357 */   public void setMethodAt(Method method, int pos) { this.method_vec.set(pos, method); }
/*     */ 
/*     */ 
/*     */   
/* 361 */   public Method getMethodAt(int pos) { return (Method)this.method_vec.get(pos); }
/*     */ 
/*     */   
/*     */   public String[] getInterfaceNames() {
/* 365 */     int size = this.interface_vec.size();
/* 366 */     String[] interfaces = new String[size];
/*     */     
/* 368 */     this.interface_vec.toArray(interfaces);
/* 369 */     return interfaces;
/*     */   }
/*     */   
/*     */   public int[] getInterfaces() {
/* 373 */     int size = this.interface_vec.size();
/* 374 */     int[] interfaces = new int[size];
/*     */     
/* 376 */     for (int i = 0; i < size; i++) {
/* 377 */       interfaces[i] = this.cp.addClass((String)this.interface_vec.get(i));
/*     */     }
/* 379 */     return interfaces;
/*     */   }
/*     */   
/*     */   public Field[] getFields() {
/* 383 */     Field[] fields = new Field[this.field_vec.size()];
/* 384 */     this.field_vec.toArray(fields);
/* 385 */     return fields;
/*     */   }
/*     */   
/*     */   public Attribute[] getAttributes() {
/* 389 */     Attribute[] attributes = new Attribute[this.attribute_vec.size()];
/* 390 */     this.attribute_vec.toArray(attributes);
/* 391 */     return attributes;
/*     */   }
/*     */   
/* 394 */   public ConstantPoolGen getConstantPool() { return this.cp; }
/*     */   
/* 396 */   public void setConstantPool(ConstantPoolGen constant_pool) { this.cp = constant_pool; }
/*     */ 
/*     */   
/*     */   public void setClassNameIndex(int class_name_index) {
/* 400 */     this.class_name_index = class_name_index;
/* 401 */     this.class_name = this.cp.getConstantPool()
/* 402 */       .getConstantString(class_name_index, (byte)7).replace('/', '.');
/*     */   }
/*     */   
/*     */   public void setSuperclassNameIndex(int superclass_name_index) {
/* 406 */     this.superclass_name_index = superclass_name_index;
/* 407 */     this.super_class_name = this.cp.getConstantPool()
/* 408 */       .getConstantString(superclass_name_index, (byte)7).replace('/', '.');
/*     */   }
/*     */   
/* 411 */   public int getSuperclassNameIndex() { return this.superclass_name_index; }
/*     */   
/* 413 */   public int getClassNameIndex() { return this.class_name_index; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addObserver(ClassObserver o) {
/* 420 */     if (this.observers == null) {
/* 421 */       this.observers = new ArrayList();
/*     */     }
/* 423 */     this.observers.add(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeObserver(ClassObserver o) {
/* 429 */     if (this.observers != null) {
/* 430 */       this.observers.remove(o);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {
/* 438 */     if (this.observers != null)
/* 439 */       for (Iterator e = this.observers.iterator(); e.hasNext();)
/* 440 */         ((ClassObserver)e.next()).notify(this);  
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 445 */       return super.clone();
/* 446 */     } catch (CloneNotSupportedException e) {
/* 447 */       System.err.println(e);
/* 448 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\ClassGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */