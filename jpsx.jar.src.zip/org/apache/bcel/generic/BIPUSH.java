/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BIPUSH
/*     */   extends Instruction
/*     */   implements ConstantPushInstruction
/*     */ {
/*     */   private byte b;
/*     */   
/*     */   BIPUSH() {}
/*     */   
/*     */   public BIPUSH(byte b) {
/*  80 */     super((short)16, (short)2);
/*  81 */     this.b = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/*  88 */     super.dump(out);
/*  89 */     out.writeByte(this.b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public String toString(boolean verbose) { return String.valueOf(super.toString(verbose)) + " " + this.b; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {
/* 104 */     this.length = 2;
/* 105 */     this.b = bytes.readByte();
/*     */   }
/*     */   
/* 108 */   public Number getValue() { return new Integer(this.b); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public Type getType(ConstantPoolGen cp) { return Type.BYTE; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 125 */     v.visitPushInstruction(this);
/* 126 */     v.visitStackProducer(this);
/* 127 */     v.visitTypedInstruction(this);
/* 128 */     v.visitConstantPushInstruction(this);
/* 129 */     v.visitBIPUSH(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\BIPUSH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */