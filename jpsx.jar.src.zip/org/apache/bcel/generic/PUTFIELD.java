/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.ExceptionConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PUTFIELD
/*     */   extends FieldInstruction
/*     */   implements PopInstruction, ExceptionThrower
/*     */ {
/*     */   PUTFIELD() {}
/*     */   
/*  79 */   public PUTFIELD(int index) { super((short)181, index); }
/*     */ 
/*     */   
/*  82 */   public int consumeStack(ConstantPoolGen cpg) { return getFieldSize(cpg) + 1; }
/*     */   
/*     */   public Class[] getExceptions() {
/*  85 */     Class[] cs = new Class[2 + ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length];
/*     */     
/*  87 */     System.arraycopy(ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION, 0, 
/*  88 */         cs, 0, ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length);
/*     */     
/*  90 */     cs[ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length + 1] = 
/*  91 */       ExceptionConstants.INCOMPATIBLE_CLASS_CHANGE_ERROR;
/*  92 */     cs[ExceptionConstants.EXCS_FIELD_AND_METHOD_RESOLUTION.length] = 
/*  93 */       ExceptionConstants.NULL_POINTER_EXCEPTION;
/*     */     
/*  95 */     return cs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/* 108 */     v.visitExceptionThrower(this);
/* 109 */     v.visitStackConsumer(this);
/* 110 */     v.visitPopInstruction(this);
/* 111 */     v.visitTypedInstruction(this);
/* 112 */     v.visitLoadClass(this);
/* 113 */     v.visitCPInstruction(this);
/* 114 */     v.visitFieldOrMethod(this);
/* 115 */     v.visitFieldInstruction(this);
/* 116 */     v.visitPUTFIELD(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\PUTFIELD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */