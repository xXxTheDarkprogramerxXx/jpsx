/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.ExceptionConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class INSTANCEOF
/*     */   extends CPInstruction
/*     */   implements LoadClass, ExceptionThrower, StackProducer, StackConsumer
/*     */ {
/*     */   INSTANCEOF() {}
/*     */   
/*  73 */   public INSTANCEOF(int index) { super((short)193, index); }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public Class[] getExceptions() { return ExceptionConstants.EXCS_CLASS_AND_INTERFACE_RESOLUTION; }
/*     */ 
/*     */   
/*     */   public ObjectType getLoadClassType(ConstantPoolGen cpg) {
/*  81 */     Type t = getType(cpg);
/*     */     
/*  83 */     if (t instanceof ArrayType) {
/*  84 */       t = ((ArrayType)t).getBasicType();
/*     */     }
/*  86 */     return (t instanceof ObjectType) ? (ObjectType)t : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Visitor v) {
/*  98 */     v.visitLoadClass(this);
/*  99 */     v.visitExceptionThrower(this);
/* 100 */     v.visitStackProducer(this);
/* 101 */     v.visitStackConsumer(this);
/* 102 */     v.visitTypedInstruction(this);
/* 103 */     v.visitCPInstruction(this);
/* 104 */     v.visitINSTANCEOF(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\INSTANCEOF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */