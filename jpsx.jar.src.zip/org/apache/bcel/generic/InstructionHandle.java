/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstructionHandle
/*     */   implements Serializable
/*     */ {
/*     */   InstructionHandle next;
/*     */   InstructionHandle prev;
/*     */   Instruction instruction;
/*     */   protected int i_position;
/*     */   private HashSet targeters;
/*     */   private HashMap attributes;
/*     */   
/*  87 */   public final InstructionHandle getNext() { return this.next; }
/*  88 */   public final InstructionHandle getPrev() { return this.prev; }
/*  89 */   public final Instruction getInstruction() { return this.instruction; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstruction(Instruction i) {
/*  96 */     if (i == null) {
/*  97 */       throw new ClassGenException("Assigning null to handle");
/*     */     }
/*  99 */     if (getClass() != BranchHandle.class && i instanceof BranchInstruction) {
/* 100 */       throw new ClassGenException("Assigning branch instruction " + i + " to plain handle");
/*     */     }
/* 102 */     if (this.instruction != null) {
/* 103 */       this.instruction.dispose();
/*     */     }
/* 105 */     this.instruction = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instruction swapInstruction(Instruction i) {
/* 114 */     Instruction oldInstruction = this.instruction;
/* 115 */     this.instruction = i;
/* 116 */     return oldInstruction;
/*     */   }
/*     */   protected InstructionHandle(Instruction i) {
/*     */     this.i_position = -1;
/* 120 */     setInstruction(i);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean reUse = false;
/* 125 */   private static ThreadLocal tl_ih_list = reUse ? new ThreadLocal() : null;
/*     */   
/* 127 */   private static InstructionHandle get(ThreadLocal tl) { return (InstructionHandle)tl.get(); }
/*     */ 
/*     */ 
/*     */   
/* 131 */   private static void set(ThreadLocal tl, InstructionHandle value) { tl.set(value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final InstructionHandle getInstructionHandle(Instruction i) {
/* 138 */     if (reUse) {
/* 139 */       InstructionHandle ih_list = get(tl_ih_list);
/* 140 */       if (ih_list == null) {
/* 141 */         return new InstructionHandle(i);
/*     */       }
/* 143 */       InstructionHandle ih = ih_list;
/* 144 */       set(tl_ih_list, ih.next);
/*     */       
/* 146 */       ih.setInstruction(i);
/*     */       
/* 148 */       return ih;
/*     */     } 
/*     */     
/* 151 */     return new InstructionHandle(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 166 */     this.i_position += offset;
/* 167 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public int getPosition() { return this.i_position; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   void setPosition(int pos) { this.i_position = pos; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addHandle() {
/* 184 */     if (reUse) {
/* 185 */       this.next = get(tl_ih_list);
/* 186 */       set(tl_ih_list, this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 194 */     this.next = this.prev = null;
/* 195 */     this.instruction.dispose();
/* 196 */     this.instruction = null;
/* 197 */     this.i_position = -1;
/* 198 */     this.attributes = null;
/* 199 */     removeAllTargeters();
/* 200 */     addHandle();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllTargeters() {
/* 206 */     if (this.targeters != null) {
/* 207 */       this.targeters.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public void removeTargeter(InstructionTargeter t) { this.targeters.remove(t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTargeter(InstructionTargeter t) {
/* 221 */     if (this.targeters == null) {
/* 222 */       this.targeters = new HashSet();
/*     */     }
/*     */     
/* 225 */     this.targeters.add(t);
/*     */   }
/*     */ 
/*     */   
/* 229 */   public boolean hasTargeters() { return (this.targeters != null && this.targeters.size() > 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstructionTargeter[] getTargeters() {
/* 236 */     if (!hasTargeters()) {
/* 237 */       return null;
/*     */     }
/* 239 */     InstructionTargeter[] t = new InstructionTargeter[this.targeters.size()];
/* 240 */     this.targeters.toArray(t);
/* 241 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public String toString(boolean verbose) { return String.valueOf(Utility.format(this.i_position, 4, false, ' ')) + ": " + this.instruction.toString(verbose); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 253 */   public String toString() { return toString(true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttribute(Object key, Object attr) {
/* 262 */     if (this.attributes == null) {
/* 263 */       this.attributes = new HashMap(3);
/*     */     }
/* 265 */     this.attributes.put(key, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(Object key) {
/* 273 */     if (this.attributes != null) {
/* 274 */       this.attributes.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(Object key) {
/* 282 */     if (this.attributes != null) {
/* 283 */       return this.attributes.get(key);
/*     */     }
/* 285 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public Collection getAttributes() { return this.attributes.values(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public void accept(Visitor v) { this.instruction.accept(v); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\InstructionHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */