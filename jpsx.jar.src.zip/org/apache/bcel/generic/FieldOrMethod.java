/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.classfile.ConstantCP;
/*     */ import org.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.ConstantUtf8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldOrMethod
/*     */   extends CPInstruction
/*     */   implements LoadClass
/*     */ {
/*     */   FieldOrMethod() {}
/*     */   
/*  76 */   protected FieldOrMethod(short opcode, int index) { super(opcode, index); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSignature(ConstantPoolGen cpg) {
/*  82 */     ConstantPool cp = cpg.getConstantPool();
/*  83 */     ConstantCP cmr = (ConstantCP)cp.getConstant(this.index);
/*  84 */     ConstantNameAndType cnat = (ConstantNameAndType)cp.getConstant(cmr.getNameAndTypeIndex());
/*     */     
/*  86 */     return ((ConstantUtf8)cp.getConstant(cnat.getSignatureIndex())).getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(ConstantPoolGen cpg) {
/*  92 */     ConstantPool cp = cpg.getConstantPool();
/*  93 */     ConstantCP cmr = (ConstantCP)cp.getConstant(this.index);
/*  94 */     ConstantNameAndType cnat = (ConstantNameAndType)cp.getConstant(cmr.getNameAndTypeIndex());
/*  95 */     return ((ConstantUtf8)cp.getConstant(cnat.getNameIndex())).getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName(ConstantPoolGen cpg) {
/* 101 */     ConstantPool cp = cpg.getConstantPool();
/* 102 */     ConstantCP cmr = (ConstantCP)cp.getConstant(this.index);
/* 103 */     return cp.getConstantString(cmr.getClassIndex(), (byte)7).replace('/', '.');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public ObjectType getClassType(ConstantPoolGen cpg) { return new ObjectType(getClassName(cpg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public ObjectType getLoadClassType(ConstantPoolGen cpg) { return getClassType(cpg); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\FieldOrMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */