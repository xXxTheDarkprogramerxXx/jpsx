/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.bcel.util.ByteSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Select
/*     */   extends BranchInstruction
/*     */   implements VariableLengthInstruction, StackProducer
/*     */ {
/*     */   protected int[] match;
/*     */   protected int[] indices;
/*     */   protected InstructionHandle[] targets;
/*     */   protected int fixed_length;
/*     */   protected int match_length;
/*  76 */   protected int padding = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Select() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Select(short opcode, int[] match, InstructionHandle[] targets, InstructionHandle target) {
/*  94 */     super(opcode, target);
/*     */     
/*  96 */     this.targets = targets;
/*  97 */     for (int i = 0; i < targets.length; i++) {
/*  98 */       notifyTarget(null, targets[i], this);
/*     */     }
/* 100 */     this.match = match;
/*     */     
/* 102 */     if ((this.match_length = match.length) != targets.length) {
/* 103 */       throw new ClassGenException("Match and target array have not the same length");
/*     */     }
/* 105 */     this.indices = new int[this.match_length];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int updatePosition(int offset, int max_offset) {
/* 122 */     this.position += offset;
/*     */     
/* 124 */     short old_length = this.length;
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.padding = (4 - (this.position + 1) % 4) % 4;
/* 129 */     this.length = (short)(this.fixed_length + this.padding);
/*     */     
/* 131 */     return this.length - old_length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(DataOutputStream out) throws IOException {
/* 139 */     out.writeByte(this.opcode);
/*     */     
/* 141 */     for (int i = 0; i < this.padding; i++) {
/* 142 */       out.writeByte(0);
/*     */     }
/* 144 */     this.index = getTargetOffset();
/* 145 */     out.writeInt(this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException {
/* 153 */     this.padding = (4 - bytes.getIndex() % 4) % 4;
/*     */     
/* 155 */     for (int i = 0; i < this.padding; i++) {
/* 156 */       bytes.readByte();
/*     */     }
/*     */ 
/*     */     
/* 160 */     this.index = bytes.readInt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean verbose) {
/* 167 */     StringBuffer buf = new StringBuffer(super.toString(verbose));
/*     */     
/* 169 */     if (verbose) {
/* 170 */       for (int i = 0; i < this.match_length; i++) {
/* 171 */         String s = "null";
/*     */         
/* 173 */         if (this.targets[i] != null) {
/* 174 */           s = this.targets[i].getInstruction().toString();
/*     */         }
/* 176 */         buf.append("(" + this.match[i] + ", " + s + " = {" + this.indices[i] + "})");
/*     */       } 
/*     */     } else {
/*     */       
/* 180 */       buf.append(" ...");
/*     */     } 
/* 182 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(int i, InstructionHandle target) {
/* 189 */     notifyTarget(this.targets[i], target, this);
/* 190 */     this.targets[i] = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTarget(InstructionHandle old_ih, InstructionHandle new_ih) {
/* 198 */     boolean targeted = false;
/*     */     
/* 200 */     if (this.target == old_ih) {
/* 201 */       targeted = true;
/* 202 */       setTarget(new_ih);
/*     */     } 
/*     */     
/* 205 */     for (int i = 0; i < this.targets.length; i++) {
/* 206 */       if (this.targets[i] == old_ih) {
/* 207 */         targeted = true;
/* 208 */         setTarget(i, new_ih);
/*     */       } 
/*     */     } 
/*     */     
/* 212 */     if (!targeted) {
/* 213 */       throw new ClassGenException("Not targeting " + old_ih);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTarget(InstructionHandle ih) {
/* 220 */     if (this.target == ih) {
/* 221 */       return true;
/*     */     }
/* 223 */     for (int i = 0; i < this.targets.length; i++) {
/* 224 */       if (this.targets[i] == ih)
/* 225 */         return true; 
/*     */     } 
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 234 */     super.dispose();
/*     */     
/* 236 */     for (int i = 0; i < this.targets.length; i++) {
/* 237 */       this.targets[i].removeTargeter(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 243 */   public int[] getMatchs() { return this.match; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public int[] getIndices() { return this.indices; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 253 */   public InstructionHandle[] getTargets() { return this.targets; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\Select.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */