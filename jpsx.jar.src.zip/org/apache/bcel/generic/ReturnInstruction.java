/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.ExceptionConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReturnInstruction
/*     */   extends Instruction
/*     */   implements ExceptionThrower, TypedInstruction, StackConsumer
/*     */ {
/*     */   ReturnInstruction() {}
/*     */   
/*  77 */   protected ReturnInstruction(short opcode) { super(opcode, (short)1); }
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  81 */     switch (this.opcode) { case 172:
/*  82 */         return Type.INT;
/*  83 */       case 173: return Type.LONG;
/*  84 */       case 174: return Type.FLOAT;
/*  85 */       case 175: return Type.DOUBLE;
/*  86 */       case 176: return Type.OBJECT;
/*  87 */       case 177: return Type.VOID; }
/*     */ 
/*     */     
/*  90 */     throw new ClassGenException("Unknown type " + this.opcode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public Class[] getExceptions() { return new Class[] { ExceptionConstants.ILLEGAL_MONITOR_STATE }; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public Type getType(ConstantPoolGen cp) { return getType(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\ReturnInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */