/*     */ package org.apache.bcel.generic;
/*     */ 
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceType
/*     */   extends Type
/*     */ {
/*  69 */   protected ReferenceType(byte t, String s) { super(t, s); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   ReferenceType() { super((byte)14, "<null object>"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCastableTo(Type t) {
/*  87 */     if (equals(Type.NULL)) {
/*  88 */       return true;
/*     */     }
/*  90 */     return isAssignmentCompatibleWith(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAssignmentCompatibleWith(Type t) {
/* 102 */     if (!(t instanceof ReferenceType)) {
/* 103 */       return false;
/*     */     }
/* 105 */     ReferenceType T = (ReferenceType)t;
/*     */     
/* 107 */     if (equals(Type.NULL)) {
/* 108 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 112 */     if (this instanceof ObjectType && ((ObjectType)this).referencesClass()) {
/*     */ 
/*     */ 
/*     */       
/* 116 */       if (T instanceof ObjectType && ((ObjectType)T).referencesClass()) {
/* 117 */         if (equals(T)) {
/* 118 */           return true;
/*     */         }
/* 120 */         if (Repository.instanceOf(((ObjectType)this).getClassName(), (
/* 121 */             (ObjectType)T).getClassName())) {
/* 122 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 127 */       if (T instanceof ObjectType && ((ObjectType)T).referencesInterface() && 
/* 128 */         Repository.implementationOf(((ObjectType)this).getClassName(), (
/* 129 */           (ObjectType)T).getClassName())) {
/* 130 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (this instanceof ObjectType && ((ObjectType)this).referencesInterface()) {
/*     */ 
/*     */       
/* 139 */       if (T instanceof ObjectType && ((ObjectType)T).referencesClass() && 
/* 140 */         T.equals(Type.OBJECT)) return true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 146 */       if (T instanceof ObjectType && ((ObjectType)T).referencesInterface()) {
/* 147 */         if (equals(T)) return true; 
/* 148 */         if (Repository.implementationOf(((ObjectType)this).getClassName(), (
/* 149 */             (ObjectType)T).getClassName())) {
/* 150 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (this instanceof ArrayType) {
/*     */ 
/*     */       
/* 160 */       if (T instanceof ObjectType && ((ObjectType)T).referencesClass() && 
/* 161 */         T.equals(Type.OBJECT)) return true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 167 */       if (T instanceof ArrayType) {
/*     */ 
/*     */         
/* 170 */         Type sc = ((ArrayType)this).getElementType();
/* 171 */         Type tc = ((ArrayType)this).getElementType();
/*     */         
/* 173 */         if (sc instanceof BasicType && tc instanceof BasicType && sc.equals(tc)) {
/* 174 */           return true;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 179 */         if (tc instanceof ReferenceType && sc instanceof ReferenceType && (
/* 180 */           (ReferenceType)sc).isAssignmentCompatibleWith((ReferenceType)tc)) {
/* 181 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       if (T instanceof ObjectType && ((ObjectType)T).referencesInterface())
/* 191 */         for (int ii = 0; ii < Constants.INTERFACES_IMPLEMENTED_BY_ARRAYS.length; ii++) {
/* 192 */           if (T.equals(new ObjectType(Constants.INTERFACES_IMPLEMENTED_BY_ARRAYS[ii]))) return true;
/*     */         
/*     */         }  
/*     */     } 
/* 196 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType getFirstCommonSuperclass(ReferenceType t) {
/* 215 */     if (equals(Type.NULL)) return t; 
/* 216 */     if (t.equals(Type.NULL)) return this; 
/* 217 */     if (equals(t)) return this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     if (this instanceof ArrayType && t instanceof ArrayType) {
/* 229 */       ArrayType arrType1 = (ArrayType)this;
/* 230 */       ArrayType arrType2 = (ArrayType)t;
/*     */       
/* 232 */       if (arrType1.getDimensions() == arrType2.getDimensions() && 
/* 233 */         arrType1.getBasicType() instanceof ObjectType && 
/* 234 */         arrType2.getBasicType() instanceof ObjectType) {
/* 235 */         return new ArrayType((
/* 236 */             (ObjectType)arrType1.getBasicType()).getFirstCommonSuperclass((ObjectType)arrType2.getBasicType()), 
/* 237 */             arrType1.getDimensions());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 243 */     if (this instanceof ArrayType || t instanceof ArrayType) {
/* 244 */       return Type.OBJECT;
/*     */     }
/*     */     
/* 247 */     if ((this instanceof ObjectType && ((ObjectType)this).referencesInterface()) || (
/* 248 */       t instanceof ObjectType && ((ObjectType)t).referencesInterface())) {
/* 249 */       return Type.OBJECT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     ObjectType thiz = (ObjectType)this;
/* 257 */     ObjectType other = (ObjectType)t;
/* 258 */     JavaClass[] thiz_sups = Repository.getSuperClasses(thiz.getClassName());
/* 259 */     JavaClass[] other_sups = Repository.getSuperClasses(other.getClassName());
/*     */     
/* 261 */     if (thiz_sups == null || other_sups == null) {
/* 262 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 266 */     JavaClass[] this_sups = new JavaClass[thiz_sups.length + 1];
/* 267 */     JavaClass[] t_sups = new JavaClass[other_sups.length + 1];
/* 268 */     System.arraycopy(thiz_sups, 0, this_sups, 1, thiz_sups.length);
/* 269 */     System.arraycopy(other_sups, 0, t_sups, 1, other_sups.length);
/* 270 */     this_sups[0] = Repository.lookupClass(thiz.getClassName());
/* 271 */     t_sups[0] = Repository.lookupClass(other.getClassName());
/*     */     
/* 273 */     for (int i = 0; i < t_sups.length; i++) {
/* 274 */       for (int j = 0; j < this_sups.length; j++) {
/* 275 */         if (this_sups[j].equals(t_sups[i])) return new ObjectType(this_sups[j].getClassName());
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType firstCommonSuperclass(ReferenceType t) {
/* 299 */     if (equals(Type.NULL)) return t; 
/* 300 */     if (t.equals(Type.NULL)) return this; 
/* 301 */     if (equals(t)) return this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     if (this instanceof ArrayType || t instanceof ArrayType) {
/* 311 */       return Type.OBJECT;
/*     */     }
/*     */     
/* 314 */     if ((this instanceof ObjectType && ((ObjectType)this).referencesInterface()) || (
/* 315 */       t instanceof ObjectType && ((ObjectType)t).referencesInterface())) {
/* 316 */       return Type.OBJECT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     ObjectType thiz = (ObjectType)this;
/* 324 */     ObjectType other = (ObjectType)t;
/* 325 */     JavaClass[] thiz_sups = Repository.getSuperClasses(thiz.getClassName());
/* 326 */     JavaClass[] other_sups = Repository.getSuperClasses(other.getClassName());
/*     */     
/* 328 */     if (thiz_sups == null || other_sups == null) {
/* 329 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 333 */     JavaClass[] this_sups = new JavaClass[thiz_sups.length + 1];
/* 334 */     JavaClass[] t_sups = new JavaClass[other_sups.length + 1];
/* 335 */     System.arraycopy(thiz_sups, 0, this_sups, 1, thiz_sups.length);
/* 336 */     System.arraycopy(other_sups, 0, t_sups, 1, other_sups.length);
/* 337 */     this_sups[0] = Repository.lookupClass(thiz.getClassName());
/* 338 */     t_sups[0] = Repository.lookupClass(other.getClassName());
/*     */     
/* 340 */     for (int i = 0; i < t_sups.length; i++) {
/* 341 */       for (int j = 0; j < this_sups.length; j++) {
/* 342 */         if (this_sups[j].equals(t_sups[i])) return new ObjectType(this_sups[j].getClassName());
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 347 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\generic\ReferenceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */