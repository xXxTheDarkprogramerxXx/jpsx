/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.bcel.classfile.ClassParser;
/*     */ import org.apache.bcel.classfile.ConstantClass;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.ConstantUtf8;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLoader
/*     */   extends java.lang.ClassLoader
/*     */ {
/*  86 */   private Hashtable classes = new Hashtable();
/*     */   
/*  88 */   private String[] ignored_packages = { "java.", "javax.", "sun." };
/*     */   
/*  90 */   private Repository repository = SyntheticRepository.getInstance();
/*  91 */   private java.lang.ClassLoader deferTo = getSystemClassLoader();
/*     */ 
/*     */   
/*     */   public ClassLoader() {}
/*     */   
/*     */   public ClassLoader(java.lang.ClassLoader deferTo) {
/*  97 */     this.deferTo = deferTo;
/*  98 */     this.repository = new ClassLoaderRepository(deferTo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public ClassLoader(String[] ignored_packages) { addIgnoredPkgs(ignored_packages); }
/*     */ 
/*     */   
/*     */   public ClassLoader(java.lang.ClassLoader deferTo, String[] ignored_packages) {
/* 109 */     this.deferTo = deferTo;
/* 110 */     this.repository = new ClassLoaderRepository(deferTo);
/*     */     
/* 112 */     addIgnoredPkgs(ignored_packages);
/*     */   }
/*     */   
/*     */   private void addIgnoredPkgs(String[] ignored_packages) {
/* 116 */     String[] new_p = new String[ignored_packages.length + this.ignored_packages.length];
/*     */     
/* 118 */     System.arraycopy(this.ignored_packages, 0, new_p, 0, this.ignored_packages.length);
/* 119 */     System.arraycopy(ignored_packages, 0, new_p, this.ignored_packages.length, 
/* 120 */         ignored_packages.length);
/*     */     
/* 122 */     this.ignored_packages = new_p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class loadClass(String class_name, boolean resolve) throws ClassNotFoundException {
/* 128 */     Class cl = null;
/*     */ 
/*     */ 
/*     */     
/* 132 */     if ((cl = (Class)this.classes.get(class_name)) == null) {
/*     */ 
/*     */ 
/*     */       
/* 136 */       for (int i = 0; i < this.ignored_packages.length; i++) {
/* 137 */         if (class_name.startsWith(this.ignored_packages[i])) {
/* 138 */           cl = this.deferTo.loadClass(class_name);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 143 */       if (cl == null) {
/* 144 */         JavaClass clazz = null;
/*     */ 
/*     */ 
/*     */         
/* 148 */         if (class_name.indexOf("$$BCEL$$") >= 0) {
/* 149 */           clazz = createClass(class_name);
/*     */         }
/* 151 */         else if ((clazz = this.repository.loadClass(class_name)) != null) {
/* 152 */           clazz = modifyClass(clazz);
/*     */         } else {
/*     */           
/* 155 */           throw new ClassNotFoundException(class_name);
/*     */         } 
/*     */         
/* 158 */         if (clazz != null) {
/* 159 */           byte[] bytes = clazz.getBytes();
/* 160 */           cl = defineClass(class_name, bytes, 0, bytes.length);
/*     */         } else {
/* 162 */           cl = Class.forName(class_name);
/*     */         } 
/*     */       } 
/* 165 */       if (resolve) {
/* 166 */         resolveClass(cl);
/*     */       }
/*     */     } 
/* 169 */     this.classes.put(class_name, cl);
/*     */     
/* 171 */     return cl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   protected JavaClass modifyClass(JavaClass clazz) { return clazz; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaClass createClass(String class_name) {
/* 196 */     int index = class_name.indexOf("$$BCEL$$");
/* 197 */     String real_name = class_name.substring(index + 8);
/*     */     
/* 199 */     JavaClass clazz = null;
/*     */     try {
/* 201 */       byte[] bytes = Utility.decode(real_name, true);
/* 202 */       ClassParser parser = new ClassParser(new ByteArrayInputStream(bytes), "foo");
/*     */       
/* 204 */       clazz = parser.parse();
/* 205 */     } catch (Throwable e) {
/* 206 */       e.printStackTrace();
/* 207 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     ConstantPool cp = clazz.getConstantPool();
/*     */     
/* 213 */     ConstantClass cl = (ConstantClass)cp.getConstant(clazz.getClassNameIndex(), (byte)
/* 214 */         7);
/* 215 */     ConstantUtf8 name = (ConstantUtf8)cp.getConstant(cl.getNameIndex(), (byte)
/* 216 */         1);
/* 217 */     name.setBytes(class_name.replace('.', '/'));
/*     */     
/* 219 */     return clazz;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */