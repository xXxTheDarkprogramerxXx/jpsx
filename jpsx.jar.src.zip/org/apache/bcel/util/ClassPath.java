/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassPath
/*     */   implements Serializable
/*     */ {
/*     */   private static class Dir
/*     */     extends PathEntry
/*     */   {
/*     */     private String dir;
/*     */     
/* 327 */     Dir(String d) { super(null); this.dir = d; }
/*     */     
/*     */     ClassPath.ClassFile getClassFile(String name, String suffix) throws IOException {
/* 330 */       final File file = new File(String.valueOf(this.dir) + File.separatorChar + 
/* 331 */           name.replace('.', File.separatorChar) + suffix);
/*     */       
/* 333 */       return file.exists() ? new ClassPath.ClassFile() {
/* 334 */           public InputStream getInputStream() throws IOException { return new FileInputStream(file); }
/*     */           public String getPath() {
/*     */             
/* 337 */             try { return file.getCanonicalPath(); }
/* 338 */             catch (IOException e) { return null; }
/*     */           
/*     */           }
/* 341 */           public long getTime() { return file.lastModified(); }
/* 342 */           public long getSize() { return file.length(); }
/* 343 */           public String getBase() { return ClassPath.Dir.this.dir; }
/*     */         
/* 345 */         } : null;
/*     */     }
/*     */     
/* 348 */     public String toString() { return this.dir; }
/*     */   }
/*     */   
/*     */   private static class Zip extends PathEntry {
/*     */     private ZipFile zip;
/*     */     
/* 354 */     Zip(ZipFile z) { super(null); this.zip = z; }
/*     */     
/*     */     ClassPath.ClassFile getClassFile(String name, String suffix) throws IOException {
/* 357 */       final ZipEntry entry = this.zip.getEntry(String.valueOf(name.replace('.', '/')) + suffix);
/*     */       
/* 359 */       return (entry != null) ? new ClassPath.ClassFile() {
/* 360 */           public InputStream getInputStream() throws IOException { return ClassPath.Zip.this.zip.getInputStream(entry); }
/* 361 */           public String getPath() { return entry.toString(); }
/* 362 */           public long getTime() { return entry.getTime(); }
/* 363 */           public long getSize() { return entry.getSize(); }
/*     */           
/* 365 */           public String getBase() { return ClassPath.Zip.this.zip.getName(); }
/*     */         
/* 367 */         } : null;
/*     */     }
/*     */   }
/*     */   public static final ClassPath SYSTEM_CLASS_PATH = new ClassPath();
/*     */   private PathEntry[] paths;
/*     */   private String class_path;
/*     */   
/*     */   public ClassPath(String class_path) {
/*     */     this.class_path = class_path;
/*     */     ArrayList vec = new ArrayList();
/*     */     StringTokenizer tok = new StringTokenizer(class_path, System.getProperty("path.separator"));
/*     */     while (tok.hasMoreTokens()) {
/*     */       String path = tok.nextToken();
/*     */       if (!path.equals("")) {
/*     */         File file = new File(path);
/*     */         try {
/*     */           if (file.exists()) {
/*     */             if (file.isDirectory()) {
/*     */               vec.add(new Dir(path));
/*     */               continue;
/*     */             } 
/*     */             vec.add(new Zip(new ZipFile(file)));
/*     */           } 
/*     */         } catch (IOException e) {
/*     */           System.err.println("CLASSPATH component " + file + ": " + e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     this.paths = new PathEntry[vec.size()];
/*     */     vec.toArray(this.paths);
/*     */   }
/*     */   
/*     */   public ClassPath() { this(getClassPath()); }
/*     */   
/*     */   public String toString() { return this.class_path; }
/*     */   
/*     */   public int hashCode() { return this.class_path.hashCode(); }
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     if (o instanceof ClassPath)
/*     */       return this.class_path.equals(((ClassPath)o).class_path); 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private static final void getPathComponents(String path, ArrayList list) {
/*     */     if (path != null) {
/*     */       StringTokenizer tok = new StringTokenizer(path, File.pathSeparator);
/*     */       while (tok.hasMoreTokens()) {
/*     */         String name = tok.nextToken();
/*     */         File file = new File(name);
/*     */         if (file.exists())
/*     */           list.add(name); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final String getClassPath() {
/*     */     class_path = System.getProperty("java.class.path");
/*     */     String boot_path = System.getProperty("sun.boot.class.path");
/*     */     String ext_path = System.getProperty("java.ext.dirs");
/*     */     ArrayList list = new ArrayList();
/*     */     getPathComponents(class_path, list);
/*     */     getPathComponents(boot_path, list);
/*     */     ArrayList dirs = new ArrayList();
/*     */     getPathComponents(ext_path, dirs);
/*     */     for (Iterator e = dirs.iterator(); e.hasNext(); ) {
/*     */       File ext_dir = new File((String)e.next());
/*     */       String[] extensions = ext_dir.list(new FilenameFilter() {
/*     */             public boolean accept(File dir, String name) {
/*     */               name = name.toLowerCase();
/*     */               return !(!name.endsWith(".zip") && !name.endsWith(".jar"));
/*     */             }
/*     */           });
/*     */       if (extensions != null)
/*     */         for (int i = 0; i < extensions.length; i++)
/*     */           list.add(String.valueOf(ext_path) + File.separatorChar + extensions[i]);  
/*     */     } 
/*     */     StringBuffer buf = new StringBuffer();
/*     */     for (Iterator e = list.iterator(); e.hasNext(); ) {
/*     */       buf.append((String)e.next());
/*     */       if (e.hasNext())
/*     */         buf.append(File.pathSeparatorChar); 
/*     */     } 
/*     */     return buf.toString().intern();
/*     */   }
/*     */   
/*     */   public InputStream getInputStream(String name) throws IOException { return getInputStream(name, ".class"); }
/*     */   
/*     */   public InputStream getInputStream(String name, String suffix) throws IOException {
/*     */     InputStream is = null;
/*     */     try {
/*     */       is = getClass().getClassLoader().getResourceAsStream(String.valueOf(name) + suffix);
/*     */     } catch (Exception exception) {}
/*     */     if (is != null)
/*     */       return is; 
/*     */     return getClassFile(name, suffix).getInputStream();
/*     */   }
/*     */   
/*     */   public ClassFile getClassFile(String name, String suffix) throws IOException {
/*     */     for (int i = 0; i < this.paths.length; i++) {
/*     */       ClassFile cf;
/*     */       if ((cf = this.paths[i].getClassFile(name, suffix)) != null)
/*     */         return cf; 
/*     */     } 
/*     */     throw new IOException("Couldn't find: " + name + suffix);
/*     */   }
/*     */   
/*     */   public ClassFile getClassFile(String name) throws IOException { return getClassFile(name, ".class"); }
/*     */   
/*     */   public byte[] getBytes(String name, String suffix) throws IOException {
/*     */     InputStream is = getInputStream(name, suffix);
/*     */     if (is == null)
/*     */       throw new IOException("Couldn't find: " + name + suffix); 
/*     */     DataInputStream dis = new DataInputStream(is);
/*     */     byte[] bytes = new byte[is.available()];
/*     */     dis.readFully(bytes);
/*     */     dis.close();
/*     */     is.close();
/*     */     return bytes;
/*     */   }
/*     */   
/*     */   public byte[] getBytes(String name) throws IOException { return getBytes(name, ".class"); }
/*     */   
/*     */   public String getPath(String name) throws IOException {
/*     */     int index = name.lastIndexOf('.');
/*     */     String suffix = "";
/*     */     if (index > 0) {
/*     */       suffix = name.substring(index);
/*     */       name = name.substring(0, index);
/*     */     } 
/*     */     return getPath(name, suffix);
/*     */   }
/*     */   
/*     */   public String getPath(String name, String suffix) throws IOException { return getClassFile(name, suffix).getPath(); }
/*     */   
/*     */   private static abstract class PathEntry implements Serializable {
/*     */     private PathEntry() {}
/*     */     
/*     */     abstract ClassPath.ClassFile getClassFile(String param1String1, String param1String2) throws IOException;
/*     */   }
/*     */   
/*     */   public static interface ClassFile {
/*     */     InputStream getInputStream() throws IOException;
/*     */     
/*     */     String getPath();
/*     */     
/*     */     String getBase();
/*     */     
/*     */     long getTime();
/*     */     
/*     */     long getSize();
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassPath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */