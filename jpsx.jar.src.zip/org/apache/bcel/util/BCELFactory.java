/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ import org.apache.bcel.generic.AllocationInstruction;
/*     */ import org.apache.bcel.generic.ArrayInstruction;
/*     */ import org.apache.bcel.generic.BranchHandle;
/*     */ import org.apache.bcel.generic.BranchInstruction;
/*     */ import org.apache.bcel.generic.CHECKCAST;
/*     */ import org.apache.bcel.generic.CPInstruction;
/*     */ import org.apache.bcel.generic.CodeExceptionGen;
/*     */ import org.apache.bcel.generic.ConstantPoolGen;
/*     */ import org.apache.bcel.generic.ConstantPushInstruction;
/*     */ import org.apache.bcel.generic.EmptyVisitor;
/*     */ import org.apache.bcel.generic.FieldInstruction;
/*     */ import org.apache.bcel.generic.IINC;
/*     */ import org.apache.bcel.generic.INSTANCEOF;
/*     */ import org.apache.bcel.generic.Instruction;
/*     */ import org.apache.bcel.generic.InstructionConstants;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.InvokeInstruction;
/*     */ import org.apache.bcel.generic.LDC;
/*     */ import org.apache.bcel.generic.LDC2_W;
/*     */ import org.apache.bcel.generic.LocalVariableInstruction;
/*     */ import org.apache.bcel.generic.MULTIANEWARRAY;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.NEWARRAY;
/*     */ import org.apache.bcel.generic.ObjectType;
/*     */ import org.apache.bcel.generic.RET;
/*     */ import org.apache.bcel.generic.ReturnInstruction;
/*     */ import org.apache.bcel.generic.Select;
/*     */ import org.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BCELFactory
/*     */   extends EmptyVisitor
/*     */ {
/*     */   private MethodGen _mg;
/*     */   private PrintWriter _out;
/*     */   private ConstantPoolGen _cp;
/*     */   private HashMap branch_map;
/*     */   private ArrayList branches;
/*     */   
/*     */   BCELFactory(MethodGen mg, PrintWriter out) {
/*  82 */     this.branch_map = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     this.branches = new ArrayList(); this._mg = mg; this._cp = mg.getConstantPool(); this._out = out;
/*     */   }
/*     */   public void start() { if (!this._mg.isAbstract() && !this._mg.isNative()) { InstructionHandle ih = this._mg.getInstructionList().getStart(); for (; ih != null; ih = ih.getNext()) { Instruction i = ih.getInstruction(); if (i instanceof BranchInstruction) this.branch_map.put(i, ih);  if (ih.hasTargeters()) { if (i instanceof BranchInstruction) { this._out.println("    InstructionHandle ih_" + ih.getPosition() + ";"); } else { this._out.print("    InstructionHandle ih_" + ih.getPosition() + " = "); }  } else { this._out.print("    "); }  if (!visitInstruction(i)) i.accept(this);  }  updateBranchTargets(); updateExceptionHandlers(); }  }
/* 260 */   private boolean visitInstruction(Instruction i) { short opcode = i.getOpcode(); if (InstructionConstants.INSTRUCTIONS[opcode] != null && !(i instanceof ConstantPushInstruction) && !(i instanceof ReturnInstruction)) { this._out.println("il.append(InstructionConstants." + i.getName().toUpperCase() + ");"); return true; }  return false; } public void visitLocalVariableInstruction(LocalVariableInstruction i) { short opcode = i.getOpcode(); Type type = i.getType(this._cp); if (opcode == 132) { this._out.println("il.append(new IINC(" + i.getIndex() + ", " + ((IINC)i).getIncrement() + "));"); } else { String kind = (opcode < 54) ? "Load" : "Store"; this._out.println("il.append(_factory.create" + kind + "(" + BCELifier.printType(type) + ", " + i.getIndex() + "));"); }  } public void visitArrayInstruction(ArrayInstruction i) { short opcode = i.getOpcode(); Type type = i.getType(this._cp); String kind = (opcode < 79) ? "Load" : "Store"; this._out.println("il.append(_factory.createArray" + kind + "(" + BCELifier.printType(type) + "));"); } public void visitFieldInstruction(FieldInstruction i) { short opcode = i.getOpcode(); String class_name = i.getClassName(this._cp); String field_name = i.getFieldName(this._cp); Type type = i.getFieldType(this._cp); this._out.println("il.append(_factory.createFieldAccess(\"" + class_name + "\", \"" + field_name + "\", " + BCELifier.printType(type) + ", " + "Constants." + Constants.OPCODE_NAMES[opcode].toUpperCase() + "));"); } public void visitInvokeInstruction(InvokeInstruction i) { short opcode = i.getOpcode(); String class_name = i.getClassName(this._cp); String method_name = i.getMethodName(this._cp); Type type = i.getReturnType(this._cp); Type[] arg_types = i.getArgumentTypes(this._cp); this._out.println("il.append(_factory.createInvoke(\"" + class_name + "\", \"" + method_name + "\", " + BCELifier.printType(type) + ", " + BCELifier.printArgumentTypes(arg_types) + ", " + "Constants." + Constants.OPCODE_NAMES[opcode].toUpperCase() + "));"); } public void visitAllocationInstruction(AllocationInstruction i) { Type type; if (i instanceof CPInstruction) { type = ((CPInstruction)i).getType(this._cp); } else { type = ((NEWARRAY)i).getType(); }  short opcode = ((Instruction)i).getOpcode(); int dim = 1; switch (opcode) { case 187: this._out.println("il.append(_factory.createNew(\"" + ((ObjectType)type).getClassName() + "\"));"); return;case 197: dim = ((MULTIANEWARRAY)i).getDimensions();case 188: case 189: this._out.println("il.append(_factory.createNewArray(" + BCELifier.printType(type) + ", (short) " + dim + "));"); return; }  throw new RuntimeException("Oops: " + opcode); } public void visitBranchInstruction(BranchInstruction bi) { BranchHandle bh = (BranchHandle)this.branch_map.get(bi);
/* 261 */     int pos = bh.getPosition();
/* 262 */     String name = String.valueOf(bi.getName()) + "_" + pos;
/*     */     
/* 264 */     if (bi instanceof Select) {
/* 265 */       Select s = (Select)bi;
/* 266 */       this.branches.add(bi);
/*     */       
/* 268 */       StringBuffer args = new StringBuffer("new int[] { ");
/* 269 */       int[] matchs = s.getMatchs();
/*     */       
/* 271 */       for (int i = 0; i < matchs.length; i++) {
/* 272 */         args.append(matchs[i]);
/*     */         
/* 274 */         if (i < matchs.length - 1) {
/* 275 */           args.append(", ");
/*     */         }
/*     */       } 
/* 278 */       args.append(" }");
/*     */       
/* 280 */       this._out.print("    Select " + name + " = new " + 
/* 281 */           bi.getName().toUpperCase() + "(" + args + 
/* 282 */           ", new InstructionHandle[] { ");
/*     */       
/* 284 */       for (int i = 0; i < matchs.length; i++) {
/* 285 */         this._out.print("null");
/*     */         
/* 287 */         if (i < matchs.length - 1) {
/* 288 */           this._out.print(", ");
/*     */         }
/*     */       } 
/* 291 */       this._out.println(");");
/*     */     } else {
/* 293 */       String target; int t_pos = bh.getTarget().getPosition();
/*     */ 
/*     */       
/* 296 */       if (pos > t_pos) {
/* 297 */         target = "ih_" + t_pos;
/*     */       } else {
/* 299 */         this.branches.add(bi);
/* 300 */         target = "null";
/*     */       } 
/*     */       
/* 303 */       this._out.println("    BranchInstruction " + name + 
/* 304 */           " = _factory.createBranchInstruction(" + 
/* 305 */           "Constants." + bi.getName().toUpperCase() + ", " + 
/* 306 */           target + ");");
/*     */     } 
/*     */     
/* 309 */     if (bh.hasTargeters())
/* 310 */     { this._out.println("    ih_" + pos + " = il.append(" + name + ");"); }
/*     */     else
/* 312 */     { this._out.println("    il.append(" + name + ");"); }  }
/*     */   private void createConstant(Object value) { String embed = value.toString(); if (value instanceof String) { embed = String.valueOf('"') + Utility.convertString(value.toString()) + '"'; } else if (value instanceof Character) { embed = "(char)0x" + Integer.toHexString(((Character)value).charValue()); }  this._out.println("il.append(new PUSH(_cp, " + embed + "));"); }
/*     */   public void visitLDC(LDC i) { createConstant(i.getValue(this._cp)); }
/*     */   public void visitLDC2_W(LDC2_W i) { createConstant(i.getValue(this._cp)); }
/* 316 */   public void visitConstantPushInstruction(ConstantPushInstruction i) { createConstant(i.getValue()); } public void visitINSTANCEOF(INSTANCEOF i) { Type type = i.getType(this._cp); this._out.println("il.append(new INSTANCEOF(_cp.addClass(" + BCELifier.printType(type) + ")));"); } public void visitCHECKCAST(CHECKCAST i) { Type type = i.getType(this._cp); this._out.println("il.append(_factory.createCheckCast(" + BCELifier.printType(type) + "));"); } public void visitReturnInstruction(ReturnInstruction i) { Type type = i.getType(this._cp); this._out.println("il.append(_factory.createReturn(" + BCELifier.printType(type) + "));"); } public void visitRET(RET i) { this._out.println("il.append(new RET(" + i.getIndex() + ")));"); }
/*     */ 
/*     */   
/*     */   private void updateBranchTargets() {
/* 320 */     for (Iterator i = this.branches.iterator(); i.hasNext(); ) {
/* 321 */       BranchInstruction bi = (BranchInstruction)i.next();
/* 322 */       BranchHandle bh = (BranchHandle)this.branch_map.get(bi);
/* 323 */       int pos = bh.getPosition();
/* 324 */       String name = String.valueOf(bi.getName()) + "_" + pos;
/* 325 */       int t_pos = bh.getTarget().getPosition();
/*     */       
/* 327 */       this._out.println("    " + name + ".setTarget(ih_" + t_pos + ");");
/*     */       
/* 329 */       if (bi instanceof Select) {
/* 330 */         InstructionHandle[] ihs = ((Select)bi).getTargets();
/*     */         
/* 332 */         for (int j = 0; j < ihs.length; j++) {
/* 333 */           t_pos = ihs[j].getPosition();
/*     */           
/* 335 */           this._out.println("    " + name + ".setTarget(" + j + 
/* 336 */               ", ih_" + t_pos + ");");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateExceptionHandlers() {
/* 343 */     CodeExceptionGen[] handlers = this._mg.getExceptionHandlers();
/*     */     
/* 345 */     for (int i = 0; i < handlers.length; i++) {
/* 346 */       CodeExceptionGen h = handlers[i];
/* 347 */       String type = (h.getCatchType() == null) ? 
/* 348 */         "null" : BCELifier.printType(h.getCatchType());
/*     */       
/* 350 */       this._out.println("    method.addExceptionHandler(ih_" + 
/* 351 */           h.getStartPC().getPosition() + ", " + 
/* 352 */           "ih_" + h.getEndPC().getPosition() + ", " + 
/* 353 */           "ih_" + h.getHandlerPC().getPosition() + ", " + 
/* 354 */           type + ");");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\BCELFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */