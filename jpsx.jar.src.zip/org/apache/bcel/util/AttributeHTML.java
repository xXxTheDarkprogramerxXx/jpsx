/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.Attribute;
/*     */ import org.apache.bcel.classfile.Code;
/*     */ import org.apache.bcel.classfile.CodeException;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.ConstantUtf8;
/*     */ import org.apache.bcel.classfile.ConstantValue;
/*     */ import org.apache.bcel.classfile.ExceptionTable;
/*     */ import org.apache.bcel.classfile.InnerClass;
/*     */ import org.apache.bcel.classfile.InnerClasses;
/*     */ import org.apache.bcel.classfile.LineNumber;
/*     */ import org.apache.bcel.classfile.LineNumberTable;
/*     */ import org.apache.bcel.classfile.LocalVariable;
/*     */ import org.apache.bcel.classfile.LocalVariableTable;
/*     */ import org.apache.bcel.classfile.SourceFile;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AttributeHTML
/*     */   implements Constants
/*     */ {
/*     */   private String class_name;
/*     */   private PrintWriter file;
/*     */   private int attr_count;
/*     */   private ConstantHTML constant_html;
/*     */   private ConstantPool constant_pool;
/*     */   
/*     */   AttributeHTML(String dir, String class_name, ConstantPool constant_pool, ConstantHTML constant_html) throws IOException {
/*  70 */     this.attr_count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.class_name = class_name;
/*  78 */     this.constant_pool = constant_pool;
/*  79 */     this.constant_html = constant_html;
/*     */     
/*  81 */     this.file = new PrintWriter(new FileOutputStream(String.valueOf(dir) + class_name + "_attributes.html"));
/*  82 */     this.file.println("<HTML><BODY BGCOLOR=\"#C0C0C0\"><TABLE BORDER=0>");
/*     */   }
/*     */   
/*     */   private final String codeLink(int link, int method_number) {
/*  86 */     return "<A HREF=\"" + this.class_name + "_code.html#code" + 
/*  87 */       method_number + "@" + link + "\" TARGET=Code>" + 
/*  88 */       link + "</A>";
/*     */   }
/*     */   
/*     */   final void close() {
/*  92 */     this.file.println("</TABLE></BODY></HTML>");
/*  93 */     this.file.close();
/*     */   }
/*     */ 
/*     */   
/*  97 */   final void writeAttribute(Attribute attribute, String anchor) throws IOException { writeAttribute(attribute, anchor, 0); } final void writeAttribute(Attribute attribute, String anchor, int method_number) throws IOException { int i; InnerClass[] classes; int i, i; LocalVariable[] vars; int i; LineNumber[] line_numbers; int indices[], len;
/*     */     CodeException[] ce;
/*     */     Code c;
/*     */     int index, index;
/* 101 */     byte tag = attribute.getTag();
/*     */ 
/*     */     
/* 104 */     if (tag == -1) {
/*     */       return;
/*     */     }
/* 107 */     this.attr_count++;
/*     */     
/* 109 */     if (this.attr_count % 2 == 0) {
/* 110 */       this.file.print("<TR BGCOLOR=\"#C0C0C0\"><TD>");
/*     */     } else {
/* 112 */       this.file.print("<TR BGCOLOR=\"#A0A0A0\"><TD>");
/*     */     } 
/* 114 */     this.file.println("<H4><A NAME=\"" + anchor + "\">" + this.attr_count + " " + ATTRIBUTE_NAMES[tag] + "</A></H4>");
/*     */ 
/*     */ 
/*     */     
/* 118 */     switch (tag) {
/*     */       case 2:
/* 120 */         c = (Code)attribute;
/*     */ 
/*     */         
/* 123 */         this.file.print("<UL><LI>Maximum stack size = " + c.getMaxStack() + 
/* 124 */             "</LI>\n<LI>Number of local variables = " + 
/* 125 */             c.getMaxLocals() + "</LI>\n<LI><A HREF=\"" + this.class_name + 
/* 126 */             "_code.html#method" + method_number + "\" TARGET=Code>Byte code</A></LI></UL>\n");
/*     */ 
/*     */         
/* 129 */         ce = c.getExceptionTable();
/* 130 */         len = ce.length;
/*     */         
/* 132 */         if (len > 0) {
/* 133 */           this.file.print("<P><B>Exceptions handled</B><UL>");
/*     */           
/* 135 */           for (int i = 0; i < len; i++) {
/* 136 */             int catch_type = ce[i].getCatchType();
/*     */             
/* 138 */             this.file.print("<LI>");
/*     */             
/* 140 */             if (catch_type != 0) {
/* 141 */               this.file.print(this.constant_html.referenceConstant(catch_type));
/*     */             } else {
/* 143 */               this.file.print("Any Exception");
/*     */             } 
/* 145 */             this.file.print("<BR>(Ranging from lines " + codeLink(ce[i].getStartPC(), method_number) + 
/* 146 */                 " to " + codeLink(ce[i].getEndPC(), method_number) + ", handled at line " + 
/* 147 */                 codeLink(ce[i].getHandlerPC(), method_number) + ")</LI>");
/*     */           } 
/* 149 */           this.file.print("</UL>");
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 1:
/* 154 */         index = ((ConstantValue)attribute).getConstantValueIndex();
/*     */ 
/*     */         
/* 157 */         this.file.print("<UL><LI><A HREF=\"" + this.class_name + "_cp.html#cp" + index + 
/* 158 */             "\" TARGET=\"ConstantPool\">Constant value index(" + index + ")</A></UL>\n");
/*     */         break;
/*     */       
/*     */       case 0:
/* 162 */         index = ((SourceFile)attribute).getSourceFileIndex();
/*     */ 
/*     */         
/* 165 */         this.file.print("<UL><LI><A HREF=\"" + this.class_name + "_cp.html#cp" + index + 
/* 166 */             "\" TARGET=\"ConstantPool\">Source file index(" + index + ")</A></UL>\n");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 171 */         indices = ((ExceptionTable)attribute).getExceptionIndexTable();
/*     */         
/* 173 */         this.file.print("<UL>");
/*     */         
/* 175 */         for (i = 0; i < indices.length; i++) {
/* 176 */           this.file.print("<LI><A HREF=\"" + this.class_name + "_cp.html#cp" + indices[i] + 
/* 177 */               "\" TARGET=\"ConstantPool\">Exception class index(" + indices[i] + ")</A>\n");
/*     */         }
/* 179 */         this.file.print("</UL>\n");
/*     */         break;
/*     */       
/*     */       case 4:
/* 183 */         line_numbers = ((LineNumberTable)attribute).getLineNumberTable();
/*     */ 
/*     */         
/* 186 */         this.file.print("<P>");
/*     */         
/* 188 */         for (i = 0; i < line_numbers.length; i++) {
/* 189 */           this.file.print("(" + line_numbers[i].getStartPC() + ",&nbsp;" + line_numbers[i].getLineNumber() + ")");
/*     */           
/* 191 */           if (i < line_numbers.length - 1) {
/* 192 */             this.file.print(", ");
/*     */           }
/*     */         } 
/*     */         break;
/*     */       case 5:
/* 197 */         vars = ((LocalVariableTable)attribute).getLocalVariableTable();
/*     */ 
/*     */         
/* 200 */         this.file.print("<UL>");
/*     */         
/* 202 */         for (i = 0; i < vars.length; i++) {
/* 203 */           int index = vars[i].getSignatureIndex();
/* 204 */           String signature = ((ConstantUtf8)this.constant_pool.getConstant(index, (byte)1)).getBytes();
/* 205 */           signature = Utility.signatureToString(signature, false);
/* 206 */           int start = vars[i].getStartPC();
/* 207 */           int end = start + vars[i].getLength();
/*     */           
/* 209 */           this.file.println("<LI>" + Class2HTML.referenceType(signature) + 
/* 210 */               "&nbsp;<B>" + vars[i].getName() + "</B> in slot %" + vars[i].getIndex() + 
/* 211 */               "<BR>Valid from lines " + 
/* 212 */               "<A HREF=\"" + this.class_name + "_code.html#code" + method_number + "@" + start + "\" TARGET=Code>" + 
/* 213 */               start + "</A> to " + 
/* 214 */               "<A HREF=\"" + this.class_name + "_code.html#code" + method_number + "@" + end + "\" TARGET=Code>" + 
/* 215 */               end + "</A></LI>");
/*     */         } 
/* 217 */         this.file.print("</UL>\n");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 6:
/* 222 */         classes = ((InnerClasses)attribute).getInnerClasses();
/*     */ 
/*     */         
/* 225 */         this.file.print("<UL>");
/*     */         
/* 227 */         for (i = 0; i < classes.length; i++) {
/*     */           String name;
/*     */           
/* 230 */           int index = classes[i].getInnerNameIndex();
/* 231 */           if (index > 0) {
/* 232 */             name = ((ConstantUtf8)this.constant_pool.getConstant(index, (byte)1)).getBytes();
/*     */           } else {
/* 234 */             name = "&lt;anonymous&gt;";
/*     */           } 
/* 236 */           String access = Utility.accessToString(classes[i].getInnerAccessFlags());
/*     */           
/* 238 */           this.file.print("<LI><FONT COLOR=\"#FF0000\">" + access + "</FONT> " + 
/* 239 */               this.constant_html.referenceConstant(classes[i].getInnerClassIndex()) + 
/* 240 */               " in&nbsp;class " + 
/* 241 */               this.constant_html.referenceConstant(classes[i].getOuterClassIndex()) + 
/* 242 */               " named " + name + "</LI>\n");
/*     */         } 
/*     */         
/* 245 */         this.file.print("</UL>\n");
/*     */         break;
/*     */       
/*     */       default:
/* 249 */         this.file.print("<P>" + attribute.toString());
/*     */         break;
/*     */     } 
/* 252 */     this.file.println("</TD></TR>");
/* 253 */     this.file.flush(); }
/*     */ 
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\AttributeHTML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */