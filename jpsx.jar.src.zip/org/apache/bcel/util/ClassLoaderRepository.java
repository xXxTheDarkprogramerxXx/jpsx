/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import org.apache.bcel.classfile.ClassParser;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLoaderRepository
/*     */   implements Repository
/*     */ {
/*     */   private java.lang.ClassLoader loader;
/*     */   private HashMap loadedClasses;
/*     */   
/*     */   public ClassLoaderRepository(java.lang.ClassLoader loader) {
/*  81 */     this
/*  82 */       .loadedClasses = new HashMap();
/*     */ 
/*     */     
/*  85 */     this.loader = loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeClass(JavaClass clazz) {
/*  92 */     this.loadedClasses.put(clazz.getClassName(), 
/*  93 */         clazz);
/*  94 */     clazz.setRepository(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void removeClass(JavaClass clazz) { this.loadedClasses.remove(clazz.getClassName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass findClass(String className) {
/* 108 */     if (this.loadedClasses.containsKey(className)) {
/* 109 */       return (JavaClass)this.loadedClasses.get(className);
/*     */     }
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(String className) {
/* 121 */     String classFile = className.replace('.', '/');
/*     */     
/* 123 */     JavaClass RC = findClass(className);
/* 124 */     if (RC != null) return RC;
/*     */     
/*     */     try {
/* 127 */       InputStream is = 
/* 128 */         this.loader.getResourceAsStream(String.valueOf(classFile) + ".class");
/*     */       
/* 130 */       if (is == null) {
/* 131 */         throw new ClassNotFoundException(String.valueOf(className) + " not found.");
/*     */       }
/*     */       
/* 134 */       ClassParser parser = new ClassParser(is, className);
/* 135 */       RC = parser.parse();
/*     */       
/* 137 */       storeClass(RC);
/*     */       
/* 139 */       return RC;
/* 140 */     } catch (IOException e) {
/* 141 */       throw new ClassNotFoundException(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 146 */   public JavaClass loadClass(Class clazz) throws ClassNotFoundException { return loadClass(clazz.getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public void clear() { this.loadedClasses.clear(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassLoaderRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */