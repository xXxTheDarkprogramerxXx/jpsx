package org.apache.bcel.util;

import java.io.Serializable;
import org.apache.bcel.classfile.JavaClass;

public interface Repository extends Serializable {
  void storeClass(JavaClass paramJavaClass);
  
  void removeClass(JavaClass paramJavaClass);
  
  JavaClass findClass(String paramString);
  
  JavaClass loadClass(String paramString);
  
  JavaClass loadClass(Class paramClass) throws ClassNotFoundException;
  
  void clear();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\Repository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */