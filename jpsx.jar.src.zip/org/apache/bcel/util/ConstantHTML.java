/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.Constant;
/*     */ import org.apache.bcel.classfile.ConstantClass;
/*     */ import org.apache.bcel.classfile.ConstantFieldref;
/*     */ import org.apache.bcel.classfile.ConstantInterfaceMethodref;
/*     */ import org.apache.bcel.classfile.ConstantMethodref;
/*     */ import org.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.ConstantString;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConstantHTML
/*     */   implements Constants
/*     */ {
/*     */   private String class_name;
/*     */   private String class_package;
/*     */   private ConstantPool constant_pool;
/*     */   private PrintWriter file;
/*     */   private String[] constant_ref;
/*     */   private Constant[] constants;
/*     */   private Method[] methods;
/*     */   
/*     */   ConstantHTML(String dir, String class_name, String class_package, Method[] methods, ConstantPool constant_pool) throws IOException {
/*  80 */     this.class_name = class_name;
/*  81 */     this.class_package = class_package;
/*  82 */     this.constant_pool = constant_pool;
/*  83 */     this.methods = methods;
/*  84 */     this.constants = constant_pool.getConstantPool();
/*  85 */     this.file = new PrintWriter(new FileOutputStream(String.valueOf(dir) + class_name + "_cp.html"));
/*  86 */     this.constant_ref = new String[this.constants.length];
/*  87 */     this.constant_ref[0] = "&lt;unknown&gt;";
/*     */     
/*  89 */     this.file.println("<HTML><BODY BGCOLOR=\"#C0C0C0\"><TABLE BORDER=0>");
/*     */ 
/*     */     
/*  92 */     for (int i = 1; i < this.constants.length; i++) {
/*  93 */       if (i % 2 == 0) {
/*  94 */         this.file.print("<TR BGCOLOR=\"#C0C0C0\"><TD>");
/*     */       } else {
/*  96 */         this.file.print("<TR BGCOLOR=\"#A0A0A0\"><TD>");
/*     */       } 
/*  98 */       if (this.constants[i] != null) {
/*  99 */         writeConstant(i);
/*     */       }
/* 101 */       this.file.print("</TD></TR>\n");
/*     */     } 
/*     */     
/* 104 */     this.file.println("</TABLE></BODY></HTML>");
/* 105 */     this.file.close();
/*     */   }
/*     */ 
/*     */   
/* 109 */   String referenceConstant(int index) { return this.constant_ref[index]; } private void writeConstant(int index) { int signature_index; ConstantNameAndType c6; String str; ConstantString c5; String short_class_name, class_name2; ConstantClass c4; String field_name, short_field_class, field_class; ConstantFieldref c3; int i; String arg_types; StringBuffer buf; String ret_type, type, args[], signature;
/*     */     ConstantNameAndType c2;
/*     */     String short_method_class, method_class, html_method_name, method_name, ref, ref;
/*     */     int name_index, name_index, name_index, name_index, name_index, class_index, class_index;
/* 113 */     byte tag = this.constants[index].getTag();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.file.println("<H4> <A NAME=cp" + index + ">" + index + "</A> " + CONSTANT_NAMES[tag] + "</H4>");
/*     */ 
/*     */ 
/*     */     
/* 122 */     switch (tag) {
/*     */       
/*     */       case 10:
/*     */       case 11:
/* 126 */         if (tag == 10) {
/* 127 */           ConstantMethodref c = (ConstantMethodref)this.constant_pool.getConstant(index, (byte)10);
/* 128 */           class_index = c.getClassIndex();
/* 129 */           name_index = c.getNameAndTypeIndex();
/*     */         } else {
/*     */           
/* 132 */           ConstantInterfaceMethodref c1 = (ConstantInterfaceMethodref)this.constant_pool.getConstant(index, (byte)11);
/* 133 */           class_index = c1.getClassIndex();
/* 134 */           name_index = c1.getNameAndTypeIndex();
/*     */         } 
/*     */ 
/*     */         
/* 138 */         method_name = this.constant_pool.constantToString(name_index, (byte)12);
/* 139 */         html_method_name = Class2HTML.toHTML(method_name);
/*     */ 
/*     */         
/* 142 */         method_class = this.constant_pool.constantToString(class_index, (byte)7);
/* 143 */         short_method_class = Utility.compactClassName(method_class);
/* 144 */         short_method_class = Utility.compactClassName(method_class);
/* 145 */         short_method_class = Utility.compactClassName(short_method_class, String.valueOf(this.class_package) + ".", true);
/*     */ 
/*     */         
/* 148 */         c2 = (ConstantNameAndType)this.constant_pool.getConstant(name_index, (byte)12);
/* 149 */         signature = this.constant_pool.constantToString(c2.getSignatureIndex(), (byte)1);
/*     */         
/* 151 */         args = Utility.methodSignatureArgumentTypes(signature, false);
/*     */ 
/*     */         
/* 154 */         type = Utility.methodSignatureReturnType(signature, false);
/* 155 */         ret_type = Class2HTML.referenceType(type);
/*     */         
/* 157 */         buf = new StringBuffer("(");
/* 158 */         for (i = 0; i < args.length; i++) {
/* 159 */           buf.append(Class2HTML.referenceType(args[i]));
/* 160 */           if (i < args.length - 1)
/* 161 */             buf.append(",&nbsp;"); 
/*     */         } 
/* 163 */         buf.append(")");
/*     */         
/* 165 */         arg_types = buf.toString();
/*     */         
/* 167 */         if (method_class.equals(this.class_name)) {
/* 168 */           ref = "<A HREF=\"" + this.class_name + "_code.html#method" + getMethodNumber(String.valueOf(method_name) + signature) + 
/* 169 */             "\" TARGET=Code>" + html_method_name + "</A>";
/*     */         } else {
/* 171 */           ref = "<A HREF=\"" + method_class + ".html" + "\" TARGET=_top>" + short_method_class + 
/* 172 */             "</A>." + html_method_name;
/*     */         } 
/* 174 */         this.constant_ref[index] = String.valueOf(ret_type) + "&nbsp;<A HREF=\"" + this.class_name + "_cp.html#cp" + class_index + 
/* 175 */           "\" TARGET=Constants>" + 
/* 176 */           short_method_class + "</A>.<A HREF=\"" + this.class_name + "_cp.html#cp" + 
/* 177 */           index + "\" TARGET=ConstantPool>" + html_method_name + "</A>&nbsp;" + arg_types;
/*     */         
/* 179 */         this.file.println("<P><TT>" + ret_type + "&nbsp;" + ref + arg_types + "&nbsp;</TT>\n<UL>" + 
/* 180 */             "<LI><A HREF=\"#cp" + class_index + "\">Class index(" + class_index + ")</A>\n" + 
/* 181 */             "<LI><A HREF=\"#cp" + name_index + "\">NameAndType index(" + name_index + ")</A></UL>");
/*     */         return;
/*     */ 
/*     */       
/*     */       case 9:
/* 186 */         c3 = (ConstantFieldref)this.constant_pool.getConstant(index, (byte)9);
/* 187 */         class_index = c3.getClassIndex();
/* 188 */         name_index = c3.getNameAndTypeIndex();
/*     */ 
/*     */         
/* 191 */         field_class = this.constant_pool.constantToString(class_index, (byte)7);
/* 192 */         short_field_class = Utility.compactClassName(field_class);
/* 193 */         short_field_class = Utility.compactClassName(short_field_class, String.valueOf(this.class_package) + ".", true);
/*     */         
/* 195 */         field_name = this.constant_pool.constantToString(name_index, (byte)12);
/*     */         
/* 197 */         if (field_class.equals(this.class_name)) {
/* 198 */           String ref = "<A HREF=\"" + field_class + "_methods.html#field" + 
/* 199 */             field_name + "\" TARGET=Methods>" + field_name + "</A>";
/*     */         } else {
/* 201 */           ref = "<A HREF=\"" + field_class + ".html\" TARGET=_top>" + 
/* 202 */             short_field_class + "</A>." + field_name + "\n";
/*     */         } 
/* 204 */         this.constant_ref[index] = "<A HREF=\"" + this.class_name + "_cp.html#cp" + class_index + "\" TARGET=Constants>" + 
/* 205 */           short_field_class + "</A>.<A HREF=\"" + this.class_name + "_cp.html#cp" + 
/* 206 */           index + "\" TARGET=ConstantPool>" + field_name + "</A>";
/*     */         
/* 208 */         this.file.println("<P><TT>" + ref + "</TT><BR>\n" + "<UL>" + 
/* 209 */             "<LI><A HREF=\"#cp" + class_index + "\">Class(" + class_index + ")</A><BR>\n" + 
/* 210 */             "<LI><A HREF=\"#cp" + name_index + "\">NameAndType(" + name_index + ")</A></UL>");
/*     */         return;
/*     */       
/*     */       case 7:
/* 214 */         c4 = (ConstantClass)this.constant_pool.getConstant(index, (byte)7);
/* 215 */         name_index = c4.getNameIndex();
/* 216 */         class_name2 = this.constant_pool.constantToString(index, tag);
/* 217 */         short_class_name = Utility.compactClassName(class_name2);
/* 218 */         short_class_name = Utility.compactClassName(short_class_name, String.valueOf(this.class_package) + ".", true);
/*     */         
/* 220 */         ref = "<A HREF=\"" + class_name2 + ".html\" TARGET=_top>" + short_class_name + "</A>";
/* 221 */         this.constant_ref[index] = "<A HREF=\"" + this.class_name + "_cp.html#cp" + index + 
/* 222 */           "\" TARGET=ConstantPool>" + short_class_name + "</A>";
/*     */         
/* 224 */         this.file.println("<P><TT>" + ref + "</TT><UL>" + 
/* 225 */             "<LI><A HREF=\"#cp" + name_index + "\">Name index(" + name_index + ")</A></UL>\n");
/*     */         return;
/*     */       
/*     */       case 8:
/* 229 */         c5 = (ConstantString)this.constant_pool.getConstant(index, (byte)8);
/* 230 */         name_index = c5.getStringIndex();
/*     */         
/* 232 */         str = Class2HTML.toHTML(this.constant_pool.constantToString(index, tag));
/*     */         
/* 234 */         this.file.println("<P><TT>" + str + "</TT><UL>" + 
/* 235 */             "<LI><A HREF=\"#cp" + name_index + "\">Name index(" + name_index + ")</A></UL>\n");
/*     */         return;
/*     */       
/*     */       case 12:
/* 239 */         c6 = (ConstantNameAndType)this.constant_pool.getConstant(index, (byte)12);
/* 240 */         name_index = c6.getNameIndex();
/* 241 */         signature_index = c6.getSignatureIndex();
/*     */         
/* 243 */         this.file.println("<P><TT>" + Class2HTML.toHTML(this.constant_pool.constantToString(index, tag)) + "</TT><UL>" + 
/* 244 */             "<LI><A HREF=\"#cp" + name_index + "\">Name index(" + name_index + ")</A>\n" + 
/* 245 */             "<LI><A HREF=\"#cp" + signature_index + "\">Signature index(" + 
/* 246 */             signature_index + ")</A></UL>\n");
/*     */         return;
/*     */     } 
/*     */     
/* 250 */     this.file.println("<P><TT>" + Class2HTML.toHTML(this.constant_pool.constantToString(index, tag)) + "</TT>\n"); }
/*     */ 
/*     */ 
/*     */   
/*     */   private final int getMethodNumber(String str) {
/* 255 */     for (int i = 0; i < this.methods.length; i++) {
/* 256 */       String cmp = String.valueOf(this.methods[i].getName()) + this.methods[i].getSignature();
/* 257 */       if (cmp.equals(str))
/* 258 */         return i; 
/*     */     } 
/* 260 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ConstantHTML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */