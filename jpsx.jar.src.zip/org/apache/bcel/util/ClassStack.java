/*    */ package org.apache.bcel.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Stack;
/*    */ import org.apache.bcel.classfile.JavaClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassStack
/*    */   implements Serializable
/*    */ {
/* 67 */   private Stack stack = new Stack();
/*    */   
/* 69 */   public void push(JavaClass clazz) { this.stack.push(clazz); }
/* 70 */   public JavaClass pop() { return (JavaClass)this.stack.pop(); }
/* 71 */   public JavaClass top() { return (JavaClass)this.stack.peek(); }
/* 72 */   public boolean empty() { return this.stack.empty(); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */