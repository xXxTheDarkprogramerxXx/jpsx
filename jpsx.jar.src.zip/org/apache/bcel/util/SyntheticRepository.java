/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import org.apache.bcel.classfile.ClassParser;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyntheticRepository
/*     */   implements Repository
/*     */ {
/*  86 */   private static final String DEFAULT_PATH = ClassPath.getClassPath();
/*     */   
/*  88 */   private static HashMap _instances = new HashMap(); private ClassPath _path;
/*     */   private SyntheticRepository(ClassPath path) {
/*  90 */     this._path = null;
/*  91 */     this._loadedClasses = new HashMap();
/*     */ 
/*     */     
/*  94 */     this._path = path;
/*     */   }
/*     */   private HashMap _loadedClasses;
/*     */   
/*  98 */   public static SyntheticRepository getInstance() { return getInstance(ClassPath.SYSTEM_CLASS_PATH); }
/*     */ 
/*     */   
/*     */   public static SyntheticRepository getInstance(ClassPath classPath) {
/* 102 */     SyntheticRepository rep = (SyntheticRepository)_instances.get(classPath);
/*     */     
/* 104 */     if (rep == null) {
/* 105 */       rep = new SyntheticRepository(classPath);
/* 106 */       _instances.put(classPath, rep);
/*     */     } 
/*     */     
/* 109 */     return rep;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeClass(JavaClass clazz) {
/* 116 */     this._loadedClasses.put(clazz.getClassName(), clazz);
/* 117 */     clazz.setRepository(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public void removeClass(JavaClass clazz) { this._loadedClasses.remove(clazz.getClassName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public JavaClass findClass(String className) { return (JavaClass)this._loadedClasses.get(className); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(String className) {
/* 141 */     if (className == null || className.equals("")) {
/* 142 */       throw new IllegalArgumentException("Invalid class name " + className);
/*     */     }
/*     */     
/* 145 */     className = className.replace('/', '.');
/*     */     
/*     */     try {
/* 148 */       return loadClass(this._path.getInputStream(className), className);
/* 149 */     } catch (IOException e) {
/* 150 */       throw new ClassNotFoundException("Exception while looking for class " + 
/* 151 */           className + ": " + e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass loadClass(Class clazz) throws ClassNotFoundException {
/* 161 */     String className = clazz.getName();
/* 162 */     String name = className;
/* 163 */     int i = name.lastIndexOf('.');
/*     */     
/* 165 */     if (i > 0) {
/* 166 */       name = name.substring(i + 1);
/*     */     }
/*     */     
/* 169 */     return loadClass(clazz.getResourceAsStream(String.valueOf(name) + ".class"), className);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaClass loadClass(InputStream is, String className) throws ClassNotFoundException {
/* 175 */     JavaClass clazz = findClass(className);
/*     */     
/* 177 */     if (clazz != null) {
/* 178 */       return clazz;
/*     */     }
/*     */     
/*     */     try {
/* 182 */       if (is != null) {
/* 183 */         ClassParser parser = new ClassParser(is, className);
/* 184 */         clazz = parser.parse();
/*     */         
/* 186 */         storeClass(clazz);
/*     */         
/* 188 */         return clazz;
/*     */       } 
/* 190 */     } catch (IOException e) {
/* 191 */       throw new ClassNotFoundException("Exception while looking for class " + 
/* 192 */           className + ": " + e.toString());
/*     */     } 
/*     */     
/* 195 */     throw new ClassNotFoundException("SyntheticRepository could not load " + 
/* 196 */         className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public void clear() { this._loadedClasses.clear(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\SyntheticRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */