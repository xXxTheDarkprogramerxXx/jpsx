/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.Attribute;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Class2HTML
/*     */   implements Constants
/*     */ {
/*     */   private JavaClass java_class;
/*     */   private String dir;
/*     */   private static String class_package;
/*     */   private static String class_name;
/*     */   private static ConstantPool constant_pool;
/*     */   
/*     */   public Class2HTML(JavaClass java_class, String dir) throws IOException {
/* 100 */     Method[] methods = java_class.getMethods();
/*     */     
/* 102 */     this.java_class = java_class;
/* 103 */     this.dir = dir;
/* 104 */     class_name = java_class.getClassName();
/* 105 */     constant_pool = java_class.getConstantPool();
/*     */ 
/*     */     
/* 108 */     int index = class_name.lastIndexOf('.');
/* 109 */     if (index > -1) {
/* 110 */       class_package = class_name.substring(0, index);
/*     */     } else {
/* 112 */       class_package = "";
/*     */     } 
/* 114 */     ConstantHTML constant_html = new ConstantHTML(dir, class_name, class_package, methods, 
/* 115 */         constant_pool);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     AttributeHTML attribute_html = new AttributeHTML(dir, class_name, constant_pool, constant_html);
/*     */     
/* 122 */     MethodHTML method_html = new MethodHTML(dir, class_name, methods, java_class.getFields(), 
/* 123 */         constant_html, attribute_html);
/*     */     
/* 125 */     writeMainHTML(attribute_html);
/*     */     
/* 127 */     attribute_html.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] argv) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: arraylength
/*     */     //   2: anewarray java/lang/String
/*     */     //   5: astore_1
/*     */     //   6: iconst_0
/*     */     //   7: istore_2
/*     */     //   8: aconst_null
/*     */     //   9: astore_3
/*     */     //   10: aconst_null
/*     */     //   11: astore #4
/*     */     //   13: aconst_null
/*     */     //   14: astore #5
/*     */     //   16: ldc 'file.separator'
/*     */     //   18: invokestatic getProperty : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   21: invokevirtual toCharArray : ()[C
/*     */     //   24: iconst_0
/*     */     //   25: caload
/*     */     //   26: istore #6
/*     */     //   28: new java/lang/StringBuilder
/*     */     //   31: dup
/*     */     //   32: ldc '.'
/*     */     //   34: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   37: iload #6
/*     */     //   39: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   42: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   45: astore #7
/*     */     //   47: iconst_0
/*     */     //   48: istore #8
/*     */     //   50: goto -> 213
/*     */     //   53: aload_0
/*     */     //   54: iload #8
/*     */     //   56: aaload
/*     */     //   57: iconst_0
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: bipush #45
/*     */     //   63: if_icmpne -> 200
/*     */     //   66: aload_0
/*     */     //   67: iload #8
/*     */     //   69: aaload
/*     */     //   70: ldc '-d'
/*     */     //   72: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   75: ifeq -> 148
/*     */     //   78: aload_0
/*     */     //   79: iinc #8, 1
/*     */     //   82: iload #8
/*     */     //   84: aaload
/*     */     //   85: astore #7
/*     */     //   87: aload #7
/*     */     //   89: new java/lang/StringBuilder
/*     */     //   92: dup
/*     */     //   93: invokespecial <init> : ()V
/*     */     //   96: iload #6
/*     */     //   98: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   101: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   104: invokevirtual endsWith : (Ljava/lang/String;)Z
/*     */     //   107: ifne -> 132
/*     */     //   110: new java/lang/StringBuilder
/*     */     //   113: dup
/*     */     //   114: aload #7
/*     */     //   116: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   119: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   122: iload #6
/*     */     //   124: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   127: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   130: astore #7
/*     */     //   132: new java/io/File
/*     */     //   135: dup
/*     */     //   136: aload #7
/*     */     //   138: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   141: invokevirtual mkdirs : ()Z
/*     */     //   144: pop
/*     */     //   145: goto -> 210
/*     */     //   148: aload_0
/*     */     //   149: iload #8
/*     */     //   151: aaload
/*     */     //   152: ldc '-zip'
/*     */     //   154: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   157: ifeq -> 172
/*     */     //   160: aload_0
/*     */     //   161: iinc #8, 1
/*     */     //   164: iload #8
/*     */     //   166: aaload
/*     */     //   167: astore #5
/*     */     //   169: goto -> 210
/*     */     //   172: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   175: new java/lang/StringBuilder
/*     */     //   178: dup
/*     */     //   179: ldc 'Unknown option '
/*     */     //   181: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   184: aload_0
/*     */     //   185: iload #8
/*     */     //   187: aaload
/*     */     //   188: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   191: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   194: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   197: goto -> 210
/*     */     //   200: aload_1
/*     */     //   201: iload_2
/*     */     //   202: iinc #2, 1
/*     */     //   205: aload_0
/*     */     //   206: iload #8
/*     */     //   208: aaload
/*     */     //   209: aastore
/*     */     //   210: iinc #8, 1
/*     */     //   213: iload #8
/*     */     //   215: aload_0
/*     */     //   216: arraylength
/*     */     //   217: if_icmplt -> 53
/*     */     //   220: iload_2
/*     */     //   221: ifne -> 235
/*     */     //   224: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*     */     //   227: ldc 'Class2HTML: No input files specified.'
/*     */     //   229: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   232: goto -> 359
/*     */     //   235: iconst_0
/*     */     //   236: istore #8
/*     */     //   238: goto -> 332
/*     */     //   241: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   244: new java/lang/StringBuilder
/*     */     //   247: dup
/*     */     //   248: ldc 'Processing '
/*     */     //   250: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   253: aload_1
/*     */     //   254: iload #8
/*     */     //   256: aaload
/*     */     //   257: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   260: ldc '...'
/*     */     //   262: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   265: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   268: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   271: aload #5
/*     */     //   273: ifnonnull -> 291
/*     */     //   276: new org/apache/bcel/classfile/ClassParser
/*     */     //   279: dup
/*     */     //   280: aload_1
/*     */     //   281: iload #8
/*     */     //   283: aaload
/*     */     //   284: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   287: astore_3
/*     */     //   288: goto -> 305
/*     */     //   291: new org/apache/bcel/classfile/ClassParser
/*     */     //   294: dup
/*     */     //   295: aload #5
/*     */     //   297: aload_1
/*     */     //   298: iload #8
/*     */     //   300: aaload
/*     */     //   301: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   304: astore_3
/*     */     //   305: aload_3
/*     */     //   306: invokevirtual parse : ()Lorg/apache/bcel/classfile/JavaClass;
/*     */     //   309: astore #4
/*     */     //   311: new org/apache/bcel/util/Class2HTML
/*     */     //   314: aload #4
/*     */     //   316: aload #7
/*     */     //   318: invokespecial <init> : (Lorg/apache/bcel/classfile/JavaClass;Ljava/lang/String;)V
/*     */     //   321: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   324: ldc 'Done.'
/*     */     //   326: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   329: iinc #8, 1
/*     */     //   332: iload #8
/*     */     //   334: iload_2
/*     */     //   335: if_icmplt -> 241
/*     */     //   338: goto -> 359
/*     */     //   341: astore #8
/*     */     //   343: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   346: aload #8
/*     */     //   348: invokevirtual println : (Ljava/lang/Object;)V
/*     */     //   351: aload #8
/*     */     //   353: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   356: invokevirtual printStackTrace : (Ljava/io/PrintStream;)V
/*     */     //   359: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #132	-> 0
/*     */     //   #133	-> 6
/*     */     //   #134	-> 8
/*     */     //   #135	-> 10
/*     */     //   #136	-> 13
/*     */     //   #137	-> 16
/*     */     //   #138	-> 28
/*     */     //   #143	-> 47
/*     */     //   #144	-> 53
/*     */     //   #145	-> 66
/*     */     //   #146	-> 78
/*     */     //   #148	-> 87
/*     */     //   #149	-> 110
/*     */     //   #151	-> 132
/*     */     //   #153	-> 148
/*     */     //   #154	-> 160
/*     */     //   #156	-> 172
/*     */     //   #159	-> 200
/*     */     //   #143	-> 210
/*     */     //   #162	-> 220
/*     */     //   #163	-> 224
/*     */     //   #165	-> 235
/*     */     //   #166	-> 241
/*     */     //   #167	-> 271
/*     */     //   #168	-> 276
/*     */     //   #170	-> 291
/*     */     //   #172	-> 305
/*     */     //   #173	-> 311
/*     */     //   #174	-> 321
/*     */     //   #165	-> 329
/*     */     //   #177	-> 341
/*     */     //   #178	-> 343
/*     */     //   #179	-> 351
/*     */     //   #181	-> 359
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	360	0	argv	[Ljava/lang/String;
/*     */     //   6	354	1	file_name	[Ljava/lang/String;
/*     */     //   8	352	2	files	I
/*     */     //   10	350	3	parser	Lorg/apache/bcel/classfile/ClassParser;
/*     */     //   13	347	4	java_class	Lorg/apache/bcel/classfile/JavaClass;
/*     */     //   16	344	5	zip_file	Ljava/lang/String;
/*     */     //   28	332	6	sep	C
/*     */     //   47	313	7	dir	Ljava/lang/String;
/*     */     //   50	170	8	i	I
/*     */     //   238	100	8	i	I
/*     */     //   343	16	8	e	Ljava/lang/Exception;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   47	338	341	java/lang/Exception }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String referenceClass(int index) {
/* 188 */     String str = constant_pool.getConstantString(index, (byte)7);
/* 189 */     str = Utility.compactClassName(str);
/* 190 */     str = Utility.compactClassName(str, String.valueOf(class_package) + ".", true);
/*     */     
/* 192 */     return "<A HREF=\"" + class_name + "_cp.html#cp" + index + 
/* 193 */       "\" TARGET=ConstantPool>" + str + "</A>";
/*     */   }
/*     */   
/*     */   static final String referenceType(String type) {
/* 197 */     String short_type = Utility.compactClassName(type);
/* 198 */     short_type = Utility.compactClassName(short_type, String.valueOf(class_package) + ".", true);
/*     */     
/* 200 */     int index = type.indexOf('[');
/* 201 */     if (index > -1) {
/* 202 */       type = type.substring(0, index);
/*     */     }
/*     */     
/* 205 */     if (type.equals("int") || type.equals("short") || type.equals("boolean") || type.equals("void") || 
/* 206 */       type.equals("char") || type.equals("byte") || type.equals("long") || type.equals("double") || 
/* 207 */       type.equals("float")) {
/* 208 */       return "<FONT COLOR=\"#00FF00\">" + type + "</FONT>";
/*     */     }
/* 210 */     return "<A HREF=\"" + type + ".html\" TARGET=_top>" + short_type + "</A>";
/*     */   }
/*     */   
/*     */   static String toHTML(String str) {
/* 214 */     StringBuffer buf = new StringBuffer();
/*     */     
/*     */     try {
/* 217 */       for (int i = 0; i < str.length(); i++) {
/*     */         char ch;
/*     */         
/* 220 */         switch (ch = str.charAt(i)) { case '<':
/* 221 */             buf.append("&lt;"); break;
/* 222 */           case '>': buf.append("&gt;"); break;
/* 223 */           case '\n': buf.append("\\n"); break;
/* 224 */           case '\r': buf.append("\\r"); break;
/* 225 */           default: buf.append(ch); break; }
/*     */       
/*     */       } 
/* 228 */     } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*     */     
/* 230 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private void writeMainHTML(AttributeHTML attribute_html) throws IOException {
/* 234 */     PrintWriter file = new PrintWriter(new FileOutputStream(String.valueOf(this.dir) + class_name + ".html"));
/* 235 */     Attribute[] attributes = this.java_class.getAttributes();
/*     */     
/* 237 */     file.println("<HTML>\n<HEAD><TITLE>Documentation for " + class_name + "</TITLE>" + 
/* 238 */         "</HEAD>\n" + 
/* 239 */         "<FRAMESET BORDER=1 cols=\"30%,*\">\n" + 
/* 240 */         "<FRAMESET BORDER=1 rows=\"80%,*\">\n" + 
/*     */         
/* 242 */         "<FRAME NAME=\"ConstantPool\" SRC=\"" + class_name + "_cp.html" + "\"\n MARGINWIDTH=\"0\" " + 
/* 243 */         "MARGINHEIGHT=\"0\" FRAMEBORDER=\"1\" SCROLLING=\"AUTO\">\n" + 
/* 244 */         "<FRAME NAME=\"Attributes\" SRC=\"" + class_name + "_attributes.html" + 
/* 245 */         "\"\n MARGINWIDTH=\"0\" " + 
/* 246 */         "MARGINHEIGHT=\"0\" FRAMEBORDER=\"1\" SCROLLING=\"AUTO\">\n" + 
/* 247 */         "</FRAMESET>\n" + 
/*     */         
/* 249 */         "<FRAMESET BORDER=1 rows=\"80%,*\">\n" + 
/* 250 */         "<FRAME NAME=\"Code\" SRC=\"" + class_name + "_code.html\"\n MARGINWIDTH=0 " + 
/* 251 */         "MARGINHEIGHT=0 FRAMEBORDER=1 SCROLLING=\"AUTO\">\n" + 
/* 252 */         "<FRAME NAME=\"Methods\" SRC=\"" + class_name + "_methods.html\"\n MARGINWIDTH=0 " + 
/* 253 */         "MARGINHEIGHT=0 FRAMEBORDER=1 SCROLLING=\"AUTO\">\n" + 
/* 254 */         "</FRAMESET></FRAMESET></HTML>");
/*     */ 
/*     */     
/* 257 */     file.close();
/*     */     
/* 259 */     for (int i = 0; i < attributes.length; i++)
/* 260 */       attribute_html.writeAttribute(attributes[i], "class" + i); 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\Class2HTML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */