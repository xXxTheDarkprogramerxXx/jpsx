/*    */ package org.apache.bcel.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import org.apache.bcel.classfile.JavaClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassSet
/*    */   implements Serializable
/*    */ {
/* 70 */   private HashMap _map = new HashMap();
/*    */   
/*    */   public boolean add(JavaClass clazz) {
/* 73 */     boolean result = false;
/*    */     
/* 75 */     if (!this._map.containsKey(clazz.getClassName())) {
/* 76 */       result = true;
/* 77 */       this._map.put(clazz.getClassName(), clazz);
/*    */     } 
/*    */     
/* 80 */     return result;
/*    */   }
/*    */   
/* 83 */   public void remove(JavaClass clazz) { this._map.remove(clazz.getClassName()); }
/* 84 */   public boolean empty() { return this._map.isEmpty(); }
/*    */   
/*    */   public JavaClass[] toArray() {
/* 87 */     Collection values = this._map.values();
/* 88 */     JavaClass[] classes = new JavaClass[values.size()];
/* 89 */     values.toArray(classes);
/* 90 */     return classes;
/*    */   }
/*    */ 
/*    */   
/* 94 */   public String[] getClassNames() { return (String[])this._map.keySet().toArray(new String[this._map.keySet().size()]); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */