/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.BitSet;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.classfile.Attribute;
/*     */ import org.apache.bcel.classfile.Code;
/*     */ import org.apache.bcel.classfile.CodeException;
/*     */ import org.apache.bcel.classfile.ConstantFieldref;
/*     */ import org.apache.bcel.classfile.ConstantInterfaceMethodref;
/*     */ import org.apache.bcel.classfile.ConstantMethodref;
/*     */ import org.apache.bcel.classfile.ConstantNameAndType;
/*     */ import org.apache.bcel.classfile.ConstantPool;
/*     */ import org.apache.bcel.classfile.LocalVariable;
/*     */ import org.apache.bcel.classfile.LocalVariableTable;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CodeHTML
/*     */   implements Constants
/*     */ {
/*     */   private String class_name;
/*     */   private Method[] methods;
/*     */   private PrintWriter file;
/*     */   private BitSet goto_set;
/*     */   private ConstantPool constant_pool;
/*     */   private ConstantHTML constant_html;
/*     */   private static boolean wide = false;
/*     */   
/*     */   CodeHTML(String dir, String class_name, Method[] methods, ConstantPool constant_pool, ConstantHTML constant_html) throws IOException {
/*  81 */     this.class_name = class_name;
/*  82 */     this.methods = methods;
/*  83 */     this.constant_pool = constant_pool;
/*  84 */     this.constant_html = constant_html;
/*     */     
/*  86 */     this.file = new PrintWriter(new FileOutputStream(String.valueOf(dir) + class_name + "_code.html"));
/*  87 */     this.file.println("<HTML><BODY BGCOLOR=\"#C0C0C0\">");
/*     */     
/*  89 */     for (int i = 0; i < methods.length; i++) {
/*  90 */       writeMethod(methods[i], i);
/*     */     }
/*  92 */     this.file.println("</BODY></HTML>");
/*  93 */     this.file.close();
/*     */   }
/*     */   
/*     */   private final String codeToHTML(ByteSequence bytes, int method_number) throws IOException {
/*     */     int i, dimensions;
/*     */     String type, args[];
/*     */     ConstantNameAndType c2;
/*     */     String str1;
/*     */     int m_index;
/*     */     String field_name;
/*     */     ConstantFieldref c1;
/*     */     int windex, i, i, npairs, i, i, offset, offset, jump_table[], jump_table[], constant, vindex, class_index, index, index, index, index, index, index, index, high, low;
/*     */     String signature, name, name;
/* 106 */     short opcode = (short)bytes.readUnsignedByte();
/*     */ 
/*     */     
/* 109 */     int default_offset = 0;
/*     */ 
/*     */     
/* 112 */     int no_pad_bytes = 0;
/*     */     
/* 114 */     StringBuffer buf = new StringBuffer("<TT>" + OPCODE_NAMES[opcode] + "</TT></TD><TD>");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (opcode == 170 || opcode == 171) {
/* 120 */       int remainder = bytes.getIndex() % 4;
/* 121 */       no_pad_bytes = (remainder == 0) ? 0 : (4 - remainder);
/*     */       
/* 123 */       for (int i = 0; i < no_pad_bytes; i++) {
/* 124 */         bytes.readByte();
/*     */       }
/*     */       
/* 127 */       default_offset = bytes.readInt();
/*     */     } 
/*     */     
/* 130 */     switch (opcode)
/*     */     { case 170:
/* 132 */         low = bytes.readInt();
/* 133 */         high = bytes.readInt();
/*     */         
/* 135 */         offset = bytes.getIndex() - 12 - no_pad_bytes - 1;
/* 136 */         default_offset += offset;
/*     */         
/* 138 */         buf.append("<TABLE BORDER=1><TR>");
/*     */ 
/*     */         
/* 141 */         jump_table = new int[high - low + 1];
/* 142 */         for (i = 0; i < jump_table.length; i++) {
/* 143 */           jump_table[i] = offset + bytes.readInt();
/*     */           
/* 145 */           buf.append("<TH>" + (low + i) + "</TH>");
/*     */         } 
/* 147 */         buf.append("<TH>default</TH></TR>\n<TR>");
/*     */ 
/*     */         
/* 150 */         for (i = 0; i < jump_table.length; i++)
/* 151 */           buf.append("<TD><A HREF=\"#code" + method_number + "@" + 
/* 152 */               jump_table[i] + "\">" + jump_table[i] + "</A></TD>"); 
/* 153 */         buf.append("<TD><A HREF=\"#code" + method_number + "@" + 
/* 154 */             default_offset + "\">" + default_offset + "</A></TD></TR>\n</TABLE>\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 396 */         buf.append("</TD>");
/* 397 */         return buf.toString();case 171: npairs = bytes.readInt(); offset = bytes.getIndex() - 8 - no_pad_bytes - 1; jump_table = new int[npairs]; default_offset += offset; buf.append("<TABLE BORDER=1><TR>"); for (i = 0; i < npairs; i++) { int match = bytes.readInt(); jump_table[i] = offset + bytes.readInt(); buf.append("<TH>" + match + "</TH>"); }  buf.append("<TH>default</TH></TR>\n<TR>"); for (i = 0; i < npairs; i++) buf.append("<TD><A HREF=\"#code" + method_number + "@" + jump_table[i] + "\">" + jump_table[i] + "</A></TD>");  buf.append("<TD><A HREF=\"#code" + method_number + "@" + default_offset + "\">" + default_offset + "</A></TD></TR>\n</TABLE>\n"); buf.append("</TD>"); return buf.toString();case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161: case 162: case 163: case 164: case 165: case 166: case 167: case 168: case 198: case 199: index = bytes.getIndex() + bytes.readShort() - 1; buf.append("<A HREF=\"#code" + method_number + "@" + index + "\">" + index + "</A>"); buf.append("</TD>"); return buf.toString();case 200: case 201: windex = bytes.getIndex() + bytes.readInt() - 1; buf.append("<A HREF=\"#code" + method_number + "@" + windex + "\">" + windex + "</A>"); buf.append("</TD>"); return buf.toString();case 21: case 22: case 23: case 24: case 25: case 54: case 55: case 56: case 57: case 58: case 169: if (wide) { vindex = bytes.readShort(); wide = false; } else { vindex = bytes.readUnsignedByte(); }  buf.append("%" + vindex); buf.append("</TD>"); return buf.toString();case 196: wide = true; buf.append("(wide)"); buf.append("</TD>"); return buf.toString();case 188: buf.append("<FONT COLOR=\"#00FF00\">" + TYPE_NAMES[bytes.readByte()] + "</FONT>"); buf.append("</TD>"); return buf.toString();case 178: case 179: case 180: case 181: index = bytes.readShort(); c1 = (ConstantFieldref)this.constant_pool.getConstant(index, (byte)9); class_index = c1.getClassIndex(); name = this.constant_pool.getConstantString(class_index, (byte)7); name = Utility.compactClassName(name, false); index = c1.getNameAndTypeIndex(); field_name = this.constant_pool.constantToString(index, (byte)12); if (name.equals(this.class_name)) { buf.append("<A HREF=\"" + this.class_name + "_methods.html#field" + field_name + "\" TARGET=Methods>" + field_name + "</A>\n"); } else { buf.append(String.valueOf(this.constant_html.referenceConstant(class_index)) + "." + field_name); }  buf.append("</TD>"); return buf.toString();case 187: case 192: case 193: index = bytes.readShort(); buf.append(this.constant_html.referenceConstant(index)); buf.append("</TD>"); return buf.toString();case 182: case 183: case 184: case 185: m_index = bytes.readShort(); if (opcode == 185) { int nargs = bytes.readUnsignedByte(); int reserved = bytes.readUnsignedByte(); ConstantInterfaceMethodref c = (ConstantInterfaceMethodref)this.constant_pool.getConstant(m_index, (byte)11); int class_index = c.getClassIndex(); String str = this.constant_pool.constantToString(c); int index = c.getNameAndTypeIndex(); } else { ConstantMethodref c = (ConstantMethodref)this.constant_pool.getConstant(m_index, (byte)10); class_index = c.getClassIndex(); String str = this.constant_pool.constantToString(c); index = c.getNameAndTypeIndex(); }  name = Class2HTML.referenceClass(class_index); str1 = Class2HTML.toHTML(this.constant_pool.constantToString(this.constant_pool.getConstant(index, (byte)12))); c2 = (ConstantNameAndType)this.constant_pool.getConstant(index, (byte)12); signature = this.constant_pool.constantToString(c2.getSignatureIndex(), (byte)1); args = Utility.methodSignatureArgumentTypes(signature, false); type = Utility.methodSignatureReturnType(signature, false); buf.append(String.valueOf(name) + ".<A HREF=\"" + this.class_name + "_cp.html#cp" + m_index + "\" TARGET=ConstantPool>" + str1 + "</A>" + "("); for (i = 0; i < args.length; i++) { buf.append(Class2HTML.referenceType(args[i])); if (i < args.length - 1) buf.append(", ");  }  buf.append("):" + Class2HTML.referenceType(type)); buf.append("</TD>"); return buf.toString();case 19: case 20: index = bytes.readShort(); buf.append("<A HREF=\"" + this.class_name + "_cp.html#cp" + index + "\" TARGET=\"ConstantPool\">" + Class2HTML.toHTML(this.constant_pool.constantToString(index, this.constant_pool.getConstant(index).getTag())) + "</a>"); buf.append("</TD>"); return buf.toString();case 18: index = bytes.readUnsignedByte(); buf.append("<A HREF=\"" + this.class_name + "_cp.html#cp" + index + "\" TARGET=\"ConstantPool\">" + Class2HTML.toHTML(this.constant_pool.constantToString(index, this.constant_pool.getConstant(index).getTag())) + "</a>"); buf.append("</TD>"); return buf.toString();case 189: index = bytes.readShort(); buf.append(this.constant_html.referenceConstant(index)); buf.append("</TD>"); return buf.toString();case 197: index = bytes.readShort(); dimensions = bytes.readByte(); buf.append(String.valueOf(this.constant_html.referenceConstant(index)) + ":" + dimensions + "-dimensional"); buf.append("</TD>"); return buf.toString();case 132: if (wide) { int vindex = bytes.readShort(); constant = bytes.readShort(); wide = false; } else { vindex = bytes.readUnsignedByte(); constant = bytes.readByte(); }  buf.append("%" + vindex + " " + constant); buf.append("</TD>"); return buf.toString(); }  if (NO_OF_OPERANDS[opcode] > 0) for (int i = 0; i < TYPE_OF_OPERANDS[opcode].length; i++) { switch (TYPE_OF_OPERANDS[opcode][i]) { case 8: buf.append(bytes.readUnsignedByte()); break;case 9: buf.append(bytes.readShort()); break;case 10: buf.append(bytes.readInt()); break;default: System.err.println("Unreachable default case reached!"); System.exit(-1); break; }  buf.append("&nbsp;"); }   buf.append("</TD>"); return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void findGotos(ByteSequence bytes, Method method, Code code) throws IOException {
/* 408 */     this.goto_set = new BitSet(bytes.available());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 415 */     if (code != null) {
/* 416 */       CodeException[] ce = code.getExceptionTable();
/* 417 */       int len = ce.length;
/*     */       
/* 419 */       for (int i = 0; i < len; i++) {
/* 420 */         this.goto_set.set(ce[i].getStartPC());
/* 421 */         this.goto_set.set(ce[i].getEndPC());
/* 422 */         this.goto_set.set(ce[i].getHandlerPC());
/*     */       } 
/*     */ 
/*     */       
/* 426 */       Attribute[] attributes = code.getAttributes();
/* 427 */       for (int i = 0; i < attributes.length; i++) {
/* 428 */         if (attributes[i].getTag() == 5) {
/* 429 */           LocalVariable[] vars = ((LocalVariableTable)attributes[i]).getLocalVariableTable();
/*     */           
/* 431 */           for (int j = 0; j < vars.length; j++) {
/* 432 */             int start = vars[j].getStartPC();
/* 433 */             int end = start + vars[j].getLength();
/* 434 */             this.goto_set.set(start);
/* 435 */             this.goto_set.set(end);
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 443 */     for (int i = 0; bytes.available() > 0; i++) {
/* 444 */       int j, j, npairs, offset, default_offset, no_pad_bytes, remainder, index, index, opcode = bytes.readUnsignedByte();
/*     */       
/* 446 */       switch (opcode) {
/*     */         
/*     */         case 170:
/*     */         case 171:
/* 450 */           remainder = bytes.getIndex() % 4;
/* 451 */           no_pad_bytes = (remainder == 0) ? 0 : (4 - remainder);
/*     */ 
/*     */           
/* 454 */           for (j = 0; j < no_pad_bytes; j++) {
/* 455 */             bytes.readByte();
/*     */           }
/*     */           
/* 458 */           default_offset = bytes.readInt();
/*     */           
/* 460 */           if (opcode == 170) {
/* 461 */             int low = bytes.readInt();
/* 462 */             int high = bytes.readInt();
/*     */             
/* 464 */             int offset = bytes.getIndex() - 12 - no_pad_bytes - 1;
/* 465 */             default_offset += offset;
/* 466 */             this.goto_set.set(default_offset);
/*     */             
/* 468 */             for (int j = 0; j < high - low + 1; j++) {
/* 469 */               int index = offset + bytes.readInt();
/* 470 */               this.goto_set.set(index);
/*     */             } 
/*     */             break;
/*     */           } 
/* 474 */           npairs = bytes.readInt();
/*     */           
/* 476 */           offset = bytes.getIndex() - 8 - no_pad_bytes - 1;
/* 477 */           default_offset += offset;
/* 478 */           this.goto_set.set(default_offset);
/*     */           
/* 480 */           for (j = 0; j < npairs; j++)
/* 481 */           { int match = bytes.readInt();
/*     */             
/* 483 */             int index = offset + bytes.readInt();
/* 484 */             this.goto_set.set(index); }  break;
/*     */         case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161:
/*     */         case 162:
/*     */         case 163:
/*     */         case 164:
/*     */         case 165:
/*     */         case 166:
/*     */         case 167:
/*     */         case 168:
/*     */         case 198:
/*     */         case 199:
/* 495 */           index = bytes.getIndex() + bytes.readShort() - 1;
/*     */           
/* 497 */           this.goto_set.set(index);
/*     */           break;
/*     */         
/*     */         case 200:
/*     */         case 201:
/* 502 */           index = bytes.getIndex() + bytes.readInt() - 1;
/* 503 */           this.goto_set.set(index);
/*     */           break;
/*     */         
/*     */         default:
/* 507 */           bytes.unreadByte();
/* 508 */           codeToHTML(bytes, 0);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeMethod(Method method, int method_number) throws IOException { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokevirtual getSignature : ()Ljava/lang/String;
/*     */     //   4: astore_3
/*     */     //   5: aload_3
/*     */     //   6: iconst_0
/*     */     //   7: invokestatic methodSignatureArgumentTypes : (Ljava/lang/String;Z)[Ljava/lang/String;
/*     */     //   10: astore #4
/*     */     //   12: aload_3
/*     */     //   13: iconst_0
/*     */     //   14: invokestatic methodSignatureReturnType : (Ljava/lang/String;Z)Ljava/lang/String;
/*     */     //   17: astore #5
/*     */     //   19: aload_1
/*     */     //   20: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   23: astore #6
/*     */     //   25: aload #6
/*     */     //   27: invokestatic toHTML : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   30: astore #7
/*     */     //   32: aload_1
/*     */     //   33: invokevirtual getAccessFlags : ()I
/*     */     //   36: invokestatic accessToString : (I)Ljava/lang/String;
/*     */     //   39: astore #8
/*     */     //   41: aload #8
/*     */     //   43: ldc_w ' '
/*     */     //   46: ldc_w '&nbsp;'
/*     */     //   49: invokestatic replace : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   52: astore #8
/*     */     //   54: aload_1
/*     */     //   55: invokevirtual getAttributes : ()[Lorg/apache/bcel/classfile/Attribute;
/*     */     //   58: astore #9
/*     */     //   60: aload_0
/*     */     //   61: getfield file : Ljava/io/PrintWriter;
/*     */     //   64: new java/lang/StringBuilder
/*     */     //   67: dup
/*     */     //   68: ldc_w '<P><B><FONT COLOR="#FF0000">'
/*     */     //   71: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   74: aload #8
/*     */     //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   79: ldc_w '</FONT>&nbsp;'
/*     */     //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   85: ldc_w '<A NAME=method'
/*     */     //   88: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   91: iload_2
/*     */     //   92: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   95: ldc_w '>'
/*     */     //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   101: aload #5
/*     */     //   103: invokestatic referenceType : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   109: ldc_w '</A>&nbsp<A HREF="'
/*     */     //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   115: aload_0
/*     */     //   116: getfield class_name : Ljava/lang/String;
/*     */     //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   122: ldc_w '_methods.html#method'
/*     */     //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   128: iload_2
/*     */     //   129: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   132: ldc '" TARGET=Methods>'
/*     */     //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   137: aload #7
/*     */     //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   142: ldc_w '</A>('
/*     */     //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   148: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   151: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   154: iconst_0
/*     */     //   155: istore #10
/*     */     //   157: goto -> 198
/*     */     //   160: aload_0
/*     */     //   161: getfield file : Ljava/io/PrintWriter;
/*     */     //   164: aload #4
/*     */     //   166: iload #10
/*     */     //   168: aaload
/*     */     //   169: invokestatic referenceType : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   172: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   175: iload #10
/*     */     //   177: aload #4
/*     */     //   179: arraylength
/*     */     //   180: iconst_1
/*     */     //   181: isub
/*     */     //   182: if_icmpge -> 195
/*     */     //   185: aload_0
/*     */     //   186: getfield file : Ljava/io/PrintWriter;
/*     */     //   189: ldc_w ',&nbsp;'
/*     */     //   192: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   195: iinc #10, 1
/*     */     //   198: iload #10
/*     */     //   200: aload #4
/*     */     //   202: arraylength
/*     */     //   203: if_icmplt -> 160
/*     */     //   206: aload_0
/*     */     //   207: getfield file : Ljava/io/PrintWriter;
/*     */     //   210: ldc_w ')</B></P>'
/*     */     //   213: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   216: aconst_null
/*     */     //   217: astore #10
/*     */     //   219: aconst_null
/*     */     //   220: astore #11
/*     */     //   222: aload #9
/*     */     //   224: arraylength
/*     */     //   225: ifle -> 547
/*     */     //   228: aload_0
/*     */     //   229: getfield file : Ljava/io/PrintWriter;
/*     */     //   232: ldc_w '<H4>Attributes</H4><UL>\\n'
/*     */     //   235: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   238: iconst_0
/*     */     //   239: istore #12
/*     */     //   241: goto -> 529
/*     */     //   244: aload #9
/*     */     //   246: iload #12
/*     */     //   248: aaload
/*     */     //   249: invokevirtual getTag : ()B
/*     */     //   252: istore #13
/*     */     //   254: iload #13
/*     */     //   256: iconst_m1
/*     */     //   257: if_icmpeq -> 331
/*     */     //   260: aload_0
/*     */     //   261: getfield file : Ljava/io/PrintWriter;
/*     */     //   264: new java/lang/StringBuilder
/*     */     //   267: dup
/*     */     //   268: ldc_w '<LI><A HREF="'
/*     */     //   271: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   274: aload_0
/*     */     //   275: getfield class_name : Ljava/lang/String;
/*     */     //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   281: ldc_w '_attributes.html#method'
/*     */     //   284: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   287: iload_2
/*     */     //   288: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   291: ldc '@'
/*     */     //   293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   296: iload #12
/*     */     //   298: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   301: ldc_w '" TARGET=Attributes>'
/*     */     //   304: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   307: getstatic org/apache/bcel/util/CodeHTML.ATTRIBUTE_NAMES : [Ljava/lang/String;
/*     */     //   310: iload #13
/*     */     //   312: aaload
/*     */     //   313: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   316: ldc_w '</A></LI>\\n'
/*     */     //   319: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   322: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   325: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   328: goto -> 365
/*     */     //   331: aload_0
/*     */     //   332: getfield file : Ljava/io/PrintWriter;
/*     */     //   335: new java/lang/StringBuilder
/*     */     //   338: dup
/*     */     //   339: ldc_w '<LI>'
/*     */     //   342: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   345: aload #9
/*     */     //   347: iload #12
/*     */     //   349: aaload
/*     */     //   350: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   353: ldc_w '</LI>'
/*     */     //   356: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   359: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   362: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   365: iload #13
/*     */     //   367: iconst_2
/*     */     //   368: if_icmpne -> 526
/*     */     //   371: aload #9
/*     */     //   373: iload #12
/*     */     //   375: aaload
/*     */     //   376: checkcast org/apache/bcel/classfile/Code
/*     */     //   379: astore #10
/*     */     //   381: aload #10
/*     */     //   383: invokevirtual getAttributes : ()[Lorg/apache/bcel/classfile/Attribute;
/*     */     //   386: astore #14
/*     */     //   388: aload #10
/*     */     //   390: invokevirtual getCode : ()[B
/*     */     //   393: astore #11
/*     */     //   395: aload_0
/*     */     //   396: getfield file : Ljava/io/PrintWriter;
/*     */     //   399: ldc_w '<UL>'
/*     */     //   402: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   405: iconst_0
/*     */     //   406: istore #15
/*     */     //   408: goto -> 508
/*     */     //   411: aload #14
/*     */     //   413: iload #15
/*     */     //   415: aaload
/*     */     //   416: invokevirtual getTag : ()B
/*     */     //   419: istore #13
/*     */     //   421: aload_0
/*     */     //   422: getfield file : Ljava/io/PrintWriter;
/*     */     //   425: new java/lang/StringBuilder
/*     */     //   428: dup
/*     */     //   429: ldc_w '<LI><A HREF="'
/*     */     //   432: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   435: aload_0
/*     */     //   436: getfield class_name : Ljava/lang/String;
/*     */     //   439: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   442: ldc_w '_attributes.html#'
/*     */     //   445: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   448: ldc_w 'method'
/*     */     //   451: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   454: iload_2
/*     */     //   455: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   458: ldc '@'
/*     */     //   460: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   463: iload #12
/*     */     //   465: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   468: ldc '@'
/*     */     //   470: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   473: iload #15
/*     */     //   475: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   478: ldc_w '" TARGET=Attributes>'
/*     */     //   481: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   484: getstatic org/apache/bcel/util/CodeHTML.ATTRIBUTE_NAMES : [Ljava/lang/String;
/*     */     //   487: iload #13
/*     */     //   489: aaload
/*     */     //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   493: ldc_w '</A></LI>\\n'
/*     */     //   496: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   499: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   502: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   505: iinc #15, 1
/*     */     //   508: iload #15
/*     */     //   510: aload #14
/*     */     //   512: arraylength
/*     */     //   513: if_icmplt -> 411
/*     */     //   516: aload_0
/*     */     //   517: getfield file : Ljava/io/PrintWriter;
/*     */     //   520: ldc_w '</UL>'
/*     */     //   523: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   526: iinc #12, 1
/*     */     //   529: iload #12
/*     */     //   531: aload #9
/*     */     //   533: arraylength
/*     */     //   534: if_icmplt -> 244
/*     */     //   537: aload_0
/*     */     //   538: getfield file : Ljava/io/PrintWriter;
/*     */     //   541: ldc_w '</UL>'
/*     */     //   544: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   547: aload #11
/*     */     //   549: ifnull -> 826
/*     */     //   552: new org/apache/bcel/util/ByteSequence
/*     */     //   555: dup
/*     */     //   556: aload #11
/*     */     //   558: invokespecial <init> : ([B)V
/*     */     //   561: astore #12
/*     */     //   563: aload #12
/*     */     //   565: aload #12
/*     */     //   567: invokevirtual available : ()I
/*     */     //   570: invokevirtual mark : (I)V
/*     */     //   573: aload_0
/*     */     //   574: aload #12
/*     */     //   576: aload_1
/*     */     //   577: aload #10
/*     */     //   579: invokespecial findGotos : (Lorg/apache/bcel/util/ByteSequence;Lorg/apache/bcel/classfile/Method;Lorg/apache/bcel/classfile/Code;)V
/*     */     //   582: aload #12
/*     */     //   584: invokevirtual reset : ()V
/*     */     //   587: aload_0
/*     */     //   588: getfield file : Ljava/io/PrintWriter;
/*     */     //   591: ldc_w '<TABLE BORDER=0><TR><TH ALIGN=LEFT>Byte<BR>offset</TH><TH ALIGN=LEFT>Instruction</TH><TH ALIGN=LEFT>Argument</TH>'
/*     */     //   594: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   597: iconst_0
/*     */     //   598: istore #13
/*     */     //   600: goto -> 798
/*     */     //   603: aload #12
/*     */     //   605: invokevirtual getIndex : ()I
/*     */     //   608: istore #14
/*     */     //   610: aload_0
/*     */     //   611: aload #12
/*     */     //   613: iload_2
/*     */     //   614: invokespecial codeToHTML : (Lorg/apache/bcel/util/ByteSequence;I)Ljava/lang/String;
/*     */     //   617: astore #15
/*     */     //   619: ldc_w ''
/*     */     //   622: astore #16
/*     */     //   624: aload_0
/*     */     //   625: getfield goto_set : Ljava/util/BitSet;
/*     */     //   628: iload #14
/*     */     //   630: invokevirtual get : (I)Z
/*     */     //   633: ifeq -> 671
/*     */     //   636: new java/lang/StringBuilder
/*     */     //   639: dup
/*     */     //   640: ldc_w '<A NAME=code'
/*     */     //   643: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   646: iload_2
/*     */     //   647: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   650: ldc '@'
/*     */     //   652: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   655: iload #14
/*     */     //   657: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   660: ldc_w '></A>'
/*     */     //   663: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   666: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   669: astore #16
/*     */     //   671: aload #12
/*     */     //   673: invokevirtual getIndex : ()I
/*     */     //   676: aload #11
/*     */     //   678: arraylength
/*     */     //   679: if_icmpne -> 731
/*     */     //   682: new java/lang/StringBuilder
/*     */     //   685: dup
/*     */     //   686: ldc_w '<A NAME=code'
/*     */     //   689: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   692: iload_2
/*     */     //   693: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   696: ldc '@'
/*     */     //   698: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   701: aload #11
/*     */     //   703: arraylength
/*     */     //   704: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   707: ldc_w '>'
/*     */     //   710: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   713: iload #14
/*     */     //   715: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   718: ldc '</A>'
/*     */     //   720: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   723: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   726: astore #17
/*     */     //   728: goto -> 748
/*     */     //   731: new java/lang/StringBuilder
/*     */     //   734: dup
/*     */     //   735: invokespecial <init> : ()V
/*     */     //   738: iload #14
/*     */     //   740: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   743: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   746: astore #17
/*     */     //   748: aload_0
/*     */     //   749: getfield file : Ljava/io/PrintWriter;
/*     */     //   752: new java/lang/StringBuilder
/*     */     //   755: dup
/*     */     //   756: ldc_w '<TR VALIGN=TOP><TD>'
/*     */     //   759: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   762: aload #17
/*     */     //   764: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   767: ldc_w '</TD><TD>'
/*     */     //   770: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   773: aload #16
/*     */     //   775: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   778: aload #15
/*     */     //   780: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   783: ldc_w '</TR>'
/*     */     //   786: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   789: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   792: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   795: iinc #13, 1
/*     */     //   798: aload #12
/*     */     //   800: invokevirtual available : ()I
/*     */     //   803: ifgt -> 603
/*     */     //   806: aload_0
/*     */     //   807: getfield file : Ljava/io/PrintWriter;
/*     */     //   810: ldc_w '<TR><TD> </A></TD></TR>'
/*     */     //   813: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   816: aload_0
/*     */     //   817: getfield file : Ljava/io/PrintWriter;
/*     */     //   820: ldc_w '</TABLE>'
/*     */     //   823: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   826: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #520	-> 0
/*     */     //   #522	-> 5
/*     */     //   #524	-> 12
/*     */     //   #526	-> 19
/*     */     //   #527	-> 25
/*     */     //   #529	-> 32
/*     */     //   #530	-> 41
/*     */     //   #532	-> 54
/*     */     //   #534	-> 60
/*     */     //   #535	-> 85
/*     */     //   #536	-> 109
/*     */     //   #537	-> 132
/*     */     //   #534	-> 151
/*     */     //   #539	-> 154
/*     */     //   #540	-> 160
/*     */     //   #541	-> 175
/*     */     //   #542	-> 185
/*     */     //   #539	-> 195
/*     */     //   #545	-> 206
/*     */     //   #547	-> 216
/*     */     //   #548	-> 219
/*     */     //   #550	-> 222
/*     */     //   #551	-> 228
/*     */     //   #552	-> 238
/*     */     //   #553	-> 244
/*     */     //   #555	-> 254
/*     */     //   #556	-> 260
/*     */     //   #557	-> 301
/*     */     //   #556	-> 325
/*     */     //   #559	-> 331
/*     */     //   #561	-> 365
/*     */     //   #562	-> 371
/*     */     //   #563	-> 381
/*     */     //   #564	-> 388
/*     */     //   #566	-> 395
/*     */     //   #567	-> 405
/*     */     //   #568	-> 411
/*     */     //   #569	-> 421
/*     */     //   #570	-> 448
/*     */     //   #571	-> 484
/*     */     //   #569	-> 502
/*     */     //   #567	-> 505
/*     */     //   #574	-> 516
/*     */     //   #552	-> 526
/*     */     //   #577	-> 537
/*     */     //   #580	-> 547
/*     */     //   #584	-> 552
/*     */     //   #585	-> 563
/*     */     //   #586	-> 573
/*     */     //   #587	-> 582
/*     */     //   #589	-> 587
/*     */     //   #592	-> 597
/*     */     //   #593	-> 603
/*     */     //   #594	-> 610
/*     */     //   #595	-> 619
/*     */     //   #600	-> 624
/*     */     //   #601	-> 636
/*     */     //   #604	-> 671
/*     */     //   #605	-> 682
/*     */     //   #607	-> 731
/*     */     //   #609	-> 748
/*     */     //   #592	-> 795
/*     */     //   #613	-> 806
/*     */     //   #614	-> 816
/*     */     //   #617	-> 826
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	827	0	this	Lorg/apache/bcel/util/CodeHTML;
/*     */     //   0	827	1	method	Lorg/apache/bcel/classfile/Method;
/*     */     //   0	827	2	method_number	I
/*     */     //   5	822	3	signature	Ljava/lang/String;
/*     */     //   12	815	4	args	[Ljava/lang/String;
/*     */     //   19	808	5	type	Ljava/lang/String;
/*     */     //   25	802	6	name	Ljava/lang/String;
/*     */     //   32	795	7	html_name	Ljava/lang/String;
/*     */     //   41	786	8	access	Ljava/lang/String;
/*     */     //   60	767	9	attributes	[Lorg/apache/bcel/classfile/Attribute;
/*     */     //   157	49	10	i	I
/*     */     //   219	608	10	c	Lorg/apache/bcel/classfile/Code;
/*     */     //   222	605	11	code	[B
/*     */     //   241	296	12	i	I
/*     */     //   254	272	13	tag	B
/*     */     //   388	138	14	attributes2	[Lorg/apache/bcel/classfile/Attribute;
/*     */     //   408	108	15	j	I
/*     */     //   563	263	12	stream	Lorg/apache/bcel/util/ByteSequence;
/*     */     //   600	206	13	i	I
/*     */     //   610	185	14	offset	I
/*     */     //   619	176	15	str	Ljava/lang/String;
/*     */     //   624	171	16	anchor	Ljava/lang/String;
/*     */     //   728	3	17	anchor2	Ljava/lang/String;
/*     */     //   748	47	17	anchor2	Ljava/lang/String; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\CodeHTML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */