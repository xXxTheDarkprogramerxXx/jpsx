/*    */ package org.apache.bcel.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import org.apache.bcel.classfile.JavaClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassVector
/*    */   implements Serializable
/*    */ {
/* 68 */   protected ArrayList vec = new ArrayList();
/*    */   
/* 70 */   public void addElement(JavaClass clazz) { this.vec.add(clazz); }
/* 71 */   public JavaClass elementAt(int index) { return (JavaClass)this.vec.get(index); }
/* 72 */   public void removeElementAt(int index) { this.vec.remove(index); }
/*    */   
/*    */   public JavaClass[] toArray() {
/* 75 */     JavaClass[] classes = new JavaClass[this.vec.size()];
/* 76 */     this.vec.toArray(classes);
/* 77 */     return classes;
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */