/*    */ package org.apache.bcel.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.LinkedList;
/*    */ import org.apache.bcel.classfile.JavaClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassQueue
/*    */   implements Serializable
/*    */ {
/* 68 */   protected LinkedList vec = new LinkedList();
/*    */   
/* 70 */   public void enqueue(JavaClass clazz) { this.vec.addLast(clazz); }
/*    */ 
/*    */   
/* 73 */   public JavaClass dequeue() { return (JavaClass)this.vec.removeFirst(); }
/*    */ 
/*    */   
/* 76 */   public boolean empty() { return this.vec.isEmpty(); }
/*    */ 
/*    */   
/* 79 */   public String toString() { return this.vec.toString(); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\ClassQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */