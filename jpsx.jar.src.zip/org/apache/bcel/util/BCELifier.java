/*     */ package org.apache.bcel.util;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.bcel.Constants;
/*     */ import org.apache.bcel.Repository;
/*     */ import org.apache.bcel.classfile.ClassParser;
/*     */ import org.apache.bcel.classfile.ConstantValue;
/*     */ import org.apache.bcel.classfile.EmptyVisitor;
/*     */ import org.apache.bcel.classfile.Field;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.classfile.Utility;
/*     */ import org.apache.bcel.generic.ArrayType;
/*     */ import org.apache.bcel.generic.ConstantPoolGen;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BCELifier
/*     */   extends EmptyVisitor
/*     */ {
/*     */   private JavaClass _clazz;
/*     */   private PrintWriter _out;
/*     */   private ConstantPoolGen _cp;
/*     */   
/*     */   public BCELifier(JavaClass clazz, OutputStream out) {
/*  81 */     this._clazz = clazz;
/*  82 */     this._out = new PrintWriter(out);
/*  83 */     this._cp = new ConstantPoolGen(this._clazz.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  89 */     visitJavaClass(this._clazz);
/*  90 */     this._out.flush();
/*     */   }
/*     */   
/*     */   public void visitJavaClass(JavaClass clazz) {
/*  94 */     String class_name = clazz.getClassName();
/*  95 */     String super_name = clazz.getSuperclassName();
/*  96 */     String package_name = clazz.getPackageName();
/*  97 */     String inter = Utility.printArray(clazz.getInterfaceNames(), 
/*  98 */         false, true);
/*  99 */     if (!"".equals(package_name)) {
/* 100 */       class_name = class_name.substring(package_name.length() + 1);
/* 101 */       this._out.println("package " + package_name + ";\n");
/*     */     } 
/*     */     
/* 104 */     this._out.println("import org.apache.bcel.generic.*;");
/* 105 */     this._out.println("import org.apache.bcel.classfile.*;");
/* 106 */     this._out.println("import org.apache.bcel.*;");
/* 107 */     this._out.println("import java.io.*;\n");
/*     */     
/* 109 */     this._out.println("public class " + class_name + "Creator implements Constants {");
/* 110 */     this._out.println("  private InstructionFactory _factory;");
/* 111 */     this._out.println("  private ConstantPoolGen    _cp;");
/* 112 */     this._out.println("  private ClassGen           _cg;\n");
/*     */     
/* 114 */     this._out.println("  public " + class_name + "Creator() {");
/* 115 */     this._out.println("    _cg = new ClassGen(\"" + (
/* 116 */         "".equals(package_name) ? class_name : (
/* 117 */         String.valueOf(package_name) + "." + class_name)) + 
/* 118 */         "\", \"" + super_name + "\", " + 
/* 119 */         "\"" + clazz.getSourceFileName() + "\", " + 
/* 120 */         printFlags(clazz.getAccessFlags(), true) + ", " + 
/* 121 */         "new String[] { " + inter + " });\n");
/*     */     
/* 123 */     this._out.println("    _cp = _cg.getConstantPool();");
/* 124 */     this._out.println("    _factory = new InstructionFactory(_cg, _cp);");
/* 125 */     this._out.println("  }\n");
/*     */     
/* 127 */     printCreate();
/*     */     
/* 129 */     Field[] fields = clazz.getFields();
/*     */     
/* 131 */     if (fields.length > 0) {
/* 132 */       this._out.println("  private void createFields() {");
/* 133 */       this._out.println("    FieldGen field;");
/*     */       
/* 135 */       for (int i = 0; i < fields.length; i++) {
/* 136 */         fields[i].accept(this);
/*     */       }
/*     */       
/* 139 */       this._out.println("  }\n");
/*     */     } 
/*     */     
/* 142 */     Method[] methods = clazz.getMethods();
/*     */     
/* 144 */     for (int i = 0; i < methods.length; i++) {
/* 145 */       this._out.println("  private void createMethod_" + i + "() {");
/*     */       
/* 147 */       methods[i].accept(this);
/* 148 */       this._out.println("  }\n");
/*     */     } 
/*     */     
/* 151 */     printMain();
/* 152 */     this._out.println("}");
/*     */   }
/*     */   
/*     */   private void printCreate() {
/* 156 */     this._out.println("  public void create(OutputStream out) throws IOException {");
/*     */     
/* 158 */     Field[] fields = this._clazz.getFields();
/* 159 */     if (fields.length > 0) {
/* 160 */       this._out.println("    createFields();");
/*     */     }
/*     */     
/* 163 */     Method[] methods = this._clazz.getMethods();
/* 164 */     for (int i = 0; i < methods.length; i++) {
/* 165 */       this._out.println("    createMethod_" + i + "();");
/*     */     }
/*     */     
/* 168 */     this._out.println("    _cg.getJavaClass().dump(out);");
/*     */     
/* 170 */     this._out.println("  }\n");
/*     */   }
/*     */   
/*     */   private void printMain() {
/* 174 */     String class_name = this._clazz.getClassName();
/*     */     
/* 176 */     this._out.println("  public static void main(String[] args) throws Exception {");
/* 177 */     this._out.println("    " + class_name + "Creator creator = new " + 
/* 178 */         class_name + "Creator();");
/* 179 */     this._out.println("    creator.create(new FileOutputStream(\"" + class_name + 
/* 180 */         ".class\"));");
/* 181 */     this._out.println("  }");
/*     */   }
/*     */   
/*     */   public void visitField(Field field) {
/* 185 */     this._out.println("\n    field = new FieldGen(" + 
/* 186 */         printFlags(field.getAccessFlags()) + 
/* 187 */         ", " + printType(field.getSignature()) + ", \"" + 
/* 188 */         field.getName() + "\", _cp);");
/*     */     
/* 190 */     ConstantValue cv = field.getConstantValue();
/*     */     
/* 192 */     if (cv != null) {
/* 193 */       String value = cv.toString();
/* 194 */       this._out.println("    field.setInitValue(" + value + ")");
/*     */     } 
/*     */     
/* 197 */     this._out.println("    _cg.addField(field.getField());");
/*     */   }
/*     */   
/*     */   public void visitMethod(Method method) {
/* 201 */     MethodGen mg = new MethodGen(method, this._clazz.getClassName(), this._cp);
/*     */     
/* 203 */     Type result_type = mg.getReturnType();
/* 204 */     Type[] arg_types = mg.getArgumentTypes();
/*     */     
/* 206 */     this._out.println("    InstructionList il = new InstructionList();");
/* 207 */     this._out.println("    MethodGen method = new MethodGen(" + 
/* 208 */         printFlags(method.getAccessFlags()) + 
/* 209 */         ", " + printType(result_type) + 
/* 210 */         ", " + printArgumentTypes(arg_types) + ", " + 
/* 211 */         "new String[] { " + 
/* 212 */         Utility.printArray(mg.getArgumentNames(), false, true) + 
/* 213 */         " }, \"" + method.getName() + "\", \"" + 
/* 214 */         this._clazz.getClassName() + "\", il, _cp);\n");
/*     */     
/* 216 */     BCELFactory factory = new BCELFactory(mg, this._out);
/* 217 */     factory.start();
/*     */     
/* 219 */     this._out.println("    method.setMaxStack();");
/* 220 */     this._out.println("    method.setMaxLocals();");
/* 221 */     this._out.println("    _cg.addMethod(method.getMethod());");
/* 222 */     this._out.println("    il.dispose();");
/*     */   }
/*     */ 
/*     */   
/* 226 */   static String printFlags(int flags) { return printFlags(flags, false); }
/*     */ 
/*     */   
/*     */   static String printFlags(int flags, boolean for_class) {
/* 230 */     if (flags == 0) {
/* 231 */       return "0";
/*     */     }
/* 233 */     StringBuffer buf = new StringBuffer();
/* 234 */     for (int i = 0, pow = 1; i <= 2048; i++) {
/* 235 */       if ((flags & pow) != 0) {
/* 236 */         if (pow == 32 && for_class) {
/* 237 */           buf.append("ACC_SUPER | ");
/*     */         } else {
/* 239 */           buf.append("ACC_" + Constants.ACCESS_NAMES[i].toUpperCase() + " | ");
/*     */         } 
/*     */       }
/* 242 */       pow <<= 1;
/*     */     } 
/*     */     
/* 245 */     String str = buf.toString();
/* 246 */     return str.substring(0, str.length() - 3);
/*     */   }
/*     */   
/*     */   static String printArgumentTypes(Type[] arg_types) {
/* 250 */     if (arg_types.length == 0) {
/* 251 */       return "Type.NO_ARGS";
/*     */     }
/* 253 */     StringBuffer args = new StringBuffer();
/*     */     
/* 255 */     for (int i = 0; i < arg_types.length; i++) {
/* 256 */       args.append(printType(arg_types[i]));
/*     */       
/* 258 */       if (i < arg_types.length - 1) {
/* 259 */         args.append(", ");
/*     */       }
/*     */     } 
/* 262 */     return "new Type[] { " + args.toString() + " }";
/*     */   }
/*     */ 
/*     */   
/* 266 */   static String printType(Type type) { return printType(type.getSignature()); }
/*     */ 
/*     */   
/*     */   static String printType(String signature) {
/* 270 */     Type type = Type.getType(signature);
/* 271 */     byte t = type.getType();
/*     */     
/* 273 */     if (t <= 12)
/* 274 */       return "Type." + Constants.TYPE_NAMES[t].toUpperCase(); 
/* 275 */     if (type.toString().equals("java.lang.String"))
/* 276 */       return "Type.STRING"; 
/* 277 */     if (type.toString().equals("java.lang.Object"))
/* 278 */       return "Type.OBJECT"; 
/* 279 */     if (type.toString().equals("java.lang.StringBuffer"))
/* 280 */       return "Type.STRINGBUFFER"; 
/* 281 */     if (type instanceof ArrayType) {
/* 282 */       ArrayType at = (ArrayType)type;
/*     */       
/* 284 */       return "new ArrayType(" + printType(at.getBasicType()) + 
/* 285 */         ", " + at.getDimensions() + ")";
/*     */     } 
/* 287 */     return "new ObjectType(\"" + Utility.signatureToString(signature, false) + 
/* 288 */       "\")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] argv) throws Exception {
/* 296 */     String name = argv[0];
/*     */     JavaClass java_class;
/* 298 */     if ((java_class = Repository.lookupClass(name)) == null) {
/* 299 */       java_class = (new ClassParser(name)).parse();
/*     */     }
/* 301 */     BCELifier bcelifier = new BCELifier(java_class, System.out);
/* 302 */     bcelifier.start();
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bce\\util\BCELifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */