/*     */ package org.apache.bcel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ExceptionConstants
/*     */ {
/*  66 */   public static final Class THROWABLE = Throwable.class;
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final Class RUNTIME_EXCEPTION = RuntimeException.class;
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final Class LINKING_EXCEPTION = LinkageError.class;
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final Class CLASS_CIRCULARITY_ERROR = ClassCircularityError.class;
/*  79 */   public static final Class CLASS_FORMAT_ERROR = ClassFormatError.class;
/*  80 */   public static final Class EXCEPTION_IN_INITIALIZER_ERROR = ExceptionInInitializerError.class;
/*  81 */   public static final Class INCOMPATIBLE_CLASS_CHANGE_ERROR = IncompatibleClassChangeError.class;
/*  82 */   public static final Class ABSTRACT_METHOD_ERROR = AbstractMethodError.class;
/*  83 */   public static final Class ILLEGAL_ACCESS_ERROR = IllegalAccessError.class;
/*  84 */   public static final Class INSTANTIATION_ERROR = InstantiationError.class;
/*  85 */   public static final Class NO_SUCH_FIELD_ERROR = NoSuchFieldError.class;
/*  86 */   public static final Class NO_SUCH_METHOD_ERROR = NoSuchMethodError.class;
/*  87 */   public static final Class NO_CLASS_DEF_FOUND_ERROR = NoClassDefFoundError.class;
/*  88 */   public static final Class UNSATISFIED_LINK_ERROR = UnsatisfiedLinkError.class;
/*  89 */   public static final Class VERIFY_ERROR = VerifyError.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static final Class NULL_POINTER_EXCEPTION = NullPointerException.class;
/*  97 */   public static final Class ARRAY_INDEX_OUT_OF_BOUNDS_EXCEPTION = ArrayIndexOutOfBoundsException.class;
/*  98 */   public static final Class ARITHMETIC_EXCEPTION = ArithmeticException.class;
/*  99 */   public static final Class NEGATIVE_ARRAY_SIZE_EXCEPTION = NegativeArraySizeException.class;
/* 100 */   public static final Class CLASS_CAST_EXCEPTION = ClassCastException.class;
/* 101 */   public static final Class ILLEGAL_MONITOR_STATE = IllegalMonitorStateException.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final Class[] EXCS_CLASS_AND_INTERFACE_RESOLUTION = { NO_CLASS_DEF_FOUND_ERROR, CLASS_FORMAT_ERROR, VERIFY_ERROR, ABSTRACT_METHOD_ERROR, 
/* 108 */       EXCEPTION_IN_INITIALIZER_ERROR, ILLEGAL_ACCESS_ERROR };
/*     */ 
/*     */ 
/*     */   
/* 112 */   public static final Class[] EXCS_FIELD_AND_METHOD_RESOLUTION = { NO_SUCH_FIELD_ERROR, ILLEGAL_ACCESS_ERROR, NO_SUCH_METHOD_ERROR };
/*     */ 
/*     */   
/* 115 */   public static final Class[] EXCS_INTERFACE_METHOD_RESOLUTION = new Class[0];
/* 116 */   public static final Class[] EXCS_STRING_RESOLUTION = new Class[0];
/*     */ 
/*     */ 
/*     */   
/* 120 */   public static final Class[] EXCS_ARRAY_EXCEPTION = { NULL_POINTER_EXCEPTION, ARRAY_INDEX_OUT_OF_BOUNDS_EXCEPTION };
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\bcel\ExceptionConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */