/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullEnumeration
/*    */   implements Enumeration
/*    */ {
/* 30 */   private static final NullEnumeration instance = new NullEnumeration();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   public static NullEnumeration getInstance() { return instance; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public boolean hasMoreElements() { return false; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   public Object nextElement() { throw new NoSuchElementException(); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\helpers\NullEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */