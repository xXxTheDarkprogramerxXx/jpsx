/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.apache.log4j.spi.ErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyslogQuietWriter
/*    */   extends QuietWriter
/*    */ {
/*    */   int syslogFacility;
/*    */   int level;
/*    */   
/*    */   public SyslogQuietWriter(Writer writer, int syslogFacility, ErrorHandler eh) {
/* 37 */     super(writer, eh);
/* 38 */     this.syslogFacility = syslogFacility;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 43 */   public void setLevel(int level) { this.level = level; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public void setSyslogFacility(int syslogFacility) { this.syslogFacility = syslogFacility; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public void write(String string) { super.write("<" + (this.syslogFacility | this.level) + ">" + string); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\helpers\SyslogQuietWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */