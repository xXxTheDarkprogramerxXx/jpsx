/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.log4j.spi.ErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountingQuietWriter
/*    */   extends QuietWriter
/*    */ {
/*    */   protected long count;
/*    */   
/* 38 */   public CountingQuietWriter(Writer writer, ErrorHandler eh) { super(writer, eh); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(String string) {
/*    */     try {
/* 44 */       this.out.write(string);
/* 45 */       this.count += string.length();
/*    */     } catch (IOException e) {
/*    */       
/* 48 */       this.errorHandler.error("Write failure.", e, 1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 54 */   public long getCount() { return this.count; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   public void setCount(long count) { this.count = count; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\helpers\CountingQuietWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */