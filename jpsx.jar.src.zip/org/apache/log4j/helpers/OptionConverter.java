/*     */ package org.apache.log4j.helpers;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import org.apache.log4j.spi.Configurator;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionConverter
/*     */ {
/*  39 */   static String DELIM_START = "${";
/*  40 */   static char DELIM_STOP = '}';
/*  41 */   static int DELIM_START_LEN = 2;
/*  42 */   static int DELIM_STOP_LEN = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] concatanateArrays(String[] l, String[] r) {
/*  50 */     int len = l.length + r.length;
/*  51 */     String[] a = new String[len];
/*     */     
/*  53 */     System.arraycopy(l, 0, a, 0, l.length);
/*  54 */     System.arraycopy(r, 0, a, l.length, r.length);
/*     */     
/*  56 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertSpecialChars(String s) {
/*  63 */     int len = s.length();
/*  64 */     StringBuffer sbuf = new StringBuffer(len);
/*     */     
/*  66 */     int i = 0;
/*  67 */     while (i < len) {
/*  68 */       char c = s.charAt(i++);
/*  69 */       if (c == '\\') {
/*  70 */         c = s.charAt(i++);
/*  71 */         if (c == 'n') { c = '\n'; }
/*  72 */         else if (c == 'r') { c = '\r'; }
/*  73 */         else if (c == 't') { c = '\t'; }
/*  74 */         else if (c == 'f') { c = '\f'; }
/*  75 */         else if (c == '\b') { c = '\b'; }
/*  76 */         else if (c == '"') { c = '"'; }
/*  77 */         else if (c == '\'') { c = '\''; }
/*  78 */         else if (c == '\\') { c = '\\'; }
/*     */       
/*  80 */       }  sbuf.append(c);
/*     */     } 
/*  82 */     return sbuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSystemProperty(String key, String def) {
/*     */     try {
/* 100 */       return System.getProperty(key, def);
/*     */     } catch (Throwable e) {
/* 102 */       LogLog.debug("Was not allowed to read system property \"" + key + "\".");
/* 103 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object instantiateByKey(Properties props, String key, Class superClass, Object defaultValue) {
/* 114 */     String className = findAndSubst(key, props);
/* 115 */     if (className == null) {
/* 116 */       LogLog.error("Could not find value for key " + key);
/* 117 */       return defaultValue;
/*     */     } 
/*     */     
/* 120 */     return instantiateByClassName(className.trim(), superClass, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(String value, boolean dEfault) {
/* 134 */     if (value == null)
/* 135 */       return dEfault; 
/* 136 */     String trimmedVal = value.trim();
/* 137 */     if ("true".equalsIgnoreCase(trimmedVal))
/* 138 */       return true; 
/* 139 */     if ("false".equalsIgnoreCase(trimmedVal))
/* 140 */       return false; 
/* 141 */     return dEfault;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt(String value, int dEfault) {
/* 147 */     if (value != null) {
/* 148 */       String s = value.trim();
/*     */       try {
/* 150 */         return Integer.valueOf(s).intValue();
/*     */       } catch (NumberFormatException e) {
/*     */         
/* 153 */         LogLog.error("[" + s + "] is not in proper int form.");
/* 154 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/* 157 */     return dEfault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(String value, Level defaultValue) {
/* 183 */     if (value == null) {
/* 184 */       return defaultValue;
/*     */     }
/* 186 */     int hashIndex = value.indexOf('#');
/* 187 */     if (hashIndex == -1) {
/* 188 */       if ("NULL".equalsIgnoreCase(value)) {
/* 189 */         return null;
/*     */       }
/*     */       
/* 192 */       return Level.toLevel(value, defaultValue);
/*     */     } 
/*     */ 
/*     */     
/* 196 */     Level result = defaultValue;
/*     */     
/* 198 */     String clazz = value.substring(hashIndex + 1);
/* 199 */     String levelName = value.substring(0, hashIndex);
/*     */ 
/*     */     
/* 202 */     if ("NULL".equalsIgnoreCase(levelName)) {
/* 203 */       return null;
/*     */     }
/*     */     
/* 206 */     LogLog.debug("toLevel:class=[" + clazz + "]" + ":pri=[" + levelName + "]");
/*     */ 
/*     */     
/*     */     try {
/* 210 */       Class customLevel = Loader.loadClass(clazz);
/*     */ 
/*     */ 
/*     */       
/* 214 */       Class[] paramTypes = { String.class, Level.class };
/*     */ 
/*     */       
/* 217 */       Method toLevelMethod = customLevel.getMethod("toLevel", paramTypes);
/*     */ 
/*     */ 
/*     */       
/* 221 */       Object[] params = { levelName, defaultValue };
/* 222 */       Object o = toLevelMethod.invoke(null, params);
/*     */       
/* 224 */       result = (Level)o;
/*     */     } catch (ClassNotFoundException e) {
/* 226 */       LogLog.warn("custom level class [" + clazz + "] not found.");
/*     */     } catch (NoSuchMethodException e) {
/* 228 */       LogLog.warn("custom level class [" + clazz + "]" + " does not have a constructor which takes one string parameter", e);
/*     */     } catch (InvocationTargetException e) {
/*     */       
/* 231 */       LogLog.warn("custom level class [" + clazz + "]" + " could not be instantiated", e);
/*     */     } catch (ClassCastException e) {
/*     */       
/* 234 */       LogLog.warn("class [" + clazz + "] is not a subclass of org.apache.log4j.Level", e);
/*     */     } catch (IllegalAccessException e) {
/*     */       
/* 237 */       LogLog.warn("class [" + clazz + "] cannot be instantiated due to access restrictions", e);
/*     */     } catch (Exception e) {
/*     */       
/* 240 */       LogLog.warn("class [" + clazz + "], level [" + levelName + "] conversion failed.", e);
/*     */     } 
/*     */     
/* 243 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toFileSize(String value, long dEfault) {
/* 249 */     if (value == null) {
/* 250 */       return dEfault;
/*     */     }
/* 252 */     String s = value.trim().toUpperCase();
/* 253 */     long multiplier = 1L;
/*     */     
/*     */     int index;
/* 256 */     if ((index = s.indexOf("KB")) != -1) {
/* 257 */       multiplier = 1024L;
/* 258 */       s = s.substring(0, index);
/*     */     }
/* 260 */     else if ((index = s.indexOf("MB")) != -1) {
/* 261 */       multiplier = 1048576L;
/* 262 */       s = s.substring(0, index);
/*     */     }
/* 264 */     else if ((index = s.indexOf("GB")) != -1) {
/* 265 */       multiplier = 1073741824L;
/* 266 */       s = s.substring(0, index);
/*     */     } 
/* 268 */     if (s != null) {
/*     */       try {
/* 270 */         return Long.valueOf(s).longValue() * multiplier;
/*     */       } catch (NumberFormatException e) {
/*     */         
/* 273 */         LogLog.error("[" + s + "] is not in proper int form.");
/* 274 */         LogLog.error("[" + value + "] not in expected format.", e);
/*     */       } 
/*     */     }
/* 277 */     return dEfault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String findAndSubst(String key, Properties props) {
/* 289 */     String value = props.getProperty(key);
/* 290 */     if (value == null) {
/* 291 */       return null;
/*     */     }
/*     */     try {
/* 294 */       return substVars(value, props);
/*     */     } catch (IllegalArgumentException e) {
/* 296 */       LogLog.error("Bad option value [" + value + "].", e);
/* 297 */       return value;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object instantiateByClassName(String className, Class superClass, Object defaultValue) {
/* 315 */     if (className != null) {
/*     */       try {
/* 317 */         Class classObj = Loader.loadClass(className);
/* 318 */         if (!superClass.isAssignableFrom(classObj)) {
/* 319 */           LogLog.error("A \"" + className + "\" object is not assignable to a \"" + superClass.getName() + "\" variable.");
/*     */           
/* 321 */           LogLog.error("The class \"" + superClass.getName() + "\" was loaded by ");
/* 322 */           LogLog.error("[" + superClass.getClassLoader() + "] whereas object of type ");
/* 323 */           LogLog.error("\"" + classObj.getName() + "\" was loaded by [" + classObj.getClassLoader() + "].");
/*     */           
/* 325 */           return defaultValue;
/*     */         } 
/* 327 */         return classObj.newInstance();
/*     */       } catch (Exception e) {
/* 329 */         LogLog.error("Could not instantiate class [" + className + "].", e);
/*     */       } 
/*     */     }
/* 332 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String substVars(String val, Properties props) {
/* 376 */     StringBuffer sbuf = new StringBuffer();
/*     */     
/* 378 */     int i = 0;
/*     */ 
/*     */     
/*     */     while (true) {
/* 382 */       int j = val.indexOf(DELIM_START, i);
/* 383 */       if (j == -1) {
/*     */         
/* 385 */         if (i == 0) {
/* 386 */           return val;
/*     */         }
/* 388 */         sbuf.append(val.substring(i, val.length()));
/* 389 */         return sbuf.toString();
/*     */       } 
/*     */       
/* 392 */       sbuf.append(val.substring(i, j));
/* 393 */       int k = val.indexOf(DELIM_STOP, j);
/* 394 */       if (k == -1) {
/* 395 */         throw new IllegalArgumentException('"' + val + "\" has no closing brace. Opening brace at position " + j + '.');
/*     */       }
/*     */ 
/*     */       
/* 399 */       j += DELIM_START_LEN;
/* 400 */       String key = val.substring(j, k);
/*     */       
/* 402 */       String replacement = getSystemProperty(key, null);
/*     */       
/* 404 */       if (replacement == null && props != null) {
/* 405 */         replacement = props.getProperty(key);
/*     */       }
/*     */       
/* 408 */       if (replacement != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 414 */         String recursiveReplacement = substVars(replacement, props);
/* 415 */         sbuf.append(recursiveReplacement);
/*     */       } 
/* 417 */       i = k + DELIM_STOP_LEN;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void selectAndConfigure(URL url, String clazz, LoggerRepository hierarchy) {
/* 448 */     PropertyConfigurator propertyConfigurator = null;
/* 449 */     String filename = url.getFile();
/*     */     
/* 451 */     if (clazz == null && filename != null && filename.endsWith(".xml")) {
/* 452 */       clazz = "org.apache.log4j.xml.DOMConfigurator";
/*     */     }
/*     */     
/* 455 */     if (clazz != null) {
/* 456 */       LogLog.debug("Preferred configurator class: " + clazz);
/* 457 */       propertyConfigurator = (Configurator)instantiateByClassName(clazz, Configurator.class, null);
/*     */ 
/*     */       
/* 460 */       if (propertyConfigurator == null) {
/* 461 */         LogLog.error("Could not instantiate configurator [" + clazz + "].");
/*     */         return;
/*     */       } 
/*     */     } else {
/* 465 */       propertyConfigurator = new PropertyConfigurator();
/*     */     } 
/*     */     
/* 468 */     propertyConfigurator.doConfigure(url, hierarchy);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\helpers\OptionConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */