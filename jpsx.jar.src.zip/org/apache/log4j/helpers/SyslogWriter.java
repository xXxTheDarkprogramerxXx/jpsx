/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.net.DatagramPacket;
/*    */ import java.net.DatagramSocket;
/*    */ import java.net.InetAddress;
/*    */ import java.net.SocketException;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyslogWriter
/*    */   extends Writer
/*    */ {
/*    */   final int SYSLOG_PORT = 514;
/*    */   static String syslogHost;
/*    */   private InetAddress address;
/*    */   private DatagramSocket ds;
/*    */   
/*    */   public SyslogWriter(String syslogHost) {
/* 36 */     this.SYSLOG_PORT = 514;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     SyslogWriter.syslogHost = syslogHost;
/*    */     
/*    */     try {
/* 47 */       this.address = InetAddress.getByName(syslogHost);
/*    */     } catch (UnknownHostException e) {
/*    */       
/* 50 */       LogLog.error("Could not find " + syslogHost + ". All logging will FAIL.", e);
/*    */     } 
/*    */ 
/*    */     
/*    */     try {
/* 55 */       this.ds = new DatagramSocket();
/*    */     } catch (SocketException e) {
/*    */       
/* 58 */       e.printStackTrace();
/* 59 */       LogLog.error("Could not instantiate DatagramSocket to " + syslogHost + ". All logging will FAIL.", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   public void write(char[] buf, int off, int len) throws IOException { write(new String(buf, off, len)); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(String string) {
/* 72 */     byte[] bytes = string.getBytes();
/* 73 */     DatagramPacket packet = new DatagramPacket(bytes, bytes.length, this.address, 'Ȃ');
/*    */ 
/*    */     
/* 76 */     if (this.ds != null)
/* 77 */       this.ds.send(packet); 
/*    */   }
/*    */   
/*    */   public void flush() {}
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\helpers\SyslogWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */