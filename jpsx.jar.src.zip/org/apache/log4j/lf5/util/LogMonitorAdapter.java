/*     */ package org.apache.log4j.lf5.util;
/*     */ 
/*     */ import java.awt.Toolkit;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.lf5.LogLevel;
/*     */ import org.apache.log4j.lf5.LogRecord;
/*     */ import org.apache.log4j.lf5.viewer.LogBrokerMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogMonitorAdapter
/*     */ {
/*     */   public static final int LOG4J_LOG_LEVELS = 0;
/*     */   public static final int JDK14_LOG_LEVELS = 1;
/*     */   private LogBrokerMonitor _logMonitor;
/*     */   private LogLevel _defaultLevel;
/*     */   
/*     */   private LogMonitorAdapter(List userDefinedLevels) {
/*  48 */     this._defaultLevel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     this._defaultLevel = (LogLevel)userDefinedLevels.get(0);
/*  57 */     this._logMonitor = new LogBrokerMonitor(userDefinedLevels);
/*     */     
/*  59 */     this._logMonitor.setFrameSize(getDefaultMonitorWidth(), getDefaultMonitorHeight());
/*     */     
/*  61 */     this._logMonitor.setFontSize(12);
/*  62 */     this._logMonitor.show();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LogMonitorAdapter newInstance(int loglevels) {
/*     */     LogMonitorAdapter logMonitorAdapter;
/*  77 */     if (loglevels == 1) {
/*  78 */       logMonitorAdapter = newInstance(LogLevel.getJdk14Levels());
/*  79 */       logMonitorAdapter.setDefaultLevel(LogLevel.FINEST);
/*  80 */       logMonitorAdapter.setSevereLevel(LogLevel.SEVERE);
/*     */     } else {
/*  82 */       logMonitorAdapter = newInstance(LogLevel.getLog4JLevels());
/*  83 */       logMonitorAdapter.setDefaultLevel(LogLevel.DEBUG);
/*  84 */       logMonitorAdapter.setSevereLevel(LogLevel.FATAL);
/*     */     } 
/*  86 */     return logMonitorAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LogMonitorAdapter newInstance(LogLevel[] userDefined) {
/*  98 */     if (userDefined == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return newInstance(Arrays.asList(userDefined));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static LogMonitorAdapter newInstance(List userDefinedLevels) { return new LogMonitorAdapter(userDefinedLevels); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public void addMessage(LogRecord record) { this._logMonitor.addMessage(record); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public void setMaxNumberOfRecords(int maxNumberOfRecords) { this._logMonitor.setMaxNumberOfLogRecords(maxNumberOfRecords); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public void setDefaultLevel(LogLevel level) { this._defaultLevel = level; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public LogLevel getDefaultLevel() { return this._defaultLevel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public void setSevereLevel(LogLevel level) { AdapterLogRecord.setSevereLevel(level); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public LogLevel getSevereLevel() { return AdapterLogRecord.getSevereLevel(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String category, LogLevel level, String message, Throwable t, String NDC) {
/* 183 */     AdapterLogRecord record = new AdapterLogRecord();
/* 184 */     record.setCategory(category);
/* 185 */     record.setMessage(message);
/* 186 */     record.setNDC(NDC);
/* 187 */     record.setThrown(t);
/*     */     
/* 189 */     if (level == null) {
/* 190 */       record.setLevel(getDefaultLevel());
/*     */     } else {
/* 192 */       record.setLevel(level);
/*     */     } 
/*     */     
/* 195 */     addMessage(record);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public void log(String category, String message) { log(category, null, message); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public void log(String category, LogLevel level, String message, String NDC) { log(category, level, message, null, NDC); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 230 */   public void log(String category, LogLevel level, String message, Throwable t) { log(category, level, message, t, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public void log(String category, LogLevel level, String message) { log(category, level, message, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getScreenWidth() {
/*     */     try {
/* 254 */       return (Toolkit.getDefaultToolkit().getScreenSize()).width;
/*     */     } catch (Throwable t) {
/* 256 */       return 800;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getScreenHeight() {
/*     */     try {
/* 267 */       return (Toolkit.getDefaultToolkit().getScreenSize()).height;
/*     */     } catch (Throwable t) {
/* 269 */       return 600;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 274 */   protected static int getDefaultMonitorWidth() { return 3 * getScreenWidth() / 4; }
/*     */ 
/*     */ 
/*     */   
/* 278 */   protected static int getDefaultMonitorHeight() { return 3 * getScreenHeight() / 4; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\lf\\util\LogMonitorAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */