/*     */ package org.apache.log4j.lf5.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import org.apache.log4j.lf5.LogLevel;
/*     */ import org.apache.log4j.lf5.LogRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdapterLogRecord
/*     */   extends LogRecord
/*     */ {
/*  44 */   private static LogLevel severeLevel = null;
/*     */   
/*  46 */   private static StringWriter sw = new StringWriter();
/*  47 */   private static PrintWriter pw = new PrintWriter(sw);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCategory(String category) {
/*  60 */     super.setCategory(category);
/*  61 */     setLocation(getLocationInfo(category));
/*     */   }
/*     */   
/*     */   public boolean isSevereLevel() {
/*  65 */     if (severeLevel == null) return false; 
/*  66 */     return severeLevel.equals(getLevel());
/*     */   }
/*     */ 
/*     */   
/*  70 */   public static void setSevereLevel(LogLevel level) { severeLevel = level; }
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static LogLevel getSevereLevel() { return severeLevel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getLocationInfo(String category) {
/*  81 */     String stackTrace = stackTraceToString(new Throwable());
/*  82 */     return parseLine(stackTrace, category);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String stackTraceToString(Throwable t) {
/*  87 */     String s = null;
/*     */     
/*  89 */     synchronized (sw) {
/*  90 */       t.printStackTrace(pw);
/*  91 */       s = sw.toString();
/*  92 */       sw.getBuffer().setLength(0);
/*     */     } 
/*     */     
/*  95 */     return s;
/*     */   }
/*     */   
/*     */   protected String parseLine(String trace, String category) {
/*  99 */     int index = trace.indexOf(category);
/* 100 */     if (index == -1) return null; 
/* 101 */     trace = trace.substring(index);
/* 102 */     return trace.substring(0, trace.indexOf(")") + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\lf\\util\AdapterLogRecord.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */