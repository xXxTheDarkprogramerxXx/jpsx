package org.apache.log4j.jmx;

import java.lang.reflect.Method;

class MethodUnion {
  Method readMethod;
  
  Method writeMethod;
  
  MethodUnion(Method paramMethod1, Method paramMethod2) {
    this.readMethod = paramMethod1;
    this.writeMethod = paramMethod2;
  }
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\jmx\MethodUnion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */