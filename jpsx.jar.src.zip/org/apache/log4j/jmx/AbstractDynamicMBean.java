package org.apache.log4j.jmx;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.DynamicMBean;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanRegistration;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.RuntimeOperationsException;
import org.apache.log4j.Logger;

public abstract class AbstractDynamicMBean implements DynamicMBean, MBeanRegistration {
  String dClassName;
  
  MBeanServer server;
  
  public AttributeList getAttributes(String[] paramArrayOfString) {
    if (paramArrayOfString == null)
      throw new RuntimeOperationsException(new IllegalArgumentException("attributeNames[] cannot be null"), "Cannot invoke a getter of " + this.dClassName); 
    AttributeList attributeList = new AttributeList();
    if (paramArrayOfString.length == 0)
      return attributeList; 
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      try {
        Object object = getAttribute(paramArrayOfString[b]);
        attributeList.add(new Attribute(paramArrayOfString[b], object));
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
    return attributeList;
  }
  
  public AttributeList setAttributes(AttributeList paramAttributeList) {
    if (paramAttributeList == null)
      throw new RuntimeOperationsException(new IllegalArgumentException("AttributeList attributes cannot be null"), "Cannot invoke a setter of " + this.dClassName); 
    AttributeList attributeList = new AttributeList();
    if (paramAttributeList.isEmpty())
      return attributeList; 
    for (Attribute attribute : paramAttributeList) {
      try {
        setAttribute(attribute);
        String str = attribute.getName();
        Object object = getAttribute(str);
        attributeList.add(new Attribute(str, object));
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
    return attributeList;
  }
  
  protected abstract Logger getLogger();
  
  public void postDeregister() { getLogger().debug("postDeregister is called."); }
  
  public void postRegister(Boolean paramBoolean) {}
  
  public void preDeregister() { getLogger().debug("preDeregister called."); }
  
  public ObjectName preRegister(MBeanServer paramMBeanServer, ObjectName paramObjectName) {
    getLogger().debug("preRegister called. Server=" + paramMBeanServer + ", name=" + paramObjectName);
    this.server = paramMBeanServer;
    return paramObjectName;
  }
  
  public abstract MBeanInfo getMBeanInfo();
  
  public abstract Object invoke(String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString) throws MBeanException, ReflectionException;
  
  public abstract void setAttribute(Attribute paramAttribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException;
  
  public abstract Object getAttribute(String paramString) throws AttributeNotFoundException, MBeanException, ReflectionException;
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\jmx\AbstractDynamicMBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */