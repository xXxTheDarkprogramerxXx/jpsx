package org.apache.log4j.jmx;

import com.sun.jdmk.comm.HtmlAdaptorServer;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import org.apache.log4j.Logger;

public class Agent {
  static Logger log = Logger.getLogger(Agent.class);
  
  public void start() {
    MBeanServer mBeanServer = MBeanServerFactory.createMBeanServer();
    HtmlAdaptorServer htmlAdaptorServer = new HtmlAdaptorServer();
    try {
      log.info("Registering HtmlAdaptorServer instance.");
      mBeanServer.registerMBean(htmlAdaptorServer, new ObjectName("Adaptor:name=html,port=8082"));
      log.info("Registering HierarchyDynamicMBean instance.");
      HierarchyDynamicMBean hierarchyDynamicMBean = new HierarchyDynamicMBean();
      mBeanServer.registerMBean(hierarchyDynamicMBean, new ObjectName("log4j:hiearchy=default"));
    } catch (Exception exception) {
      log.error("Problem while regitering MBeans instances.", exception);
      return;
    } 
    htmlAdaptorServer.start();
  }
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\jmx\Agent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */