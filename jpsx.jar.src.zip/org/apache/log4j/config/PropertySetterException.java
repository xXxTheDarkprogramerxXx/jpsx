/*    */ package org.apache.log4j.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertySetterException
/*    */   extends Exception
/*    */ {
/*    */   protected Throwable rootCause;
/*    */   
/* 31 */   public PropertySetterException(String msg) { super(msg); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public PropertySetterException(Throwable rootCause) { this.rootCause = rootCause; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 46 */     String msg = super.getMessage();
/* 47 */     if (msg == null && this.rootCause != null) {
/* 48 */       msg = this.rootCause.getMessage();
/*    */     }
/* 50 */     return msg;
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\config\PropertySetterException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */