/*     */ package org.apache.log4j.chainsaw;
/*     */ 
/*     */ import org.apache.log4j.Priority;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EventDetails
/*     */ {
/*     */   private final long mTimeStamp;
/*     */   private final Priority mPriority;
/*     */   private final String mCategoryName;
/*     */   private final String mNDC;
/*     */   private final String mThreadName;
/*     */   private final String mMessage;
/*     */   private final String[] mThrowableStrRep;
/*     */   private final String mLocationDetails;
/*     */   
/*     */   EventDetails(long aTimeStamp, Priority aPriority, String aCategoryName, String aNDC, String aThreadName, String aMessage, String[] aThrowableStrRep, String aLocationDetails) {
/*  67 */     this.mTimeStamp = aTimeStamp;
/*  68 */     this.mPriority = aPriority;
/*  69 */     this.mCategoryName = aCategoryName;
/*  70 */     this.mNDC = aNDC;
/*  71 */     this.mThreadName = aThreadName;
/*  72 */     this.mMessage = aMessage;
/*  73 */     this.mThrowableStrRep = aThrowableStrRep;
/*  74 */     this.mLocationDetails = aLocationDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   EventDetails(LoggingEvent aEvent) { this(aEvent.timeStamp, aEvent.getLevel(), aEvent.getLoggerName(), aEvent.getNDC(), aEvent.getThreadName(), aEvent.getRenderedMessage(), aEvent.getThrowableStrRep(), (aEvent.getLocationInformation() == null) ? null : (aEvent.getLocationInformation()).fullInfo); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   long getTimeStamp() { return this.mTimeStamp; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   Priority getPriority() { return this.mPriority; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   String getCategoryName() { return this.mCategoryName; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   String getNDC() { return this.mNDC; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   String getThreadName() { return this.mThreadName; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   String getMessage() { return this.mMessage; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   String getLocationDetails() { return this.mLocationDetails; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   String[] getThrowableStrRep() { return this.mThrowableStrRep; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\chainsaw\EventDetails.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */