/*     */ package org.apache.log4j.chainsaw;
/*     */ 
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ControlPanel
/*     */   extends JPanel
/*     */ {
/*  40 */   private static final Logger LOG = Logger.getLogger(ControlPanel.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ControlPanel(MyTableModel aModel) {
/*  49 */     setBorder(BorderFactory.createTitledBorder("Controls: "));
/*  50 */     GridBagLayout gridbag = new GridBagLayout();
/*  51 */     GridBagConstraints c = new GridBagConstraints();
/*  52 */     setLayout(gridbag);
/*     */ 
/*     */     
/*  55 */     c.ipadx = 5;
/*  56 */     c.ipady = 5;
/*     */ 
/*     */     
/*  59 */     c.gridx = 0;
/*  60 */     c.anchor = 13;
/*     */     
/*  62 */     c.gridy = 0;
/*  63 */     JLabel label = new JLabel("Filter Level:");
/*  64 */     gridbag.setConstraints(label, c);
/*  65 */     add(label);
/*     */     
/*  67 */     c.gridy++;
/*  68 */     label = new JLabel("Filter Thread:");
/*  69 */     gridbag.setConstraints(label, c);
/*  70 */     add(label);
/*     */     
/*  72 */     c.gridy++;
/*  73 */     label = new JLabel("Filter Logger:");
/*  74 */     gridbag.setConstraints(label, c);
/*  75 */     add(label);
/*     */     
/*  77 */     c.gridy++;
/*  78 */     label = new JLabel("Filter NDC:");
/*  79 */     gridbag.setConstraints(label, c);
/*  80 */     add(label);
/*     */     
/*  82 */     c.gridy++;
/*  83 */     label = new JLabel("Filter Message:");
/*  84 */     gridbag.setConstraints(label, c);
/*  85 */     add(label);
/*     */ 
/*     */     
/*  88 */     c.weightx = 1.0D;
/*     */     
/*  90 */     c.gridx = 1;
/*  91 */     c.anchor = 17;
/*     */     
/*  93 */     c.gridy = 0;
/*  94 */     Priority[] allPriorities = Priority.getAllPossiblePriorities();
/*  95 */     JComboBox priorities = new JComboBox(allPriorities);
/*  96 */     Priority lowest = allPriorities[allPriorities.length - 1];
/*  97 */     priorities.setSelectedItem(lowest);
/*  98 */     aModel.setPriorityFilter(lowest);
/*  99 */     gridbag.setConstraints(priorities, c);
/* 100 */     add(priorities);
/* 101 */     priorities.setEditable(false);
/* 102 */     priorities.addActionListener(new ActionListener(this, aModel, priorities) { private final MyTableModel val$aModel; private final JComboBox val$priorities; private final ControlPanel this$0;
/*     */           
/* 104 */           public void actionPerformed(ActionEvent aEvent) { this.val$aModel.setPriorityFilter((Priority)this.val$priorities.getSelectedItem()); }
/*     */            }
/*     */       );
/*     */ 
/*     */ 
/*     */     
/* 110 */     c.fill = 2;
/* 111 */     c.gridy++;
/* 112 */     JTextField threadField = new JTextField("");
/* 113 */     threadField.getDocument().addDocumentListener(new DocumentListener(this, aModel, threadField) { private final MyTableModel val$aModel; private final JTextField val$threadField; private final ControlPanel this$0;
/*     */           
/* 115 */           public void insertUpdate(DocumentEvent aEvent) { this.val$aModel.setThreadFilter(this.val$threadField.getText()); }
/*     */ 
/*     */           
/* 118 */           public void removeUpdate(DocumentEvent aEvente) { this.val$aModel.setThreadFilter(this.val$threadField.getText()); }
/*     */           
/*     */           public void changedUpdate(DocumentEvent aEvent) {
/* 121 */             this.val$aModel.setThreadFilter(this.val$threadField.getText());
/*     */           } }
/*     */       );
/* 124 */     gridbag.setConstraints(threadField, c);
/* 125 */     add(threadField);
/*     */     
/* 127 */     c.gridy++;
/* 128 */     JTextField catField = new JTextField("");
/* 129 */     catField.getDocument().addDocumentListener(new DocumentListener(this, aModel, catField) { private final MyTableModel val$aModel; private final JTextField val$catField; private final ControlPanel this$0;
/*     */           
/* 131 */           public void insertUpdate(DocumentEvent aEvent) { this.val$aModel.setCategoryFilter(this.val$catField.getText()); }
/*     */ 
/*     */           
/* 134 */           public void removeUpdate(DocumentEvent aEvent) { this.val$aModel.setCategoryFilter(this.val$catField.getText()); }
/*     */           
/*     */           public void changedUpdate(DocumentEvent aEvent) {
/* 137 */             this.val$aModel.setCategoryFilter(this.val$catField.getText());
/*     */           } }
/*     */       );
/* 140 */     gridbag.setConstraints(catField, c);
/* 141 */     add(catField);
/*     */     
/* 143 */     c.gridy++;
/* 144 */     JTextField ndcField = new JTextField("");
/* 145 */     ndcField.getDocument().addDocumentListener(new DocumentListener(this, aModel, ndcField) { private final MyTableModel val$aModel; private final JTextField val$ndcField; private final ControlPanel this$0;
/*     */           
/* 147 */           public void insertUpdate(DocumentEvent aEvent) { this.val$aModel.setNDCFilter(this.val$ndcField.getText()); }
/*     */ 
/*     */           
/* 150 */           public void removeUpdate(DocumentEvent aEvent) { this.val$aModel.setNDCFilter(this.val$ndcField.getText()); }
/*     */           
/*     */           public void changedUpdate(DocumentEvent aEvent) {
/* 153 */             this.val$aModel.setNDCFilter(this.val$ndcField.getText());
/*     */           } }
/*     */       );
/* 156 */     gridbag.setConstraints(ndcField, c);
/* 157 */     add(ndcField);
/*     */     
/* 159 */     c.gridy++;
/* 160 */     JTextField msgField = new JTextField("");
/* 161 */     msgField.getDocument().addDocumentListener(new DocumentListener(this, aModel, msgField) { private final MyTableModel val$aModel; private final JTextField val$msgField; private final ControlPanel this$0;
/*     */           
/* 163 */           public void insertUpdate(DocumentEvent aEvent) { this.val$aModel.setMessageFilter(this.val$msgField.getText()); }
/*     */ 
/*     */           
/* 166 */           public void removeUpdate(DocumentEvent aEvent) { this.val$aModel.setMessageFilter(this.val$msgField.getText()); }
/*     */           
/*     */           public void changedUpdate(DocumentEvent aEvent) {
/* 169 */             this.val$aModel.setMessageFilter(this.val$msgField.getText());
/*     */           } }
/*     */       );
/*     */ 
/*     */     
/* 174 */     gridbag.setConstraints(msgField, c);
/* 175 */     add(msgField);
/*     */ 
/*     */     
/* 178 */     c.weightx = 0.0D;
/* 179 */     c.fill = 2;
/* 180 */     c.anchor = 13;
/* 181 */     c.gridx = 2;
/*     */     
/* 183 */     c.gridy = 0;
/* 184 */     JButton exitButton = new JButton("Exit");
/* 185 */     exitButton.setMnemonic('x');
/* 186 */     exitButton.addActionListener(ExitAction.INSTANCE);
/* 187 */     gridbag.setConstraints(exitButton, c);
/* 188 */     add(exitButton);
/*     */     
/* 190 */     c.gridy++;
/* 191 */     JButton clearButton = new JButton("Clear");
/* 192 */     clearButton.setMnemonic('c');
/* 193 */     clearButton.addActionListener(new ActionListener(this, aModel) { private final MyTableModel val$aModel; private final ControlPanel this$0;
/*     */           
/* 195 */           public void actionPerformed(ActionEvent aEvent) { this.val$aModel.clear(); }
/*     */            }
/*     */       );
/* 198 */     gridbag.setConstraints(clearButton, c);
/* 199 */     add(clearButton);
/*     */     
/* 201 */     c.gridy++;
/* 202 */     JButton toggleButton = new JButton("Pause");
/* 203 */     toggleButton.setMnemonic('p');
/* 204 */     toggleButton.addActionListener(new ActionListener(this, aModel, toggleButton) { private final MyTableModel val$aModel;
/*     */           public void actionPerformed(ActionEvent aEvent) {
/* 206 */             this.val$aModel.toggle();
/* 207 */             this.val$toggleButton.setText(this.val$aModel.isPaused() ? "Resume" : "Pause");
/*     */           }
/*     */           private final JButton val$toggleButton; private final ControlPanel this$0; }
/*     */       );
/* 211 */     gridbag.setConstraints(toggleButton, c);
/* 212 */     add(toggleButton);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\org\apache\log4j\chainsaw\ControlPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.6
 */