package classes.api.org.jpsx.api;

public interface CPUControl {
  void go();
  
  void step();
  
  void pause();
  
  void addBreakpoint(int paramInt);
  
  void removeBreakpoint(int paramInt);
  
  int[] getBreakpoints();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\CPUControl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */