package classes.api.org.jpsx.api;

public interface CPUListener {
  void cpuResumed();
  
  void cpuPaused();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\CPUListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */