package classes.api.org.jpsx.api.components.core.addressspace;

import org.jpsx.api.components.core.addressspace.AddressSpace;

public interface AddressSpace {
  public static final int RAM_AND = 1610612735;
  
  public static final int SCRATCH_XOR = 528482304;
  
  public static final int BIOS_XOR = -1077936128;
  
  public static final int RAM_SIZE = 2097152;
  
  public static final int SCRATCH_BASE = 528482304;
  
  public static final int SCRATCH_SIZE = 4096;
  
  public static final int SCRATCH_END = 528486400;
  
  public static final int PAR_BASE = 520093696;
  
  public static final int PAR_SIZE = 65536;
  
  public static final int PAR_END = 520159232;
  
  public static final int HW_BASE = 528486400;
  
  public static final int HW_SIZE = 8192;
  
  public static final int HW_END = 528494592;
  
  public static final int BIOS_BASE = -1077936128;
  
  public static final int BIOS_SIZE = 524288;
  
  public static final int BIOS_END = -1077411840;
  
  public static final byte TAG_RAM = 1;
  
  public static final byte TAG_SCRATCH = 2;
  
  public static final byte TAG_HW = 4;
  
  public static final byte TAG_BIOS = 8;
  
  public static final byte TAG_PAR = 16;
  
  public static final byte TAG_POLL = 32;
  
  public static final byte TAG_RESERVED_FOR_COMPILER = 64;
  
  int internalRead32(int paramInt);
  
  void internalWrite32(int paramInt1, int paramInt2);
  
  int read8(int paramInt);
  
  int read16(int paramInt);
  
  int read32(int paramInt);
  
  void write8(int paramInt1, int paramInt2);
  
  void write16(int paramInt1, int paramInt2);
  
  void write32(int paramInt1, int paramInt2);
  
  void enableMemoryWrite(boolean paramBoolean);
  
  byte getTag(int paramInt);
  
  void orTag(int paramInt, byte paramByte);
  
  void resolve(int paramInt, ResolveResult paramResolveResult);
  
  void resolve(int paramInt1, int paramInt2, ResolveResult paramResolveResult);
  
  int[] getMainRAM();
  
  void tagAddressAccessWrite(int paramInt1, int paramInt2);
  
  void tagAddressAccessRead8(int paramInt1, int paramInt2);
  
  void tagAddressAccessRead16(int paramInt1, int paramInt2);
  
  void tagAddressAccessRead32(int paramInt1, int paramInt2);
  
  void tagClearPollCounters();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\addressspace\AddressSpace.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */