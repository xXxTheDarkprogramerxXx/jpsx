package classes.api.org.jpsx.api.components.core.cpu;

import org.jpsx.api.components.core.cpu.CPUInstruction;

public interface R3000 {
  public static final int R_SP = 29;
  
  public static final int R_RETADDR = 31;
  
  int getReg(int paramInt);
  
  void setReg(int paramInt1, int paramInt2);
  
  int getPC();
  
  int getLO();
  
  int getHI();
  
  void setPC(int paramInt);
  
  void setLO(int paramInt);
  
  void setHI(int paramInt);
  
  CPUInstruction decodeInstruction(int paramInt);
  
  String disassemble(int paramInt1, int paramInt2);
  
  boolean isExecutionThread();
  
  void setBreakout();
  
  void restoreInterpreterState();
  
  void interpreterBranch(int paramInt);
  
  void interpreterJump(int paramInt1, int paramInt2);
  
  void interpreterJumpAndLink(int paramInt1, int paramInt2, int paramInt3);
  
  void compilerInterrupted();
  
  int[] getInterpreterRegs();
  
  CPUInstruction getInvalidInstruction();
  
  void executeFromPC();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\R3000.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */