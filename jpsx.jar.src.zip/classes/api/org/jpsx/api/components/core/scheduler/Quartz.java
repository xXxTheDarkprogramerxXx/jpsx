package classes.api.org.jpsx.api.components.core.scheduler;

public interface Quartz {
  public static final long SEC = 1000000000L;
  
  public static final long MSEC = 1000000L;
  
  long nanoTime();
  
  long bestGranularity();
  
  long nanoTime(long paramLong);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\scheduler\Quartz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */