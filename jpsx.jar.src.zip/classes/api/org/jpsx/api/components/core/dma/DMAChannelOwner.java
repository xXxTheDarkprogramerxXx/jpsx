package classes.api.org.jpsx.api.components.core.dma;

import org.jpsx.api.components.core.dma.DMAController;

public interface DMAChannelOwner {
  void register(DMAController paramDMAController);
  
  String getName();
  
  int getDMAChannel();
  
  void beginDMATransferToDevice(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void beginDMATransferFromDevice(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void cancelDMATransfer(int paramInt);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\dma\DMAChannelOwner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */