package classes.api.org.jpsx.api.components.core.cpu;

public interface SCP {
  public static final int EXCEPT_INTERRUPT = 0;
  
  public static final int EXCEPT_TLB_MOD = 1;
  
  public static final int EXCEPT_TLB_REFILL_L = 2;
  
  public static final int EXCEPT_TLB_REFILL_S = 3;
  
  public static final int EXCEPT_ADDRESS_ERROR_L = 4;
  
  public static final int EXCEPT_ADDRESS_ERROR_S = 5;
  
  public static final int EXCEPT_BUS_ERROR_I = 6;
  
  public static final int EXCEPT_BUS_ERROR_D = 7;
  
  public static final int EXCEPT_SYSCALL = 8;
  
  public static final int EXCEPT_BREAKPOINT = 9;
  
  public static final int EXCEPT_RESERVED_INSTRUCTION = 10;
  
  public static final int EXCEPT_COPROCESSOR_UNUSABLE = 11;
  
  public static final int EXCEPT_OVERFLOW = 12;
  
  void setInterruptLine(int paramInt, boolean paramBoolean);
  
  void signalReservedInstructionException();
  
  void signalIntegerOverflowException();
  
  void signalBreakException();
  
  void signalSyscallException();
  
  void signalInterruptException();
  
  boolean shouldInterrupt();
  
  int currentExceptionType();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\SCP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */