/*     */ package classes.api.org.jpsx.api.components.core.cpu;
/*     */ 
/*     */ import org.apache.bcel.generic.InstructionList;
/*     */ import org.jpsx.api.components.core.cpu.CPUInstruction;
/*     */ import org.jpsx.api.components.core.cpu.CompilationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CPUInstruction
/*     */ {
/*     */   public static final int FLAG_BRANCH = 1;
/*     */   public static final int FLAG_UNCONDITIONAL = 2;
/*     */   public static final int FLAG_IMM_NEAR_TARGET = 4;
/*     */   public static final int FLAG_IMM_FAR_TARGET = 8;
/*     */   public static final int FLAG_LINK = 16;
/*     */   public static final int FLAG_SIMULATABLE = 32;
/*     */   public static final int FLAG_READS_RS = 256;
/*     */   public static final int FLAG_READS_RT = 512;
/*     */   public static final int FLAG_WRITES_RT = 1024;
/*     */   public static final int FLAG_WRITES_RD = 2048;
/*     */   public static final int FLAG_REQUIRES_COMPLETE_INTERPRETER_STATE = 262144;
/*     */   public static final int FLAG_MEM8 = 8192;
/*     */   public static final int FLAG_MEM16 = 16384;
/*     */   public static final int FLAG_MEM32 = 32768;
/*     */   public static final int FLAG_MEM = 57344;
/*     */   public static final int FLAG_REFERENCES_PC = 65536;
/*     */   public static final int FLAG_MAY_RESTORE_INTERPRETER_STATE = 131072;
/*     */   public static final int FLAG_MAY_SIGNAL_EXCEPTION = 131072;
/*     */   public static final int BRANCH_NEVER = 0;
/*     */   public static final int BRANCH_SOMETIMES = 1;
/*     */   public static final int BRANCH_ALWAYS = 2;
/*     */   private String name;
/*     */   private Class interpreterClass;
/*     */   private int flags;
/*     */   
/*     */   public CPUInstruction(String name, Class interpreterClass, int exceptions, int flags) {
/*  90 */     this.interpreterClass = interpreterClass;
/*  91 */     this.name = name;
/*  92 */     this.flags = flags;
/*     */   }
/*     */   
/*     */   public int getBranchType(int ci) {
/*  96 */     if (0 != (this.flags & true)) {
/*  97 */       if (0 != (this.flags & 0x2))
/*  98 */         return 2; 
/*  99 */       return 1;
/*     */     } 
/* 101 */     return 0;
/*     */   }
/*     */ 
/*     */   
/* 105 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public Class getInterpreterClass() { return this.interpreterClass; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public CPUInstruction subDecode(int ci) { return this; }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public final int getFlags() { return this.flags; }
/*     */ 
/*     */   
/*     */   public void compile(CompilationContext context, int address, int ci, InstructionList il) {
/* 121 */     if (0 != (getFlags() & true)) {
/* 122 */       throw new IllegalStateException("default compiler may not be used for branch instructions: " + getName());
/*     */     }
/* 124 */     context.emitInterpretedInstruction(il, ci, this.interpreterClass.getName(), getInterpretMethodName());
/*     */   }
/*     */ 
/*     */   
/* 128 */   public boolean simulate(int ci, int[] regs) { return false; }
/*     */ 
/*     */ 
/*     */   
/* 132 */   public String getInterpretMethodName() { return "interpret_" + getName(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\CPUInstruction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */