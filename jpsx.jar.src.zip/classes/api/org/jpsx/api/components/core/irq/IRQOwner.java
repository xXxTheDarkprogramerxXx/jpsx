package classes.api.org.jpsx.api.components.core.irq;

import org.jpsx.api.components.core.irq.IRQController;

public interface IRQOwner {
  void register(IRQController paramIRQController);
  
  int getIRQ();
  
  String getName();
  
  void raiseIRQ();
  
  void irqSet();
  
  void irqCleared();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\irq\IRQOwner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */