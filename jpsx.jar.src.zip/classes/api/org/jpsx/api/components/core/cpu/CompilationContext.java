package classes.api.org.jpsx.api.components.core.cpu;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.InstructionList;

public interface CompilationContext {
  int getRegValue(int paramInt);
  
  int getConstantRegs();
  
  int getWritesReg();
  
  int getReadsReg();
  
  ConstantPoolGen getConstantPoolGen();
  
  void emitInterpretedInstruction(InstructionList paramInstructionList, int paramInt, String paramString1, String paramString2);
  
  void emitGetReg(InstructionList paramInstructionList, int paramInt);
  
  void emitSetReg(InstructionList paramInstructionList, int paramInt);
  
  void emitCall(InstructionList paramInstructionList, int paramInt1, int paramInt2);
  
  void emitCall(InstructionList paramInstructionList, int paramInt);
  
  void emitJump(InstructionList paramInstructionList);
  
  void emitJump(InstructionList paramInstructionList, int paramInt);
  
  void emitReadMem8(InstructionList paramInstructionList, int paramInt, boolean paramBoolean);
  
  void emitReadMem8(InstructionList paramInstructionList, int paramInt1, int paramInt2);
  
  void emitReadMem16(InstructionList paramInstructionList, int paramInt, boolean paramBoolean);
  
  void emitReadMem16(InstructionList paramInstructionList, int paramInt1, int paramInt2);
  
  void emitReadMem32(InstructionList paramInstructionList, int paramInt, boolean paramBoolean);
  
  void emitReadMem32(InstructionList paramInstructionList, int paramInt1, int paramInt2, boolean paramBoolean);
  
  void emitWriteMem8(InstructionList paramInstructionList1, int paramInt, InstructionList paramInstructionList2);
  
  void emitWriteMem8(InstructionList paramInstructionList, int paramInt1, int paramInt2);
  
  void emitWriteMem16(InstructionList paramInstructionList1, int paramInt, InstructionList paramInstructionList2);
  
  void emitWriteMem16(InstructionList paramInstructionList, int paramInt1, int paramInt2);
  
  void emitWriteMem32(InstructionList paramInstructionList1, int paramInt, InstructionList paramInstructionList2, boolean paramBoolean);
  
  void emitWriteMem32(InstructionList paramInstructionList1, int paramInt1, int paramInt2, InstructionList paramInstructionList2, boolean paramBoolean);
  
  void emitDelaySlot(InstructionList paramInstructionList);
  
  int getTempLocal(int paramInt);
  
  InstructionHandle getBranchTarget(int paramInt);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\CompilationContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */