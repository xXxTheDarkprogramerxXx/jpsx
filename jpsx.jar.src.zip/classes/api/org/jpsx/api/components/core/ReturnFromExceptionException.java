/*    */ package classes.api.org.jpsx.api.components.core;
/*    */ 
/*    */ import org.jpsx.api.components.core.ReturnFromExceptionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReturnFromExceptionException
/*    */   extends RuntimeException
/*    */ {
/* 21 */   public static final ReturnFromExceptionException INSTANCE = new ReturnFromExceptionException();
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\ReturnFromExceptionException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */