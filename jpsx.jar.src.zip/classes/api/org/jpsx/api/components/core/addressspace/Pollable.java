package classes.api.org.jpsx.api.components.core.addressspace;

public interface Pollable {
  void poll(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\addressspace\Pollable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */