package classes.api.org.jpsx.api.components.core.addressspace;

import org.jpsx.api.InvalidConfigurationException;
import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;

public interface MemoryMapped {
  void registerAddresses(AddressSpaceRegistrar paramAddressSpaceRegistrar) throws InvalidConfigurationException;
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\addressspace\MemoryMapped.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */