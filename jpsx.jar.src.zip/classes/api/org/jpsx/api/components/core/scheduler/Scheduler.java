package classes.api.org.jpsx.api.components.core.scheduler;

import org.jpsx.api.components.core.scheduler.ScheduledAction;

public interface Scheduler {
  void schedule(long paramLong, ScheduledAction paramScheduledAction);
  
  void schedule(long paramLong1, long paramLong2, ScheduledAction paramScheduledAction);
  
  boolean isScheduled(ScheduledAction paramScheduledAction);
  
  void cpuThreadWait();
  
  void cpuThreadNotify();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\scheduler\Scheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */