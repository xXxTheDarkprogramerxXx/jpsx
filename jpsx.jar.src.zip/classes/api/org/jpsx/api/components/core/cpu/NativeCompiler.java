package classes.api.org.jpsx.api.components.core.cpu;

public interface NativeCompiler {
  boolean jumpAndLink(int paramInt1, int paramInt2);
  
  void clearCache();
  
  boolean exceptionInCompiler(Throwable paramThrowable);
  
  void interrupt();
  
  boolean addBreakpoint(int paramInt);
  
  void removeBreakpoint(int paramInt);
  
  void restoreInterpreterState();
  
  int getReg(int paramInt);
  
  void setReg(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\NativeCompiler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */