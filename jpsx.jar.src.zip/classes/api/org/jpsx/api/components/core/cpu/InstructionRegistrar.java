package classes.api.org.jpsx.api.components.core.cpu;

import org.jpsx.api.components.core.cpu.CPUInstruction;
import org.jpsx.api.components.core.cpu.CPUInstructionDisassembler;

public interface InstructionRegistrar {
  void setInstruction(int paramInt, CPUInstruction paramCPUInstruction);
  
  void setSPECIALInstruction(int paramInt, CPUInstruction paramCPUInstruction);
  
  void setREGIMMInstruction(int paramInt, CPUInstruction paramCPUInstruction);
  
  void setInstructionDisassembler(String paramString, CPUInstructionDisassembler paramCPUInstructionDisassembler);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\InstructionRegistrar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */