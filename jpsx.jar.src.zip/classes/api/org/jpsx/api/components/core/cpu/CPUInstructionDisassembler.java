package classes.api.org.jpsx.api.components.core.cpu;

import org.jpsx.api.components.core.cpu.CPUInstruction;

public interface CPUInstructionDisassembler {
  String disassemble(CPUInstruction paramCPUInstruction, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\cpu\CPUInstructionDisassembler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */