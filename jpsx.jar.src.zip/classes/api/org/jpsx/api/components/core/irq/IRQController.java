package classes.api.org.jpsx.api.components.core.irq;

import org.jpsx.api.components.core.irq.IRQOwner;

public interface IRQController {
  public static final int IRQ_VSYNC = 0;
  
  public static final int IRQ_GPU = 1;
  
  public static final int IRQ_CD = 2;
  
  public static final int IRQ_DMA = 3;
  
  public static final int IRQ_COUNTER0 = 4;
  
  public static final int IRQ_COUNTER1 = 5;
  
  public static final int IRQ_COUNTER2 = 6;
  
  public static final int IRQ_SIO0 = 7;
  
  void registerIRQOwner(IRQOwner paramIRQOwner);
  
  void raiseIRQ(int paramInt);
  
  int getIRQRequest();
  
  int getIRQMask();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\irq\IRQController.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */