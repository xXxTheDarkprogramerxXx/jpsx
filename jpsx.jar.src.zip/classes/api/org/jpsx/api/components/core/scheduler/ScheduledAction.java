package classes.api.org.jpsx.api.components.core.scheduler;

public interface ScheduledAction {
  long run(long paramLong);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\scheduler\ScheduledAction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */