package classes.api.org.jpsx.api.components.core.dma;

import org.jpsx.api.components.core.dma.DMAChannelOwner;

public interface DMAController {
  public static final int DMA_MDEC_IN = 0;
  
  public static final int DMA_MDEC_OUT = 1;
  
  public static final int DMA_GPU = 2;
  
  public static final int DMA_CD = 3;
  
  public static final int DMA_SPU = 4;
  
  public static final int DMA_GPU_OTC = 6;
  
  void registerDMAChannel(DMAChannelOwner paramDMAChannelOwner);
  
  void dmaChannelTransferComplete(DMAChannelOwner paramDMAChannelOwner);
  
  void dmaChannelTransferComplete(DMAChannelOwner paramDMAChannelOwner, boolean paramBoolean);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\dma\DMAController.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */