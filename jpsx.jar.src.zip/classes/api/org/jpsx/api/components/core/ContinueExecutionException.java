/*    */ package classes.api.org.jpsx.api.components.core;
/*    */ 
/*    */ import org.jpsx.api.components.core.ContinueExecutionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContinueExecutionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private boolean skipCurrentInstruction;
/* 23 */   public static ContinueExecutionException SKIP_CURRENT = new ContinueExecutionException(true);
/* 24 */   public static ContinueExecutionException DONT_SKIP_CURRENT = new ContinueExecutionException(false);
/*    */ 
/*    */   
/* 27 */   public ContinueExecutionException() { this(false); }
/*    */ 
/*    */ 
/*    */   
/* 31 */   public ContinueExecutionException(boolean skipCurrentInstruction) { this.skipCurrentInstruction = skipCurrentInstruction; }
/*    */ 
/*    */ 
/*    */   
/* 35 */   public boolean skipCurrentInstruction() { return this.skipCurrentInstruction; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\ContinueExecutionException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */