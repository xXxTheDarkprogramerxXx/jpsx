package classes.api.org.jpsx.api.components.core.addressspace;

import org.jpsx.api.components.core.addressspace.Pollable;

public interface AddressSpaceRegistrar {
  void registerRead8Callback(int paramInt, Class paramClass, String paramString);
  
  void registerRead16Callback(int paramInt, Class paramClass, String paramString);
  
  void registerRead16Callback(int paramInt, Class paramClass, String paramString, boolean paramBoolean);
  
  void registerRead32Callback(int paramInt, Class paramClass, String paramString, boolean paramBoolean);
  
  void registerRead32Callback(int paramInt, Class paramClass, String paramString);
  
  void registerWrite8Callback(int paramInt, Class paramClass, String paramString);
  
  void registerWrite16Callback(int paramInt, Class paramClass, String paramString);
  
  void registerWrite16Callback(int paramInt, Class paramClass, String paramString, boolean paramBoolean);
  
  void registerWrite32Callback(int paramInt, Class paramClass, String paramString);
  
  void registerWrite32Callback(int paramInt, Class paramClass, String paramString, boolean paramBoolean);
  
  void registerPoll32Callback(int paramInt, Pollable paramPollable);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\core\addressspace\AddressSpaceRegistrar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */