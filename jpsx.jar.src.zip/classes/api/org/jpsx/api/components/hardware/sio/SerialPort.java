package classes.api.org.jpsx.api.components.hardware.sio;

import org.jpsx.api.components.hardware.sio.SerialDevice;

public interface SerialPort {
  void connect(SerialDevice paramSerialDevice);
  
  void disconnect();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\sio\SerialPort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */