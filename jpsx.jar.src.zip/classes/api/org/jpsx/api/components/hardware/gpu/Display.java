package classes.api.org.jpsx.api.components.hardware.gpu;

public interface Display {
  void initDisplay();
  
  int[] acquireDisplayBuffer();
  
  void releaseDisplayBuffer();
  
  void refresh();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\gpu\Display.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */