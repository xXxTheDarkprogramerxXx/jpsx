/*    */ package classes.api.org.jpsx.api.components.hardware.cd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaException
/*    */   extends Exception
/*    */ {
/* 22 */   public MediaException(String message) { super(message); }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public MediaException(String message, Throwable cause) { super(message, cause); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\cd\MediaException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */