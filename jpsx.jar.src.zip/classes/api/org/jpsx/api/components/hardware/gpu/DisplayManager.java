package classes.api.org.jpsx.api.components.hardware.gpu;

public interface DisplayManager {
  boolean getInterlaceField();
  
  boolean getNTSC();
  
  boolean getInterlaced();
  
  boolean getDoubleY();
  
  boolean getRGB24();
  
  boolean getBlanked();
  
  int getDefaultPixelWidth();
  
  int getDefaultPixelHeight();
  
  int getPixelWidth();
  
  int getPixelHeight();
  
  int getXOrigin();
  
  int getYOrigin();
  
  int getLeftMarginPixels();
  
  int getRightMarginPixels();
  
  int getTopMarginPixels();
  
  int getBottomMarginPixels();
  
  void preAsync();
  
  void vsync();
  
  void setOrigin(int paramInt1, int paramInt2);
  
  void toggleInterlaceField();
  
  void dirtyRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void setPixelDivider(int paramInt);
  
  void setNTSC(boolean paramBoolean);
  
  void setInterlaced(boolean paramBoolean);
  
  void setDoubleY(boolean paramBoolean);
  
  void setRGB24(boolean paramBoolean);
  
  void setBlanked(boolean paramBoolean);
  
  void setHorizontalTiming(int paramInt1, int paramInt2);
  
  void setVerticalTiming(int paramInt1, int paramInt2);
  
  int getDefaultTimingWidth();
  
  int getDefaultTimingHeight();
  
  int getLeftMargin();
  
  int getRightMargin();
  
  int getTopMargin();
  
  int getBottomMargin();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\gpu\DisplayManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */