package classes.api.org.jpsx.api.components.hardware.cd;

import org.jpsx.api.components.hardware.cd.CDMedia;

public interface CDDrive {
  CDMedia getCurrentMedia();
  
  void refreshMedia();
  
  boolean isDriveOpen();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\cd\CDDrive.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */