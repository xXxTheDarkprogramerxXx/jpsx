package classes.api.org.jpsx.api.components.hardware.cd;

public interface CDAudioSink {
  int getCDAudioLatency();
  
  void setCDAudioRate(int paramInt);
  
  void newCDAudio();
  
  boolean cdAudioData(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  void setExternalCDAudioVolumeLeft(int paramInt);
  
  void setExternalCDAudioVolumeRight(int paramInt);
  
  boolean isCDAudible();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\cd\CDAudioSink.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */