package classes.api.org.jpsx.api.components.hardware.cd;

import org.jpsx.api.components.hardware.cd.CDMedia;
import org.jpsx.api.components.hardware.cd.MediaException;

public interface CDMedia {
  int getFirstTrack();
  
  int getLastTrack();
  
  int getTrackMSF(int paramInt);
  
  TrackType getTrackType(int paramInt);
  
  void readSector(int paramInt, byte[] paramArrayOfByte) throws MediaException;
  
  void readSector(int paramInt, int[] paramArrayOfInt) throws MediaException;
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\cd\CDMedia.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */