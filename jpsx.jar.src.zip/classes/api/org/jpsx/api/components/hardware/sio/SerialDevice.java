package classes.api.org.jpsx.api.components.hardware.sio;

public interface SerialDevice {
  void prepareForTransfer();
  
  void send(int paramInt);
  
  int receive();
  
  String getDescription();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\components\hardware\sio\SerialDevice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */