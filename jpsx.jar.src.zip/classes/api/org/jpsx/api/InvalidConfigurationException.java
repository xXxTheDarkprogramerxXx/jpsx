/*    */ package classes.api.org.jpsx.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidConfigurationException
/*    */   extends RuntimeException
/*    */ {
/* 22 */   public InvalidConfigurationException(String message) { super(message); }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public InvalidConfigurationException(String message, Throwable cause) { super(message, cause); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\api\org\jpsx\api\InvalidConfigurationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */