package classes.bootstrap.org.jpsx.bootstrap;

import org.jpsx.bootstrap.configuration.MachineDefinition;

public interface JPSXMachineLifecycle {
  void initialize(MachineDefinition paramMachineDefinition);
  
  void start();
  
  void close();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\JPSXMachineLifecycle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */