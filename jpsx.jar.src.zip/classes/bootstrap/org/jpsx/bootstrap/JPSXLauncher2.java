/*     */ package classes.bootstrap.org.jpsx.bootstrap;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.InvalidConfigurationException;
/*     */ import org.jpsx.bootstrap.JPSXLauncher2;
/*     */ import org.jpsx.bootstrap.JPSXMachineLifecycle;
/*     */ import org.jpsx.bootstrap.classloader.JPSXClassLoader;
/*     */ import org.jpsx.bootstrap.configuration.MachineDefinition;
/*     */ import org.jpsx.bootstrap.configuration.XMLMachineDefinitionParser;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPSXLauncher2
/*     */ {
/*  39 */   private static final Logger log = Logger.getLogger("Bootstrap");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String JPSX_MACHINE_CLASS = "org.jpsx.runtime.JPSXMachineImpl";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) { // Byte code:
/*     */     //   0: new java/awt/Frame
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: pop
/*     */     //   8: new java/util/Properties
/*     */     //   11: dup
/*     */     //   12: invokespecial <init> : ()V
/*     */     //   15: astore_1
/*     */     //   16: ldc 'jpsx.xml'
/*     */     //   18: astore_2
/*     */     //   19: ldc 'default'
/*     */     //   21: astore_3
/*     */     //   22: ldc 'log4j.properties'
/*     */     //   24: astore #4
/*     */     //   26: iconst_0
/*     */     //   27: istore #5
/*     */     //   29: iload #5
/*     */     //   31: aload_0
/*     */     //   32: arraylength
/*     */     //   33: if_icmpge -> 188
/*     */     //   36: aload_0
/*     */     //   37: iload #5
/*     */     //   39: aaload
/*     */     //   40: ldc '-config'
/*     */     //   42: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   45: ifeq -> 72
/*     */     //   48: iload #5
/*     */     //   50: aload_0
/*     */     //   51: arraylength
/*     */     //   52: iconst_1
/*     */     //   53: isub
/*     */     //   54: if_icmpne -> 61
/*     */     //   57: invokestatic usage : ()V
/*     */     //   60: return
/*     */     //   61: aload_0
/*     */     //   62: iinc #5, 1
/*     */     //   65: iload #5
/*     */     //   67: aaload
/*     */     //   68: astore_2
/*     */     //   69: goto -> 182
/*     */     //   72: aload_0
/*     */     //   73: iload #5
/*     */     //   75: aaload
/*     */     //   76: ldc '-log'
/*     */     //   78: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   81: ifeq -> 109
/*     */     //   84: iload #5
/*     */     //   86: aload_0
/*     */     //   87: arraylength
/*     */     //   88: iconst_1
/*     */     //   89: isub
/*     */     //   90: if_icmpne -> 97
/*     */     //   93: invokestatic usage : ()V
/*     */     //   96: return
/*     */     //   97: aload_0
/*     */     //   98: iinc #5, 1
/*     */     //   101: iload #5
/*     */     //   103: aaload
/*     */     //   104: astore #4
/*     */     //   106: goto -> 182
/*     */     //   109: aload_0
/*     */     //   110: iload #5
/*     */     //   112: aaload
/*     */     //   113: ldc '='
/*     */     //   115: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   118: ifle -> 161
/*     */     //   121: aload_0
/*     */     //   122: iload #5
/*     */     //   124: aaload
/*     */     //   125: ldc '='
/*     */     //   127: invokevirtual indexOf : (Ljava/lang/String;)I
/*     */     //   130: istore #6
/*     */     //   132: aload_1
/*     */     //   133: aload_0
/*     */     //   134: iload #5
/*     */     //   136: aaload
/*     */     //   137: iconst_0
/*     */     //   138: iload #6
/*     */     //   140: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   143: aload_0
/*     */     //   144: iload #5
/*     */     //   146: aaload
/*     */     //   147: iload #6
/*     */     //   149: iconst_1
/*     */     //   150: iadd
/*     */     //   151: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   154: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   157: pop
/*     */     //   158: goto -> 182
/*     */     //   161: aload_0
/*     */     //   162: iload #5
/*     */     //   164: aaload
/*     */     //   165: ldc '-?'
/*     */     //   167: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   170: ifeq -> 177
/*     */     //   173: invokestatic usage : ()V
/*     */     //   176: return
/*     */     //   177: aload_0
/*     */     //   178: iload #5
/*     */     //   180: aaload
/*     */     //   181: astore_3
/*     */     //   182: iinc #5, 1
/*     */     //   185: goto -> 29
/*     */     //   188: aload #4
/*     */     //   190: invokestatic configure : (Ljava/lang/String;)V
/*     */     //   193: new java/lang/Thread
/*     */     //   196: dup
/*     */     //   197: new org/jpsx/bootstrap/JPSXLauncher2$1
/*     */     //   200: dup
/*     */     //   201: aload_1
/*     */     //   202: invokespecial <init> : (Ljava/util/Properties;)V
/*     */     //   205: invokespecial <init> : (Ljava/lang/Runnable;)V
/*     */     //   208: invokevirtual start : ()V
/*     */     //   211: new java/lang/Thread
/*     */     //   214: dup
/*     */     //   215: new org/jpsx/bootstrap/JPSXLauncher2$2
/*     */     //   218: dup
/*     */     //   219: aload_1
/*     */     //   220: invokespecial <init> : (Ljava/util/Properties;)V
/*     */     //   223: invokespecial <init> : (Ljava/lang/Runnable;)V
/*     */     //   226: invokevirtual start : ()V
/*     */     //   229: aload_2
/*     */     //   230: aload_3
/*     */     //   231: aload_1
/*     */     //   232: invokestatic runMachine : (Ljava/lang/String;Ljava/lang/String;Ljava/util/Properties;)V
/*     */     //   235: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #45	-> 0
/*     */     //   #47	-> 8
/*     */     //   #48	-> 16
/*     */     //   #49	-> 19
/*     */     //   #50	-> 22
/*     */     //   #52	-> 26
/*     */     //   #53	-> 36
/*     */     //   #54	-> 48
/*     */     //   #55	-> 57
/*     */     //   #56	-> 60
/*     */     //   #58	-> 61
/*     */     //   #59	-> 72
/*     */     //   #60	-> 84
/*     */     //   #61	-> 93
/*     */     //   #62	-> 96
/*     */     //   #64	-> 97
/*     */     //   #65	-> 109
/*     */     //   #66	-> 121
/*     */     //   #67	-> 132
/*     */     //   #68	-> 158
/*     */     //   #69	-> 173
/*     */     //   #70	-> 176
/*     */     //   #72	-> 177
/*     */     //   #52	-> 182
/*     */     //   #77	-> 188
/*     */     //   #79	-> 193
/*     */     //   #84	-> 211
/*     */     //   #89	-> 229
/*     */     //   #90	-> 235
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   132	26	6	split	I
/*     */     //   29	159	5	i	I
/*     */     //   0	236	0	args	[Ljava/lang/String;
/*     */     //   16	220	1	vars	Ljava/util/Properties;
/*     */     //   19	217	2	configFile	Ljava/lang/String;
/*     */     //   22	214	3	machineId	Ljava/lang/String;
/*     */     //   26	210	4	log4jFile	Ljava/lang/String; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void runMachine(String configFile, String machineId, Properties vars) {
/*     */     Element config;
/*  93 */     log.info("configFile=" + configFile + " machineId=" + machineId);
/*     */     
/*     */     try {
/*  96 */       DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  97 */       config = builder.parse(new File(configFile)).getDocumentElement();
/*  98 */     } catch (IOException e) {
/*  99 */       log.error("Cannot open/read '" + configFile + "'", e);
/*     */       return;
/* 101 */     } catch (Exception e) {
/* 102 */       log.error("Cannot parse '" + configFile + "'", e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 107 */       MachineDefinition machineDefinition = (new XMLMachineDefinitionParser()).parse(config, machineId, vars);
/* 108 */       JPSXMachineLifecycle machine = JPSXClassLoader.newMachine(JPSXLauncher2.class.getClassLoader(), machineDefinition);
/* 109 */       machine.start();
/* 110 */     } catch (InvalidConfigurationException e) {
/* 111 */       log.error("Invalid Configuration", e);
/* 112 */     } catch (Throwable t) {
/* 113 */       log.error("Unexpected error", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 118 */   private static void usage() { System.err.println("Usage: JPSXLauncher (-log <log4jproperties>) (-config <xmlfile>) (<machineId>) (var=value)*\n  The default log4j properties file is 'log4j.properties'\n  The default xmlfile is 'jpsx.xml'\n  The default machineId is 'default'"); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\JPSXLauncher2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */