/*    */ package classes.bootstrap.org.jpsx.bootstrap.configuration;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.jpsx.bootstrap.configuration.ComponentDefinition;
/*    */ import org.jpsx.bootstrap.configuration.MachineDefinition;
/*    */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MachineDefinition
/*    */ {
/* 39 */   private List<ComponentDefinition> components = CollectionsFactory.newArrayList();
/* 40 */   private List<String> classNamePrefixes = CollectionsFactory.newArrayList();
/*    */ 
/*    */   
/* 43 */   public void addComponent(ComponentDefinition definition) { this.components.add(definition); }
/*    */ 
/*    */ 
/*    */   
/* 47 */   public void removeComponent(ComponentDefinition definition) { this.components.remove(definition); }
/*    */ 
/*    */ 
/*    */   
/* 51 */   public List<ComponentDefinition> getComponents() { return Collections.unmodifiableList(this.components); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   public void addClassPrefix(String classPrefix) { this.classNamePrefixes.add(classPrefix); }
/*    */ 
/*    */ 
/*    */   
/* 63 */   public List<String> getClassNamePrefixes() { return Collections.unmodifiableList(this.classNamePrefixes); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\configuration\MachineDefinition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */