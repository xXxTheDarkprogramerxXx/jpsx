/*     */ package classes.bootstrap.org.jpsx.bootstrap.configuration;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.InvalidConfigurationException;
/*     */ import org.jpsx.bootstrap.configuration.ComponentDefinition;
/*     */ import org.jpsx.bootstrap.configuration.MachineDefinition;
/*     */ import org.jpsx.bootstrap.configuration.XMLMachineDefinitionParser;
/*     */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLMachineDefinitionParser
/*     */ {
/*     */   public static final String CATEGORY = "XML-Config";
/*  36 */   private static Logger log = Logger.getLogger("XML-Config");
/*     */   
/*     */   public static final String ROOT_ELEMENT = "jpsx";
/*     */   
/*     */   public static final String MACHINE_ELEMENT = "machine";
/*     */   
/*     */   public static final String MACHINE_ID_ATTRIBUTE = "id";
/*     */   
/*     */   public static final String COMPONENT_ELEMENT = "component";
/*     */   
/*     */   public static final String COMPONENT_ID_ATTRIBUTE = "id";
/*     */   public static final String COMPONENT_CLASS_NAME_ATTRIBUTE = "classname";
/*     */   public static final String COMPONENT_SET_ELEMENT = "components";
/*     */   public static final String COMPONENT_SET_ID_ATTRIBUTE = "id";
/*     */   public static final String INCLUDE_ELEMENT = "include";
/*     */   public static final String INCLUDE_REF_ID_ATTRIBUTE = "refid";
/*     */   public static final String VAR_ELEMENT = "var";
/*     */   public static final String VAR_NAME_ATTRIBUTE = "name";
/*     */   public static final String VAR_VALUE_ATTRIBUTE = "value";
/*     */   public static final String PROPERTY_ELEMENT = "property";
/*     */   public static final String PROPERTY_NAME_ATTRIBUTE = "name";
/*     */   public static final String PROPERTY_VALUE_ATTRIBUTE = "value";
/*     */   private Properties vars;
/*     */   private Map<String, ComponentDefinition> componentsById;
/*  60 */   private XPath xPath = XPathFactory.newInstance().newXPath();
/*     */   private Element rootElement;
/*     */   
/*     */   public MachineDefinition parse(Element element, String machineId, Properties vars) throws InvalidConfigurationException {
/*  64 */     MachineDefinition rc = new MachineDefinition();
/*     */     
/*  66 */     this.componentsById = CollectionsFactory.newHashMap();
/*  67 */     this.rootElement = getUniqueElement(element, "/jpsx", "root <jpsx> element");
/*  68 */     this.vars = vars;
/*     */     
/*  70 */     Element machineElement = getUniqueElement(this.rootElement, "machine[@id='" + machineId + "']", "machine with id " + machineId);
/*  71 */     parseComponents(rc, machineElement);
/*  72 */     return rc;
/*     */   }
/*     */   
/*     */   private void parseComponents(MachineDefinition machine, Element containerElement) {
/*  76 */     NodeList nodes = containerElement.getChildNodes();
/*  77 */     for (int i = 0; i < nodes.getLength(); i++) {
/*  78 */       Node node = nodes.item(i);
/*  79 */       if (node instanceof Element) {
/*  80 */         Element element = (Element)nodes.item(i);
/*  81 */         if (element.getTagName().equals("component"))
/*  82 */         { parseComponentElement(machine, element); }
/*  83 */         else if (element.getTagName().equals("include"))
/*  84 */         { String id = element.getAttribute("refid");
/*  85 */           id = resolveVariables(id);
/*  86 */           Element refElement = getUniqueElement(this.rootElement, "component[@id='" + id + "']|" + "components" + "[@" + "id" + "='" + id + "']", "referenced component/nodes with id " + id);
/*     */ 
/*     */ 
/*     */           
/*  90 */           if (refElement.getTagName().equals("component")) {
/*  91 */             parseComponentElement(machine, refElement);
/*     */           } else {
/*  93 */             parseComponents(machine, refElement);
/*     */           }  }
/*  95 */         else if (element.getTagName().equals("var"))
/*  96 */         { String name = element.getAttribute("name");
/*  97 */           String value = element.getAttribute("value");
/*  98 */           if (!name.equals("")) {
/*  99 */             value = resolveVariables(value);
/* 100 */             if (value.equals("")) { this.vars.remove(name); }
/* 101 */             else { this.vars.setProperty(name, value); }
/*     */           
/*     */           }  }
/* 104 */         else { throw new InvalidConfigurationException("Unexpected element " + element.getTagName()); }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parseComponentElement(MachineDefinition machine, Element componentElement) {
/* 111 */     String id = componentElement.hasAttribute("id") ? componentElement.getAttribute("id") : null;
/* 112 */     String className = componentElement.getAttribute("classname");
/*     */     
/* 114 */     if (className.equals("")) {
/* 115 */       throw new InvalidConfigurationException("Machine has component (id=" + id + ") with no className");
/*     */     }
/*     */     
/* 118 */     ComponentDefinition component = addComponent(machine, id, componentElement.getAttribute("classname"));
/* 119 */     parseConfiguration(component, componentElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseConfiguration(ComponentDefinition component, Element element) {
/* 134 */     NodeList nodes = element.getElementsByTagName("property");
/* 135 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 136 */       Node node = nodes.item(i);
/* 137 */       if (node instanceof Element) {
/* 138 */         Element prop = (Element)node;
/* 139 */         if (prop.hasAttribute("name") && prop.hasAttribute("value")) {
/* 140 */           String value = prop.getAttribute("value");
/* 141 */           value = resolveVariables(value);
/* 142 */           if (!value.equals("")) {
/* 143 */             component.setProperty(prop.getAttribute("name"), value);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Element getUniqueElement(Element context, String path, String description) {
/*     */     NodeList nodes;
/*     */     try {
/* 153 */       nodes = (NodeList)this.xPath.evaluate(path, context, XPathConstants.NODESET);
/* 154 */     } catch (XPathExpressionException e) {
/* 155 */       throw new InvalidConfigurationException("XPath Error", e);
/*     */     } 
/* 157 */     if (nodes == null || nodes.getLength() == 0) {
/* 158 */       throw new InvalidConfigurationException("Can't find: " + description);
/*     */     }
/* 160 */     if (nodes.getLength() > 1) {
/* 161 */       log.warn("More than one node found for search: " + description);
/*     */     }
/* 163 */     Node node = nodes.item(0);
/* 164 */     if (node instanceof Element) {
/* 165 */       return (Element)node;
/*     */     }
/* 167 */     throw new InvalidConfigurationException("Match for '" + description + "' was not an element");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String resolveVariables(String value) {
/* 177 */     StringBuffer rc = new StringBuffer();
/* 178 */     int index = 0;
/*     */     while (true) {
/* 180 */       int start = value.indexOf("${", index);
/* 181 */       if (start == -1)
/* 182 */         break;  int end = value.indexOf("}");
/* 183 */       if (end == -1)
/* 184 */         break;  rc.append(value.substring(index, start));
/* 185 */       String varName = value.substring(start + 2, end);
/* 186 */       String varValue = getVariable(varName);
/* 187 */       if (varValue != null) {
/* 188 */         rc.append(varValue);
/*     */       }
/* 190 */       index = end + 1;
/*     */     } 
/* 192 */     rc.append(value.substring(index));
/* 193 */     return rc.toString();
/*     */   }
/*     */ 
/*     */   
/* 197 */   public String getVariable(String name) { return this.vars.getProperty(name); }
/*     */ 
/*     */   
/*     */   public ComponentDefinition addComponent(MachineDefinition machine, String id, String className) {
/* 201 */     ComponentDefinition component = new ComponentDefinition(className);
/* 202 */     if (id != null) {
/* 203 */       ComponentDefinition oldComponent = (ComponentDefinition)this.componentsById.get(id);
/* 204 */       if (oldComponent != null) {
/* 205 */         machine.removeComponent(oldComponent);
/*     */       }
/* 207 */       this.componentsById.put(id, component);
/*     */     } 
/* 209 */     machine.addComponent(component);
/* 210 */     return component;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\configuration\XMLMachineDefinitionParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */