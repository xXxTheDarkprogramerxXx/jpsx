/*    */ package classes.bootstrap.org.jpsx.bootstrap.configuration;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.jpsx.bootstrap.configuration.ComponentDefinition;
/*    */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentDefinition
/*    */ {
/*    */   private String className;
/*    */   private Map<String, String> properties;
/*    */   
/*    */   public ComponentDefinition(String className) {
/* 26 */     this.properties = CollectionsFactory.newHashMap();
/*    */ 
/*    */     
/* 29 */     this.className = className;
/*    */   }
/*    */ 
/*    */   
/* 33 */   public void setProperty(String property, String value) { this.properties.put(property, value); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   public String getClassName() { return this.className; }
/*    */ 
/*    */ 
/*    */   
/* 41 */   public Map<String, String> getProperties() { return this.properties; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\configuration\ComponentDefinition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */