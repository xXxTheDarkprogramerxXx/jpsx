/*     */ package classes.bootstrap.org.jpsx.bootstrap;
/*     */ 
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import org.jpsx.api.InvalidConfigurationException;
/*     */ import org.jpsx.bootstrap.JPSXLauncher;
/*     */ import org.jpsx.bootstrap.JPSXMachineLifecycle;
/*     */ import org.jpsx.bootstrap.classloader.JPSXClassLoader;
/*     */ import org.jpsx.bootstrap.configuration.MachineDefinition;
/*     */ import org.jpsx.bootstrap.configuration.XMLMachineDefinitionParser;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPSXLauncher
/*     */ {
/*  40 */   private static final Logger log = Logger.getLogger("Bootstrap");
/*     */   
/*     */   public static void main(String[] args) {
/*     */     Element config;
/*  44 */     new Frame();
/*     */     
/*  46 */     Properties vars = new Properties();
/*  47 */     String configFile = "jpsx.xml";
/*  48 */     String machineId = "default";
/*  49 */     String log4jFile = "log4j.properties";
/*     */     
/*  51 */     for (int i = 0; i < args.length; i++) {
/*  52 */       if (args[i].equals("-config"))
/*  53 */       { if (i == args.length - 1) {
/*  54 */           usage();
/*     */           return;
/*     */         } 
/*  57 */         configFile = args[++i]; }
/*  58 */       else if (args[i].equals("-log"))
/*  59 */       { if (i == args.length - 1) {
/*  60 */           usage();
/*     */           return;
/*     */         } 
/*  63 */         log4jFile = args[++i]; }
/*  64 */       else if (args[i].indexOf("=") > 0)
/*  65 */       { int split = args[i].indexOf("=");
/*  66 */         vars.put(args[i].substring(0, split), args[i].substring(split + 1)); }
/*  67 */       else { if (args[i].equals("-?")) {
/*  68 */           usage();
/*     */           return;
/*     */         } 
/*  71 */         machineId = args[i]; }
/*     */     
/*     */     } 
/*     */ 
/*     */     
/*  76 */     PropertyConfigurator.configure(log4jFile);
/*     */     
/*  78 */     log.info("configFile=" + configFile + " machineId=" + machineId);
/*     */     
/*     */     try {
/*  81 */       DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  82 */       config = builder.parse(new File(configFile)).getDocumentElement();
/*  83 */     } catch (IOException e) {
/*  84 */       log.error("Cannot open/read '" + configFile + "'", e);
/*     */       return;
/*  86 */     } catch (Exception e) {
/*  87 */       log.error("Cannot parse '" + configFile + "'", e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/*  92 */       MachineDefinition machineDefinition = (new XMLMachineDefinitionParser()).parse(config, machineId, vars);
/*  93 */       JPSXMachineLifecycle machine = JPSXClassLoader.newMachine(JPSXLauncher.class.getClassLoader(), machineDefinition);
/*  94 */       machine.start();
/*  95 */     } catch (InvalidConfigurationException e) {
/*  96 */       log.error("Invalid Configuration", e);
/*  97 */     } catch (Throwable t) {
/*  98 */       log.error("Unexpected error", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 103 */   private static void usage() { System.err.println("Usage: JPSXLauncher (-log <log4jproperties>) (-config <xmlfile>) (<machineId>) (var=value)*\n  The default log4j properties file is 'log4j.properties'\n  The default xmlfile is 'jpsx.xml'\n  The default machineId is 'default'"); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\JPSXLauncher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */