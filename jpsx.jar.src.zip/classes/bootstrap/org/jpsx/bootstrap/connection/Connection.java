/*    */ package classes.bootstrap.org.jpsx.bootstrap.connection;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.jpsx.bootstrap.connection.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Connection<I>
/*    */   extends Object
/*    */ {
/*    */   private String name;
/*    */   private Class<I> ifc;
/*    */   private boolean open;
/*    */   
/*    */   protected Connection(String name, Class<I> ifc, Set<Flags> flags) {
/* 69 */     if (!ifc.isInterface()) throw new IllegalArgumentException("ifc must be an interface"); 
/* 70 */     this.name = name;
/* 71 */     this.ifc = ifc;
/* 72 */     if (!flags.contains(Flags.InitiallyClosed)) {
/* 73 */       this.open = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 78 */   public String getName() { return this.name; }
/*    */ 
/*    */ 
/*    */   
/* 82 */   public final Class<I> getInterface() { return this.ifc; }
/*    */ 
/*    */ 
/*    */   
/* 86 */   public final boolean isOpen() { return this.open; }
/*    */ 
/*    */   
/*    */   public void open() {
/* 90 */     assert !this.open;
/* 91 */     this.open = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 96 */     assert this.open;
/* 97 */     this.open = false;
/*    */   }
/*    */   
/*    */   public abstract I resolve();
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\connection\Connection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */