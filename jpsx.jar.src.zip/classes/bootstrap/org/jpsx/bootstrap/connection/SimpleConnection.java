/*    */ package classes.bootstrap.org.jpsx.bootstrap.connection;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import org.jpsx.api.InvalidConfigurationException;
/*    */ import org.jpsx.bootstrap.connection.Connection;
/*    */ import org.jpsx.bootstrap.connection.SimpleConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleConnection<I>
/*    */   extends Connection<I>
/*    */ {
/*    */   private I target;
/*    */   
/* 40 */   public SimpleConnection(String name, Class<I> ifc, EnumSet<Connection.Flags> flags) { super(name, ifc, flags); }
/*    */ 
/*    */   
/*    */   public void set(I target) {
/* 44 */     if (target == null)
/* 45 */       throw new IllegalStateException("Target for simple connection '" + getName() + "' may only be set once"); 
/* 46 */     this.target = target;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public I resolve() {
/* 56 */     if (this.target == null) {
/* 57 */       throw new InvalidConfigurationException("No target for simple connection '" + getName() + "'");
/*    */     }
/* 59 */     return (I)this.target;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public I peek() { return (I)this.target; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public static <T> SimpleConnection<T> create(String name, Class<T> clazz) { return new SimpleConnection(name, clazz, EnumSet.noneOf(Connection.Flags.class)); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 90 */   public static <T> SimpleConnection<T> create(String name, Class<T> clazz, EnumSet<Connection.Flags> flags) { return new SimpleConnection(name, clazz, flags); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\connection\SimpleConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */