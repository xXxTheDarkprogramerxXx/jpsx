/*    */ package classes.bootstrap.org.jpsx.bootstrap.connection;
/*    */ 
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.EnumSet;
/*    */ import java.util.List;
/*    */ import org.jpsx.bootstrap.connection.Connection;
/*    */ import org.jpsx.bootstrap.connection.MultipleConnection;
/*    */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipleConnection<I>
/*    */   extends Connection<I>
/*    */ {
/* 41 */   private final List<I> targets = CollectionsFactory.newArrayList();
/*    */   
/*    */   private I dispatcher;
/*    */   
/* 45 */   public MultipleConnection(String name, Class<I> ifc, EnumSet<Connection.Flags> flags) { super(name, ifc, flags); }
/*    */ 
/*    */   
/*    */   public void add(I target) {
/* 49 */     assert target != null;
/*    */     
/* 51 */     assert this.dispatcher == null : "targets may not be added to connection after first dispatch";
/* 52 */     this.targets.add(target);
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(I target) {
/* 57 */     assert this.dispatcher == null : "targets may not be removed from connection after first dispatch";
/* 58 */     this.targets.remove(target);
/*    */   }
/*    */ 
/*    */   
/*    */   public I resolve() {
/* 63 */     if (this.dispatcher == null) {
/* 64 */       if (this.targets.size() == 1) {
/* 65 */         this.dispatcher = this.targets.iterator().next();
/*    */       } else {
/*    */         
/* 68 */         this.dispatcher = getInterface().cast(Proxy.newProxyInstance(getInterface().getClassLoader(), new Class[] { getInterface() }, new Invoker(this)));
/*    */       } 
/*    */     }
/* 71 */     return (I)this.dispatcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 93 */   public static <T> MultipleConnection<T> create(String name, Class<T> clazz) { return new MultipleConnection(name, clazz, EnumSet.noneOf(Connection.Flags.class)); }
/*    */ 
/*    */ 
/*    */   
/* 97 */   public static <T> MultipleConnection<T> create(String name, Class<T> clazz, EnumSet<Connection.Flags> flags) { return new MultipleConnection(name, clazz, flags); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\connection\MultipleConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */