/*    */ package classes.bootstrap.org.jpsx.bootstrap.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionsFactory
/*    */ {
/* 24 */   public static <V> Set<V> newHashSet() { return new HashSet(); }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public static <K, V> Map<K, V> newHashMap() { return new HashMap(); }
/*    */ 
/*    */ 
/*    */   
/* 32 */   public static <K, V> Map<K, V> newTreeMap() { return new TreeMap(); }
/*    */ 
/*    */ 
/*    */   
/* 36 */   public static <K, V> Map<K, V> newTreeMap(Comparator<? super K> c) { return new TreeMap(c); }
/*    */ 
/*    */ 
/*    */   
/* 40 */   public static <V> List<V> newArrayList() { return new ArrayList(); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstra\\util\CollectionsFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */