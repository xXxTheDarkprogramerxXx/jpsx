/*     */ package classes.bootstrap.org.jpsx.bootstrap.classloader;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.bcel.classfile.ClassParser;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.generic.ClassGen;
/*     */ import org.apache.bcel.generic.InstructionList;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.jpsx.api.InvalidConfigurationException;
/*     */ import org.jpsx.bootstrap.JPSXMachineLifecycle;
/*     */ import org.jpsx.bootstrap.classloader.ClassGenerator;
/*     */ import org.jpsx.bootstrap.classloader.ClassModifier;
/*     */ import org.jpsx.bootstrap.classloader.JPSXClassLoader;
/*     */ import org.jpsx.bootstrap.configuration.MachineDefinition;
/*     */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPSXClassLoader
/*     */   extends ClassLoader
/*     */ {
/*     */   public static final boolean dumpClasses = false;
/*     */   private static final String JPSX_MACHINE_CLASS = "org.jpsx.runtime.JPSXMachineImpl";
/*  63 */   private static int BUFFER_SIZE = 8192;
/*     */   
/*  65 */   private List<String> generatorClassnamePrefixes = CollectionsFactory.newArrayList();
/*  66 */   private List<ClassGenerator> generators = CollectionsFactory.newArrayList();
/*  67 */   private List<String> modifierClassnamePrefixes = CollectionsFactory.newArrayList();
/*  68 */   private List<ClassModifier> modifiers = CollectionsFactory.newArrayList();
/*  69 */   private Set<String> jpsxClassnamePrefixes = CollectionsFactory.newHashSet();
/*     */   
/*     */   private JPSXClassLoader(ClassLoader parent, MachineDefinition machineDefinition) {
/*  72 */     super(parent);
/*  73 */     this.jpsxClassnamePrefixes.add("org.jpsx.runtime");
/*  74 */     this.jpsxClassnamePrefixes.addAll(machineDefinition.getClassNamePrefixes());
/*     */   }
/*     */ 
/*     */   
/*     */   public static JPSXMachineLifecycle newMachine(ClassLoader parent, MachineDefinition machineDefinition) throws InvalidConfigurationException {
/*  79 */     JPSXClassLoader loader = new JPSXClassLoader(parent, machineDefinition);
/*     */     try {
/*  81 */       Class clazz = Class.forName("org.jpsx.runtime.JPSXMachineImpl", true, loader);
/*  82 */       JPSXMachineLifecycle rc = (JPSXMachineLifecycle)clazz.newInstance();
/*  83 */       rc.initialize(machineDefinition);
/*  84 */       return rc;
/*  85 */     } catch (Exception e) {
/*  86 */       throw new InvalidConfigurationException("Failed to create machine instance", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int prefixIndex(Collection<String> prefixes, String name) {
/*  91 */     int i = 0;
/*  92 */     for (String prefix : prefixes) {
/*  93 */       if (name.startsWith(prefix)) {
/*  94 */         return i;
/*     */       }
/*  96 */       i++;
/*     */     } 
/*  98 */     return -1;
/*     */   }
/*     */   
/*     */   public static void registerClassGenerator(String classnamePrefix, ClassGenerator generator) {
/* 102 */     JPSXClassLoader instance = getLoaderInstance(generator);
/* 103 */     instance.generatorClassnamePrefixes.add(classnamePrefix);
/* 104 */     instance.generators.add(generator);
/*     */   }
/*     */   
/*     */   public static void registerClassModifier(String classnamePrefix, ClassModifier modifier) {
/* 108 */     JPSXClassLoader instance = getLoaderInstance(modifier);
/* 109 */     instance.modifierClassnamePrefixes.add(classnamePrefix);
/* 110 */     instance.modifiers.add(modifier);
/*     */   }
/*     */   
/*     */   private static JPSXClassLoader getLoaderInstance(Object obj) {
/* 114 */     ClassLoader loader = obj.getClass().getClassLoader();
/* 115 */     assert loader != null && loader instanceof JPSXClassLoader : obj + " was not loaded by JPSXClassLoader";
/* 116 */     return (JPSXClassLoader)loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class getClassFromStream(InputStream stream, String classname) throws IOException {
/* 128 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 129 */     byte[] buffer = new byte[BUFFER_SIZE];
/*     */     
/*     */     int bytesRead;
/* 132 */     while ((bytesRead = stream.read(buffer, 0, BUFFER_SIZE)) != -1) {
/* 133 */       baos.write(buffer, 0, bytesRead);
/*     */     }
/*     */     
/* 136 */     byte[] classData = baos.toByteArray();
/*     */ 
/*     */     
/* 139 */     return defineClass(classname, classData, 0, classData.length, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 151 */     Class c = findLoadedClass(name);
/* 152 */     if (c == null)
/*     */     {
/* 154 */       if (-1 != prefixIndex(this.jpsxClassnamePrefixes, name)) {
/* 155 */         c = makeClass(name);
/*     */       } else {
/* 157 */         return super.loadClass(name, resolve);
/*     */       } 
/*     */     }
/* 160 */     if (resolve) {
/* 161 */       resolveClass(c);
/*     */     }
/* 163 */     return c;
/*     */   }
/*     */   
/*     */   private Class makeClass(String name) throws ClassNotFoundException {
/* 167 */     ClassGen cgen = null;
/*     */     
/* 169 */     int genIndex = prefixIndex(this.generatorClassnamePrefixes, name);
/* 170 */     int modIndex = prefixIndex(this.modifierClassnamePrefixes, name);
/*     */     
/* 172 */     if (genIndex != -1) {
/*     */       
/* 174 */       cgen = ((ClassGenerator)this.generators.get(genIndex)).generateClass(name);
/*     */     } else {
/*     */       
/* 177 */       URL url = getResource(getClassFilename(name));
/* 178 */       if (url != null) {
/*     */         try {
/* 180 */           InputStream stream = url.openStream();
/* 181 */           if (modIndex == -1)
/*     */           {
/* 183 */             return getClassFromStream(stream, name);
/*     */           }
/* 185 */           cgen = new ClassGen((new ClassParser(stream, getClassFilename(name))).parse());
/*     */         }
/* 187 */         catch (IOException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 192 */     if (cgen != null && modIndex != -1)
/*     */     {
/*     */       
/* 195 */       cgen = ((ClassModifier)this.modifiers.get(modIndex)).modifyClass(name, cgen);
/*     */     }
/*     */     
/* 198 */     if (cgen == null) {
/* 199 */       throw new ClassNotFoundException(name);
/*     */     }
/*     */     
/* 202 */     JavaClass jclass = cgen.getJavaClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     byte[] classData = jclass.getBytes();
/* 212 */     return defineClass(name, classData, 0, classData.length, null);
/*     */   }
/*     */   
/*     */   public static MethodGen emptyMethod(ClassGen cgen, Method m) {
/* 216 */     MethodGen mg = new MethodGen(m, cgen.getClassName(), cgen.getConstantPool());
/* 217 */     return new MethodGen(mg.getAccessFlags(), mg.getReturnType(), mg.getArgumentTypes(), mg.getArgumentNames(), mg.getName(), mg.getClassName(), new InstructionList(), mg.getConstantPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public static String getClassFilename(String classname) { return classname.replace('.', '/') + ".class"; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\classloader\JPSXClassLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */