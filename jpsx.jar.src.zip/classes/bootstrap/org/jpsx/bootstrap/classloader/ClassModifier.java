package classes.bootstrap.org.jpsx.bootstrap.classloader;

import org.apache.bcel.generic.ClassGen;

public interface ClassModifier {
  ClassGen modifyClass(String paramString, ClassGen paramClassGen);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\bootstrap\org\jpsx\bootstrap\classloader\ClassModifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */