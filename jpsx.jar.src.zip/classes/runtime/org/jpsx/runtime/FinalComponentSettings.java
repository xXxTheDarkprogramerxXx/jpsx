/*    */ package classes.runtime.org.jpsx.runtime;
/*    */ 
/*    */ import org.jpsx.api.InvalidConfigurationException;
/*    */ import org.jpsx.runtime.FinalComponentSettings;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinalComponentSettings
/*    */ {
/*    */   private static JPSXComponent component;
/*    */   
/*    */   public static JPSXComponent getComponent() {
/* 44 */     if (component == null) {
/* 45 */       throw new InvalidConfigurationException("Attempted to access cached component settings before component initialization");
/*    */     }
/* 47 */     return component;
/*    */   }
/*    */   
/*    */   public static void setComponent(JPSXComponent component) {
/* 51 */     if (FinalComponentSettings.component != null)
/* 52 */       throw new InvalidConfigurationException("Attempted to set component more than once"); 
/* 53 */     FinalComponentSettings.component = component;
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\FinalComponentSettings.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */