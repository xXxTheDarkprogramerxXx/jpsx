/*    */ package classes.runtime.org.jpsx.runtime.components.hardware.bios;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ import java.nio.IntBuffer;
/*    */ import java.nio.channels.FileChannel;
/*    */ import org.jpsx.api.InvalidConfigurationException;
/*    */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*    */ import org.jpsx.runtime.components.hardware.bios.ImageBIOS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageBIOS
/*    */   extends JPSXComponent
/*    */ {
/*    */   private static final int ADDRESS = -1077936128;
/*    */   private static final int SIZE = 524288;
/*    */   
/* 44 */   public ImageBIOS() { super("JPSX BIOS using ROM image"); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: invokespecial init : ()V
/*    */     //   4: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.ALL_POPULATORS : Lorg/jpsx/bootstrap/connection/MultipleConnection;
/*    */     //   7: new org/jpsx/runtime/components/hardware/bios/ImageBIOS$1
/*    */     //   10: dup
/*    */     //   11: aload_0
/*    */     //   12: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/bios/ImageBIOS;)V
/*    */     //   15: invokevirtual add : (Ljava/lang/Object;)V
/*    */     //   18: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #48	-> 0
/*    */     //   #49	-> 4
/*    */     //   #54	-> 18
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	19	0	this	Lorg/jpsx/runtime/components/hardware/bios/ImageBIOS; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void populateMemory() {
/* 57 */     String filename = "bios.bin";
/*    */     
/*    */     try {
/* 60 */       RandomAccessFile in = new RandomAccessFile(filename, "r");
/* 61 */       AddressSpace.ResolveResult rr = new AddressSpace.ResolveResult();
/* 62 */       AddressSpace addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/* 63 */       addressSpace.resolve(-1077936128, rr);
/*    */       
/* 65 */       FileChannel channel = in.getChannel();
/* 66 */       ByteBuffer bytebuf = ByteBuffer.allocateDirect(524288);
/* 67 */       bytebuf.order(ByteOrder.LITTLE_ENDIAN);
/* 68 */       IntBuffer intbuf = bytebuf.asIntBuffer();
/* 69 */       bytebuf.clear();
/*    */       
/* 71 */       if (524288 != channel.read(bytebuf, 0L)) {
/* 72 */         throw new InvalidConfigurationException("BIOS image " + filename + " is not the correct size");
/*    */       }
/* 74 */       intbuf.rewind();
/* 75 */       intbuf.get(rr.mem);
/* 76 */       channel.close();
/* 77 */     } catch (IOException e) {
/* 78 */       throw new InvalidConfigurationException("Can't load BIOS image " + filename, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\bios\ImageBIOS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */