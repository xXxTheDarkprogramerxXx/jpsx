/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.sio;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import org.jpsx.api.components.hardware.sio.SerialPort;
/*     */ import org.jpsx.runtime.RuntimeConnections;
/*     */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.sio.AWTKeyboardController;
/*     */ import org.jpsx.runtime.components.hardware.sio.StandardController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTKeyboardController
/*     */   extends StandardController
/*     */   implements KeyListener
/*     */ {
/*     */   protected KeyMapping mapping;
/*  35 */   protected static final KeyMapping DEF_CONTROLLER_0_MAPPING = new KeyMapping();
/*     */   static  {
/*  37 */     DEF_CONTROLLER_0_MAPPING.put(2048, 32);
/*  38 */     DEF_CONTROLLER_0_MAPPING.put(256, 83);
/*  39 */     DEF_CONTROLLER_0_MAPPING.put(4096, 38);
/*  40 */     DEF_CONTROLLER_0_MAPPING.put(32768, 37);
/*  41 */     DEF_CONTROLLER_0_MAPPING.put(8192, 39);
/*  42 */     DEF_CONTROLLER_0_MAPPING.put(16384, 40);
/*  43 */     DEF_CONTROLLER_0_MAPPING.put(16, 56);
/*  44 */     DEF_CONTROLLER_0_MAPPING.put(16, 224);
/*  45 */     DEF_CONTROLLER_0_MAPPING.put(64, 75);
/*  46 */     DEF_CONTROLLER_0_MAPPING.put(128, 226);
/*  47 */     DEF_CONTROLLER_0_MAPPING.put(32, 73);
/*  48 */     DEF_CONTROLLER_0_MAPPING.put(32, 227);
/*  49 */     DEF_CONTROLLER_0_MAPPING.put(64, 225);
/*  50 */     DEF_CONTROLLER_0_MAPPING.put(128, 85);
/*  51 */     DEF_CONTROLLER_0_MAPPING.put(4, 49);
/*  52 */     DEF_CONTROLLER_0_MAPPING.put(1, 81);
/*  53 */     DEF_CONTROLLER_0_MAPPING.put(8, 50);
/*  54 */     DEF_CONTROLLER_0_MAPPING.put(2, 87);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public AWTKeyboardController() { this(DEF_CONTROLLER_0_MAPPING); }
/*     */ 
/*     */   
/*     */   public AWTKeyboardController(KeyMapping mapping) {
/*  77 */     super("JPSX AWT Keyboard Controller");
/*  78 */     this.mapping = mapping;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*  83 */     super.init();
/*  84 */     RuntimeConnections.KEY_LISTENERS.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void resolveConnections() { ((SerialPort)HardwareComponentConnections.LEFT_PORT_INSTANCE.resolve()).connect(this); }
/*     */ 
/*     */   
/*     */   public void keyTyped(KeyEvent e) {}
/*     */ 
/*     */   
/*     */   public void keyPressed(KeyEvent e) {
/*  96 */     int vkey = e.getKeyCode();
/*  97 */     pressed(this.mapping.get(vkey));
/*     */   }
/*     */   
/*     */   public void keyReleased(KeyEvent e) {
/* 101 */     int vkey = e.getKeyCode();
/* 102 */     released(this.mapping.get(vkey));
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\sio\AWTKeyboardController.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */