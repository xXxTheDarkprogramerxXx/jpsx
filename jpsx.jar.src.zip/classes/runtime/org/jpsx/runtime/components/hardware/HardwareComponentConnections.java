/*    */ package classes.runtime.org.jpsx.runtime.components.hardware;
/*    */ 
/*    */ import org.jpsx.api.components.hardware.cd.CDAudioSink;
/*    */ import org.jpsx.api.components.hardware.cd.CDDrive;
/*    */ import org.jpsx.api.components.hardware.gpu.Display;
/*    */ import org.jpsx.api.components.hardware.gpu.DisplayManager;
/*    */ import org.jpsx.api.components.hardware.sio.SerialPort;
/*    */ import org.jpsx.bootstrap.connection.SimpleConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HardwareComponentConnections
/*    */ {
/* 31 */   public static final SimpleConnection<CDDrive> CD_DRIVE = SimpleConnection.create("CD Drive", CDDrive.class);
/* 32 */   public static final SimpleConnection<CDAudioSink> CD_AUDIO_SINK = SimpleConnection.create("CD Audio Sink", CDAudioSink.class);
/* 33 */   public static final SimpleConnection<SerialPort> LEFT_PORT_INSTANCE = SimpleConnection.create("Left Serial Port", SerialPort.class);
/* 34 */   public static final SimpleConnection<SerialPort> RIGHT_PORT_INSTANCE = SimpleConnection.create("Right Serial Port", SerialPort.class);
/* 35 */   public static final SimpleConnection<Display> DISPLAY = SimpleConnection.create("JPSX GPU Display", Display.class);
/* 36 */   public static final SimpleConnection<DisplayManager> DISPLAY_MANAGER = SimpleConnection.create("JPXS GPU Display Manager", DisplayManager.class);
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\HardwareComponentConnections.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */