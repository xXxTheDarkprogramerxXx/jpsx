/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.spu;
/*     */ 
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*     */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.spu.NullSPU;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullSPU
/*     */   extends SingletonJPSXComponent
/*     */   implements MemoryMapped
/*     */ {
/*     */   protected static final int ADDR_VOICES = 528489472;
/*     */   protected static final int ADDR_MAIN_VOL_L = 528489856;
/*     */   protected static final int ADDR_MAIN_VOL_R = 528489858;
/*     */   protected static final int ADDR_REVERB_L = 528489860;
/*     */   protected static final int ADDR_REVERB_R = 528489862;
/*     */   protected static final int ADDR_CHANNEL_ON0 = 528489864;
/*     */   protected static final int ADDR_CHANNEL_ON1 = 528489866;
/*     */   protected static final int ADDR_CHANNEL_OFF0 = 528489868;
/*     */   protected static final int ADDR_CHANNEL_OFF1 = 528489870;
/*     */   protected static final int ADDR_CHANNEL_FM0 = 528489872;
/*     */   protected static final int ADDR_CHANNEL_FM1 = 528489874;
/*     */   protected static final int ADDR_CHANNEL_NOISE0 = 528489876;
/*     */   protected static final int ADDR_CHANNEL_NOISE1 = 528489878;
/*     */   protected static final int ADDR_CHANNEL_REVERB0 = 528489880;
/*     */   protected static final int ADDR_CHANNEL_REVERB1 = 528489882;
/*     */   protected static final int ADDR_CHANNEL_MUTE0 = 528489884;
/*     */   protected static final int ADDR_CHANNEL_MUTE1 = 528489886;
/*     */   protected static final int ADDR_TRANSFER_ADDR = 528489894;
/*     */   protected static final int ADDR_TRANSFER_DATA = 528489896;
/*     */   protected static final int ADDR_SPU_CTRL = 528489898;
/*     */   protected static final int ADDR_SPU_STATUS = 528489902;
/*     */   protected static final int ADDR_CD_VOL_L = 528489904;
/*     */   protected static final int ADDR_CD_VOL_R = 528489906;
/*     */   protected static final int VOICES = 24;
/*     */   protected static final int VOICE_VOL_L = 0;
/*     */   protected static final int VOICE_VOL_R = 2;
/*     */   protected static final int VOICE_PITCH = 4;
/*     */   protected static final int VOICE_START_OFFSET = 6;
/*     */   protected static final int VOICE_ADS_LEVEL = 8;
/*     */   protected static final int VOICE_SR_RATE = 10;
/*     */   protected static final int VOICE_ADSR_VOL = 12;
/*     */   protected static final int VOICE_REPEAT_OFFSET = 14;
/*     */   protected static int m_ctrl;
/*     */   protected static int m_transferAddress;
/*     */   static boolean toggle;
/*     */   
/*  75 */   public NullSPU() { super("JPSX Null (no sound) SPU"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  81 */     super.init();
/*  82 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*  83 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new SPUDMAChannel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/*  89 */     for (int i = 0; i < 24; i++) {
/*  90 */       int base = 528489472 + i * 16;
/*  91 */       registrar.registerWrite16Callback(base + 0, NullSPU.class, "writeVolLeft");
/*  92 */       registrar.registerWrite16Callback(base + 2, NullSPU.class, "writeVolRight");
/*  93 */       registrar.registerWrite16Callback(base + 4, NullSPU.class, "writePitch");
/*  94 */       registrar.registerWrite16Callback(base + 6, NullSPU.class, "writeStartOffset");
/*  95 */       registrar.registerWrite16Callback(base + 8, NullSPU.class, "writeADSLevel");
/*  96 */       registrar.registerWrite16Callback(base + 10, NullSPU.class, "writeSRRate");
/*  97 */       registrar.registerWrite16Callback(base + 12, NullSPU.class, "writeADSRVol");
/*  98 */       registrar.registerWrite16Callback(base + 14, NullSPU.class, "writeRepeatOffset");
/*     */     } 
/* 100 */     registrar.registerWrite16Callback(528489856, NullSPU.class, "writeMainVolLeft");
/* 101 */     registrar.registerWrite16Callback(528489858, NullSPU.class, "writeMainVolRight");
/* 102 */     registrar.registerWrite16Callback(528489860, NullSPU.class, "writeReverbLeft");
/* 103 */     registrar.registerWrite16Callback(528489862, NullSPU.class, "writeReverbRight");
/* 104 */     registrar.registerWrite16Callback(528489864, NullSPU.class, "writeChannelOn0");
/* 105 */     registrar.registerWrite16Callback(528489866, NullSPU.class, "writeChannelOn1");
/* 106 */     registrar.registerWrite16Callback(528489868, NullSPU.class, "writeChannelOff0");
/* 107 */     registrar.registerWrite16Callback(528489870, NullSPU.class, "writeChannelOff1");
/* 108 */     registrar.registerWrite16Callback(528489872, NullSPU.class, "writeChannelFM0");
/* 109 */     registrar.registerWrite16Callback(528489874, NullSPU.class, "writeChannelFM1");
/* 110 */     registrar.registerWrite16Callback(528489876, NullSPU.class, "writeChannelNoise0");
/* 111 */     registrar.registerWrite16Callback(528489878, NullSPU.class, "writeChannelNoise1");
/* 112 */     registrar.registerWrite16Callback(528489880, NullSPU.class, "writeChannelReverb0");
/* 113 */     registrar.registerWrite16Callback(528489882, NullSPU.class, "writeChannelReverb1");
/* 114 */     registrar.registerWrite16Callback(528489884, NullSPU.class, "writeChannelMute0");
/* 115 */     registrar.registerWrite16Callback(528489886, NullSPU.class, "writeChannelMute1");
/*     */     
/* 117 */     registrar.registerWrite16Callback(528489898, NullSPU.class, "writeSPUCtrl");
/* 118 */     registrar.registerRead16Callback(528489898, NullSPU.class, "readSPUCtrl");
/*     */     
/* 120 */     registrar.registerWrite16Callback(528489904, NullSPU.class, "writeCDVolL");
/* 121 */     registrar.registerWrite16Callback(528489906, NullSPU.class, "writeCDVolR");
/*     */     
/* 123 */     registrar.registerRead16Callback(528489902, NullSPU.class, "readSPUStatus");
/*     */     
/* 125 */     registrar.registerWrite16Callback(528489894, NullSPU.class, "writeTransferAddr");
/* 126 */     registrar.registerWrite16Callback(528489896, NullSPU.class, "writeTransferData");
/* 127 */     registrar.registerRead16Callback(528489894, NullSPU.class, "readTransferAddr");
/*     */   }
/*     */ 
/*     */   
/* 131 */   public static void writeVolLeft(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 135 */   public static void writeVolRight(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 139 */   public static void writePitch(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 143 */   public static void writeStartOffset(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 147 */   public static void writeADSLevel(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 151 */   public static void writeSRRate(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static void writeADSRVol(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */ 
/*     */   
/* 159 */   public static void writeRepeatOffset(int address, int val) { int voice = address - 528489472 >> 4; }
/*     */ 
/*     */   
/*     */   public static void writeMainVolLeft(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeMainVolRight(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeReverbLeft(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeReverbRight(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelOn0(int address, int val) {
/* 175 */     for (int i = 0; i < 16; i++) {
/* 176 */       if (0 != (val & 1 << i));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeChannelOn1(int address, int val) {
/* 183 */     for (int i = 0; i < 8; i++) {
/* 184 */       if (0 != (val & 1 << i));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeChannelOff0(int address, int val) {
/* 191 */     for (int i = 0; i < 16; i++) {
/* 192 */       if (0 != (val & 1 << i));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeChannelOff1(int address, int val) {
/* 199 */     for (int i = 0; i < 8; i++) {
/* 200 */       if (0 != (val & 1 << i));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeChannelFM0(int address, int val) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeChannelFM1(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelNoise0(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelNoise1(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelReverb0(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelReverb1(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelMute0(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeChannelMute1(int address, int val) {}
/*     */ 
/*     */   
/* 231 */   public static void writeSPUCtrl(int address, int val) { m_ctrl = val; }
/*     */ 
/*     */ 
/*     */   
/* 235 */   public static int readSPUCtrl(int address) { return m_ctrl; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeCDVolL(int address, int val) {}
/*     */ 
/*     */   
/*     */   public static void writeCDVolR(int address, int val) {}
/*     */ 
/*     */   
/* 245 */   public static void writeTransferAddr(int address, int val) { m_transferAddress = val & 0xFFFF; }
/*     */ 
/*     */ 
/*     */   
/* 249 */   public static int readTransferAddr(int address) { return m_transferAddress; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeTransferData(int address, int val) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readSPUStatus(int address) {
/* 258 */     toggle = !toggle;
/*     */     
/* 260 */     return toggle ? 1024 : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\spu\NullSPU.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */