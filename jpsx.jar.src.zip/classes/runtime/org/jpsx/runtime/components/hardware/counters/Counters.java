/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.counters;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*     */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*     */ import org.jpsx.api.components.core.irq.IRQController;
/*     */ import org.jpsx.api.components.core.scheduler.Quartz;
/*     */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*     */ import org.jpsx.api.components.hardware.cd.CDDrive;
/*     */ import org.jpsx.api.components.hardware.cd.CDMedia;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.counters.Counters;
/*     */ import org.jpsx.runtime.util.CDUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Counters
/*     */   extends SingletonJPSXComponent
/*     */   implements MemoryMapped
/*     */ {
/*     */   public static final String CATEGORY = "Counters";
/*  42 */   public static final Logger log = Logger.getLogger("Counters");
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER0_COUNT = 528486656;
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER1_COUNT = 528486672;
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER2_COUNT = 528486688;
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER0_MODE = 528486660;
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER1_MODE = 528486676;
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER2_MODE = 528486692;
/*     */   
/*     */   public static final int ADDR_HARD_COUNTER0_TARGET = 528486664;
/*     */   public static final int ADDR_HARD_COUNTER1_TARGET = 528486680;
/*     */   public static final int ADDR_HARD_COUNTER2_TARGET = 528486696;
/*     */   private static final long CLOCK_FREQ = 33868800L;
/*     */   private static final int NTSC_VSYNC_FREQ = 60;
/*     */   private static final int PAL_VSYNC_FREQ = 50;
/*     */   private static long VSYNC_FREQ;
/*     */   private static long HSYNC_FREQ;
/*     */   private static long PIXEL_FREQ;
/*     */   private static long VSYNC_PERIOD;
/*     */   private static Counter[] counters;
/*     */   private static boolean bandicootUS;
/*     */   private static IRQController irqController;
/*     */   private static Quartz quartz;
/*     */   private static Scheduler scheduler;
/*     */   
/*  72 */   public Counters() { super("JPSX Hardware Counters"); }
/*     */ 
/*     */   
/*     */   public void init() {
/*  76 */     super.init();
/*  77 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*     */     
/*  79 */     setNTSC(true);
/*  80 */     bandicootUS = getBooleanProperty("bandicootUS", false);
/*  81 */     log.info("Bandicoot = " + bandicootUS);
/*  82 */     counters = new Counter[3];
/*  83 */     counters[0] = new Counter(false);
/*  84 */     counters[1] = new Counter(true);
/*  85 */     counters[2] = new Counter(2);
/*  86 */     for (Counter counter : counters) {
/*  87 */       CoreComponentConnections.IRQ_OWNERS.add(counter.getIrq());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/*  93 */     super.resolveConnections();
/*  94 */     irqController = (IRQController)CoreComponentConnections.IRQ_CONTROLLER.resolve();
/*  95 */     quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/*  96 */     scheduler = (Scheduler)CoreComponentConnections.SCHEDULER.resolve();
/*     */   }
/*     */   
/*     */   public void begin() {
/* 100 */     for (Counter counter : counters) {
/* 101 */       counter.init();
/*     */     }
/* 103 */     CDDrive drive = (CDDrive)HardwareComponentConnections.CD_DRIVE.resolve();
/* 104 */     CDMedia media = (drive == null) ? null : drive.getCurrentMedia();
/*     */     
/* 106 */     if (0 != (CDUtil.getMediaType(media) & 0x10)) {
/* 107 */       log.info("Picking PAL based on current media");
/* 108 */       setNTSC(false);
/*     */     } else {
/* 110 */       log.info("Picking NTSC based on current media");
/* 111 */       setNTSC(true);
/*     */     } 
/* 113 */     (new VSyncAction(null)).start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/* 280 */     for (int i = 0; i <= 32; i += 16) {
/* 281 */       registrar.registerRead32Callback(528486656 + i, Counters.class, "countRead32", true);
/* 282 */       registrar.registerWrite32Callback(528486656 + i, Counters.class, "countWrite32", true);
/* 283 */       registrar.registerRead32Callback(528486660 + i, Counters.class, "modeRead32", true);
/* 284 */       registrar.registerWrite32Callback(528486660 + i, Counters.class, "modeWrite32", true);
/* 285 */       registrar.registerRead32Callback(528486664 + i, Counters.class, "targetRead32", true);
/* 286 */       registrar.registerWrite32Callback(528486664 + i, Counters.class, "targetWrite32", true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 291 */   private static Counter getCounter(int address) { return counters[(address & 0x30) >> 4]; }
/*     */ 
/*     */ 
/*     */   
/* 295 */   public static int countRead32(int address) { return getCounter(address).getValue(); }
/*     */ 
/*     */ 
/*     */   
/* 299 */   public static void countWrite32(int address, int value, int mask) { getCounter(address).setValue(value & 0xFFFF); }
/*     */ 
/*     */ 
/*     */   
/* 303 */   public static int modeRead32(int address) { return getCounter(address).getMode(); }
/*     */ 
/*     */   
/*     */   public static void modeWrite32(int address, int value, int mask) {
/* 307 */     Counter c = getCounter(address);
/* 308 */     c.setMode(c.getMode() & (mask ^ 0xFFFFFFFF) | value & mask);
/*     */   }
/*     */ 
/*     */   
/* 312 */   public static int targetRead32(int address) { return getCounter(address).getTarget(); }
/*     */ 
/*     */   
/*     */   public static void targetWrite32(int address, int value, int mask) {
/* 316 */     Counter c = getCounter(address);
/* 317 */     mask &= 0xFFFF;
/* 318 */     c.setTarget(c.getTarget() & (mask ^ 0xFFFFFFFF) | value & mask);
/*     */   }
/*     */   
/*     */   public static void setNTSC(boolean NTSC) {
/* 322 */     VSYNC_FREQ = NTSC ? 60L : 50L;
/* 323 */     VSYNC_PERIOD = 1000000000L / VSYNC_FREQ;
/* 324 */     int scans = NTSC ? 525 : 625;
/* 325 */     HSYNC_FREQ = VSYNC_FREQ * scans / 2L;
/*     */ 
/*     */     
/* 328 */     PIXEL_FREQ = 3840L * HSYNC_FREQ;
/* 329 */     if (log.isDebugEnabled()) {
/* 330 */       log.debug("HSYNC FREQ: " + HSYNC_FREQ);
/* 331 */       log.debug("PIXEL FREQ: " + PIXEL_FREQ);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\counters\Counters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */