/*       */ package classes.runtime.org.jpsx.runtime.components.hardware.gpu;
/*       */ 
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.net.URL;
/*       */ import org.apache.bcel.classfile.ClassParser;
/*       */ import org.apache.bcel.classfile.ConstantUtf8;
/*       */ import org.apache.bcel.classfile.Field;
/*       */ import org.apache.bcel.classfile.JavaClass;
/*       */ import org.apache.bcel.generic.ClassGen;
/*       */ import org.apache.bcel.generic.ConstantPoolGen;
/*       */ import org.apache.bcel.generic.FieldGen;
/*       */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*       */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*       */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*       */ import org.jpsx.api.components.core.addressspace.Pollable;
/*       */ import org.jpsx.api.components.core.cpu.PollBlockListener;
/*       */ import org.jpsx.api.components.hardware.gpu.Display;
/*       */ import org.jpsx.api.components.hardware.gpu.DisplayManager;
/*       */ import org.jpsx.bootstrap.classloader.ClassGenerator;
/*       */ import org.jpsx.bootstrap.classloader.JPSXClassLoader;
/*       */ import org.jpsx.runtime.SingletonJPSXComponent;
/*       */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*       */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*       */ import org.jpsx.runtime.components.hardware.gpu.GPU;
/*       */ import org.jpsx.runtime.util.MiscUtil;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ public class GPU
/*       */   extends SingletonJPSXComponent
/*       */   implements ClassGenerator, MemoryMapped, PollBlockListener, Pollable
/*       */ {
/*       */   private static final boolean ignoreGPU = false;
/*       */   private static final boolean dumpGPUD = false;
/*       */   private static final boolean debugTransfers = false;
/*       */   private static final boolean debugTexturePage = false;
/*       */   private static final boolean rgb24conversion = true;
/*       */   private static final boolean supportTextureWindow = true;
/*       */   private static final int ADDR_GPU_DATA = 528488464;
/*       */   private static final int ADDR_GPU_CTRLSTATUS = 528488468;
/*       */   private static final int GPUD_CMD_NONE = 0;
/*       */   private static final int GPUD_CMD_FILLING = 1;
/*       */   private static final int GPUD_CMD_EXTRA = 2;
/*       */   private static final int DRAWMODE_SEMI_5P5 = 0;
/*       */   private static final int DRAWMODE_SEMI_10P10 = 32;
/*       */   private static final int DRAWMODE_SEMI_10M10 = 64;
/*       */   private static final int DRAWMODE_SEMI_10P25 = 96;
/*       */   private static final int SEMI_NONE = 0;
/*       */   private static final int SEMI_5P5 = 1;
/*       */   private static final int SEMI_10P10 = 2;
/*       */   private static final int SEMI_10M10 = 3;
/*       */   private static final int SEMI_10P25 = 4;
/*       */   private static final int DRAWMODE_TEXTURE_4BIT = 0;
/*       */   private static final int DRAWMODE_TEXTURE_8BIT = 128;
/*       */   private static final int DRAWMODE_TEXTURE_16BIT = 256;
/*       */   private static final int DRAWMODE_TEXTURE_4BITW = 32768;
/*       */   private static final int DRAWMODE_TEXTURE_8BITW = 32896;
/*       */   private static final int DRAWMODE_TEXTURE_16BITW = 33024;
/*       */   private static final int DRAWMODE_SET_MASK = 2048;
/*       */   private static final int DRAWMODE_CHECK_MASK = 4096;
/*       */   private static final int TEXTURE_NONE = 0;
/*       */   private static final int TEXTURE_4BIT = 1;
/*       */   private static final int TEXTURE_8BIT = 2;
/*       */   private static final int TEXTURE_16BIT = 3;
/*       */   private static final int TEXTURE_4BITW = 4;
/*       */   private static final int TEXTURE_8BITW = 5;
/*       */   private static final int TEXTURE_16BITW = 6;
/*       */   private static final int PIXEL_SOLID_CLUT = 536870912;
/*       */   private static final int PIXEL_SOLID_CLUT_CHECKED = 268435456;
/*       */   private static final int PIXEL_RGB24 = 134217728;
/*       */   private static final int PIXEL_DMA_A = 33554432;
/*       */   private static final int PIXEL_DMA_B = 67108864;
/*       */   private static final int PIXEL_DMA_C = 100663296;
/*       */   private static final int GPU_RGBXX_X_MASK = 234881024;
/*       */   private static final int GPU_RGB24_A = 167772160;
/*       */   private static final int GPU_RGB24_B = 201326592;
/*       */   private static final int GPU_RGB24_C = 234881024;
/*       */   private static final int GPU_RGB15_A = 33554432;
/*       */   private static final int GPU_RGB15_B = 67108864;
/*       */   private static final int GPU_RGB15_C = 100663296;
/*       */   private static Display display;
/*       */   private static DisplayManager manager;
/*       */   
/*   125 */   public GPU() { super("JPSX Software GPU"); }
/*       */ 
/*       */ 
/*       */   
/*       */   public void resolveConnections() {
/*   130 */     super.resolveConnections();
/*   131 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*   132 */     display = (Display)HardwareComponentConnections.DISPLAY.resolve();
/*   133 */     manager = (DisplayManager)HardwareComponentConnections.DISPLAY_MANAGER.resolve();
/*       */   }
/*       */ 
/*       */   
/*       */   public void begin() {
/*   138 */     display.initDisplay();
/*   139 */     gpusReset(0);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*   144 */   private static final int[] dma16flags = { 33554432, 67108864, 100663296, 33554432 }; private static AddressSpace addressSpace; private static int displayMode; private static int dmaMode; private static int maskMode; private static int drawMode;
/*       */   private static int cmdBufferUsed;
/*       */   private static int cmdBufferTarget;
/*       */   private static int m_gpudState;
/*       */   private static int m_drawOffsetX;
/*       */   private static int m_drawOffsetY;
/*       */   
/*   151 */   private static final int getTexturePage() { return drawMode & 0x1F; }
/*       */   private static int m_dmaRGB24Index; private static int m_dmaRGB24LastPixel; private static int m_dmaRGB24LastDWord; private static int m_dmaX; private static int m_dmaY; private static int m_dmaOriginX; private static int m_dmaOriginY; private static int m_dmaW; private static int m_dmaH; private static int m_dmaDWordsRemaining;
/*       */   private static int m_dmaWordsRemaining;
/*       */   
/*   155 */   private static final int getMaskModes() { return drawMode & 0x1800; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int getTextureMode() {
/*   162 */     rc = drawMode & 0x180;
/*   163 */     if (noTextureWindow) return rc; 
/*   164 */     return rc | 0x8000;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   171 */   private static final int getSemiMode() { return drawMode & 0x60; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static boolean noTextureWindow = true;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   200 */   private static final int[] twuLookup = new int[32];
/*   201 */   private static final int[] twvLookup = new int[32];
/*       */ 
/*       */   
/*       */   private static boolean rgb24;
/*       */ 
/*       */   
/*       */   private static int m_gpudCommand;
/*       */ 
/*       */   
/*       */   private static int m_clipLeft;
/*       */ 
/*       */   
/*       */   private static int m_clipRight;
/*       */ 
/*       */   
/*       */   private static int m_clipTop;
/*       */ 
/*       */   
/*       */   private static int m_clipBottom;
/*       */ 
/*       */   
/*       */   private static final int CMD_BUFFER_SIZE = 16;
/*       */   
/*   224 */   private static final int[] m_cmdBuffer = new int[16];
/*       */   
/*       */   private static int[] videoRAM;
/*       */   
/*   228 */   private static final byte[][] _4bitTexturePages = new byte[32][];
/*   229 */   private static final byte[][] _8bitTexturePages = new byte[32][];
/*       */   
/*       */   public void init() {
/*   232 */     super.init();
/*   233 */     JPSXClassLoader.registerClassGenerator("org.jpsx.runtime.components.hardware.gpu.GPU$_T", this);
/*   234 */     JPSXClassLoader.registerClassGenerator("org.jpsx.runtime.components.hardware.gpu.GPU$_L", this);
/*   235 */     JPSXClassLoader.registerClassGenerator("org.jpsx.runtime.components.hardware.gpu.GPU$_S", this);
/*   236 */     JPSXClassLoader.registerClassGenerator("org.jpsx.runtime.components.hardware.gpu.GPU$_Q", this);
/*   237 */     JPSXClassLoader.registerClassGenerator("org.jpsx.runtime.components.hardware.gpu.GPU$_R", this);
/*   238 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*   239 */     CoreComponentConnections.POLL_BLOCK_LISTENERS.add(this);
/*   240 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new GPUDMAChannel(null));
/*   241 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new OTCDMAChannel(null));
/*       */   }
/*       */   private static int[] m_gpudFunctionArgumentCount = { 
/*   244 */       1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 4, 4, 4, 7, 7, 7, 7, 5, 5, 5, 5, 9, 9, 9, 9, 6, 6, 6, 6, 9, 9, 9, 9, 8, 8, 8, 8, 12, 12, 12, 12, 3, 1, 3, 1, 1, 1, 1, 1, 3, 1, 3, 1, 1, 1, 1, 1, 4, 1, 4, 1, 1, 1, 1, 1, 4, 1, 4, 1, 1, 1, 1, 1, 3, 3, 3, 3, 4, 4, 4, 4, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 2, 2, 2, 2, 3, 3, 3, 3, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static boolean m_displayEnabled;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/*   507 */     registrar.registerWrite32Callback(528488468, GPU.class, "gpuCtrlWrite32");
/*   508 */     registrar.registerWrite32Callback(528488464, GPU.class, "gpuDataWrite32");
/*   509 */     registrar.registerRead32Callback(528488468, GPU.class, "gpuStatusRead32");
/*   510 */     registrar.registerRead32Callback(528488464, GPU.class, "gpuDataRead32");
/*       */     
/*   512 */     registrar.registerPoll32Callback(528488468, this);
/*       */   }
/*       */   
/*   515 */   static long baseTime = System.currentTimeMillis();
/*   516 */   static int counter = 0;
/*       */   
/*       */   private static void debuggo() {
/*   519 */     System.out.println(counter + " " + (System.currentTimeMillis() - baseTime));
/*   520 */     counter++;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void gpuCtrlWrite32(int address, int val) {
/*   529 */     switch (val >> 24) {
/*       */       case 0:
/*   531 */         gpusReset(val);
/*       */         break;
/*       */       case 1:
/*   534 */         gpusCmdReset(val);
/*       */         break;
/*       */       case 2:
/*   537 */         gpusIRQReset(val);
/*       */         break;
/*       */       case 3:
/*   540 */         gpusSetDispEnable(val);
/*       */         break;
/*       */       case 4:
/*   543 */         gpusSetDataTransferMode(val);
/*       */         break;
/*       */       case 5:
/*   546 */         gpusSetDisplayOrigin(val);
/*       */         break;
/*       */       case 6:
/*   549 */         gpusSetMonitorLeftRight(val);
/*       */         break;
/*       */       case 7:
/*   552 */         gpusSetMonitorTopBottom(val);
/*       */         break;
/*       */       case 8:
/*   555 */         gpusSetDisplayMode(val);
/*       */         break;
/*       */       case 16:
/*   558 */         gpusRequestInfo(val);
/*       */         break;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void gpuDataWrite32(int address, int val) {
/*   568 */     videoRAM = display.acquireDisplayBuffer(); try {
/*       */       int dwordsUsed;
/*   570 */       switch (m_gpudState) {
/*       */         case 0:
/*   572 */           m_gpudCommand = val >> 24 & 0xFF;
/*   573 */           m_cmdBuffer[0] = val;
/*   574 */           cmdBufferUsed = 1;
/*   575 */           cmdBufferTarget = m_gpudFunctionArgumentCount[m_gpudCommand];
/*   576 */           m_gpudState = 1;
/*       */           break;
/*       */         case 1:
/*   579 */           m_cmdBuffer[cmdBufferUsed++] = val;
/*       */           break;
/*       */         case 2:
/*   582 */           m_cmdBuffer[0] = val;
/*   583 */           dwordsUsed = GPUDRouter.invoke(m_cmdBuffer, 0, 1);
/*   584 */           assert dwordsUsed == 1;
/*       */           return;
/*       */       } 
/*   587 */       assert m_gpudState == 1;
/*   588 */       if (cmdBufferUsed == cmdBufferTarget) {
/*   589 */         m_gpudState = 0;
/*   590 */         GPUDRouter.invoke(m_cmdBuffer, 0, cmdBufferUsed);
/*       */       } 
/*       */     } finally {
/*   593 */       display.releaseDisplayBuffer();
/*   594 */       videoRAM = null;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static byte[] get4BitTexturePage() {
/*   612 */     page = getTexturePage() & 0x1F;
/*   613 */     byte[] rc = _4bitTexturePages[page];
/*   614 */     if (rc == null) {
/*   615 */       assert !rgb24;
/*       */       
/*   617 */       rc = new byte[65536];
/*   618 */       int offset = (page & 0xF) * 64 + (page & 0x10) * 1024 * 16;
/*   619 */       int destOffset = 0;
/*   620 */       for (int y = 0; y < 256; y++) {
/*   621 */         for (int x = 0; x < 64; x++) {
/*   622 */           int val = unmakePixel(videoRAM[offset++]);
/*       */           
/*   624 */           rc[destOffset++] = (byte)(val & 0xF);
/*   625 */           rc[destOffset++] = (byte)((val & 0xF0) >> 4);
/*   626 */           rc[destOffset++] = (byte)((val & 0xF00) >> 8);
/*   627 */           rc[destOffset++] = (byte)((val & 0xF000) >> 12);
/*       */         } 
/*   629 */         offset += 960;
/*       */       } 
/*   631 */       _4bitTexturePages[page] = rc;
/*       */     } 
/*   633 */     return rc;
/*       */   }
/*       */   
/*       */   private static byte[] get8BitTexturePage() {
/*   637 */     page = getTexturePage() & 0x1F;
/*   638 */     byte[] rc = _8bitTexturePages[page];
/*   639 */     if (rc == null) {
/*   640 */       assert !rgb24;
/*       */       
/*   642 */       rc = new byte[65536];
/*   643 */       int offset = (page & 0xF) * 64 + (page & 0x10) * 1024 * 16;
/*   644 */       int destOffset = 0;
/*   645 */       for (int y = 0; y < 256; y++) {
/*   646 */         for (int x = 0; x < 128; x++) {
/*   647 */           int val = unmakePixel(videoRAM[offset++]);
/*       */           
/*   649 */           rc[destOffset++] = (byte)(val & 0xFF);
/*   650 */           rc[destOffset++] = (byte)((val & 0xFF00) >> 8);
/*       */         } 
/*   652 */         offset += 896;
/*       */       } 
/*   654 */       _8bitTexturePages[page] = rc;
/*       */     } 
/*   656 */     return rc;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  7790 */   public static int gpudCacheFlush(int[] data, int offset, int size) { return 0; }
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudClear(int[] data, int offset, int size) {
/*  7795 */     int x = data[offset + 1] << 20 >> 20;
/*  7796 */     int y = data[offset + 1] << 4 >> 20;
/*  7797 */     int w = data[offset + 2] & 0xFFFF;
/*  7798 */     int h = data[offset + 2] >> 16;
/*  7799 */     int r = data[offset] & 0xFF;
/*  7800 */     int g = data[offset] >> 8 & 0xFF;
/*  7801 */     int b = data[offset] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7806 */     if (x < 0) {
/*  7807 */       w += x;
/*  7808 */       x = 0;
/*       */     } 
/*  7810 */     if (y < 0) {
/*  7811 */       h += y;
/*  7812 */       y = 0;
/*       */     } 
/*  7814 */     if (x + w > 1024) {
/*  7815 */       w = 1024 - x;
/*       */     }
/*  7817 */     if (y + h > 512) {
/*  7818 */       h = 512 - y;
/*       */     }
/*       */     
/*  7821 */     int base = x + y * 1024;
/*  7822 */     int color = b | g << 8 | r << 16;
/*  7823 */     for (; h > 0; h--) {
/*  7824 */       for (int i = base; i < base + w; i++) {
/*  7825 */         videoRAM[i] = color;
/*       */       }
/*  7827 */       base += 1024;
/*       */     } 
/*  7829 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud3PointFlat(int[] data, int offset, int size) {
/*  7833 */     Vertex v0 = m_v0;
/*  7834 */     Vertex v1 = m_v1;
/*  7835 */     Vertex v2 = m_v2;
/*       */     
/*  7837 */     v0.x = data[offset + 1] << 20 >> 20;
/*  7838 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/*  7840 */     v1.x = data[offset + 2] << 20 >> 20;
/*  7841 */     v1.y = data[offset + 2] << 4 >> 20;
/*       */     
/*  7843 */     v2.x = data[offset + 3] << 20 >> 20;
/*  7844 */     v2.y = data[offset + 3] << 4 >> 20;
/*       */     
/*  7846 */     m_polygonInfo.r = data[offset] & 0xFF;
/*  7847 */     m_polygonInfo.g = data[offset] >> 8 & 0xFF;
/*  7848 */     m_polygonInfo.b = data[offset] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7854 */     switch (getMaskModes())
/*       */     { case 0:
/*  7856 */         _T000000.render(m_polygonInfo, v0, v1, v2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7868 */         return 0;case 2048: _T000100.render(m_polygonInfo, v0, v1, v2); return 0;case 4096: _T000010.render(m_polygonInfo, v0, v1, v2); return 0; }  _T000110.render(m_polygonInfo, v0, v1, v2); return 0;
/*       */   }
/*       */   
/*       */   public static int gpud3PointFlatSemi(int[] data, int offset, int size) {
/*  7872 */     Vertex v0 = m_v0;
/*  7873 */     Vertex v1 = m_v1;
/*  7874 */     Vertex v2 = m_v2;
/*       */     
/*  7876 */     v0.x = data[offset + 1] << 20 >> 20;
/*  7877 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/*  7879 */     v1.x = data[offset + 2] << 20 >> 20;
/*  7880 */     v1.y = data[offset + 2] << 4 >> 20;
/*       */     
/*  7882 */     v2.x = data[offset + 3] << 20 >> 20;
/*  7883 */     v2.y = data[offset + 3] << 4 >> 20;
/*       */     
/*  7885 */     m_polygonInfo.r = data[offset] & 0xFF;
/*  7886 */     m_polygonInfo.g = data[offset] >> 8 & 0xFF;
/*  7887 */     m_polygonInfo.b = data[offset] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7892 */     switch (getMaskModes())
/*       */     { case 0:
/*  7894 */         switch (getSemiMode()) {
/*       */           case 0:
/*  7896 */             _T001000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  7899 */             _T002000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  7902 */             _T003000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  7905 */             _T004000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7958 */         return 0;case 2048: switch (getSemiMode()) { case 0: _T001100.render(m_polygonInfo, v0, v1, v2); break;case 32: _T002100.render(m_polygonInfo, v0, v1, v2); break;case 64: _T003100.render(m_polygonInfo, v0, v1, v2); break;case 96: _T004100.render(m_polygonInfo, v0, v1, v2); break; }  return 0;case 4096: switch (getSemiMode()) { case 0: _T001010.render(m_polygonInfo, v0, v1, v2); break;case 32: _T002010.render(m_polygonInfo, v0, v1, v2); break;case 64: _T003010.render(m_polygonInfo, v0, v1, v2); break;case 96: _T004010.render(m_polygonInfo, v0, v1, v2); break; }  return 0; }  switch (getSemiMode()) { case 0: _T001110.render(m_polygonInfo, v0, v1, v2); break;case 32: _T002110.render(m_polygonInfo, v0, v1, v2); break;case 64: _T003110.render(m_polygonInfo, v0, v1, v2); break;case 96: _T004110.render(m_polygonInfo, v0, v1, v2); break; }  return 0;
/*       */   }
/*       */   
/*  7961 */   private static Vertex m_v0 = new Vertex();
/*  7962 */   private static Vertex m_v1 = new Vertex();
/*  7963 */   private static Vertex m_v2 = new Vertex();
/*  7964 */   private static Vertex m_v3 = new Vertex();
/*       */ 
/*       */   
/*  7967 */   private static void drawModePacket(int packet) { drawMode = drawMode & 0xFFFFFE00 | packet >> 16 & 0x1FF; }
/*       */ 
/*       */   
/*  7970 */   private static PolygonRenderInfo m_polygonInfo = new PolygonRenderInfo();
/*  7971 */   private static LineRenderInfo m_lineInfo = new LineRenderInfo();
/*       */   public static int gpud3PointTexture(int[] data, int offset, int size) {
/*       */     boolean nobreg, nobreg;
/*  7974 */     Vertex v0 = m_v0;
/*  7975 */     Vertex v1 = m_v1;
/*  7976 */     Vertex v2 = m_v2;
/*       */     
/*  7978 */     v0.x = data[offset + 1] << 20 >> 20;
/*  7979 */     v0.y = data[offset + 1] << 4 >> 20;
/*  7980 */     v0.u = data[offset + 2] & 0xFF;
/*  7981 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/*       */     
/*  7983 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/*  7984 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/*  7985 */     m_polygonInfo.clut = videoRAM;
/*  7986 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */ 
/*       */     
/*  7989 */     v1.x = data[offset + 3] << 20 >> 20;
/*  7990 */     v1.y = data[offset + 3] << 4 >> 20;
/*  7991 */     v1.u = data[offset + 4] & 0xFF;
/*  7992 */     v1.v = data[offset + 4] >> 8 & 0xFF;
/*       */     
/*  7994 */     drawModePacket(data[offset + 4]);
/*       */     
/*  7996 */     v2.x = data[offset + 5] << 20 >> 20;
/*  7997 */     v2.y = data[offset + 5] << 4 >> 20;
/*  7998 */     v2.u = data[offset + 6] & 0xFF;
/*  7999 */     v2.v = data[offset + 6] >> 8 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8005 */     switch (getTextureMode()) {
/*       */       case 0:
/*  8007 */         if (getPalette4(data[offset])) {
/*  8008 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8010 */               _T400001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/*  8013 */               _T400101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/*  8016 */               _T400011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*  8019 */           _T400111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/*  8023 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8025 */             _T400000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/*  8028 */             _T400100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/*  8031 */             _T400010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*  8034 */         _T400110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 128:
/*  8040 */         if (getPalette8(data[offset])) {
/*  8041 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8043 */               _T800001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/*  8046 */               _T800101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/*  8049 */               _T800011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*  8052 */           _T800111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/*  8056 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8058 */             _T800000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/*  8061 */             _T800100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/*  8064 */             _T800010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*  8067 */         _T800110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 256:
/*  8073 */         nobreg = false;
/*  8074 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  8075 */           nobreg = true;
/*       */         }
/*       */         
/*  8078 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8080 */             _T600000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/*  8083 */             _T600100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/*  8086 */             _T600010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*  8089 */         _T600110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32768:
/*  8095 */         if (getPalette4(data[offset])) {
/*  8096 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8098 */               _T500001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/*  8101 */               _T500101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/*  8104 */               _T500011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*  8107 */           _T500111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/*  8111 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8113 */             _T500000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/*  8116 */             _T500100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/*  8119 */             _T500010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*  8122 */         _T500110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32896:
/*  8128 */         if (getPalette8(data[offset])) {
/*  8129 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8131 */               _T900001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/*  8134 */               _T900101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/*  8137 */               _T900011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*  8140 */           _T900111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/*  8144 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8146 */             _T900000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/*  8149 */             _T900100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/*  8152 */             _T900010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*  8155 */         _T900110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 33024:
/*  8161 */         nobreg = false;
/*  8162 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  8163 */           nobreg = true;
/*       */         }
/*       */         
/*  8166 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8168 */             _T700000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/*  8171 */             _T700100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/*  8174 */             _T700010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*  8177 */         _T700110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */     } 
/*       */ 
/*       */     
/*  8182 */     return 0;
/*       */   }
/*       */   
/*  8185 */   static int[] m_tempPalette = new int[256];
/*       */ 
/*       */   
/*       */   public static boolean getPalette4(int val) {
/*  8189 */     int[] src = m_polygonInfo.clut;
/*  8190 */     int srcIndex = m_polygonInfo.clutOffset;
/*  8191 */     int first = src[srcIndex];
/*       */ 
/*       */     
/*  8194 */     if ((val & 0x1000000) != 0 || (val & 0xFFFFFF) == 8421504) {
/*  8195 */       if (0 != (first & 0x10000000)) {
/*  8196 */         return ((first & 0x20000000) != 0);
/*       */       }
/*  8198 */       boolean solid = true;
/*  8199 */       for (int i = 0; i < 16; i++) {
/*  8200 */         int current = src[srcIndex + i];
/*  8201 */         if (0 == (current & 0x1FFFFFF)) {
/*  8202 */           solid = false;
/*       */           
/*       */           break;
/*       */         } 
/*       */       } 
/*  8207 */       if (solid) {
/*  8208 */         src[srcIndex] = src[srcIndex] | 0x30000000;
/*       */       } else {
/*  8210 */         src[srcIndex] = src[srcIndex] & 0xDFFFFFFF | 0x10000000;
/*       */       } 
/*  8212 */       return solid;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8219 */     int rmul = val & 0xFF;
/*  8220 */     int gmul = val >> 8 & 0xFF;
/*  8221 */     int bmul = val >> 16 & 0xFF;
/*  8222 */     int[] dest = m_tempPalette;
/*  8223 */     boolean solid = true;
/*  8224 */     for (int i = 0; i < 16; i++) {
/*  8225 */       int current = src[srcIndex + i];
/*  8226 */       int b = current & 0xFF;
/*  8227 */       int g = current >> 8 & 0xFF;
/*  8228 */       int r = current >> 16 & 0xFF;
/*       */       
/*  8230 */       int mask = ((current & 0xFFFFFF) == 0) ? 0 : 1;
/*  8231 */       r = r * rmul >> 7;
/*  8232 */       if (r > 255) r = 255; 
/*  8233 */       g = g * gmul >> 7;
/*  8234 */       if (g > 255) g = 255; 
/*  8235 */       b = b * bmul >> 7;
/*  8236 */       if (b > 255) b = 255; 
/*  8237 */       dest[i] = current & 0x1000000 | r << 16 | g << 8 | b | mask;
/*  8238 */       if (dest[i] == 0) {
/*  8239 */         solid = false;
/*       */       }
/*       */     } 
/*  8242 */     m_polygonInfo.clut = dest;
/*  8243 */     m_polygonInfo.clutOffset = 0;
/*  8244 */     return solid;
/*       */   }
/*       */ 
/*       */   
/*       */   public static boolean getPalette8(int val) {
/*  8249 */     int[] src = m_polygonInfo.clut;
/*  8250 */     int srcIndex = m_polygonInfo.clutOffset;
/*  8251 */     int first = src[srcIndex];
/*       */     
/*  8253 */     if ((val & 0x1000000) != 0 || (val & 0xFFFFFF) == 8421504) {
/*  8254 */       if (0 != (first & 0x10000000)) {
/*  8255 */         return ((first & 0x20000000) != 0);
/*       */       }
/*  8257 */       boolean solid = true;
/*  8258 */       for (int i = 0; i < 256; i++) {
/*  8259 */         int current = src[srcIndex + i];
/*  8260 */         if (0 == (current & 0x1FFFFFF)) {
/*  8261 */           solid = false;
/*       */           
/*       */           break;
/*       */         } 
/*       */       } 
/*  8266 */       if (solid) {
/*  8267 */         src[srcIndex] = src[srcIndex] | 0x30000000;
/*       */       } else {
/*  8269 */         src[srcIndex] = src[srcIndex] & 0xDFFFFFFF | 0x10000000;
/*       */       } 
/*  8271 */       return solid;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8278 */     boolean solid = true;
/*  8279 */     int rmul = val & 0xFF;
/*  8280 */     int gmul = val >> 8 & 0xFF;
/*  8281 */     int bmul = val >> 16 & 0xFF;
/*  8282 */     int[] dest = m_tempPalette;
/*  8283 */     for (int i = 0; i < 256; i++) {
/*  8284 */       int current = src[srcIndex + i];
/*  8285 */       int b = current & 0xFF;
/*  8286 */       int g = current >> 8 & 0xFF;
/*  8287 */       int r = current >> 16 & 0xFF;
/*       */       
/*  8289 */       int mask = ((current & 0xFFFFFF) == 0) ? 0 : 1;
/*  8290 */       r = r * rmul >> 7;
/*  8291 */       if (r > 255) r = 255; 
/*  8292 */       g = g * gmul >> 7;
/*  8293 */       if (g > 255) g = 255; 
/*  8294 */       b = b * bmul >> 7;
/*  8295 */       if (b > 255) b = 255; 
/*  8296 */       dest[i] = current & 0x1000000 | r << 16 | g << 8 | b | mask;
/*  8297 */       if (dest[i] == 0) {
/*  8298 */         solid = false;
/*       */       }
/*       */     } 
/*  8301 */     m_polygonInfo.clut = dest;
/*  8302 */     m_polygonInfo.clutOffset = 0;
/*  8303 */     return solid;
/*       */   }
/*       */   public static int gpud3PointTextureSemi(int[] data, int offset, int size) {
/*       */     boolean nobreg, nobreg;
/*  8307 */     Vertex v0 = m_v0;
/*  8308 */     Vertex v1 = m_v1;
/*  8309 */     Vertex v2 = m_v2;
/*  8310 */     Vertex v3 = m_v3;
/*       */     
/*  8312 */     v0.x = data[offset + 1] << 20 >> 20;
/*  8313 */     v0.y = data[offset + 1] << 4 >> 20;
/*  8314 */     v0.u = data[offset + 2] & 0xFF;
/*  8315 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/*       */     
/*  8317 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/*  8318 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/*  8319 */     m_polygonInfo.clut = videoRAM;
/*  8320 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/*  8322 */     v1.x = data[offset + 3] << 20 >> 20;
/*  8323 */     v1.y = data[offset + 3] << 4 >> 20;
/*  8324 */     v1.u = data[offset + 4] & 0xFF;
/*  8325 */     v1.v = data[offset + 4] >> 8 & 0xFF;
/*       */     
/*  8327 */     drawModePacket(data[offset + 4]);
/*       */     
/*  8329 */     v2.x = data[offset + 5] << 20 >> 20;
/*  8330 */     v2.y = data[offset + 5] << 4 >> 20;
/*  8331 */     v2.u = data[offset + 6] & 0xFF;
/*  8332 */     v2.v = data[offset + 6] >> 8 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8338 */     switch (getTextureMode()) {
/*       */       case 0:
/*  8340 */         if (getPalette4(data[offset])) {
/*  8341 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8343 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8345 */                   _T401001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8348 */                   _T402001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8351 */                   _T403001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8354 */                   _T404001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  8359 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8361 */                   _T401101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8364 */                   _T402101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8367 */                   _T403101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8370 */                   _T404101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  8375 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8377 */                   _T401011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8380 */                   _T402011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8383 */                   _T403011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8386 */                   _T404011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  8391 */           switch (getSemiMode()) {
/*       */             case 0:
/*  8393 */               _T401111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/*  8396 */               _T402111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/*  8399 */               _T403111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/*  8402 */               _T404111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  8408 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8410 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8412 */                 _T401000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8415 */                 _T402000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8418 */                 _T403000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8421 */                 _T404000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  8426 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8428 */                 _T401100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8431 */                 _T402100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8434 */                 _T403100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8437 */                 _T404100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  8442 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8444 */                 _T401010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8447 */                 _T402010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8450 */                 _T403010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8453 */                 _T404010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  8458 */         switch (getSemiMode()) {
/*       */           case 0:
/*  8460 */             _T401110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  8463 */             _T402110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  8466 */             _T403110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  8469 */             _T404110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 128:
/*  8477 */         if (getPalette8(data[offset])) {
/*  8478 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8480 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8482 */                   _T801001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8485 */                   _T802001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8488 */                   _T803001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8491 */                   _T804001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  8496 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8498 */                   _T801101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8501 */                   _T802101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8504 */                   _T803101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8507 */                   _T804101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  8512 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8514 */                   _T801011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8517 */                   _T802011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8520 */                   _T803011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8523 */                   _T804011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  8528 */           switch (getSemiMode()) {
/*       */             case 0:
/*  8530 */               _T801111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/*  8533 */               _T802111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/*  8536 */               _T803111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/*  8539 */               _T804111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  8545 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8547 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8549 */                 _T801000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8552 */                 _T802000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8555 */                 _T803000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8558 */                 _T804000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  8563 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8565 */                 _T801100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8568 */                 _T802100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8571 */                 _T803100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8574 */                 _T804100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  8579 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8581 */                 _T801010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8584 */                 _T802010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8587 */                 _T803010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8590 */                 _T804010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  8595 */         switch (getSemiMode()) {
/*       */           case 0:
/*  8597 */             _T801110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  8600 */             _T802110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  8603 */             _T803110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  8606 */             _T804110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 256:
/*  8614 */         nobreg = false;
/*  8615 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  8616 */           nobreg = true;
/*       */         }
/*       */         
/*  8619 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8621 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8623 */                 _T601000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8626 */                 _T602000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8629 */                 _T603000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8632 */                 _T604000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  8637 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8639 */                 _T601100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8642 */                 _T602100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8645 */                 _T603100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8648 */                 _T604100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  8653 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8655 */                 _T601010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8658 */                 _T602010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8661 */                 _T603010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8664 */                 _T604010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  8669 */         switch (getSemiMode()) {
/*       */           case 0:
/*  8671 */             _T601110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  8674 */             _T602110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  8677 */             _T603110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  8680 */             _T604110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32768:
/*  8688 */         if (getPalette4(data[offset])) {
/*  8689 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8691 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8693 */                   _T501001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8696 */                   _T502001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8699 */                   _T503001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8702 */                   _T504001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  8707 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8709 */                   _T501101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8712 */                   _T502101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8715 */                   _T503101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8718 */                   _T504101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  8723 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8725 */                   _T501011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8728 */                   _T502011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8731 */                   _T503011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8734 */                   _T504011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  8739 */           switch (getSemiMode()) {
/*       */             case 0:
/*  8741 */               _T501111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/*  8744 */               _T502111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/*  8747 */               _T503111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/*  8750 */               _T504111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  8756 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8758 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8760 */                 _T501000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8763 */                 _T502000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8766 */                 _T503000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8769 */                 _T504000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  8774 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8776 */                 _T501100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8779 */                 _T502100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8782 */                 _T503100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8785 */                 _T504100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  8790 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8792 */                 _T501010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8795 */                 _T502010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8798 */                 _T503010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8801 */                 _T504010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  8806 */         switch (getSemiMode()) {
/*       */           case 0:
/*  8808 */             _T501110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  8811 */             _T502110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  8814 */             _T503110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  8817 */             _T504110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32896:
/*  8825 */         if (getPalette8(data[offset])) {
/*  8826 */           switch (getMaskModes()) {
/*       */             case 0:
/*  8828 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8830 */                   _T901001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8833 */                   _T902001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8836 */                   _T903001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8839 */                   _T904001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  8844 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8846 */                   _T901101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8849 */                   _T902101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8852 */                   _T903101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8855 */                   _T904101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  8860 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  8862 */                   _T901011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/*  8865 */                   _T902011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/*  8868 */                   _T903011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/*  8871 */                   _T904011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  8876 */           switch (getSemiMode()) {
/*       */             case 0:
/*  8878 */               _T901111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/*  8881 */               _T902111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/*  8884 */               _T903111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/*  8887 */               _T904111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  8893 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8895 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8897 */                 _T901000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8900 */                 _T902000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8903 */                 _T903000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8906 */                 _T904000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  8911 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8913 */                 _T901100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8916 */                 _T902100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8919 */                 _T903100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8922 */                 _T904100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  8927 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8929 */                 _T901010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8932 */                 _T902010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8935 */                 _T903010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8938 */                 _T904010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  8943 */         switch (getSemiMode()) {
/*       */           case 0:
/*  8945 */             _T901110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  8948 */             _T902110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  8951 */             _T903110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  8954 */             _T904110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 33024:
/*  8962 */         nobreg = false;
/*  8963 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  8964 */           nobreg = true;
/*       */         }
/*       */         
/*  8967 */         switch (getMaskModes()) {
/*       */           case 0:
/*  8969 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8971 */                 _T701000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8974 */                 _T702000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8977 */                 _T703000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8980 */                 _T704000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  8985 */             switch (getSemiMode()) {
/*       */               case 0:
/*  8987 */                 _T701100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  8990 */                 _T702100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  8993 */                 _T703100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  8996 */                 _T704100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  9001 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9003 */                 _T701010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/*  9006 */                 _T702010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/*  9009 */                 _T703010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/*  9012 */                 _T704010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  9017 */         switch (getSemiMode()) {
/*       */           case 0:
/*  9019 */             _T701110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/*  9022 */             _T702110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/*  9025 */             _T703110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/*  9028 */             _T704110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */     } 
/*       */     
/*  9035 */     return 0;
/*       */   }
/*       */ 
/*       */   
/*  9039 */   private static String colorString(int r, int g, int b) { return "(" + MiscUtil.toHex(r, 2) + "," + MiscUtil.toHex(g, 2) + "," + MiscUtil.toHex(b, 2) + ")"; }
/*       */ 
/*       */   
/*       */   public static int gpud4PointFlat(int[] data, int offset, int size) {
/*  9043 */     Vertex v0 = m_v0;
/*  9044 */     Vertex v1 = m_v1;
/*  9045 */     Vertex v2 = m_v2;
/*  9046 */     Vertex v3 = m_v3;
/*       */     
/*  9048 */     v0.x = data[offset + 1] << 20 >> 20;
/*  9049 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/*  9051 */     v1.x = data[offset + 2] << 20 >> 20;
/*  9052 */     v1.y = data[offset + 2] << 4 >> 20;
/*       */     
/*  9054 */     v2.x = data[offset + 3] << 20 >> 20;
/*  9055 */     v2.y = data[offset + 3] << 4 >> 20;
/*       */     
/*  9057 */     v3.x = data[offset + 4] << 20 >> 20;
/*  9058 */     v3.y = data[offset + 4] << 4 >> 20;
/*       */     
/*  9060 */     m_polygonInfo.r = data[offset] & 0xFF;
/*  9061 */     m_polygonInfo.g = data[offset] >> 8 & 0xFF;
/*  9062 */     m_polygonInfo.b = data[offset] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9069 */     switch (getMaskModes())
/*       */     { case 0:
/*  9071 */         _Q000000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  9083 */         return 0;case 2048: _Q000100.render(m_polygonInfo, v0, v1, v2, v3); return 0;case 4096: _Q000010.render(m_polygonInfo, v0, v1, v2, v3); return 0; }  _Q000110.render(m_polygonInfo, v0, v1, v2, v3); return 0;
/*       */   }
/*       */   
/*       */   public static int gpud4PointFlatSemi(int[] data, int offset, int size) {
/*  9087 */     Vertex v0 = m_v0;
/*  9088 */     Vertex v1 = m_v1;
/*  9089 */     Vertex v2 = m_v2;
/*  9090 */     Vertex v3 = m_v3;
/*       */     
/*  9092 */     v0.x = data[offset + 1] << 20 >> 20;
/*  9093 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/*  9095 */     v1.x = data[offset + 2] << 20 >> 20;
/*  9096 */     v1.y = data[offset + 2] << 4 >> 20;
/*       */     
/*  9098 */     v2.x = data[offset + 3] << 20 >> 20;
/*  9099 */     v2.y = data[offset + 3] << 4 >> 20;
/*       */     
/*  9101 */     v3.x = data[offset + 4] << 20 >> 20;
/*  9102 */     v3.y = data[offset + 4] << 4 >> 20;
/*       */     
/*  9104 */     m_polygonInfo.r = data[offset] & 0xFF;
/*  9105 */     m_polygonInfo.g = data[offset] >> 8 & 0xFF;
/*  9106 */     m_polygonInfo.b = data[offset] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9111 */     switch (getMaskModes())
/*       */     { case 0:
/*  9113 */         switch (getSemiMode()) {
/*       */           case 0:
/*  9115 */             _Q001000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/*  9118 */             _Q002000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/*  9121 */             _Q003000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/*  9124 */             _Q004000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  9177 */         return 0;case 2048: switch (getSemiMode()) { case 0: _Q001100.render(m_polygonInfo, v0, v1, v2, v3); break;case 32: _Q002100.render(m_polygonInfo, v0, v1, v2, v3); break;case 64: _Q003100.render(m_polygonInfo, v0, v1, v2, v3); break;case 96: _Q004100.render(m_polygonInfo, v0, v1, v2, v3); break; }  return 0;case 4096: switch (getSemiMode()) { case 0: _Q001010.render(m_polygonInfo, v0, v1, v2, v3); break;case 32: _Q002010.render(m_polygonInfo, v0, v1, v2, v3); break;case 64: _Q003010.render(m_polygonInfo, v0, v1, v2, v3); break;case 96: _Q004010.render(m_polygonInfo, v0, v1, v2, v3); break; }  return 0; }  switch (getSemiMode()) { case 0: _Q001110.render(m_polygonInfo, v0, v1, v2, v3); break;case 32: _Q002110.render(m_polygonInfo, v0, v1, v2, v3); break;case 64: _Q003110.render(m_polygonInfo, v0, v1, v2, v3); break;case 96: _Q004110.render(m_polygonInfo, v0, v1, v2, v3); break; }  return 0;
/*       */   }
/*       */   public static int gpud4PointTexture(int[] data, int offset, int size) {
/*       */     boolean nobreg, nobreg;
/*  9181 */     Vertex v0 = m_v0;
/*  9182 */     Vertex v1 = m_v1;
/*  9183 */     Vertex v2 = m_v2;
/*  9184 */     Vertex v3 = m_v3;
/*       */     
/*  9186 */     v0.x = data[offset + 1] << 20 >> 20;
/*  9187 */     v0.y = data[offset + 1] << 4 >> 20;
/*  9188 */     v0.u = data[offset + 2] & 0xFF;
/*  9189 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/*       */     
/*  9191 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/*  9192 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/*  9193 */     m_polygonInfo.clut = videoRAM;
/*  9194 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/*  9196 */     v1.x = data[offset + 3] << 20 >> 20;
/*  9197 */     v1.y = data[offset + 3] << 4 >> 20;
/*  9198 */     v1.u = data[offset + 4] & 0xFF;
/*  9199 */     v1.v = data[offset + 4] >> 8 & 0xFF;
/*       */     
/*  9201 */     drawModePacket(data[offset + 4]);
/*       */     
/*  9203 */     v2.x = data[offset + 5] << 20 >> 20;
/*  9204 */     v2.y = data[offset + 5] << 4 >> 20;
/*  9205 */     v2.u = data[offset + 6] & 0xFF;
/*  9206 */     v2.v = data[offset + 6] >> 8 & 0xFF;
/*       */     
/*  9208 */     v3.x = data[offset + 7] << 20 >> 20;
/*  9209 */     v3.y = data[offset + 7] << 4 >> 20;
/*  9210 */     v3.u = data[offset + 8] & 0xFF;
/*  9211 */     v3.v = data[offset + 8] >> 8 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9217 */     switch (getTextureMode()) {
/*       */       case 0:
/*  9219 */         if (getPalette4(data[offset])) {
/*  9220 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9222 */               _Q400001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/*  9225 */               _Q400101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/*  9228 */               _Q400011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*  9231 */           _Q400111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/*  9235 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9237 */             _Q400000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/*  9240 */             _Q400100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/*  9243 */             _Q400010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*  9246 */         _Q400110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 128:
/*  9252 */         if (getPalette8(data[offset])) {
/*  9253 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9255 */               _Q800001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/*  9258 */               _Q800101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/*  9261 */               _Q800011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*  9264 */           _Q800111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/*  9268 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9270 */             _Q800000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/*  9273 */             _Q800100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/*  9276 */             _Q800010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*  9279 */         _Q800110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 256:
/*  9285 */         nobreg = false;
/*  9286 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  9287 */           nobreg = true;
/*       */         }
/*       */         
/*  9290 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9292 */             _Q600000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/*  9295 */             _Q600100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/*  9298 */             _Q600010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*  9301 */         _Q600110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32768:
/*  9307 */         if (getPalette4(data[offset])) {
/*  9308 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9310 */               _Q500001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/*  9313 */               _Q500101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/*  9316 */               _Q500011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*  9319 */           _Q500111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/*  9323 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9325 */             _Q500000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/*  9328 */             _Q500100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/*  9331 */             _Q500010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*  9334 */         _Q500110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32896:
/*  9340 */         if (getPalette8(data[offset])) {
/*  9341 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9343 */               _Q900001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/*  9346 */               _Q900101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/*  9349 */               _Q900011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*  9352 */           _Q900111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/*  9356 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9358 */             _Q900000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/*  9361 */             _Q900100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/*  9364 */             _Q900010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*  9367 */         _Q900110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 33024:
/*  9373 */         nobreg = false;
/*  9374 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  9375 */           nobreg = true;
/*       */         }
/*       */         
/*  9378 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9380 */             _Q700000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/*  9383 */             _Q700100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/*  9386 */             _Q700010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*  9389 */         _Q700110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */     } 
/*       */ 
/*       */     
/*  9394 */     return 0;
/*       */   }
/*       */   public static int gpud4PointTextureSemi(int[] data, int offset, int size) {
/*       */     boolean nobreg, nobreg;
/*  9398 */     Vertex v0 = m_v0;
/*  9399 */     Vertex v1 = m_v1;
/*  9400 */     Vertex v2 = m_v2;
/*  9401 */     Vertex v3 = m_v3;
/*       */     
/*  9403 */     v0.x = data[offset + 1] << 20 >> 20;
/*  9404 */     v0.y = data[offset + 1] << 4 >> 20;
/*  9405 */     v0.u = data[offset + 2] & 0xFF;
/*  9406 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/*       */     
/*  9408 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/*  9409 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/*  9410 */     m_polygonInfo.clut = videoRAM;
/*  9411 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/*  9413 */     v1.x = data[offset + 3] << 20 >> 20;
/*  9414 */     v1.y = data[offset + 3] << 4 >> 20;
/*  9415 */     v1.u = data[offset + 4] & 0xFF;
/*  9416 */     v1.v = data[offset + 4] >> 8 & 0xFF;
/*       */     
/*  9418 */     drawModePacket(data[offset + 4]);
/*       */     
/*  9420 */     v2.x = data[offset + 5] << 20 >> 20;
/*  9421 */     v2.y = data[offset + 5] << 4 >> 20;
/*  9422 */     v2.u = data[offset + 6] & 0xFF;
/*  9423 */     v2.v = data[offset + 6] >> 8 & 0xFF;
/*       */     
/*  9425 */     v3.x = data[offset + 7] << 20 >> 20;
/*  9426 */     v3.y = data[offset + 7] << 4 >> 20;
/*  9427 */     v3.u = data[offset + 8] & 0xFF;
/*  9428 */     v3.v = data[offset + 8] >> 8 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9434 */     switch (getTextureMode()) {
/*       */       case 0:
/*  9436 */         if (getPalette4(data[offset])) {
/*  9437 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9439 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9441 */                   _Q401001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9444 */                   _Q402001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9447 */                   _Q403001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9450 */                   _Q404001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  9455 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9457 */                   _Q401101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9460 */                   _Q402101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9463 */                   _Q403101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9466 */                   _Q404101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  9471 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9473 */                   _Q401011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9476 */                   _Q402011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9479 */                   _Q403011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9482 */                   _Q404011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  9487 */           switch (getSemiMode()) {
/*       */             case 0:
/*  9489 */               _Q401111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/*  9492 */               _Q402111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/*  9495 */               _Q403111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/*  9498 */               _Q404111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  9504 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9506 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9508 */                 _Q401000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9511 */                 _Q402000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9514 */                 _Q403000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9517 */                 _Q404000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  9522 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9524 */                 _Q401100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9527 */                 _Q402100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9530 */                 _Q403100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9533 */                 _Q404100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  9538 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9540 */                 _Q401010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9543 */                 _Q402010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9546 */                 _Q403010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9549 */                 _Q404010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  9554 */         switch (getSemiMode()) {
/*       */           case 0:
/*  9556 */             _Q401110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/*  9559 */             _Q402110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/*  9562 */             _Q403110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/*  9565 */             _Q404110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 128:
/*  9573 */         if (getPalette8(data[offset])) {
/*  9574 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9576 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9578 */                   _Q801001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9581 */                   _Q802001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9584 */                   _Q803001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9587 */                   _Q804001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  9592 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9594 */                   _Q801101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9597 */                   _Q802101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9600 */                   _Q803101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9603 */                   _Q804101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  9608 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9610 */                   _Q801011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9613 */                   _Q802011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9616 */                   _Q803011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9619 */                   _Q804011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  9624 */           switch (getSemiMode()) {
/*       */             case 0:
/*  9626 */               _Q801111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/*  9629 */               _Q802111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/*  9632 */               _Q803111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/*  9635 */               _Q804111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  9641 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9643 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9645 */                 _Q801000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9648 */                 _Q802000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9651 */                 _Q803000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9654 */                 _Q804000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  9659 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9661 */                 _Q801100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9664 */                 _Q802100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9667 */                 _Q803100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9670 */                 _Q804100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  9675 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9677 */                 _Q801010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9680 */                 _Q802010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9683 */                 _Q803010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9686 */                 _Q804010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  9691 */         switch (getSemiMode()) {
/*       */           case 0:
/*  9693 */             _Q801110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/*  9696 */             _Q802110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/*  9699 */             _Q803110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/*  9702 */             _Q804110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 256:
/*  9710 */         nobreg = false;
/*  9711 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/*  9712 */           nobreg = true;
/*       */         }
/*       */         
/*  9715 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9717 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9719 */                 _Q601000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9722 */                 _Q602000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9725 */                 _Q603000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9728 */                 _Q604000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  9733 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9735 */                 _Q601100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9738 */                 _Q602100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9741 */                 _Q603100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9744 */                 _Q604100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  9749 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9751 */                 _Q601010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9754 */                 _Q602010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9757 */                 _Q603010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9760 */                 _Q604010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  9765 */         switch (getSemiMode()) {
/*       */           case 0:
/*  9767 */             _Q601110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/*  9770 */             _Q602110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/*  9773 */             _Q603110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/*  9776 */             _Q604110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32768:
/*  9784 */         if (getPalette4(data[offset])) {
/*  9785 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9787 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9789 */                   _Q501001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9792 */                   _Q502001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9795 */                   _Q503001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9798 */                   _Q504001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  9803 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9805 */                   _Q501101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9808 */                   _Q502101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9811 */                   _Q503101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9814 */                   _Q504101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  9819 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9821 */                   _Q501011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9824 */                   _Q502011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9827 */                   _Q503011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9830 */                   _Q504011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  9835 */           switch (getSemiMode()) {
/*       */             case 0:
/*  9837 */               _Q501111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/*  9840 */               _Q502111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/*  9843 */               _Q503111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/*  9846 */               _Q504111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  9852 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9854 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9856 */                 _Q501000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9859 */                 _Q502000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9862 */                 _Q503000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9865 */                 _Q504000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/*  9870 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9872 */                 _Q501100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9875 */                 _Q502100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9878 */                 _Q503100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9881 */                 _Q504100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/*  9886 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9888 */                 _Q501010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9891 */                 _Q502010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9894 */                 _Q503010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/*  9897 */                 _Q504010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/*  9902 */         switch (getSemiMode()) {
/*       */           case 0:
/*  9904 */             _Q501110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/*  9907 */             _Q502110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/*  9910 */             _Q503110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/*  9913 */             _Q504110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32896:
/*  9921 */         if (getPalette8(data[offset])) {
/*  9922 */           switch (getMaskModes()) {
/*       */             case 0:
/*  9924 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9926 */                   _Q901001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9929 */                   _Q902001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9932 */                   _Q903001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9935 */                   _Q904001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/*  9940 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9942 */                   _Q901101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9945 */                   _Q902101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9948 */                   _Q903101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9951 */                   _Q904101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/*  9956 */               switch (getSemiMode()) {
/*       */                 case 0:
/*  9958 */                   _Q901011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/*  9961 */                   _Q902011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/*  9964 */                   _Q903011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/*  9967 */                   _Q904011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/*  9972 */           switch (getSemiMode()) {
/*       */             case 0:
/*  9974 */               _Q901111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/*  9977 */               _Q902111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/*  9980 */               _Q903111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/*  9983 */               _Q904111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/*  9989 */         switch (getMaskModes()) {
/*       */           case 0:
/*  9991 */             switch (getSemiMode()) {
/*       */               case 0:
/*  9993 */                 _Q901000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/*  9996 */                 _Q902000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/*  9999 */                 _Q903000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 10002 */                 _Q904000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 10007 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10009 */                 _Q901100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 10012 */                 _Q902100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 10015 */                 _Q903100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 10018 */                 _Q904100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 10023 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10025 */                 _Q901010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 10028 */                 _Q902010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 10031 */                 _Q903010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 10034 */                 _Q904010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 10039 */         switch (getSemiMode()) {
/*       */           case 0:
/* 10041 */             _Q901110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 10044 */             _Q902110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 10047 */             _Q903110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 10050 */             _Q904110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 33024:
/* 10058 */         nobreg = false;
/* 10059 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/* 10060 */           nobreg = true;
/*       */         }
/*       */         
/* 10063 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10065 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10067 */                 _Q701000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 10070 */                 _Q702000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 10073 */                 _Q703000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 10076 */                 _Q704000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 10081 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10083 */                 _Q701100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 10086 */                 _Q702100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 10089 */                 _Q703100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 10092 */                 _Q704100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 10097 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10099 */                 _Q701010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 10102 */                 _Q702010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 10105 */                 _Q703010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 10108 */                 _Q704010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 10113 */         switch (getSemiMode()) {
/*       */           case 0:
/* 10115 */             _Q701110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 10118 */             _Q702110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 10121 */             _Q703110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 10124 */             _Q704110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */     } 
/*       */     
/* 10131 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud3PointGouraud(int[] data, int offset, int size) {
/* 10135 */     Vertex v0 = m_v0;
/* 10136 */     Vertex v1 = m_v1;
/* 10137 */     Vertex v2 = m_v2;
/*       */     
/* 10139 */     v0.x = data[offset + 1] << 20 >> 20;
/* 10140 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/* 10142 */     v0.r = data[offset] & 0xFF;
/* 10143 */     v0.g = data[offset] >> 8 & 0xFF;
/* 10144 */     v0.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 10146 */     v1.x = data[offset + 3] << 20 >> 20;
/* 10147 */     v1.y = data[offset + 3] << 4 >> 20;
/*       */     
/* 10149 */     v1.r = data[offset + 2] & 0xFF;
/* 10150 */     v1.g = data[offset + 2] >> 8 & 0xFF;
/* 10151 */     v1.b = data[offset + 2] >> 16 & 0xFF;
/*       */     
/* 10153 */     v2.x = data[offset + 5] << 20 >> 20;
/* 10154 */     v2.y = data[offset + 5] << 4 >> 20;
/*       */     
/* 10156 */     v2.r = data[offset + 4] & 0xFF;
/* 10157 */     v2.g = data[offset + 4] >> 8 & 0xFF;
/* 10158 */     v2.b = data[offset + 4] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10164 */     switch (getMaskModes())
/*       */     { case 0:
/* 10166 */         _T010001.render(m_polygonInfo, v0, v1, v2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 10178 */         return 0;case 2048: _T010101.render(m_polygonInfo, v0, v1, v2); return 0;case 4096: _T010011.render(m_polygonInfo, v0, v1, v2); return 0; }  _T010111.render(m_polygonInfo, v0, v1, v2); return 0;
/*       */   }
/*       */   
/*       */   public static int gpud3PointGouraudSemi(int[] data, int offset, int size) {
/* 10182 */     Vertex v0 = m_v0;
/* 10183 */     Vertex v1 = m_v1;
/* 10184 */     Vertex v2 = m_v2;
/*       */     
/* 10186 */     v0.r = data[offset] & 0xFF;
/* 10187 */     v0.g = data[offset] >> 8 & 0xFF;
/* 10188 */     v0.b = data[offset] >> 16 & 0xFF;
/* 10189 */     v0.x = data[offset + 1] << 20 >> 20;
/* 10190 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/* 10192 */     v1.r = data[offset + 2] & 0xFF;
/* 10193 */     v1.g = data[offset + 2] >> 8 & 0xFF;
/* 10194 */     v1.b = data[offset + 2] >> 16 & 0xFF;
/* 10195 */     v1.x = data[offset + 3] << 20 >> 20;
/* 10196 */     v1.y = data[offset + 3] << 4 >> 20;
/*       */     
/* 10198 */     v2.r = data[offset + 4] & 0xFF;
/* 10199 */     v2.g = data[offset + 4] >> 8 & 0xFF;
/* 10200 */     v2.b = data[offset + 4] >> 16 & 0xFF;
/* 10201 */     v2.x = data[offset + 5] << 20 >> 20;
/* 10202 */     v2.y = data[offset + 5] << 4 >> 20;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10208 */     switch (getSemiMode()) {
/*       */       case 0:
/* 10210 */         _T011000.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */       case 32:
/* 10213 */         _T012000.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */       case 64:
/* 10216 */         _T013000.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */       case 96:
/* 10219 */         _T014000.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */     } 
/* 10222 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud3PointTextureGouraud(int[] data, int offset, int size) {
/* 10226 */     Vertex v0 = m_v0;
/* 10227 */     Vertex v1 = m_v1;
/* 10228 */     Vertex v2 = m_v2;
/*       */     
/* 10230 */     v0.x = data[offset + 1] << 20 >> 20;
/* 10231 */     v0.y = data[offset + 1] << 4 >> 20;
/* 10232 */     v0.u = data[offset + 2] & 0xFF;
/* 10233 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/* 10234 */     v0.r = data[offset] & 0xFF;
/* 10235 */     v0.g = data[offset] >> 8 & 0xFF;
/* 10236 */     v0.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 10238 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/* 10239 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/* 10240 */     m_polygonInfo.clut = videoRAM;
/* 10241 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/* 10243 */     v1.x = data[offset + 4] << 20 >> 20;
/* 10244 */     v1.y = data[offset + 4] << 4 >> 20;
/* 10245 */     v1.u = data[offset + 5] & 0xFF;
/* 10246 */     v1.v = data[offset + 5] >> 8 & 0xFF;
/* 10247 */     v1.r = data[offset + 3] & 0xFF;
/* 10248 */     v1.g = data[offset + 3] >> 8 & 0xFF;
/* 10249 */     v1.b = data[offset + 3] >> 16 & 0xFF;
/*       */     
/* 10251 */     drawModePacket(data[offset + 5]);
/*       */     
/* 10253 */     v2.x = data[offset + 7] << 20 >> 20;
/* 10254 */     v2.y = data[offset + 7] << 4 >> 20;
/* 10255 */     v2.u = data[offset + 8] & 0xFF;
/* 10256 */     v2.v = data[offset + 8] >> 8 & 0xFF;
/* 10257 */     v2.r = data[offset + 6] & 0xFF;
/* 10258 */     v2.g = data[offset + 6] >> 8 & 0xFF;
/* 10259 */     v2.b = data[offset + 6] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10265 */     switch (getTextureMode()) {
/*       */       case 0:
/* 10267 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 10268 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10270 */               _T410001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/* 10273 */               _T410101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/* 10276 */               _T410011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/* 10279 */           _T410111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/* 10283 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10285 */             _T410000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/* 10288 */             _T410100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/* 10291 */             _T410010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/* 10294 */         _T410110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 128:
/* 10300 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 10301 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10303 */               _T810001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/* 10306 */               _T810101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/* 10309 */               _T810011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/* 10312 */           _T810111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/* 10316 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10318 */             _T810000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/* 10321 */             _T810100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/* 10324 */             _T810010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/* 10327 */         _T810110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 256:
/* 10333 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10335 */             _T610000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/* 10338 */             _T610100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/* 10341 */             _T610010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/* 10344 */         _T610110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */       
/*       */       case 32768:
/* 10349 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 10350 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10352 */               _T510001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/* 10355 */               _T510101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/* 10358 */               _T510011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/* 10361 */           _T510111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/* 10365 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10367 */             _T510000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/* 10370 */             _T510100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/* 10373 */             _T510010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/* 10376 */         _T510110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32896:
/* 10382 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 10383 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10385 */               _T910001.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 2048:
/* 10388 */               _T910101.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 4096:
/* 10391 */               _T910011.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/* 10394 */           _T910111.render(m_polygonInfo, v0, v1, v2);
/*       */           
/*       */           break;
/*       */         } 
/* 10398 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10400 */             _T910000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/* 10403 */             _T910100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/* 10406 */             _T910010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/* 10409 */         _T910110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 33024:
/* 10415 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10417 */             _T710000.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 2048:
/* 10420 */             _T710100.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 4096:
/* 10423 */             _T710010.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/* 10426 */         _T710110.render(m_polygonInfo, v0, v1, v2);
/*       */         break;
/*       */     } 
/*       */     
/* 10430 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud3PointTextureGouraudSemi(int[] data, int offset, int size) {
/* 10434 */     Vertex v0 = m_v0;
/* 10435 */     Vertex v1 = m_v1;
/* 10436 */     Vertex v2 = m_v2;
/*       */     
/* 10438 */     v0.x = data[offset + 1] << 20 >> 20;
/* 10439 */     v0.y = data[offset + 1] << 4 >> 20;
/* 10440 */     v0.u = data[offset + 2] & 0xFF;
/* 10441 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/* 10442 */     v0.r = data[offset] & 0xFF;
/* 10443 */     v0.g = data[offset] >> 8 & 0xFF;
/* 10444 */     v0.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 10446 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/* 10447 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/* 10448 */     m_polygonInfo.clut = videoRAM;
/* 10449 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/* 10451 */     v1.x = data[offset + 4] << 20 >> 20;
/* 10452 */     v1.y = data[offset + 4] << 4 >> 20;
/* 10453 */     v1.u = data[offset + 5] & 0xFF;
/* 10454 */     v1.v = data[offset + 5] >> 8 & 0xFF;
/* 10455 */     v1.r = data[offset + 3] & 0xFF;
/* 10456 */     v1.g = data[offset + 3] >> 8 & 0xFF;
/* 10457 */     v1.b = data[offset + 3] >> 16 & 0xFF;
/*       */     
/* 10459 */     drawModePacket(data[offset + 5]);
/*       */     
/* 10461 */     v2.x = data[offset + 7] << 20 >> 20;
/* 10462 */     v2.y = data[offset + 7] << 4 >> 20;
/* 10463 */     v2.u = data[offset + 8] & 0xFF;
/* 10464 */     v2.v = data[offset + 8] >> 8 & 0xFF;
/* 10465 */     v2.r = data[offset + 6] & 0xFF;
/* 10466 */     v2.g = data[offset + 6] >> 8 & 0xFF;
/* 10467 */     v2.b = data[offset + 6] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10473 */     switch (getTextureMode()) {
/*       */       case 0:
/* 10475 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 10476 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10478 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10480 */                   _T411001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10483 */                   _T412001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10486 */                   _T413001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10489 */                   _T414001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 10494 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10496 */                   _T411101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10499 */                   _T412101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10502 */                   _T413101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10505 */                   _T414101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 10510 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10512 */                   _T411011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10515 */                   _T412011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10518 */                   _T413011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10521 */                   _T414011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 10526 */           switch (getSemiMode()) {
/*       */             case 0:
/* 10528 */               _T411111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/* 10531 */               _T412111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/* 10534 */               _T413111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/* 10537 */               _T414111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 10543 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10545 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10547 */                 _T411000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10550 */                 _T412000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10553 */                 _T413000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10556 */                 _T414000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 10561 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10563 */                 _T411100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10566 */                 _T412100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10569 */                 _T413100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10572 */                 _T414100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 10577 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10579 */                 _T411010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10582 */                 _T412010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10585 */                 _T413010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10588 */                 _T414010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 10593 */         switch (getSemiMode()) {
/*       */           case 0:
/* 10595 */             _T411110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/* 10598 */             _T412110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/* 10601 */             _T413110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/* 10604 */             _T414110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 128:
/* 10612 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 10613 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10615 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10617 */                   _T811001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10620 */                   _T812001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10623 */                   _T813001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10626 */                   _T814001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 10631 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10633 */                   _T811101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10636 */                   _T812101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10639 */                   _T813101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10642 */                   _T814101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 10647 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10649 */                   _T811011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10652 */                   _T812011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10655 */                   _T813011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10658 */                   _T814011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 10663 */           switch (getSemiMode()) {
/*       */             case 0:
/* 10665 */               _T811111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/* 10668 */               _T812111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/* 10671 */               _T813111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/* 10674 */               _T814111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 10680 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10682 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10684 */                 _T811000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10687 */                 _T812000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10690 */                 _T813000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10693 */                 _T814000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 10698 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10700 */                 _T811100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10703 */                 _T812100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10706 */                 _T813100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10709 */                 _T814100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 10714 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10716 */                 _T811010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10719 */                 _T812010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10722 */                 _T813010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10725 */                 _T814010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 10730 */         switch (getSemiMode()) {
/*       */           case 0:
/* 10732 */             _T811110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/* 10735 */             _T812110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/* 10738 */             _T813110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/* 10741 */             _T814110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 256:
/* 10749 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10751 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10753 */                 _T611000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10756 */                 _T612000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10759 */                 _T613000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10762 */                 _T614000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 10767 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10769 */                 _T611100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10772 */                 _T612100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10775 */                 _T613100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10778 */                 _T614100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 10783 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10785 */                 _T611010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10788 */                 _T612010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10791 */                 _T613010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10794 */                 _T614010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 10799 */         switch (getSemiMode()) {
/*       */           case 0:
/* 10801 */             _T611110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/* 10804 */             _T612110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/* 10807 */             _T613110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/* 10810 */             _T614110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32768:
/* 10817 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 10818 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10820 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10822 */                   _T511001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10825 */                   _T512001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10828 */                   _T513001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10831 */                   _T514001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 10836 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10838 */                   _T511101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10841 */                   _T512101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10844 */                   _T513101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10847 */                   _T514101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 10852 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10854 */                   _T511011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10857 */                   _T512011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10860 */                   _T513011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10863 */                   _T514011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 10868 */           switch (getSemiMode()) {
/*       */             case 0:
/* 10870 */               _T511111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/* 10873 */               _T512111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/* 10876 */               _T513111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/* 10879 */               _T514111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 10885 */         switch (getMaskModes()) {
/*       */           case 0:
/* 10887 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10889 */                 _T511000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10892 */                 _T512000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10895 */                 _T513000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10898 */                 _T514000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 10903 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10905 */                 _T511100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10908 */                 _T512100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10911 */                 _T513100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10914 */                 _T514100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 10919 */             switch (getSemiMode()) {
/*       */               case 0:
/* 10921 */                 _T511010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 10924 */                 _T512010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 10927 */                 _T513010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 10930 */                 _T514010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 10935 */         switch (getSemiMode()) {
/*       */           case 0:
/* 10937 */             _T511110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/* 10940 */             _T512110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/* 10943 */             _T513110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/* 10946 */             _T514110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32896:
/* 10954 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 10955 */           switch (getMaskModes()) {
/*       */             case 0:
/* 10957 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10959 */                   _T911001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10962 */                   _T912001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10965 */                   _T913001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10968 */                   _T914001.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 10973 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10975 */                   _T911101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10978 */                   _T912101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10981 */                   _T913101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 10984 */                   _T914101.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 10989 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 10991 */                   _T911011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 32:
/* 10994 */                   _T912011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 64:
/* 10997 */                   _T913011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */                 case 96:
/* 11000 */                   _T914011.render(m_polygonInfo, v0, v1, v2);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 11005 */           switch (getSemiMode()) {
/*       */             case 0:
/* 11007 */               _T911111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 32:
/* 11010 */               _T912111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 64:
/* 11013 */               _T913111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */             case 96:
/* 11016 */               _T914111.render(m_polygonInfo, v0, v1, v2);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 11022 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11024 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11026 */                 _T911000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 11029 */                 _T912000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 11032 */                 _T913000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 11035 */                 _T914000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 11040 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11042 */                 _T911100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 11045 */                 _T912100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 11048 */                 _T913100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 11051 */                 _T914100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 11056 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11058 */                 _T911010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 11061 */                 _T912010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 11064 */                 _T913010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 11067 */                 _T914010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 11072 */         switch (getSemiMode()) {
/*       */           case 0:
/* 11074 */             _T911110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/* 11077 */             _T912110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/* 11080 */             _T913110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/* 11083 */             _T914110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 33024:
/* 11091 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11093 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11095 */                 _T711000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 11098 */                 _T712000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 11101 */                 _T713000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 11104 */                 _T714000.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 11109 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11111 */                 _T711100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 11114 */                 _T712100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 11117 */                 _T713100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 11120 */                 _T714100.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 11125 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11127 */                 _T711010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 32:
/* 11130 */                 _T712010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 64:
/* 11133 */                 _T713010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */               case 96:
/* 11136 */                 _T714010.render(m_polygonInfo, v0, v1, v2);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 11141 */         switch (getSemiMode()) {
/*       */           case 0:
/* 11143 */             _T711110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 32:
/* 11146 */             _T712110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 64:
/* 11149 */             _T713110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */           case 96:
/* 11152 */             _T714110.render(m_polygonInfo, v0, v1, v2);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */     } 
/* 11158 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud4PointGouraud(int[] data, int offset, int size) {
/* 11162 */     Vertex v0 = m_v0;
/* 11163 */     Vertex v1 = m_v1;
/* 11164 */     Vertex v2 = m_v2;
/* 11165 */     Vertex v3 = m_v3;
/*       */     
/* 11167 */     v0.r = data[offset] & 0xFF;
/* 11168 */     v0.g = data[offset] >> 8 & 0xFF;
/* 11169 */     v0.b = data[offset] >> 16 & 0xFF;
/* 11170 */     v0.x = data[offset + 1] << 20 >> 20;
/* 11171 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/* 11173 */     v1.r = data[offset + 2] & 0xFF;
/* 11174 */     v1.g = data[offset + 2] >> 8 & 0xFF;
/* 11175 */     v1.b = data[offset + 2] >> 16 & 0xFF;
/* 11176 */     v1.x = data[offset + 3] << 20 >> 20;
/* 11177 */     v1.y = data[offset + 3] << 4 >> 20;
/*       */     
/* 11179 */     v2.r = data[offset + 4] & 0xFF;
/* 11180 */     v2.g = data[offset + 4] >> 8 & 0xFF;
/* 11181 */     v2.b = data[offset + 4] >> 16 & 0xFF;
/* 11182 */     v2.x = data[offset + 5] << 20 >> 20;
/* 11183 */     v2.y = data[offset + 5] << 4 >> 20;
/*       */     
/* 11185 */     v3.r = data[offset + 6] & 0xFF;
/* 11186 */     v3.g = data[offset + 6] >> 8 & 0xFF;
/* 11187 */     v3.b = data[offset + 6] >> 16 & 0xFF;
/* 11188 */     v3.x = data[offset + 7] << 20 >> 20;
/* 11189 */     v3.y = data[offset + 7] << 4 >> 20;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11194 */     _Q010000.render(m_polygonInfo, v0, v1, v2, v3);
/* 11195 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud4PointGouraudSemi(int[] data, int offset, int size) {
/* 11199 */     Vertex v0 = m_v0;
/* 11200 */     Vertex v1 = m_v1;
/* 11201 */     Vertex v2 = m_v2;
/* 11202 */     Vertex v3 = m_v3;
/*       */     
/* 11204 */     v0.r = data[offset] & 0xFF;
/* 11205 */     v0.g = data[offset] >> 8 & 0xFF;
/* 11206 */     v0.b = data[offset] >> 16 & 0xFF;
/* 11207 */     v0.x = data[offset + 1] << 20 >> 20;
/* 11208 */     v0.y = data[offset + 1] << 4 >> 20;
/*       */     
/* 11210 */     v1.r = data[offset + 2] & 0xFF;
/* 11211 */     v1.g = data[offset + 2] >> 8 & 0xFF;
/* 11212 */     v1.b = data[offset + 2] >> 16 & 0xFF;
/* 11213 */     v1.x = data[offset + 3] << 20 >> 20;
/* 11214 */     v1.y = data[offset + 3] << 4 >> 20;
/*       */     
/* 11216 */     v2.r = data[offset + 4] & 0xFF;
/* 11217 */     v2.g = data[offset + 4] >> 8 & 0xFF;
/* 11218 */     v2.b = data[offset + 4] >> 16 & 0xFF;
/* 11219 */     v2.x = data[offset + 5] << 20 >> 20;
/* 11220 */     v2.y = data[offset + 5] << 4 >> 20;
/*       */     
/* 11222 */     v3.r = data[offset + 6] & 0xFF;
/* 11223 */     v3.g = data[offset + 6] >> 8 & 0xFF;
/* 11224 */     v3.b = data[offset + 6] >> 16 & 0xFF;
/* 11225 */     v3.x = data[offset + 7] << 20 >> 20;
/* 11226 */     v3.y = data[offset + 7] << 4 >> 20;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11232 */     switch (getSemiMode()) {
/*       */       case 0:
/* 11234 */         _Q011000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */       case 32:
/* 11237 */         _Q012000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */       case 64:
/* 11240 */         _Q013000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */       case 96:
/* 11243 */         _Q014000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */     } 
/* 11246 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud4PointTextureGouraud(int[] data, int offset, int size) {
/* 11250 */     Vertex v0 = m_v0;
/* 11251 */     Vertex v1 = m_v1;
/* 11252 */     Vertex v2 = m_v2;
/* 11253 */     Vertex v3 = m_v3;
/*       */     
/* 11255 */     v0.x = data[offset + 1] << 20 >> 20;
/* 11256 */     v0.y = data[offset + 1] << 4 >> 20;
/* 11257 */     v0.u = data[offset + 2] & 0xFF;
/* 11258 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/* 11259 */     v0.r = data[offset] & 0xFF;
/* 11260 */     v0.g = data[offset] >> 8 & 0xFF;
/* 11261 */     v0.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 11263 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/* 11264 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/* 11265 */     m_polygonInfo.clut = videoRAM;
/* 11266 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/* 11268 */     v1.x = data[offset + 4] << 20 >> 20;
/* 11269 */     v1.y = data[offset + 4] << 4 >> 20;
/* 11270 */     v1.u = data[offset + 5] & 0xFF;
/* 11271 */     v1.v = data[offset + 5] >> 8 & 0xFF;
/* 11272 */     v1.r = data[offset + 3] & 0xFF;
/* 11273 */     v1.g = data[offset + 3] >> 8 & 0xFF;
/* 11274 */     v1.b = data[offset + 3] >> 16 & 0xFF;
/*       */     
/* 11276 */     drawModePacket(data[offset + 5]);
/*       */     
/* 11278 */     v2.x = data[offset + 7] << 20 >> 20;
/* 11279 */     v2.y = data[offset + 7] << 4 >> 20;
/* 11280 */     v2.u = data[offset + 8] & 0xFF;
/* 11281 */     v2.v = data[offset + 8] >> 8 & 0xFF;
/* 11282 */     v2.r = data[offset + 6] & 0xFF;
/* 11283 */     v2.g = data[offset + 6] >> 8 & 0xFF;
/* 11284 */     v2.b = data[offset + 6] >> 16 & 0xFF;
/*       */     
/* 11286 */     v3.x = data[offset + 10] << 20 >> 20;
/* 11287 */     v3.y = data[offset + 10] << 4 >> 20;
/* 11288 */     v3.u = data[offset + 11] & 0xFF;
/* 11289 */     v3.v = data[offset + 11] >> 8 & 0xFF;
/* 11290 */     v3.r = data[offset + 9] & 0xFF;
/* 11291 */     v3.g = data[offset + 9] >> 8 & 0xFF;
/* 11292 */     v3.b = data[offset + 9] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11298 */     switch (getTextureMode()) {
/*       */       case 0:
/* 11300 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 11301 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11303 */               _Q410001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/* 11306 */               _Q410101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/* 11309 */               _Q410011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/* 11312 */           _Q410111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/* 11316 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11318 */             _Q410000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/* 11321 */             _Q410100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/* 11324 */             _Q410010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/* 11327 */         _Q410110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 128:
/* 11333 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 11334 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11336 */               _Q810001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/* 11339 */               _Q810101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/* 11342 */               _Q810011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/* 11345 */           _Q810111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/* 11349 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11351 */             _Q810000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/* 11354 */             _Q810100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/* 11357 */             _Q810010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/* 11360 */         _Q810110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 256:
/* 11366 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11368 */             _Q610000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/* 11371 */             _Q610100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/* 11374 */             _Q610010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/* 11377 */         _Q610110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */       
/*       */       case 32768:
/* 11382 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 11383 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11385 */               _Q510001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/* 11388 */               _Q510101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/* 11391 */               _Q510011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/* 11394 */           _Q510111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/* 11398 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11400 */             _Q510000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/* 11403 */             _Q510100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/* 11406 */             _Q510010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/* 11409 */         _Q510110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32896:
/* 11415 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 11416 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11418 */               _Q910001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 2048:
/* 11421 */               _Q910101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 4096:
/* 11424 */               _Q910011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/* 11427 */           _Q910111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */           
/*       */           break;
/*       */         } 
/* 11431 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11433 */             _Q910000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/* 11436 */             _Q910100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/* 11439 */             _Q910010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/* 11442 */         _Q910110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 33024:
/* 11448 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11450 */             _Q710000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 2048:
/* 11453 */             _Q710100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 4096:
/* 11456 */             _Q710010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/* 11459 */         _Q710110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */         break;
/*       */     } 
/*       */     
/* 11463 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpud4PointTextureGouraudSemi(int[] data, int offset, int size) {
/* 11467 */     Vertex v0 = m_v0;
/* 11468 */     Vertex v1 = m_v1;
/* 11469 */     Vertex v2 = m_v2;
/* 11470 */     Vertex v3 = m_v3;
/*       */     
/* 11472 */     v0.x = data[offset + 1] << 20 >> 20;
/* 11473 */     v0.y = data[offset + 1] << 4 >> 20;
/* 11474 */     v0.u = data[offset + 2] & 0xFF;
/* 11475 */     v0.v = data[offset + 2] >> 8 & 0xFF;
/* 11476 */     v0.r = data[offset] & 0xFF;
/* 11477 */     v0.g = data[offset] >> 8 & 0xFF;
/* 11478 */     v0.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 11480 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/* 11481 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/* 11482 */     m_polygonInfo.clut = videoRAM;
/* 11483 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/* 11485 */     v1.x = data[offset + 4] << 20 >> 20;
/* 11486 */     v1.y = data[offset + 4] << 4 >> 20;
/* 11487 */     v1.u = data[offset + 5] & 0xFF;
/* 11488 */     v1.v = data[offset + 5] >> 8 & 0xFF;
/* 11489 */     v1.r = data[offset + 3] & 0xFF;
/* 11490 */     v1.g = data[offset + 3] >> 8 & 0xFF;
/* 11491 */     v1.b = data[offset + 3] >> 16 & 0xFF;
/*       */     
/* 11493 */     drawModePacket(data[offset + 5]);
/*       */     
/* 11495 */     v2.x = data[offset + 7] << 20 >> 20;
/* 11496 */     v2.y = data[offset + 7] << 4 >> 20;
/* 11497 */     v2.u = data[offset + 8] & 0xFF;
/* 11498 */     v2.v = data[offset + 8] >> 8 & 0xFF;
/* 11499 */     v2.r = data[offset + 6] & 0xFF;
/* 11500 */     v2.g = data[offset + 6] >> 8 & 0xFF;
/* 11501 */     v2.b = data[offset + 6] >> 16 & 0xFF;
/*       */     
/* 11503 */     v3.x = data[offset + 10] << 20 >> 20;
/* 11504 */     v3.y = data[offset + 10] << 4 >> 20;
/* 11505 */     v3.u = data[offset + 11] & 0xFF;
/* 11506 */     v3.v = data[offset + 11] >> 8 & 0xFF;
/* 11507 */     v3.r = data[offset + 9] & 0xFF;
/* 11508 */     v3.g = data[offset + 9] >> 8 & 0xFF;
/* 11509 */     v3.b = data[offset + 9] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11515 */     switch (getTextureMode()) {
/*       */       case 0:
/* 11517 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 11518 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11520 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11522 */                   _Q411001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11525 */                   _Q412001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11528 */                   _Q413001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11531 */                   _Q414001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 11536 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11538 */                   _Q411101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11541 */                   _Q412101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11544 */                   _Q413101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11547 */                   _Q414101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 11552 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11554 */                   _Q411011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11557 */                   _Q412011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11560 */                   _Q413011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11563 */                   _Q414011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 11568 */           switch (getSemiMode()) {
/*       */             case 0:
/* 11570 */               _Q411111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/* 11573 */               _Q412111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/* 11576 */               _Q413111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/* 11579 */               _Q414111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 11585 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11587 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11589 */                 _Q411000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11592 */                 _Q412000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11595 */                 _Q413000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11598 */                 _Q414000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 11603 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11605 */                 _Q411100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11608 */                 _Q412100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11611 */                 _Q413100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11614 */                 _Q414100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 11619 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11621 */                 _Q411010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11624 */                 _Q412010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11627 */                 _Q413010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11630 */                 _Q414010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 11635 */         switch (getSemiMode()) {
/*       */           case 0:
/* 11637 */             _Q411110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 11640 */             _Q412110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 11643 */             _Q413110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 11646 */             _Q414110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 128:
/* 11654 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 11655 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11657 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11659 */                   _Q811001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11662 */                   _Q812001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11665 */                   _Q813001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11668 */                   _Q814001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 11673 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11675 */                   _Q811101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11678 */                   _Q812101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11681 */                   _Q813101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11684 */                   _Q814101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 11689 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11691 */                   _Q811011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11694 */                   _Q812011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11697 */                   _Q813011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11700 */                   _Q814011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 11705 */           switch (getSemiMode()) {
/*       */             case 0:
/* 11707 */               _Q811111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/* 11710 */               _Q812111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/* 11713 */               _Q813111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/* 11716 */               _Q814111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 11722 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11724 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11726 */                 _Q811000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11729 */                 _Q812000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11732 */                 _Q813000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11735 */                 _Q814000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 11740 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11742 */                 _Q811100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11745 */                 _Q812100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11748 */                 _Q813100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11751 */                 _Q814100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 11756 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11758 */                 _Q811010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11761 */                 _Q812010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11764 */                 _Q813010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11767 */                 _Q814010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 11772 */         switch (getSemiMode()) {
/*       */           case 0:
/* 11774 */             _Q811110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 11777 */             _Q812110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 11780 */             _Q813110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 11783 */             _Q814110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 256:
/* 11791 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11793 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11795 */                 _Q611000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11798 */                 _Q612000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11801 */                 _Q613000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11804 */                 _Q614000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 11809 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11811 */                 _Q611100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11814 */                 _Q612100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11817 */                 _Q613100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11820 */                 _Q614100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 11825 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11827 */                 _Q611010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11830 */                 _Q612010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11833 */                 _Q613010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11836 */                 _Q614010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 11841 */         switch (getSemiMode()) {
/*       */           case 0:
/* 11843 */             _Q611110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 11846 */             _Q612110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 11849 */             _Q613110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 11852 */             _Q614110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32768:
/* 11859 */         if (getPalette4(data[offset] | 0x1000000)) {
/* 11860 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11862 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11864 */                   _Q511001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11867 */                   _Q512001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11870 */                   _Q513001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11873 */                   _Q514001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 11878 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11880 */                   _Q511101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11883 */                   _Q512101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11886 */                   _Q513101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11889 */                   _Q514101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 11894 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 11896 */                   _Q511011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 11899 */                   _Q512011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 11902 */                   _Q513011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 11905 */                   _Q514011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 11910 */           switch (getSemiMode()) {
/*       */             case 0:
/* 11912 */               _Q511111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/* 11915 */               _Q512111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/* 11918 */               _Q513111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/* 11921 */               _Q514111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 11927 */         switch (getMaskModes()) {
/*       */           case 0:
/* 11929 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11931 */                 _Q511000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11934 */                 _Q512000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11937 */                 _Q513000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11940 */                 _Q514000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 11945 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11947 */                 _Q511100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11950 */                 _Q512100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11953 */                 _Q513100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11956 */                 _Q514100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 11961 */             switch (getSemiMode()) {
/*       */               case 0:
/* 11963 */                 _Q511010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 11966 */                 _Q512010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 11969 */                 _Q513010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 11972 */                 _Q514010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 11977 */         switch (getSemiMode()) {
/*       */           case 0:
/* 11979 */             _Q511110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 11982 */             _Q512110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 11985 */             _Q513110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 11988 */             _Q514110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32896:
/* 11996 */         if (getPalette8(data[offset] | 0x1000000)) {
/* 11997 */           switch (getMaskModes()) {
/*       */             case 0:
/* 11999 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12001 */                   _Q911001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 12004 */                   _Q912001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 12007 */                   _Q913001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 12010 */                   _Q914001.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 12015 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12017 */                   _Q911101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 12020 */                   _Q912101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 12023 */                   _Q913101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 12026 */                   _Q914101.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 12031 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12033 */                   _Q911011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 32:
/* 12036 */                   _Q912011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 64:
/* 12039 */                   _Q913011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */                 case 96:
/* 12042 */                   _Q914011.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 12047 */           switch (getSemiMode()) {
/*       */             case 0:
/* 12049 */               _Q911111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 32:
/* 12052 */               _Q912111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 64:
/* 12055 */               _Q913111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */             case 96:
/* 12058 */               _Q914111.render(m_polygonInfo, v0, v1, v2, v3);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 12064 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12066 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12068 */                 _Q911000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 12071 */                 _Q912000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 12074 */                 _Q913000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 12077 */                 _Q914000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 12082 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12084 */                 _Q911100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 12087 */                 _Q912100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 12090 */                 _Q913100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 12093 */                 _Q914100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 12098 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12100 */                 _Q911010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 12103 */                 _Q912010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 12106 */                 _Q913010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 12109 */                 _Q914010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 12114 */         switch (getSemiMode()) {
/*       */           case 0:
/* 12116 */             _Q911110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 12119 */             _Q912110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 12122 */             _Q913110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 12125 */             _Q914110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 33024:
/* 12133 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12135 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12137 */                 _Q711000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 12140 */                 _Q712000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 12143 */                 _Q713000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 12146 */                 _Q714000.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 12151 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12153 */                 _Q711100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 12156 */                 _Q712100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 12159 */                 _Q713100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 12162 */                 _Q714100.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 12167 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12169 */                 _Q711010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 32:
/* 12172 */                 _Q712010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 64:
/* 12175 */                 _Q713010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */               case 96:
/* 12178 */                 _Q714010.render(m_polygonInfo, v0, v1, v2, v3);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 12183 */         switch (getSemiMode()) {
/*       */           case 0:
/* 12185 */             _Q711110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 32:
/* 12188 */             _Q712110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 64:
/* 12191 */             _Q713110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */           case 96:
/* 12194 */             _Q714110.render(m_polygonInfo, v0, v1, v2, v3);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */     } 
/* 12200 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpudLine(int[] data, int offset, int size) {
/* 12204 */     Vertex v0 = m_v0;
/* 12205 */     Vertex v1 = m_v1;
/* 12206 */     v0.x = data[offset + 1] << 20 >> 20;
/* 12207 */     v0.y = data[offset + 1] << 4 >> 20;
/* 12208 */     v1.x = data[offset + 2] << 20 >> 20;
/* 12209 */     v1.y = data[offset + 2] << 4 >> 20;
/* 12210 */     m_lineInfo.color = makePixel(data[offset] & 0xFF, data[offset] >> 8 & 0xFF, data[offset] >> 16 & 0xFF, 0);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12215 */     switch (getMaskModes())
/*       */     { case 0:
/* 12217 */         _L000000.render(m_lineInfo, v0, v1);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12229 */         return 0;case 2048: _L000100.render(m_lineInfo, v0, v1); return 0;case 4096: _L000010.render(m_lineInfo, v0, v1); return 0; }  _L000110.render(m_lineInfo, v0, v1); return 0;
/*       */   }
/*       */   
/*       */   public static int gpudLineSemi(int[] data, int offset, int size) {
/* 12233 */     Vertex v0 = m_v0;
/* 12234 */     Vertex v1 = m_v1;
/* 12235 */     v0.x = data[offset + 1] << 20 >> 20;
/* 12236 */     v0.y = data[offset + 1] << 4 >> 20;
/* 12237 */     v1.x = data[offset + 2] << 20 >> 20;
/* 12238 */     v1.y = data[offset + 2] << 4 >> 20;
/* 12239 */     m_lineInfo.color = makePixel(data[offset] & 0xFF, data[offset] >> 8 & 0xFF, data[offset] >> 16 & 0xFF, 0);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12244 */     switch (getMaskModes())
/*       */     { case 0:
/* 12246 */         switch (getSemiMode()) {
/*       */           case 0:
/* 12248 */             _L001000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */           case 32:
/* 12251 */             _L002000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */           case 64:
/* 12254 */             _L003000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */           case 96:
/* 12257 */             _L004000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */         } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12310 */         return 0;case 2048: switch (getSemiMode()) { case 0: _L001100.render(m_lineInfo, v0, v1); break;case 32: _L002100.render(m_lineInfo, v0, v1); break;case 64: _L003100.render(m_lineInfo, v0, v1); break;case 96: _L004100.render(m_lineInfo, v0, v1); break; }  return 0;case 4096: switch (getSemiMode()) { case 0: _L001010.render(m_lineInfo, v0, v1); break;case 32: _L002010.render(m_lineInfo, v0, v1); break;case 64: _L003010.render(m_lineInfo, v0, v1); break;case 96: _L004010.render(m_lineInfo, v0, v1); break; }  return 0; }  switch (getSemiMode()) { case 0: _L001110.render(m_lineInfo, v0, v1); break;case 32: _L002110.render(m_lineInfo, v0, v1); break;case 64: _L003110.render(m_lineInfo, v0, v1); break;case 96: _L004110.render(m_lineInfo, v0, v1); break; }  return 0;
/*       */   }
/*       */   
/*       */   public static int gpudPolyLine(int[] data, int offset, int size) {
/* 12314 */     System.out.println("GPUD PolyLine");
/* 12315 */     throw new IllegalStateException();
/*       */   }
/*       */ 
/*       */   
/*       */   public static int gpudPolyLineSemi(int[] data, int offset, int size) {
/* 12320 */     System.out.println("GPUD PolyLineSemi");
/* 12321 */     throw new IllegalStateException();
/*       */   }
/*       */ 
/*       */   
/*       */   public static int gpudLineGouraudSemi(int[] data, int offset, int size) {
/* 12326 */     Vertex v0 = m_v0;
/* 12327 */     Vertex v1 = m_v1;
/* 12328 */     v0.x = data[offset + 1] << 20 >> 20;
/* 12329 */     v0.y = data[offset + 1] << 4 >> 20;
/* 12330 */     v1.x = data[offset + 3] << 20 >> 20;
/* 12331 */     v1.y = data[offset + 3] << 4 >> 20;
/* 12332 */     m_lineInfo.r0 = data[offset] & 0xFF;
/* 12333 */     m_lineInfo.g0 = data[offset] >> 8 & 0xFF;
/* 12334 */     m_lineInfo.b0 = data[offset] >> 16 & 0xFF;
/* 12335 */     m_lineInfo.r1 = data[offset + 2] & 0xFF;
/* 12336 */     m_lineInfo.g1 = data[offset + 2] >> 8 & 0xFF;
/* 12337 */     m_lineInfo.b1 = data[offset + 2] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12343 */     switch (getMaskModes())
/*       */     { case 0:
/* 12345 */         switch (getSemiMode()) {
/*       */           case 0:
/* 12347 */             _L011000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */           case 32:
/* 12350 */             _L012000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */           case 64:
/* 12353 */             _L013000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */           case 96:
/* 12356 */             _L014000.render(m_lineInfo, v0, v1);
/*       */             break;
/*       */         } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12409 */         return 0;case 2048: switch (getSemiMode()) { case 0: _L011100.render(m_lineInfo, v0, v1); break;case 32: _L012100.render(m_lineInfo, v0, v1); break;case 64: _L013100.render(m_lineInfo, v0, v1); break;case 96: _L014100.render(m_lineInfo, v0, v1); break; }  return 0;case 4096: switch (getSemiMode()) { case 0: _L011010.render(m_lineInfo, v0, v1); break;case 32: _L012010.render(m_lineInfo, v0, v1); break;case 64: _L013010.render(m_lineInfo, v0, v1); break;case 96: _L014010.render(m_lineInfo, v0, v1); break; }  return 0; }  switch (getSemiMode()) { case 0: _L011110.render(m_lineInfo, v0, v1); break;case 32: _L012110.render(m_lineInfo, v0, v1); break;case 64: _L013110.render(m_lineInfo, v0, v1); break;case 96: _L014110.render(m_lineInfo, v0, v1); break; }  return 0;
/*       */   }
/*       */   
/*       */   public static int gpudLineGouraud(int[] data, int offset, int size) {
/* 12413 */     Vertex v0 = m_v0;
/* 12414 */     Vertex v1 = m_v1;
/* 12415 */     v0.x = data[offset + 1] << 20 >> 20;
/* 12416 */     v0.y = data[offset + 1] << 4 >> 20;
/* 12417 */     v1.x = data[offset + 3] << 20 >> 20;
/* 12418 */     v1.y = data[offset + 3] << 4 >> 20;
/* 12419 */     m_lineInfo.r0 = data[offset] & 0xFF;
/* 12420 */     m_lineInfo.g0 = data[offset] >> 8 & 0xFF;
/* 12421 */     m_lineInfo.b0 = data[offset] >> 16 & 0xFF;
/* 12422 */     m_lineInfo.r1 = data[offset + 2] & 0xFF;
/* 12423 */     m_lineInfo.g1 = data[offset + 2] >> 8 & 0xFF;
/* 12424 */     m_lineInfo.b1 = data[offset + 2] >> 16 & 0xFF;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12429 */     switch (getMaskModes())
/*       */     { case 0:
/* 12431 */         _L010000.render(m_lineInfo, v0, v1);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12443 */         return 0;case 2048: _L010100.render(m_lineInfo, v0, v1); return 0;case 4096: _L010010.render(m_lineInfo, v0, v1); return 0; }  _L010110.render(m_lineInfo, v0, v1); return 0;
/*       */   }
/*       */   
/*       */   public static int gpudPolyLineGouraud(int[] data, int offset, int size) {
/* 12447 */     System.out.println("GPUD PolyLineGouraud");
/* 12448 */     throw new IllegalStateException();
/*       */   }
/*       */ 
/*       */   
/* 12452 */   private static int[] polyLineCmdBuffer = new int[4];
/*       */   
/*       */   public static int gpudPolyLineGouraudSemi(int[] data, int offset, int size) {
/* 12455 */     if (m_gpudState != 2) {
/* 12456 */       gpudLineGouraudSemi(data, offset, 4);
/* 12457 */       polyLineCmdBuffer[0] = data[offset + 2];
/* 12458 */       polyLineCmdBuffer[1] = data[offset + 3];
/* 12459 */       polyLineCmdBuffer[2] = 1431655765;
/* 12460 */       m_gpudState = 2;
/* 12461 */       return 0;
/*       */     } 
/*       */     
/* 12464 */     if (data[offset] == 1431655765) {
/* 12465 */       m_gpudState = 0;
/* 12466 */       return 1;
/*       */     } 
/* 12468 */     if (polyLineCmdBuffer[2] == 1431655765) {
/* 12469 */       polyLineCmdBuffer[2] = data[offset];
/*       */     } else {
/* 12471 */       polyLineCmdBuffer[3] = data[offset + 1];
/* 12472 */       gpudLineGouraudSemi(polyLineCmdBuffer, 0, 4);
/* 12473 */       polyLineCmdBuffer[0] = polyLineCmdBuffer[2];
/* 12474 */       polyLineCmdBuffer[1] = polyLineCmdBuffer[3];
/* 12475 */       polyLineCmdBuffer[2] = 1431655765;
/*       */     } 
/* 12477 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudRectangle(int[] data, int offset, int size) {
/* 12483 */     m_polygonInfo.r = data[offset] & 0xFF;
/* 12484 */     m_polygonInfo.g = data[offset] >> 8 & 0xFF;
/* 12485 */     m_polygonInfo.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 12487 */     int x = data[offset + 1] << 20 >> 20;
/* 12488 */     int y = data[offset + 1] << 4 >> 20;
/*       */     
/* 12490 */     int w = data[offset + 2] & 0xFFFF;
/* 12491 */     int h = data[offset + 2] >> 16;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12496 */     switch (getMaskModes())
/*       */     { case 0:
/* 12498 */         _S000000.render(m_polygonInfo, x, y, w, h);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12510 */         return 0;case 2048: _S000100.render(m_polygonInfo, x, y, w, h); return 0;case 4096: _S000010.render(m_polygonInfo, x, y, w, h); return 0; }  _S000110.render(m_polygonInfo, x, y, w, h); return 0;
/*       */   }
/*       */ 
/*       */   
/*       */   public static int gpudRectangleSemi(int[] data, int offset, int size) {
/* 12515 */     m_polygonInfo.r = data[offset] & 0xFF;
/* 12516 */     m_polygonInfo.g = data[offset] >> 8 & 0xFF;
/* 12517 */     m_polygonInfo.b = data[offset] >> 16 & 0xFF;
/*       */     
/* 12519 */     int x = data[offset + 1] << 20 >> 20;
/* 12520 */     int y = data[offset + 1] << 4 >> 20;
/*       */     
/* 12522 */     int w = data[offset + 2] & 0xFFFF;
/* 12523 */     int h = data[offset + 2] >> 16;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12528 */     switch (getMaskModes())
/*       */     { case 0:
/* 12530 */         switch (getSemiMode()) {
/*       */           case 0:
/* 12532 */             _S001000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 12535 */             _S002000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 12538 */             _S003000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 12541 */             _S004000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12594 */         return 0;case 2048: switch (getSemiMode()) { case 0: _S001100.render(m_polygonInfo, x, y, w, h); break;case 32: _S002100.render(m_polygonInfo, x, y, w, h); break;case 64: _S003100.render(m_polygonInfo, x, y, w, h); break;case 96: _S004100.render(m_polygonInfo, x, y, w, h); break; }  return 0;case 4096: switch (getSemiMode()) { case 0: _S001010.render(m_polygonInfo, x, y, w, h); break;case 32: _S002010.render(m_polygonInfo, x, y, w, h); break;case 64: _S003010.render(m_polygonInfo, x, y, w, h); break;case 96: _S004010.render(m_polygonInfo, x, y, w, h); break; }  return 0; }  switch (getSemiMode()) { case 0: _S001110.render(m_polygonInfo, x, y, w, h); break;case 32: _S002110.render(m_polygonInfo, x, y, w, h); break;case 64: _S003110.render(m_polygonInfo, x, y, w, h); break;case 96: _S004110.render(m_polygonInfo, x, y, w, h); break; }  return 0;
/*       */   }
/*       */ 
/*       */   
/*       */   public static int gpudSprite(int[] data, int offset, int size) {
/*       */     boolean nobreg, nobreg;
/* 12600 */     int x = data[offset + 1] << 20 >> 20;
/* 12601 */     int y = data[offset + 1] << 4 >> 20;
/*       */     
/* 12603 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/* 12604 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/* 12605 */     m_polygonInfo.u = data[offset + 2] & 0xFF;
/* 12606 */     m_polygonInfo.v = data[offset + 2] >> 8 & 0xFF;
/* 12607 */     m_polygonInfo.clut = videoRAM;
/* 12608 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/* 12610 */     int w = data[offset + 3] & 0x1FF;
/* 12611 */     int h = data[offset + 3] >> 16;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12631 */     switch (getTextureMode()) {
/*       */       case 0:
/* 12633 */         if (getPalette4(data[offset])) {
/* 12634 */           switch (getMaskModes()) {
/*       */             case 0:
/* 12636 */               _S400001.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 2048:
/* 12639 */               _S400101.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 4096:
/* 12642 */               _S400011.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/* 12645 */           _S400111.render(m_polygonInfo, x, y, w, h);
/*       */           
/*       */           break;
/*       */         } 
/* 12649 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12651 */             _S400000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 2048:
/* 12654 */             _S400100.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 4096:
/* 12657 */             _S400010.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/* 12660 */         _S400110.render(m_polygonInfo, x, y, w, h);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 128:
/* 12666 */         if (getPalette8(data[offset])) {
/* 12667 */           switch (getMaskModes()) {
/*       */             case 0:
/* 12669 */               _S800001.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 2048:
/* 12672 */               _S800101.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 4096:
/* 12675 */               _S800011.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/* 12678 */           _S800111.render(m_polygonInfo, x, y, w, h);
/*       */           
/*       */           break;
/*       */         } 
/* 12682 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12684 */             _S800000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 2048:
/* 12687 */             _S800100.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 4096:
/* 12690 */             _S800010.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/* 12693 */         _S800110.render(m_polygonInfo, x, y, w, h);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 256:
/* 12699 */         nobreg = false;
/* 12700 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/* 12701 */           nobreg = true;
/*       */         }
/*       */         
/* 12704 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12706 */             _S600000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 2048:
/* 12709 */             _S600100.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 4096:
/* 12712 */             _S600010.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/* 12715 */         _S600110.render(m_polygonInfo, x, y, w, h);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32768:
/* 12721 */         if (getPalette4(data[offset])) {
/* 12722 */           switch (getMaskModes()) {
/*       */             case 0:
/* 12724 */               _S500001.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 2048:
/* 12727 */               _S500101.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 4096:
/* 12730 */               _S500011.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/* 12733 */           _S500111.render(m_polygonInfo, x, y, w, h);
/*       */           
/*       */           break;
/*       */         } 
/* 12737 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12739 */             _S500000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 2048:
/* 12742 */             _S500100.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 4096:
/* 12745 */             _S500010.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/* 12748 */         _S500110.render(m_polygonInfo, x, y, w, h);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 32896:
/* 12754 */         if (getPalette8(data[offset])) {
/* 12755 */           switch (getMaskModes()) {
/*       */             case 0:
/* 12757 */               _S900001.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 2048:
/* 12760 */               _S900101.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 4096:
/* 12763 */               _S900011.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/* 12766 */           _S900111.render(m_polygonInfo, x, y, w, h);
/*       */           
/*       */           break;
/*       */         } 
/* 12770 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12772 */             _S900000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 2048:
/* 12775 */             _S900100.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 4096:
/* 12778 */             _S900010.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/* 12781 */         _S900110.render(m_polygonInfo, x, y, w, h);
/*       */         break;
/*       */ 
/*       */ 
/*       */       
/*       */       case 33024:
/* 12787 */         nobreg = false;
/* 12788 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/* 12789 */           nobreg = true;
/*       */         }
/*       */         
/* 12792 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12794 */             _S700000.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 2048:
/* 12797 */             _S700100.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 4096:
/* 12800 */             _S700010.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/* 12803 */         _S700110.render(m_polygonInfo, x, y, w, h);
/*       */         break;
/*       */     } 
/*       */ 
/*       */     
/* 12808 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudSpriteSemi(int[] data, int offset, int size) {
/*       */     boolean nobreg, nobreg;
/* 12815 */     int x = data[offset + 1] << 20 >> 20;
/* 12816 */     int y = data[offset + 1] << 4 >> 20;
/*       */     
/* 12818 */     int cly = data[offset + 2] >> 22 & 0x1FF;
/* 12819 */     int clx = (data[offset + 2] & 0x3F0000) >> 12;
/* 12820 */     m_polygonInfo.u = data[offset + 2] & 0xFF;
/* 12821 */     m_polygonInfo.v = data[offset + 2] >> 8 & 0xFF;
/* 12822 */     m_polygonInfo.clut = videoRAM;
/* 12823 */     m_polygonInfo.clutOffset = cly * 1024 + clx;
/*       */     
/* 12825 */     int w = data[offset + 3] & 0x1FF;
/* 12826 */     int h = data[offset + 3] >> 16;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 12831 */     switch (getTextureMode()) {
/*       */       case 0:
/* 12833 */         if (getPalette4(data[offset])) {
/* 12834 */           switch (getMaskModes()) {
/*       */             case 0:
/* 12836 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12838 */                   _S401001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 12841 */                   _S402001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 12844 */                   _S403001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 12847 */                   _S404001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 12852 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12854 */                   _S401101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 12857 */                   _S402101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 12860 */                   _S403101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 12863 */                   _S404101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 12868 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12870 */                   _S401011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 12873 */                   _S402011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 12876 */                   _S403011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 12879 */                   _S404011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 12884 */           switch (getSemiMode()) {
/*       */             case 0:
/* 12886 */               _S401111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 32:
/* 12889 */               _S402111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 64:
/* 12892 */               _S403111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 96:
/* 12895 */               _S404111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 12901 */         switch (getMaskModes()) {
/*       */           case 0:
/* 12903 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12905 */                 _S401000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 12908 */                 _S402000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 12911 */                 _S403000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 12914 */                 _S404000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 12919 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12921 */                 _S401100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 12924 */                 _S402100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 12927 */                 _S403100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 12930 */                 _S404100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 12935 */             switch (getSemiMode()) {
/*       */               case 0:
/* 12937 */                 _S401010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 12940 */                 _S402010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 12943 */                 _S403010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 12946 */                 _S404010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 12951 */         switch (getSemiMode()) {
/*       */           case 0:
/* 12953 */             _S401110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 12956 */             _S402110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 12959 */             _S403110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 12962 */             _S404110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 128:
/* 12970 */         if (getPalette8(data[offset])) {
/* 12971 */           switch (getMaskModes()) {
/*       */             case 0:
/* 12973 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12975 */                   _S801001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 12978 */                   _S802001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 12981 */                   _S803001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 12984 */                   _S804001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 12989 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 12991 */                   _S801101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 12994 */                   _S802101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 12997 */                   _S803101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13000 */                   _S804101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 13005 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13007 */                   _S801011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13010 */                   _S802011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13013 */                   _S803011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13016 */                   _S804011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 13021 */           switch (getSemiMode()) {
/*       */             case 0:
/* 13023 */               _S801111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 32:
/* 13026 */               _S802111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 64:
/* 13029 */               _S803111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 96:
/* 13032 */               _S804111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 13038 */         switch (getMaskModes()) {
/*       */           case 0:
/* 13040 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13042 */                 _S801000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13045 */                 _S802000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13048 */                 _S803000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13051 */                 _S804000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 13056 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13058 */                 _S801100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13061 */                 _S802100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13064 */                 _S803100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13067 */                 _S804100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 13072 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13074 */                 _S801010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13077 */                 _S802010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13080 */                 _S803010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13083 */                 _S804010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 13088 */         switch (getSemiMode()) {
/*       */           case 0:
/* 13090 */             _S801110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 13093 */             _S802110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 13096 */             _S803110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 13099 */             _S804110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 256:
/* 13107 */         nobreg = false;
/* 13108 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/* 13109 */           nobreg = true;
/*       */         }
/*       */         
/* 13112 */         switch (getMaskModes()) {
/*       */           case 0:
/* 13114 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13116 */                 _S601000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13119 */                 _S602000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13122 */                 _S603000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13125 */                 _S604000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 13130 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13132 */                 _S601100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13135 */                 _S602100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13138 */                 _S603100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13141 */                 _S604100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 13146 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13148 */                 _S601010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13151 */                 _S602010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13154 */                 _S603010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13157 */                 _S604010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 13162 */         switch (getSemiMode()) {
/*       */           case 0:
/* 13164 */             _S601110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 13167 */             _S602110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 13170 */             _S603110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 13173 */             _S604110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32768:
/* 13181 */         if (getPalette4(data[offset])) {
/* 13182 */           switch (getMaskModes()) {
/*       */             case 0:
/* 13184 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13186 */                   _S501001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13189 */                   _S502001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13192 */                   _S503001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13195 */                   _S504001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 13200 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13202 */                   _S501101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13205 */                   _S502101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13208 */                   _S503101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13211 */                   _S504101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 13216 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13218 */                   _S501011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13221 */                   _S502011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13224 */                   _S503011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13227 */                   _S504011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 13232 */           switch (getSemiMode()) {
/*       */             case 0:
/* 13234 */               _S501111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 32:
/* 13237 */               _S502111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 64:
/* 13240 */               _S503111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 96:
/* 13243 */               _S504111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 13249 */         switch (getMaskModes()) {
/*       */           case 0:
/* 13251 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13253 */                 _S501000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13256 */                 _S502000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13259 */                 _S503000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13262 */                 _S504000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 13267 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13269 */                 _S501100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13272 */                 _S502100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13275 */                 _S503100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13278 */                 _S504100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 13283 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13285 */                 _S501010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13288 */                 _S502010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13291 */                 _S503010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13294 */                 _S504010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 13299 */         switch (getSemiMode()) {
/*       */           case 0:
/* 13301 */             _S501110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 13304 */             _S502110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 13307 */             _S503110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 13310 */             _S504110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 32896:
/* 13318 */         if (getPalette8(data[offset])) {
/* 13319 */           switch (getMaskModes()) {
/*       */             case 0:
/* 13321 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13323 */                   _S901001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13326 */                   _S902001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13329 */                   _S903001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13332 */                   _S904001.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 2048:
/* 13337 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13339 */                   _S901101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13342 */                   _S902101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13345 */                   _S903101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13348 */                   _S904101.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */             case 4096:
/* 13353 */               switch (getSemiMode()) {
/*       */                 case 0:
/* 13355 */                   _S901011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 32:
/* 13358 */                   _S902011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 64:
/* 13361 */                   _S903011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */                 case 96:
/* 13364 */                   _S904011.render(m_polygonInfo, x, y, w, h);
/*       */                   break;
/*       */               } 
/*       */               break;
/*       */           } 
/* 13369 */           switch (getSemiMode()) {
/*       */             case 0:
/* 13371 */               _S901111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 32:
/* 13374 */               _S902111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 64:
/* 13377 */               _S903111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */             case 96:
/* 13380 */               _S904111.render(m_polygonInfo, x, y, w, h);
/*       */               break;
/*       */           } 
/*       */           
/*       */           break;
/*       */         } 
/* 13386 */         switch (getMaskModes()) {
/*       */           case 0:
/* 13388 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13390 */                 _S901000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13393 */                 _S902000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13396 */                 _S903000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13399 */                 _S904000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 13404 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13406 */                 _S901100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13409 */                 _S902100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13412 */                 _S903100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13415 */                 _S904100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 13420 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13422 */                 _S901010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13425 */                 _S902010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13428 */                 _S903010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13431 */                 _S904010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 13436 */         switch (getSemiMode()) {
/*       */           case 0:
/* 13438 */             _S901110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 13441 */             _S902110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 13444 */             _S903110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 13447 */             _S904110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */ 
/*       */         
/*       */         break;
/*       */       
/*       */       case 33024:
/* 13455 */         nobreg = false;
/* 13456 */         if ((data[offset] & 0x1000000) != 0 || (data[offset] & 0xFFFFFF) == 8421504) {
/* 13457 */           nobreg = true;
/*       */         }
/*       */         
/* 13460 */         switch (getMaskModes()) {
/*       */           case 0:
/* 13462 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13464 */                 _S701000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13467 */                 _S702000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13470 */                 _S703000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13473 */                 _S704000.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 2048:
/* 13478 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13480 */                 _S701100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13483 */                 _S702100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13486 */                 _S703100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13489 */                 _S704100.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */           case 4096:
/* 13494 */             switch (getSemiMode()) {
/*       */               case 0:
/* 13496 */                 _S701010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 32:
/* 13499 */                 _S702010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 64:
/* 13502 */                 _S703010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */               case 96:
/* 13505 */                 _S704010.render(m_polygonInfo, x, y, w, h);
/*       */                 break;
/*       */             } 
/*       */             break;
/*       */         } 
/* 13510 */         switch (getSemiMode()) {
/*       */           case 0:
/* 13512 */             _S701110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 32:
/* 13515 */             _S702110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 64:
/* 13518 */             _S703110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */           case 96:
/* 13521 */             _S704110.render(m_polygonInfo, x, y, w, h);
/*       */             break;
/*       */         } 
/*       */         
/*       */         break;
/*       */     } 
/*       */     
/* 13528 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpudRectangle1x1(int[] data, int offset, int size) {
/* 13532 */     int tmp = data[offset + 2];
/* 13533 */     data[offset + 2] = 65537;
/* 13534 */     int rc = gpudRectangle(data, offset, size);
/* 13535 */     data[offset + 2] = tmp;
/* 13536 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudRectangle1x1Semi(int[] data, int offset, int size) {
/* 13540 */     int tmp = data[offset + 2];
/* 13541 */     data[offset + 2] = 65537;
/* 13542 */     int rc = gpudRectangleSemi(data, offset, size);
/* 13543 */     data[offset + 2] = tmp;
/* 13544 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudSprite1x1(int[] data, int offset, int size) {
/* 13548 */     int tmp = data[offset + 3];
/* 13549 */     data[offset + 3] = 65537;
/* 13550 */     int rc = gpudSprite(data, offset, size);
/* 13551 */     data[offset + 3] = tmp;
/* 13552 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudSprite1x1Semi(int[] data, int offset, int size) {
/* 13556 */     int tmp = data[offset + 3];
/* 13557 */     data[offset + 3] = 65537;
/* 13558 */     int rc = gpudSpriteSemi(data, offset, size);
/* 13559 */     data[offset + 3] = tmp;
/* 13560 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudRectangle8x8(int[] data, int offset, int size) {
/* 13564 */     int tmp = data[offset + 2];
/* 13565 */     data[offset + 2] = 524296;
/* 13566 */     int rc = gpudRectangle(data, offset, size);
/* 13567 */     data[offset + 2] = tmp;
/* 13568 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudRectangle8x8Semi(int[] data, int offset, int size) {
/* 13572 */     int tmp = data[offset + 2];
/* 13573 */     data[offset + 2] = 524296;
/* 13574 */     int rc = gpudRectangleSemi(data, offset, size);
/* 13575 */     data[offset + 2] = tmp;
/* 13576 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudSprite8x8(int[] data, int offset, int size) {
/* 13580 */     int tmp = data[offset + 3];
/* 13581 */     data[offset + 3] = 524296;
/* 13582 */     int rc = gpudSprite(data, offset, size);
/* 13583 */     data[offset + 3] = tmp;
/* 13584 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudSprite8x8Semi(int[] data, int offset, int size) {
/* 13588 */     int tmp = data[offset + 3];
/* 13589 */     data[offset + 3] = 524296;
/* 13590 */     int rc = gpudSpriteSemi(data, offset, size);
/* 13591 */     data[offset + 3] = tmp;
/* 13592 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudRectangle16x16(int[] data, int offset, int size) {
/* 13596 */     int tmp = data[offset + 2];
/* 13597 */     data[offset + 2] = 1048592;
/* 13598 */     int rc = gpudRectangle(data, offset, size);
/* 13599 */     data[offset + 2] = tmp;
/* 13600 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudRectangle16x16Semi(int[] data, int offset, int size) {
/* 13604 */     int tmp = data[offset + 2];
/* 13605 */     data[offset + 2] = 1048592;
/* 13606 */     int rc = gpudRectangleSemi(data, offset, size);
/* 13607 */     data[offset + 2] = tmp;
/* 13608 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudSprite16x16(int[] data, int offset, int size) {
/* 13612 */     int tmp = data[offset + 3];
/* 13613 */     data[offset + 3] = 1048592;
/* 13614 */     int rc = gpudSprite(data, offset, size);
/* 13615 */     data[offset + 3] = tmp;
/* 13616 */     return rc;
/*       */   }
/*       */   
/*       */   public static int gpudSprite16x16Semi(int[] data, int offset, int size) {
/* 13620 */     int tmp = data[offset + 3];
/* 13621 */     data[offset + 3] = 1048592;
/* 13622 */     int rc = gpudSpriteSemi(data, offset, size);
/* 13623 */     data[offset + 3] = tmp;
/* 13624 */     return rc;
/*       */   }
/*       */ 
/*       */   
/*       */   public static int gpudVRAMtoVRAM(int[] data, int offset, int size) {
/* 13629 */     int sx = data[offset + 1] & 0x3FF;
/* 13630 */     int sy = data[offset + 1] >> 16 & 0x1FF;
/* 13631 */     int dx = data[offset + 2] & 0x3FF;
/* 13632 */     int dy = data[offset + 2] >> 16 & 0x1FF;
/*       */     
/* 13634 */     if (sx == dx && sy == dy)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 13640 */       return 0;
/*       */     }
/* 13642 */     int w = data[offset + 3] & 0x3FF;
/* 13643 */     int h = data[offset + 3] >> 16 & 0x1FF;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 13648 */     if (w > 0) {
/* 13649 */       int src = sx + sy * 1024;
/* 13650 */       int dest = dx + dy * 1024;
/*       */       
/* 13652 */       if (dest < src) {
/* 13653 */         for (; h > 0; h--) {
/* 13654 */           for (int x = 0; x < w; x++) {
/* 13655 */             videoRAM[dest + x] = videoRAM[src + x];
/*       */           }
/* 13657 */           src += 1024;
/* 13658 */           dest += 1024;
/*       */         } 
/*       */       } else {
/* 13661 */         src += (h - 1) * 1024;
/* 13662 */         dest += (h - 1) * 1024;
/* 13663 */         for (; h > 0; h--) {
/* 13664 */           for (int x = w - 1; x >= 0; x--) {
/* 13665 */             videoRAM[dest + x] = videoRAM[src + x];
/*       */           }
/* 13667 */           src -= 1024;
/* 13668 */           dest -= 1024;
/*       */         } 
/*       */       } 
/*       */     } 
/* 13672 */     manager.dirtyRectangle(dx, dy, w, h);
/* 13673 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpudMemToVRAM(int[] data, int offset, int size) {
/* 13677 */     if (m_gpudState != 2) {
/* 13678 */       int x = data[offset + 1] & 0x3FF;
/* 13679 */       int y = data[offset + 1] >> 16 & 0x1FF;
/* 13680 */       int w = data[offset + 2] & 0x7FF;
/* 13681 */       int h = data[offset + 2] >> 16 & 0x3FF;
/* 13682 */       int dwordSize = w * h + 1 >> 1;
/*       */       
/* 13684 */       m_dmaRGB24Index = 0;
/* 13685 */       m_dmaX = x;
/* 13686 */       m_dmaY = y;
/* 13687 */       m_dmaOriginX = x;
/* 13688 */       m_dmaOriginY = y;
/* 13689 */       m_dmaW = w;
/* 13690 */       m_dmaH = h;
/*       */       
/* 13692 */       if (dwordSize > 0) {
/* 13693 */         m_gpudState = 2;
/* 13694 */         m_dmaDWordsRemaining = dwordSize;
/*       */       } 
/* 13696 */       return 0;
/*       */     } 
/*       */ 
/*       */     
/* 13700 */     if (size > m_dmaDWordsRemaining) {
/* 13701 */       size = m_dmaDWordsRemaining;
/*       */     }
/* 13703 */     int rc = size;
/* 13704 */     m_dmaDWordsRemaining -= size;
/*       */     
/* 13706 */     size *= 2;
/*       */ 
/*       */ 
/*       */     
/*       */     try {
/* 13711 */       int[] ram = display.acquireDisplayBuffer();
/*       */ 
/*       */       
/* 13714 */       if (rgb24 && m_dmaW % 6 == 0) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 13730 */         while (size > 0) {
/* 13731 */           int dword = data[offset++];
/* 13732 */           switch (m_dmaRGB24Index) {
/*       */             case 0:
/* 13734 */               m_dmaRGB24LastPixel = dword & 0xFFFFFF;
/* 13735 */               ram[m_dmaX + m_dmaY * 1024] = 0xA000000 | m_dmaRGB24LastPixel;
/* 13736 */               m_dmaRGB24LastDWord = dword;
/* 13737 */               m_dmaX++;
/* 13738 */               m_dmaRGB24Index = 1;
/*       */               break;
/*       */             case 1:
/* 13741 */               ram[m_dmaX + m_dmaY * 1024] = 0xC000000 | m_dmaRGB24LastPixel & 0xFFFF00 | m_dmaRGB24LastDWord >> 24 & 0xFF;
/* 13742 */               m_dmaX++;
/* 13743 */               ram[m_dmaX + m_dmaY * 1024] = 0xE000000 | m_dmaRGB24LastDWord >> 24 & 0xFF | dword << 8 & 0xFFFFFF;
/* 13744 */               m_dmaRGB24LastDWord = dword;
/* 13745 */               m_dmaX++;
/* 13746 */               m_dmaRGB24Index = 2;
/*       */               break;
/*       */             case 2:
/* 13749 */               m_dmaRGB24LastPixel = m_dmaRGB24LastDWord >> 16 & 0xFFFF | dword << 16 & 0xFFFFFF;
/* 13750 */               ram[m_dmaX + m_dmaY * 1024] = 0xA000000 | m_dmaRGB24LastPixel;
/* 13751 */               m_dmaX++;
/* 13752 */               ram[m_dmaX + m_dmaY * 1024] = 0xC000000 | m_dmaRGB24LastPixel & 0xFFFF00 | dword >> 8 & 0xFF;
/* 13753 */               m_dmaX++;
/* 13754 */               ram[m_dmaX + m_dmaY * 1024] = 0xE000000 | dword >> 8 & 0xFFFFFF;
/* 13755 */               m_dmaX++;
/* 13756 */               m_dmaRGB24Index = 0;
/*       */               break;
/*       */           } 
/* 13759 */           if (m_dmaX == m_dmaOriginX + m_dmaW) {
/* 13760 */             m_dmaX = m_dmaOriginX;
/* 13761 */             m_dmaY++;
/* 13762 */             m_dmaRGB24Index = 0;
/* 13763 */             if (m_dmaY == m_dmaOriginY + m_dmaH) {
/*       */               break;
/*       */             }
/*       */           } 
/* 13767 */           size -= 2;
/*       */         } 
/*       */       } else {
/*       */         
/* 13771 */         while (size > 0) {
/* 13772 */           int dword = data[offset++];
/* 13773 */           int val = dword >> 16 & 0xFFFF;
/* 13774 */           ram[m_dmaX + m_dmaY * 1024] = dma16flags[m_dmaRGB24Index] | makePixel((dword & 0x1F) << 3, (dword & 0x3E0) >> 2, (dword & 0x7C00) >> 7, (dword & 0x8000) >> 15);
/* 13775 */           m_dmaX++;
/* 13776 */           m_dmaRGB24Index++;
/* 13777 */           if (m_dmaX == m_dmaOriginX + m_dmaW) {
/* 13778 */             m_dmaX = m_dmaOriginX;
/* 13779 */             m_dmaY++;
/* 13780 */             if (m_dmaY == m_dmaOriginY + m_dmaH) {
/*       */               break;
/*       */             }
/* 13783 */             m_dmaRGB24Index = 0;
/*       */           } 
/* 13785 */           size--;
/*       */           
/* 13787 */           ram[m_dmaX + m_dmaY * 1024] = dma16flags[m_dmaRGB24Index] | makePixel((val & 0x1F) << 3, (val & 0x3E0) >> 2, (val & 0x7C00) >> 7, (val & 0x8000) >> 15);
/* 13788 */           m_dmaX++;
/* 13789 */           m_dmaRGB24Index++;
/* 13790 */           if (m_dmaX == m_dmaOriginX + m_dmaW) {
/* 13791 */             m_dmaX = m_dmaOriginX;
/* 13792 */             m_dmaY++;
/* 13793 */             if (m_dmaY == m_dmaOriginY + m_dmaH) {
/*       */               break;
/*       */             }
/* 13796 */             m_dmaRGB24Index = 0;
/*       */           } 
/* 13798 */           size--;
/* 13799 */           if (m_dmaRGB24Index >= 3) m_dmaRGB24Index -= 3; 
/*       */         } 
/*       */       } 
/*       */     } finally {
/* 13803 */       display.releaseDisplayBuffer();
/*       */     } 
/*       */     
/* 13806 */     if (m_dmaDWordsRemaining == 0) {
/* 13807 */       int x = m_dmaOriginX;
/* 13808 */       int y = m_dmaOriginY;
/* 13809 */       int w = m_dmaW;
/* 13810 */       int h = m_dmaH;
/*       */       
/* 13812 */       for (int page = 0; page < 32; page++) {
/* 13813 */         int px = (page & 0xF) * 64;
/* 13814 */         int py = (page & 0x10) * 16;
/* 13815 */         if (intersects(x, y, w, h, px, py, 64, 256))
/*       */         {
/*       */ 
/*       */ 
/*       */           
/* 13820 */           _4bitTexturePages[page] = null;
/*       */         }
/* 13822 */         if (intersects(x, y, w, h, px, py, 128, 256))
/*       */         {
/*       */ 
/*       */ 
/*       */           
/* 13827 */           _8bitTexturePages[page] = null;
/*       */         }
/*       */       } 
/* 13830 */       manager.dirtyRectangle(x, y, w, h);
/* 13831 */       m_gpudState = 0;
/*       */     } 
/* 13833 */     return rc;
/*       */   }
/*       */ 
/*       */   
/*       */   private static boolean intersects(int x0, int y0, int w0, int h0, int x1, int y1, int w1, int h1) {
/* 13838 */     if (w0 == 0 || h0 == 0 || w1 == 0 || h1 == 0) return false; 
/* 13839 */     w0 += x0;
/* 13840 */     w1 += x1;
/* 13841 */     h0 += y0;
/* 13842 */     h1 += y1;
/* 13843 */     return (w0 > x1 && h0 > y1 && w1 > x0 && h1 > y0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudVRAMToMem(int[] data, int offset, int size) {
/* 13866 */     int x = data[offset + 1] & 0x3FF;
/* 13867 */     int y = data[offset + 1] >> 16 & 0x1FF;
/* 13868 */     int w = data[offset + 2] & 0x7FF;
/* 13869 */     int h = data[offset + 2] >> 16 & 0x3FF;
/*       */     
/* 13871 */     m_dmaX = x;
/* 13872 */     m_dmaY = y;
/* 13873 */     m_dmaOriginX = x;
/* 13874 */     m_dmaOriginY = y;
/* 13875 */     m_dmaW = w;
/* 13876 */     m_dmaH = h;
/* 13877 */     m_dmaWordsRemaining = w * h;
/*       */     
/* 13879 */     assert !rgb24;
/* 13880 */     return 0;
/*       */   }
/*       */   
/*       */   private static int readPixel() {
/* 13884 */     if (m_dmaWordsRemaining > 0) {
/* 13885 */       m_dmaWordsRemaining--;
/* 13886 */       rc = unmakePixel(videoRAM[m_dmaX + m_dmaY * 1024]);
/* 13887 */       m_dmaX++;
/* 13888 */       if (m_dmaX == m_dmaOriginX + m_dmaW) {
/* 13889 */         m_dmaX = m_dmaOriginX;
/* 13890 */         m_dmaY++;
/*       */       } 
/* 13892 */       return rc;
/*       */     } 
/* 13894 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpudSetDrawMode(int[] data, int offset, int size) {
/* 13898 */     drawMode = data[offset] & 0x7FF;
/* 13899 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudSetTextureWindow(int[] data, int offset, int size) {
/* 13907 */     noTextureWindow = (0 == (data[offset] & 0xFFFFF));
/* 13908 */     if (!noTextureWindow) {
/* 13909 */       int twy = data[offset] >> 15 & 0x1F;
/* 13910 */       int twx = data[offset] >> 10 & 0x1F;
/* 13911 */       int twh = 32 - (data[offset] >> 5 & 0x1F);
/* 13912 */       int tww = 32 - (data[offset] & 0x1F);
/*       */ 
/*       */       
/* 13915 */       int val = twx << 3;
/* 13916 */       int w = 0;
/* 13917 */       for (int i = twx; i < 32 + twx; i++) {
/* 13918 */         twuLookup[i & 0x1F] = val;
/* 13919 */         val += 8;
/* 13920 */         w++;
/* 13921 */         if (w == tww) {
/* 13922 */           w = 0;
/* 13923 */           val = twx << 3;
/*       */         } 
/*       */       } 
/*       */       
/* 13927 */       val = twy << 11;
/* 13928 */       int h = 0;
/* 13929 */       for (int i = twy; i < 32 + twy; i++) {
/* 13930 */         twvLookup[i & 0x1F] = val;
/* 13931 */         val += 2048;
/* 13932 */         h++;
/* 13933 */         if (h == twh) {
/* 13934 */           h = 0;
/* 13935 */           val = twy << 11;
/*       */         } 
/*       */       } 
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 13943 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpudSetClipTopLeft(int[] data, int offset, int size) {
/* 13947 */     m_clipLeft = data[offset] & 0x3FF;
/* 13948 */     m_clipTop = data[offset] >> 10 & 0x3FF;
/*       */     
/* 13950 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudSetClipBottomRight(int[] data, int offset, int size) {
/* 13956 */     m_clipRight = (data[offset] & 0x3FF) + 1;
/* 13957 */     m_clipBottom = (data[offset] >> 10 & 0x3FF) + 1;
/*       */     
/* 13959 */     return 0;
/*       */   }
/*       */   
/*       */   public static int gpudSetDrawingOffset(int[] data, int offset, int size) {
/* 13963 */     m_drawOffsetX = (data[offset] & 0x7FF) << 21 >> 21;
/* 13964 */     m_drawOffsetY = (data[offset] & 0x3FF800) << 10 >> 21;
/*       */     
/* 13966 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int gpudSetMaskMode(int[] data, int offset, int size) {
/* 13973 */     drawMode = drawMode & 0xFFFFE7FF | (data[offset] & 0x1800) >> 11;
/* 13974 */     return 0;
/*       */   }
/*       */ 
/*       */   
/*       */   public static int gpuStatusRead32(int address) {
/* 13979 */     int rc = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 13993 */     rc |= drawMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 14001 */     rc |= displayMode << 16;
/*       */ 
/*       */     
/* 14004 */     if (!m_displayEnabled) {
/* 14005 */       rc |= 0x800000;
/*       */     }
/*       */ 
/*       */     
/* 14009 */     rc |= 0x4000000;
/*       */ 
/*       */ 
/*       */     
/* 14013 */     rc |= 0x8000000;
/*       */ 
/*       */     
/* 14016 */     rc |= 0x10000000;
/*       */ 
/*       */     
/* 14019 */     rc |= dmaMode << 29;
/*       */ 
/*       */ 
/*       */     
/* 14023 */     if (manager.getInterlaceField()) {
/* 14024 */       rc |= Integer.MIN_VALUE;
/*       */     }
/* 14026 */     return rc;
/*       */   }
/*       */ 
/*       */   
/* 14030 */   public void aboutToBlock() { manager.preAsync(); }
/*       */ 
/*       */   
/*       */   public void poll(int address, int size) {
/* 14034 */     assert address == 528488468;
/* 14035 */     if (0 != (displayMode & 0x40))
/*       */     {
/* 14037 */       manager.toggleInterlaceField();
/*       */     }
/*       */ 
/*       */     
/* 14041 */     manager.vsync();
/*       */   }
/*       */   
/*       */   public static int gpuDataRead32(int address) {
/* 14045 */     videoRAM = display.acquireDisplayBuffer();
/*       */ 
/*       */     
/*       */     try {
/* 14049 */       return readPixel() + (readPixel() << 16);
/*       */     } finally {
/*       */       
/* 14052 */       display.releaseDisplayBuffer();
/* 14053 */       videoRAM = null;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void gpusReset(int val) {
/* 14177 */     gpusSetDispEnable(1);
/* 14178 */     gpusSetDisplayMode(0);
/* 14179 */     gpusSetDisplayOrigin(0);
/* 14180 */     maskMode = 0;
/* 14181 */     m_gpudState = 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 14187 */   private static void gpusCmdReset(int val) { m_gpudState = 0; }
/*       */ 
/*       */ 
/*       */   
/*       */   private static void gpusIRQReset(int val) {}
/*       */ 
/*       */   
/*       */   private static void gpusSetDispEnable(int val) {
/* 14195 */     m_displayEnabled = ((val & true) == 0);
/* 14196 */     manager.setBlanked(!m_displayEnabled);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/* 14201 */   private static void gpusSetDataTransferMode(int val) { dmaMode = val & 0x3; }
/*       */ 
/*       */ 
/*       */   
/*       */   private static void gpusSetDisplayOrigin(int val) {
/* 14206 */     int originX = val & 0x3FF;
/* 14207 */     int originY = val >> 10 & 0x1FF;
/* 14208 */     manager.setOrigin(originX, originY);
/*       */   }
/*       */   
/*       */   private static void gpusSetMonitorLeftRight(int val) {
/* 14212 */     int l = val & 0xFFF;
/* 14213 */     int r = val >> 12 & 0xFFF;
/* 14214 */     manager.setHorizontalTiming(l, r);
/*       */   }
/*       */   
/*       */   private static void gpusSetMonitorTopBottom(int val) {
/* 14218 */     int t = val & 0x3FF;
/* 14219 */     int b = val >> 10 & 0x3FF;
/* 14220 */     manager.setVerticalTiming(t, b);
/*       */   }
/*       */   
/*       */   private static void gpusSetDisplayMode(int val) {
/* 14224 */     displayMode = (val & 0x3F) << 1 | val & true;
/*       */     
/* 14226 */     boolean doubleY = (0 != (val & 0x4));
/* 14227 */     boolean pal = (0 != (val & 0x8));
/* 14228 */     boolean rgb24 = (0 != (val & 0x10));
/* 14229 */     boolean interlace = (0 != (val & 0x20));
/* 14230 */     int divider = 8;
/*       */ 
/*       */     
/* 14233 */     switch (val & 0x43) {
/*       */       case 0:
/* 14235 */         divider = 10;
/*       */         break;
/*       */       case 1:
/* 14238 */         divider = 8;
/*       */         break;
/*       */       case 2:
/* 14241 */         divider = 5;
/*       */         break;
/*       */       case 3:
/* 14244 */         divider = 4;
/*       */         break;
/*       */       case 64:
/* 14247 */         divider = 7;
/*       */         break;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/* 14253 */     manager.setPixelDivider(divider);
/* 14254 */     manager.setRGB24(rgb24);
/* 14255 */     manager.setInterlaced(interlace);
/* 14256 */     manager.setDoubleY(doubleY);
/* 14257 */     manager.setNTSC(!pal);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static void gpusRequestInfo(int val) {
/* 14264 */     val = (int)(val & 0xFFFFFFL);
/* 14265 */     switch (val) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       case 7:
/* 14280 */         addressSpace.internalWrite32(528488464, 2);
/*       */         break;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static void handleGPUData(int[] mem, int offset, int size) {
/* 14309 */     int origOffset = offset;
/*       */     
/* 14311 */     while (size > 0) {
/* 14312 */       int dwordsUsed; int i; int count; switch (m_gpudState) {
/*       */         case 0:
/* 14314 */           m_gpudCommand = mem[offset] >> 24 & 0xFF;
/*       */ 
/*       */           
/* 14317 */           count = m_gpudFunctionArgumentCount[m_gpudCommand];
/* 14318 */           if (size >= count) {
/* 14319 */             GPUDRouter.invoke(mem, offset, count);
/* 14320 */             offset += count;
/* 14321 */             size -= count;
/*       */             continue;
/*       */           } 
/* 14324 */           for (i = 0; i < size; i++) {
/* 14325 */             m_cmdBuffer[i++] = mem[offset++];
/*       */           }
/* 14327 */           cmdBufferUsed = size;
/* 14328 */           cmdBufferTarget = count;
/* 14329 */           m_gpudState = 2;
/* 14330 */           size = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         case 1:
/* 14336 */           m_cmdBuffer[cmdBufferUsed++] = mem[offset++];
/* 14337 */           size--;
/* 14338 */           if (cmdBufferUsed == cmdBufferTarget) {
/* 14339 */             m_gpudState = 0;
/* 14340 */             GPUDRouter.invoke(m_cmdBuffer, 0, cmdBufferUsed);
/*       */           } 
/*       */ 
/*       */ 
/*       */         
/*       */         case 2:
/* 14346 */           dwordsUsed = GPUDRouter.invoke(mem, offset, size);
/* 14347 */           assert dwordsUsed <= size;
/*       */           
/* 14349 */           size -= dwordsUsed;
/* 14350 */           offset += dwordsUsed;
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/* 14356 */   private static AddressSpace.ResolveResult m_resolveResult = new AddressSpace.ResolveResult(); private static JavaClass m_templateTClass; private static JavaClass m_templateLClass; private static JavaClass m_templateSClass; private static JavaClass m_templateQClass; private static JavaClass m_templateRClass;
/*       */   
/*       */   private static void handleGPUDataChain(int address) {
/* 14359 */     address &= 0xFFFFFF;
/* 14360 */     int[] mainRAM = addressSpace.getMainRAM();
/* 14361 */     while (address < 2097152) {
/* 14362 */       int head = mainRAM[address >> 2];
/*       */       
/* 14364 */       int count = head >> 24 & 0xFF;
/* 14365 */       if (count > 0) {
/* 14366 */         handleGPUData(mainRAM, (address >> 2) + 1, count);
/*       */       }
/* 14368 */       address = head & 0xFFFFFF;
/*       */       
/* 14370 */       if ((address & 0xFFFFFF) == 0) {
/*       */         break;
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/* 14377 */   public static final int makePixel(int val) { return makePixel((val & 0x1F) << 3, (val & 0x3E0) >> 2, (val & 0x7C00) >> 7, (val & 0x8000) >> 15); }
/*       */ 
/*       */ 
/*       */   
/* 14381 */   public static final int makePixel(int r, int g, int b, int mask) { return r << 16 | g << 8 | b | mask << 24; }
/*       */ 
/*       */ 
/*       */   
/* 14385 */   public static final int unmakePixel(int pixel) { return (pixel & 0xF8) << 7 | (pixel & 0xF800) >> 6 | (pixel & 0xF80000) >> 19 | (pixel & 0x1000000) >> 9; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private JavaClass getTemplateTClass() {
/* 14395 */     if (m_templateTClass == null) {
/* 14396 */       String filename = "org/jpsx/runtime/components/hardware/gpu/GPU$TemplateTriangleRenderer.class";
/* 14397 */       URL url = getClass().getClassLoader().getResource(filename);
/*       */       try {
/* 14399 */         stream = url.openStream();
/*       */         try {
/* 14401 */           m_templateTClass = (new ClassParser(stream, filename)).parse();
/*       */         } finally {
/* 14403 */           stream.close();
/*       */         } 
/* 14405 */       } catch (IOException e) {}
/*       */     } 
/*       */     
/* 14408 */     return m_templateTClass.copy();
/*       */   }
/*       */   
/*       */   private JavaClass getTemplateSClass() {
/* 14412 */     if (m_templateSClass == null) {
/* 14413 */       String filename = "org/jpsx/runtime/components/hardware/gpu/GPU$TemplateSpriteRenderer.class";
/* 14414 */       URL url = getClass().getClassLoader().getResource(filename);
/*       */       try {
/* 14416 */         stream = url.openStream();
/*       */         try {
/* 14418 */           m_templateSClass = (new ClassParser(stream, filename)).parse();
/*       */         } finally {
/* 14420 */           stream.close();
/*       */         } 
/* 14422 */       } catch (IOException e) {}
/*       */     } 
/*       */     
/* 14425 */     return m_templateSClass.copy();
/*       */   }
/*       */   
/*       */   private JavaClass getTemplateQClass() {
/* 14429 */     if (m_templateQClass == null) {
/* 14430 */       String filename = "org/jpsx/runtime/components/hardware/gpu/GPU$TemplateQuadRenderer.class";
/* 14431 */       URL url = getClass().getClassLoader().getResource(filename);
/*       */       try {
/* 14433 */         stream = url.openStream();
/*       */         try {
/* 14435 */           m_templateQClass = (new ClassParser(stream, filename)).parse();
/*       */         } finally {
/* 14437 */           stream.close();
/*       */         } 
/* 14439 */       } catch (IOException e) {}
/*       */     } 
/*       */     
/* 14442 */     return m_templateQClass.copy();
/*       */   }
/*       */   
/*       */   private JavaClass getTemplateRClass() {
/* 14446 */     if (m_templateRClass == null) {
/* 14447 */       String filename = "org/jpsx/runtime/components/hardware/gpu/GPU$TemplateRectangleRenderer.class";
/* 14448 */       URL url = getClass().getClassLoader().getResource(filename);
/*       */       try {
/* 14450 */         stream = url.openStream();
/*       */         try {
/* 14452 */           m_templateRClass = (new ClassParser(stream, filename)).parse();
/*       */         } finally {
/* 14454 */           stream.close();
/*       */         } 
/* 14456 */       } catch (IOException e) {}
/*       */     } 
/*       */     
/* 14459 */     return m_templateRClass.copy();
/*       */   }
/*       */   
/*       */   private JavaClass getTemplateLClass() {
/* 14463 */     if (m_templateLClass == null) {
/* 14464 */       String filename = "org/jpsx/runtime/components/hardware/gpu/GPU$TemplateLineRenderer.class";
/* 14465 */       URL url = getClass().getClassLoader().getResource(filename);
/*       */       try {
/* 14467 */         stream = url.openStream();
/*       */         try {
/* 14469 */           m_templateLClass = (new ClassParser(stream, filename)).parse();
/*       */         } finally {
/* 14471 */           stream.close();
/*       */         } 
/* 14473 */       } catch (IOException e) {}
/*       */     } 
/*       */     
/* 14476 */     return m_templateLClass.copy();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ClassGen generateClass(String classname) {
/* 14500 */     String suffix = classname.substring(classname.indexOf("$_") + 2);
/* 14501 */     if (suffix.charAt(0) == 'T' || suffix.charAt(0) == 'L' || suffix.charAt(0) == 'S' || suffix.charAt(0) == 'Q' || suffix.charAt(0) == 'R') {
/*       */       JavaClass jclass; boolean targetSolid, targetMaskCheck, targetMaskSet; int targetSemi; boolean targetGouraud; int targetTextureType;
/* 14503 */       switch (suffix.charAt(1)) {
/*       */         case '0':
/* 14505 */           targetTextureType = 0;
/*       */           break;
/*       */         case '4':
/* 14508 */           targetTextureType = 1;
/*       */           break;
/*       */         case '8':
/* 14511 */           targetTextureType = 2;
/*       */           break;
/*       */         case '6':
/* 14514 */           targetTextureType = 3;
/*       */           break;
/*       */         case '5':
/* 14517 */           targetTextureType = 4;
/*       */           break;
/*       */         case '9':
/* 14520 */           targetTextureType = 5;
/*       */           break;
/*       */         case '7':
/* 14523 */           targetTextureType = 6;
/*       */           break;
/*       */         default:
/* 14526 */           throw new IllegalStateException("Unknown texture type " + suffix.charAt(1));
/*       */       } 
/*       */       
/* 14529 */       switch (suffix.charAt(2)) {
/*       */         case '0':
/* 14531 */           targetGouraud = false;
/*       */           break;
/*       */         case '1':
/* 14534 */           targetGouraud = true;
/*       */           break;
/*       */         default:
/* 14537 */           throw new IllegalStateException("Unknown gouraud flag " + suffix.charAt(2));
/*       */       } 
/*       */       
/* 14540 */       switch (suffix.charAt(3)) {
/*       */         case '0':
/* 14542 */           targetSemi = 0;
/*       */           break;
/*       */         case '1':
/* 14545 */           targetSemi = 1;
/*       */           break;
/*       */         case '2':
/* 14548 */           targetSemi = 2;
/*       */           break;
/*       */         case '3':
/* 14551 */           targetSemi = 3;
/*       */           break;
/*       */         case '4':
/* 14554 */           targetSemi = 4;
/*       */           break;
/*       */         default:
/* 14557 */           throw new IllegalStateException("Unknown semi flag " + suffix.charAt(3));
/*       */       } 
/*       */       
/* 14560 */       switch (suffix.charAt(4)) {
/*       */         case '0':
/* 14562 */           targetMaskSet = false;
/*       */           break;
/*       */         case '1':
/* 14565 */           targetMaskSet = true;
/*       */           break;
/*       */         default:
/* 14568 */           throw new IllegalStateException("Unknown mask set flag " + suffix.charAt(4));
/*       */       } 
/*       */       
/* 14571 */       switch (suffix.charAt(5)) {
/*       */         case '0':
/* 14573 */           targetMaskCheck = false;
/*       */           break;
/*       */         case '1':
/* 14576 */           targetMaskCheck = true;
/*       */           break;
/*       */         default:
/* 14579 */           throw new IllegalStateException("Unknown mask check flag " + suffix.charAt(5));
/*       */       } 
/*       */       
/* 14582 */       switch (suffix.charAt(6)) {
/*       */         case '0':
/* 14584 */           targetSolid = false;
/*       */           break;
/*       */         case '1':
/* 14587 */           targetSolid = true;
/*       */           break;
/*       */         default:
/* 14590 */           throw new IllegalStateException("Unknown solid flag " + suffix.charAt(6));
/*       */       } 
/*       */ 
/*       */       
/* 14594 */       if (suffix.charAt(0) == 'T') {
/* 14595 */         jclass = getTemplateTClass();
/* 14596 */       } else if (suffix.charAt(0) == 'L') {
/* 14597 */         jclass = getTemplateLClass();
/* 14598 */       } else if (suffix.charAt(0) == 'S') {
/* 14599 */         jclass = getTemplateSClass();
/* 14600 */       } else if (suffix.charAt(0) == 'R') {
/* 14601 */         jclass = getTemplateRClass();
/*       */       } else {
/* 14603 */         jclass = getTemplateQClass();
/*       */       } 
/* 14605 */       String origClassName = jclass.getClassName();
/* 14606 */       jclass.setFileName(JPSXClassLoader.getClassFilename(classname));
/* 14607 */       ClassGen cgen = new ClassGen(jclass);
/* 14608 */       ConstantPoolGen cp = cgen.getConstantPool();
/*       */ 
/*       */       
/* 14611 */       cgen.setClassName(classname);
/* 14612 */       if (suffix.charAt(0) == 'Q') {
/* 14613 */         int utfIndex = cp.lookupUtf8("org/jpsx/runtime/components/hardware/gpu/GPU$TemplateTriangleRenderer");
/* 14614 */         cp.setConstant(utfIndex, new ConstantUtf8(classname.replace('Q', 'T').replace('.', '/')));
/* 14615 */         utfIndex = cp.lookupUtf8("org/jpsx/runtime/components/hardware/gpu/GPU$TemplateRectangleRenderer");
/* 14616 */         cp.setConstant(utfIndex, new ConstantUtf8(classname.replace('Q', 'R').replace('.', '/')));
/*       */ 
/*       */       
/*       */       }
/*       */       else {
/*       */ 
/*       */         
/* 14623 */         Field field = cgen.containsField("_renderTextureType");
/* 14624 */         FieldGen fg = new FieldGen(field, cp);
/* 14625 */         fg.isFinal(true);
/* 14626 */         fg.cancelInitValue();
/* 14627 */         fg.setInitValue(targetTextureType);
/* 14628 */         cgen.replaceField(field, fg.getField());
/*       */         
/* 14630 */         field = cgen.containsField("_renderSemiType");
/* 14631 */         fg = new FieldGen(field, cp);
/* 14632 */         fg.isFinal(true);
/* 14633 */         fg.cancelInitValue();
/* 14634 */         fg.setInitValue(targetSemi);
/* 14635 */         cgen.replaceField(field, fg.getField());
/*       */         
/* 14637 */         field = cgen.containsField("_renderBReg");
/* 14638 */         fg = new FieldGen(field, cp);
/* 14639 */         fg.isFinal(true);
/* 14640 */         fg.cancelInitValue();
/* 14641 */         fg.setInitValue((targetGouraud && targetTextureType != 0));
/* 14642 */         cgen.replaceField(field, fg.getField());
/*       */         
/* 14644 */         field = cgen.containsField("_renderGouraud");
/* 14645 */         fg = new FieldGen(field, cp);
/* 14646 */         fg.isFinal(true);
/* 14647 */         fg.cancelInitValue();
/* 14648 */         fg.setInitValue(targetGouraud);
/* 14649 */         cgen.replaceField(field, fg.getField());
/*       */         
/* 14651 */         field = cgen.containsField("_renderCheckMask");
/* 14652 */         fg = new FieldGen(field, cp);
/* 14653 */         fg.isFinal(true);
/* 14654 */         fg.cancelInitValue();
/* 14655 */         fg.setInitValue(targetMaskCheck);
/* 14656 */         cgen.replaceField(field, fg.getField());
/*       */         
/* 14658 */         field = cgen.containsField("_renderSetMask");
/* 14659 */         fg = new FieldGen(field, cp);
/* 14660 */         fg.isFinal(true);
/* 14661 */         fg.cancelInitValue();
/* 14662 */         fg.setInitValue(targetMaskSet);
/* 14663 */         cgen.replaceField(field, fg.getField());
/*       */         
/* 14665 */         field = cgen.containsField("_renderSolid");
/* 14666 */         fg = new FieldGen(field, cp);
/* 14667 */         fg.isFinal(true);
/* 14668 */         fg.cancelInitValue();
/* 14669 */         fg.setInitValue(targetSolid);
/* 14670 */         cgen.replaceField(field, fg.getField());
/*       */       } 
/*       */ 
/*       */ 
/*       */       
/* 14675 */       cp.setConstant(cp.lookupClass(origClassName), cp.getConstant(cp.lookupClass(classname)));
/* 14676 */       return cgen;
/*       */     } 
/* 14678 */     throw new IllegalStateException("Unknown inner class to generate " + classname);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setVRAMFormat(boolean rgb24) {
/* 14685 */     if (rgb24 != GPU.rgb24) {
/*       */       
/* 14687 */       GPU.rgb24 = rgb24;
/* 14688 */       int[] ram = display.acquireDisplayBuffer();
/* 14689 */       if (rgb24) {
/*       */ 
/*       */ 
/*       */         
/* 14693 */         int last = 0;
/* 14694 */         for (int i = 0; i < 524288; i++) {
/* 14695 */           int pp, decoded2, decoded, decoded, decoded, pixel = ram[i];
/* 14696 */           switch (pixel & 0xE000000) {
/*       */             case 33554432:
/* 14698 */               decoded = unmakePixel(pixel);
/* 14699 */               decoded2 = unmakePixel(ram[i + 1]);
/* 14700 */               ram[i] = 0xA000000 | decoded | (decoded2 & 0xFF) << 16;
/* 14701 */               last = decoded;
/*       */               break;
/*       */             
/*       */             case 67108864:
/* 14705 */               decoded = unmakePixel(pixel);
/* 14706 */               pp = last | (decoded & 0xFF) << 16;
/* 14707 */               ram[i] = 0xC000000 | pp & 0xFFFF00 | decoded >> 8 & 0xFF;
/* 14708 */               last = decoded;
/*       */               break;
/*       */             
/*       */             case 100663296:
/* 14712 */               decoded = unmakePixel(pixel);
/* 14713 */               ram[i] = 0xE000000 | decoded << 8 | last >> 8 & 0xFF;
/*       */               break;
/*       */           } 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         } 
/*       */       } else {
/* 14722 */         for (int i = 0; i < 524288; i++) {
/* 14723 */           int pixel = ram[i];
/* 14724 */           switch (pixel & 0xE000000) {
/*       */             case 167772160:
/* 14726 */               ram[i] = 0x2000000 | makePixel(pixel & 0xFFFF);
/*       */               break;
/*       */             
/*       */             case 201326592:
/* 14730 */               ram[i] = 0x4000000 | makePixel((pixel & 0xFF) << 8 | pixel >> 16 & 0xFF);
/*       */               break;
/*       */             
/*       */             case 234881024:
/* 14734 */               ram[i] = 0x6000000 | makePixel(pixel >> 8 & 0xFFFF);
/*       */               break;
/*       */           } 
/*       */         
/*       */         } 
/*       */       } 
/* 14740 */       display.releaseDisplayBuffer();
/*       */     } 
/*       */   }
/*       */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\gpu\GPU.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */