/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.mdec;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*     */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*     */ import org.jpsx.runtime.JPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.mdec.MDEC;
/*     */ import org.jpsx.runtime.util.MiscUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MDEC
/*     */   extends JPSXComponent
/*     */   implements MemoryMapped
/*     */ {
/*  31 */   private static final Logger log = Logger.getLogger("MDEC");
/*     */   
/*  33 */   private static final boolean debugMDEC = log.isDebugEnabled();
/*     */   
/*     */   private static final int ADDR_MDEC_CTRL = 528488480;
/*     */   
/*     */   private static final int ADDR_MDEC_STATUS = 528488484;
/*     */   
/*     */   private static final int NFIFO0 = -2147483648;
/*     */   
/*     */   private static final int FIFO1 = 1073741824;
/*     */   
/*     */   private static final int BUSY0 = 536870912;
/*     */   
/*     */   private static final int DREQ0 = 268435456;
/*     */   
/*     */   private static final int DREQ1 = 134217728;
/*     */   
/*     */   private static final int RGB24 = 33554432;
/*     */   
/*     */   private static final int BUSY1 = 16777216;
/*     */   
/*     */   private static final int STP = 8388608;
/*     */   
/*     */   private static final int CTRL_RGB24 = 134217728;
/*     */   
/*     */   private static final int CTRL_STP = 33554432;
/*  58 */   private static final int[] yqm = new int[64];
/*  59 */   private static final int[] uvqm = new int[64];
/*     */   private static final int[] unzig = { 
/*  61 */       0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 };
/*     */ 
/*     */   
/*     */   private static AddressSpace addressSpace;
/*     */   
/*     */   private static int ctrl;
/*     */   
/*     */   private static int status;
/*     */   
/*     */   private static int stp;
/*     */   
/*  72 */   private static AddressSpace.ResolveResult source = new AddressSpace.ResolveResult();
/*     */   
/*     */   private static int sourceRemaining;
/*     */   
/*  76 */   public MDEC() { super("JPSX Movie Decoder"); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  81 */     super.init();
/*  82 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*  83 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new InChannel(null));
/*  84 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new OutChannel(null));
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/*  89 */     super.resolveConnections();
/*  90 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*     */   }
/*     */   
/*     */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/*  94 */     registrar.registerWrite32Callback(528488480, MDEC.class, "writeCtrl32");
/*  95 */     registrar.registerWrite32Callback(528488484, MDEC.class, "writeStatus32");
/*  96 */     registrar.registerRead32Callback(528488480, MDEC.class, "readCtrl32");
/*  97 */     registrar.registerRead32Callback(528488484, MDEC.class, "readStatus32");
/*     */   }
/*     */   
/*     */   public static void writeStatus32(int address, int value) {
/* 101 */     if (debugMDEC) log.debug("MDEC status write32 " + MiscUtil.toHex(value, 8)); 
/* 102 */     if (value == Integer.MIN_VALUE) {
/* 103 */       if (debugMDEC) log.debug("MDEC turn off FIFO"); 
/* 104 */       status = value;
/* 105 */     } else if (value == 1610612736) {
/* 106 */       if (debugMDEC) log.debug("MDEC turn on FIFO"); 
/* 107 */       status = value & 0xDFFFFFFF;
/*     */     } else {
/* 109 */       throw new IllegalStateException("MDEC unknown status write " + MiscUtil.toHex(value, 8));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void writeCtrl32(int address, int value) {
/* 114 */     if (debugMDEC) log.debug("MDEC ctrl write32 " + MiscUtil.toHex(value, 8));
/*     */     
/* 116 */     ctrl = value;
/* 117 */     if (0 != (ctrl & 0x8000000)) {
/* 118 */       status &= 0xFDFFFFFF;
/*     */     } else {
/* 120 */       status |= 0x2000000;
/*     */     } 
/* 122 */     if (0 != (ctrl & 0x2000000)) {
/* 123 */       status |= 0x800000;
/* 124 */       stp = 32768;
/*     */     } else {
/* 126 */       status &= 0xFF7FFFFF;
/* 127 */       stp = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int readStatus32(int address) {
/* 132 */     int rc = status;
/* 133 */     if (debugMDEC) log.debug("MDEC status read32 " + MiscUtil.toHex(rc, 8)); 
/* 134 */     return rc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public static int readCtrl32(int address) { throw new IllegalStateException("wahhh?"); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\mdec\MDEC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */