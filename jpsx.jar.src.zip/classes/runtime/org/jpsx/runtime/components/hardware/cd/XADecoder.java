/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.cd;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.runtime.components.hardware.cd.XADecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XADecoder
/*     */ {
/*     */   Logger log;
/*  28 */   private static int[] IK0 = { 0, -60, -115, -98, -122 };
/*  29 */   private static int[] IK1 = { 0, 0, 52, 55, 60 };
/*     */ 
/*     */   
/*  32 */   private static int[] headTable = { 4, 6, 8, 10 }; private ChannelContext leftContext;
/*     */   private ChannelContext rightContext;
/*     */   private boolean firstSector;
/*     */   private boolean invalid;
/*     */   private int freq;
/*     */   private int bps;
/*     */   private boolean stereo;
/*     */   private static final int BLOCK_SIZE = 28;
/*     */   private int[] encoded;
/*     */   
/*     */   public XADecoder() { this.log = Logger.getLogger("XADecode");
/*  43 */     this.leftContext = new ChannelContext(null);
/*  44 */     this.rightContext = new ChannelContext(null);
/*  45 */     this.firstSector = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.encoded = new int[14];
/*     */     reset(); }
/*     */   public void reset() {
/*     */     this.leftContext.reset();
/*     */     this.rightContext.reset();
/*     */     this.firstSector = true;
/* 124 */   } private int decode(byte[] src, int srcOffset, byte[] dest, int destOffset) { int nbits = (this.bps == 4) ? 4 : 2;
/* 125 */     int sampleCount = 0;
/*     */     
/* 127 */     if (this.stereo) {
/* 128 */       for (int j = 0; j < 18; j++) {
/* 129 */         int sound_groupsp = srcOffset + j * 128;
/* 130 */         int sound_datap = sound_groupsp + 16;
/*     */         
/* 132 */         for (int i = 0; i < nbits; i++) {
/* 133 */           int datap = 0;
/* 134 */           int sound_datap2 = sound_datap + i;
/* 135 */           if (this.bps == 8 && this.freq == 37800) {
/* 136 */             for (int k = 0; k < 14; k++, sound_datap2 += 8) {
/* 137 */               this.encoded[datap++] = src[sound_datap2] & 0xFF | (src[sound_datap2 + 4] & 0xFF) << 8;
/*     */             }
/*     */           } else {
/*     */             
/* 141 */             for (int k = 0; k < 7; k++, sound_datap2 += 16) {
/* 142 */               this.encoded[datap++] = src[sound_datap2] & 0xF | (src[sound_datap2 + 4] & 0xF) << 4 | (src[sound_datap2 + 8] & 0xF) << 8 | (src[sound_datap2 + 12] & 0xF) << 12;
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 148 */           decodeBlock16(this.leftContext, src[sound_groupsp + headTable[i]], this.encoded, dest, destOffset, 4);
/*     */           
/* 150 */           datap = 0;
/* 151 */           sound_datap2 = sound_datap + i;
/* 152 */           if (this.bps == 8 && this.freq == 37800) {
/* 153 */             for (int k = 0; k < 14; k++, sound_datap2 += 8) {
/* 154 */               this.encoded[datap++] = src[sound_datap2] & 0xFF | (src[sound_datap2 + 4] & 0xFF) << 8;
/*     */             }
/*     */           } else {
/*     */             
/* 158 */             for (int k = 0; k < 7; k++, sound_datap2 += 16) {
/* 159 */               this.encoded[datap++] = (src[sound_datap2] & 0xF0 | (src[sound_datap2 + 4] & 0xF0) << 4 | (src[sound_datap2 + 8] & 0xF0) << 8 | (src[sound_datap2 + 12] & 0xF0) << 12) >> 4;
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 165 */           decodeBlock16(this.rightContext, src[sound_groupsp + headTable[i] + 1], this.encoded, dest, destOffset + 2, 4);
/* 166 */           destOffset += 112;
/* 167 */           sampleCount += 28;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 171 */       for (int j = 0; j < 18; j++) {
/* 172 */         int sound_groupsp = srcOffset + j * 128;
/* 173 */         int sound_datap = sound_groupsp + 16;
/*     */         
/* 175 */         for (int i = 0; i < nbits; i++) {
/* 176 */           int datap = 0;
/* 177 */           int sound_datap2 = sound_datap + i;
/* 178 */           if (this.bps == 8 && this.freq == 37800) {
/* 179 */             for (int k = 0; k < 14; k++, sound_datap2 += 8) {
/* 180 */               this.encoded[datap++] = src[sound_datap2] & 0xFF | (src[sound_datap2 + 4] & 0xFF) << 8;
/*     */             }
/*     */           } else {
/*     */             
/* 184 */             for (int k = 0; k < 7; k++, sound_datap2 += 16) {
/* 185 */               this.encoded[datap++] = src[sound_datap2] & 0xF | (src[sound_datap2 + 4] & 0xF) << 4 | (src[sound_datap2 + 8] & 0xF) << 8 | (src[sound_datap2 + 12] & 0xF) << 12;
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 191 */           decodeBlock16(this.leftContext, src[sound_groupsp + headTable[i]], this.encoded, dest, destOffset, 4);
/* 192 */           destOffset += 112;
/* 193 */           sampleCount += 28;
/*     */           
/* 195 */           datap = 0;
/* 196 */           sound_datap2 = sound_datap + i;
/* 197 */           if (this.bps == 8 && this.freq == 37800) {
/* 198 */             for (int k = 0; k < 14; k++, sound_datap2 += 8) {
/* 199 */               this.encoded[datap++] = src[sound_datap2] & 0xFF | (src[sound_datap2 + 4] & 0xFF) << 8;
/*     */             }
/*     */           } else {
/*     */             
/* 203 */             for (int k = 0; k < 7; k++, sound_datap2 += 16) {
/* 204 */               this.encoded[datap++] = (src[sound_datap2] & 0xF0 | (src[sound_datap2 + 4] & 0xF0) << 4 | (src[sound_datap2 + 8] & 0xF0) << 8 | (src[sound_datap2 + 12] & 0xF0) << 12) >> 4;
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 210 */           decodeBlock16(this.leftContext, src[sound_groupsp + headTable[i] + 1], this.encoded, dest, destOffset, 4);
/* 211 */           destOffset += 112;
/* 212 */           sampleCount += 28;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     return sampleCount; }
/*     */   private void decodeBlock16(ChannelContext context, int filterRange, int[] src, byte[] dest, int destOffset, int inc) { int filterId = filterRange >> 4 & 0xF; int range = (filterRange & 0xF) + 12; filterId &= 0x3; int fy0 = context.y0; int fy1 = context.y1; int ik0 = IK0[filterId]; int ik1 = IK1[filterId]; int s = 0; int d = destOffset; for (int i = 7; i > 0; i--) { int x = src[s++]; int x0 = x << 28 >> range; x0 -= (ik0 * fy0 + ik1 * fy1 >> 6); if (x0 > 524072) { x0 = 524072; } else if (x0 < -525088) { x0 = 525088; }  dest[d] = (byte)(x0 >> 4); dest[d + 1] = (byte)(x0 >> 12); d += inc; int x1 = (x << 24 & 0xF0000000) >> range; x1 -= (ik0 * x0 + ik1 * fy0 >> 6); if (x1 > 524072) { x1 = 524072; } else if (x1 < -525088) { x1 = 525088; }  dest[d] = (byte)(x1 >> 4); dest[d + 1] = (byte)(x1 >> 12); d += inc; int x2 = (x << 20 & 0xF0000000) >> range; x2 -= (ik0 * x1 + ik1 * x0 >> 6); if (x0 > 524072) { x2 = 524072; } else if (x2 < -525088) { x2 = 525088; }  dest[d] = (byte)(x2 >> 4); dest[d + 1] = (byte)(x2 >> 12); d += inc; int x3 = (x << 16 & 0xF0000000) >> range; x3 -= (ik0 * x2 + ik1 * x1 >> 6); if (x0 > 524072) { x3 = 524072; }
/*     */       else if (x3 < -525088) { x3 = 525088; }
/*     */        dest[d] = (byte)(x3 >> 4); dest[d + 1] = (byte)(x3 >> 12); d += inc; fy1 = x2; fy0 = x3; }
/* 269 */      context.y0 = fy0; context.y1 = fy1; } public int decodeXAAudioSector(byte[] sector, byte[] samples) { if (this.firstSector) {
/* 270 */       int coding = sector[19];
/* 271 */       switch (coding >> 2 & 0x3) {
/*     */         case 0:
/* 273 */           this.freq = 37800;
/*     */           break;
/*     */         case 1:
/* 276 */           this.freq = 18900;
/*     */           break;
/*     */         default:
/* 279 */           this.invalid = true;
/*     */           break;
/*     */       } 
/* 282 */       switch (coding >> 4 & 0x3) {
/*     */         case 0:
/* 284 */           this.bps = 4;
/*     */           break;
/*     */         case 1:
/* 287 */           this.bps = 8;
/*     */           break;
/*     */         default:
/* 290 */           this.invalid = true;
/*     */           break;
/*     */       } 
/* 293 */       switch (coding & 0x3) {
/*     */         case 0:
/* 295 */           this.stereo = false;
/*     */           break;
/*     */         case 1:
/* 298 */           this.stereo = true;
/*     */           break;
/*     */         default:
/* 301 */           this.invalid = true;
/*     */           break;
/*     */       } 
/* 304 */       if (this.invalid) {
/* 305 */         this.log.debug("INVALID XA");
/*     */       } else {
/* 307 */         this.log.debug("XA " + this.freq + "x" + this.bps + " " + (this.stereo ? "stereo" : "mono"));
/*     */       } 
/* 309 */       reset();
/* 310 */       this.firstSector = false;
/*     */     } 
/* 312 */     if (this.invalid) {
/* 313 */       return 0;
/*     */     }
/* 315 */     return decode(sector, 24, samples, 0); }
/*     */ 
/*     */ 
/*     */   
/* 319 */   public int getFrequency() { return this.freq; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\cd\XADecoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */