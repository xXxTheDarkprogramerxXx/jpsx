/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.mdec;
/*     */ 
/*     */ import org.jpsx.runtime.components.hardware.mdec.IDCT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IDCT
/*     */ {
/*     */   private static final int W1 = 2841;
/*     */   private static final int W2 = 2676;
/*     */   private static final int W3 = 2408;
/*     */   private static final int W5 = 1609;
/*     */   private static final int W6 = 1108;
/*     */   private static final int W7 = 565;
/*  28 */   private static final int[] clamp = new int[2048];
/*     */ 
/*     */   
/*     */   private static void idctrow(int[] blk, int base) {
/*     */     int x1, x2, x3, x4, x5, x6, x7;
/*  33 */     if (0 == ((x1 = blk[base + 4] << 11) | (x2 = blk[base + 6]) | (x3 = blk[base + 2]) | (x4 = blk[base + 1]) | (x5 = blk[base + 7]) | (x6 = blk[base + 5]) | (x7 = blk[base + 3]))) {
/*     */       
/*  35 */       blk[base + 7] = blk[base + 0] << 3; blk[base + 6] = blk[base + 0] << 3; blk[base + 5] = blk[base + 0] << 3; blk[base + 4] = blk[base + 0] << 3; blk[base + 3] = blk[base + 0] << 3; blk[base + 2] = blk[base + 0] << 3; blk[base + 1] = blk[base + 0] << 3; blk[base + 0] = blk[base + 0] << 3;
/*     */       
/*     */       return;
/*     */     } 
/*  39 */     int x0 = (blk[base + 0] << 11) + 128;
/*     */     
/*  41 */     int x8 = 565 * (x4 + x5);
/*  42 */     x4 = x8 + 2276 * x4;
/*  43 */     x5 = x8 - 3406 * x5;
/*  44 */     x8 = 2408 * (x6 + x7);
/*  45 */     x6 = x8 - 799 * x6;
/*  46 */     x7 = x8 - 4017 * x7;
/*     */     
/*  48 */     x8 = x0 + x1;
/*  49 */     x0 -= x1;
/*  50 */     x1 = 1108 * (x3 + x2);
/*  51 */     x2 = x1 - 3784 * x2;
/*  52 */     x3 = x1 + 1568 * x3;
/*  53 */     x1 = x4 + x6;
/*  54 */     x4 -= x6;
/*  55 */     x6 = x5 + x7;
/*  56 */     x5 -= x7;
/*     */     
/*  58 */     x7 = x8 + x3;
/*  59 */     x8 -= x3;
/*  60 */     x3 = x0 + x2;
/*  61 */     x0 -= x2;
/*  62 */     x2 = 181 * (x4 + x5) + 128 >> 8;
/*  63 */     x4 = 181 * (x4 - x5) + 128 >> 8;
/*     */     
/*  65 */     blk[base + 0] = x7 + x1 >> 8;
/*  66 */     blk[base + 1] = x3 + x2 >> 8;
/*  67 */     blk[base + 2] = x0 + x4 >> 8;
/*  68 */     blk[base + 3] = x8 + x6 >> 8;
/*  69 */     blk[base + 4] = x8 - x6 >> 8;
/*  70 */     blk[base + 5] = x0 - x4 >> 8;
/*  71 */     blk[base + 6] = x3 - x2 >> 8;
/*  72 */     blk[base + 7] = x7 - x1 >> 8;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void idctcol(int[] blk, int base) {
/*     */     int x1, x2, x3, x4, x5, x6, x7;
/*  78 */     if (0 == ((x1 = blk[base + 32] << 8) | (x2 = blk[base + 48]) | (x3 = blk[base + 16]) | (x4 = blk[base + 8]) | (x5 = blk[base + 56]) | (x6 = blk[base + 40]) | (x7 = blk[base + 24]))) {
/*     */       
/*  80 */       blk[base + 56] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 48] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 40] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 32] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 24] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 16] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 8] = clamp[1024 + (blk[base + 0] + 32 >> 6)]; blk[base + 0] = clamp[1024 + (blk[base + 0] + 32 >> 6)];
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  85 */     int x0 = (blk[base + 0] << 8) + 8192;
/*     */     
/*  87 */     int x8 = 565 * (x4 + x5) + 4;
/*  88 */     x4 = x8 + 2276 * x4 >> 3;
/*  89 */     x5 = x8 - 3406 * x5 >> 3;
/*  90 */     x8 = 2408 * (x6 + x7) + 4;
/*  91 */     x6 = x8 - 799 * x6 >> 3;
/*  92 */     x7 = x8 - 4017 * x7 >> 3;
/*     */     
/*  94 */     x8 = x0 + x1;
/*  95 */     x0 -= x1;
/*  96 */     x1 = 1108 * (x3 + x2) + 4;
/*  97 */     x2 = x1 - 3784 * x2 >> 3;
/*  98 */     x3 = x1 + 1568 * x3 >> 3;
/*  99 */     x1 = x4 + x6;
/* 100 */     x4 -= x6;
/* 101 */     x6 = x5 + x7;
/* 102 */     x5 -= x7;
/*     */     
/* 104 */     x7 = x8 + x3;
/* 105 */     x8 -= x3;
/* 106 */     x3 = x0 + x2;
/* 107 */     x0 -= x2;
/* 108 */     x2 = 181 * (x4 + x5) + 128 >> 8;
/* 109 */     x4 = 181 * (x4 - x5) + 128 >> 8;
/*     */     
/* 111 */     blk[base + 0] = clamp[1024 + (x7 + x1 >> 14)];
/* 112 */     blk[base + 8] = clamp[1024 + (x3 + x2 >> 14)];
/* 113 */     blk[base + 16] = clamp[1024 + (x0 + x4 >> 14)];
/* 114 */     blk[base + 24] = clamp[1024 + (x8 + x6 >> 14)];
/* 115 */     blk[base + 32] = clamp[1024 + (x8 - x6 >> 14)];
/* 116 */     blk[base + 40] = clamp[1024 + (x0 - x4 >> 14)];
/* 117 */     blk[base + 48] = clamp[1024 + (x3 - x2 >> 14)];
/* 118 */     blk[base + 56] = clamp[1024 + (x7 - x1 >> 14)];
/*     */   }
/*     */   
/*     */   public static void transform(int[] block) {
/* 122 */     for (int i = 0; i < 64; i += 8) {
/* 123 */       idctrow(block, i);
/*     */     }
/* 125 */     for (int i = 0; i < 8; i++)
/* 126 */       idctcol(block, i); 
/*     */   }
/*     */   
/*     */   static  {
/* 130 */     for (i = 0; i < 2048; i++) {
/* 131 */       if (i < 1024) {
/* 132 */         clamp[i] = 0;
/* 133 */       } else if (i < 1280) {
/* 134 */         clamp[i] = i - 1024;
/*     */       } else {
/* 136 */         clamp[i] = 255;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\mdec\IDCT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */