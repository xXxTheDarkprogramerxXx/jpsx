/*    */ package classes.runtime.org.jpsx.runtime.components.hardware.sio;
/*    */ 
/*    */ import org.jpsx.runtime.components.hardware.sio.BasicPad;
/*    */ import org.jpsx.runtime.components.hardware.sio.StandardController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StandardController
/*    */   extends BasicPad
/*    */ {
/* 21 */   protected int padState = 65535;
/*    */   public static final int PADLup = 4096;
/*    */   
/* 24 */   protected StandardController(String description) { super(description); }
/*    */ 
/*    */   
/*    */   public static final int PADLdown = 16384;
/*    */   
/*    */   public static final int PADLleft = 32768;
/*    */   
/*    */   public static final int PADLright = 8192;
/*    */   
/*    */   public static final int PADRup = 16;
/*    */   
/*    */   public static final int PADRdown = 64;
/*    */   public static final int PADRleft = 128;
/*    */   public static final int PADRright = 32;
/*    */   public static final int PADi = 512;
/*    */   public static final int PADj = 1024;
/*    */   public static final int PADk = 256;
/*    */   public static final int PADl = 8;
/*    */   public static final int PADm = 2;
/*    */   public static final int PADn = 4;
/*    */   public static final int PADo = 1;
/*    */   public static final int PADh = 2048;
/*    */   public static final int PADL1 = 4;
/*    */   public static final int PADL2 = 1;
/*    */   public static final int PADR1 = 8;
/*    */   public static final int PADR2 = 2;
/*    */   public static final int PADstart = 2048;
/*    */   public static final int PADselect = 256;
/*    */   
/* 53 */   public int getType() { return 65; }
/*    */ 
/*    */   
/*    */   public void getState(byte[] state) {
/* 57 */     state[0] = (byte)(this.padState >> 8 & 0xFF);
/* 58 */     state[1] = (byte)(this.padState & 0xFF);
/*    */   }
/*    */ 
/*    */   
/* 62 */   public void pressed(int mask) { this.padState &= (mask ^ 0xFFFFFFFF); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   public void released(int mask) { this.padState |= mask; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\sio\StandardController.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */