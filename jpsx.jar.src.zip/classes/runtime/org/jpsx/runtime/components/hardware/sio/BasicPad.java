/*    */ package classes.runtime.org.jpsx.runtime.components.hardware.sio;
/*    */ 
/*    */ import org.jpsx.api.components.hardware.sio.SerialDevice;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ import org.jpsx.runtime.components.hardware.sio.BasicPad;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BasicPad
/*    */   extends JPSXComponent
/*    */   implements SerialDevice
/*    */ {
/*    */   protected byte[] rxBuffer;
/*    */   protected byte[] txBuffer;
/*    */   protected int state;
/*    */   protected int txIndex;
/*    */   
/*    */   public abstract int getType();
/*    */   
/*    */   public abstract void getState(byte[] paramArrayOfByte);
/*    */   
/*    */   protected BasicPad(String description) {
/* 32 */     super(description);
/*    */ 
/*    */     
/* 35 */     this.rxBuffer = new byte[32];
/* 36 */     this.txBuffer = new byte[32];
/*    */   }
/*    */ 
/*    */   
/*    */   public void prepareForTransfer() {
/* 41 */     getState(this.rxBuffer);
/* 42 */     this.state = 0;
/* 43 */     this.txIndex = 0;
/*    */   }
/*    */   
/*    */   public int receive() {
/*    */     int rc;
/* 48 */     if (this.state == 0) {
/* 49 */       rc = 0;
/* 50 */     } else if (this.state == 1) {
/* 51 */       rc = getType();
/* 52 */       if (rc == 65) {
/* 53 */         if (this.txBuffer[0] == 67) {
/* 54 */           rc = 67;
/*    */         }
/* 56 */         if (this.txBuffer[0] == 69) {
/* 57 */           rc = 243;
/*    */         }
/*    */       } 
/* 60 */     } else if (this.state == 2) {
/* 61 */       rc = 90;
/*    */     } else {
/* 63 */       rc = this.rxBuffer[this.state - 3];
/*    */     } 
/* 65 */     this.state++;
/* 66 */     return rc;
/*    */   }
/*    */ 
/*    */   
/* 70 */   public void send(int data) { this.txBuffer[this.txIndex++] = (byte)data; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\sio\BasicPad.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */