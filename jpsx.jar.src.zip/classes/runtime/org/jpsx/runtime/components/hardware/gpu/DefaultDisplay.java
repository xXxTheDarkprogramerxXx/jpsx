/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.gpu;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.VolatileImage;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.hardware.gpu.Display;
/*     */ import org.jpsx.api.components.hardware.gpu.DisplayManager;
/*     */ import org.jpsx.runtime.JPSXComponent;
/*     */ import org.jpsx.runtime.RuntimeConnections;
/*     */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.gpu.DefaultDisplay;
/*     */ import org.jpsx.runtime.components.hardware.gpu.GPU;
/*     */ import org.jpsx.runtime.util.Timing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDisplay
/*     */   extends JPSXComponent
/*     */   implements Display, KeyListener
/*     */ {
/*  36 */   private static final Logger log = Logger.getLogger("Display");
/*     */   
/*     */   public static final String LOCATION_X_PROPERTY = "x";
/*     */   
/*     */   public static final String LOCATION_Y_PROPERTY = "y";
/*     */   
/*     */   private Frame frame;
/*     */   
/*     */   private int[] ram;
/*     */   
/*     */   private BufferedImage bufferedImage;
/*     */   
/*     */   private Graphics graphics;
/*     */   private DisplayManager displayManager;
/*     */   private int sourceWidth;
/*     */   private int sourceHeight;
/*     */   private boolean showBlitTime;
/*     */   private boolean antiAlias;
/*     */   private boolean displayVRAM;
/*     */   private boolean funkyfudge;
/*  56 */   private ImageInfo[] imageInfoCache = { new ImageInfo(this), new ImageInfo(this), new ImageInfo(this), new ImageInfo(this) };
/*     */ 
/*     */ 
/*     */   
/*     */   private int cacheReplaceIndex;
/*     */ 
/*     */   
/*     */   private VolatileImage volatileImage;
/*     */ 
/*     */   
/*  66 */   private int MAX_X = 960;
/*  67 */   private int MAX_Y = 512;
/*     */   
/*  69 */   private final int[] xres = { 320, 640, 800, 960, 1024, 1280 };
/*  70 */   private final int[] yres = { 256, 512, 600, 768, 768, 1024 };
/*     */   
/*     */   private static final int BLIT_TIME_COUNT = 100;
/*     */   
/*     */   private long blitTimeTotal;
/*     */   private int blitTimeCount;
/*     */   private boolean noStretch;
/*  77 */   int resindex = 1;
/*     */ 
/*     */   
/*  80 */   public DefaultDisplay() { super("JPSX Default AWT Frame Display"); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  85 */     super.init();
/*  86 */     HardwareComponentConnections.DISPLAY.set(this);
/*  87 */     RuntimeConnections.KEY_LISTENERS.add(this);
/*  88 */     this.showBlitTime = Boolean.valueOf(getProperty("showBlitTime", "false")).booleanValue();
/*  89 */     this.antiAlias = Boolean.valueOf(getProperty("antiAlias", "true")).booleanValue();
/*  90 */     this.noStretch = Boolean.valueOf(getProperty("noStretch", "false")).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/*  95 */     super.resolveConnections();
/*  96 */     this.displayManager = (DisplayManager)HardwareComponentConnections.DISPLAY_MANAGER.resolve();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initDisplay() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new org/jpsx/runtime/components/hardware/gpu/DefaultDisplay$1
/*     */     //   4: dup
/*     */     //   5: aload_0
/*     */     //   6: ldc 'JPSX'
/*     */     //   8: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gpu/DefaultDisplay;Ljava/lang/String;)V
/*     */     //   11: putfield frame : Ljava/awt/Frame;
/*     */     //   14: new java/awt/image/DirectColorModel
/*     */     //   17: dup
/*     */     //   18: bipush #24
/*     */     //   20: ldc 16711680
/*     */     //   22: ldc 65280
/*     */     //   24: sipush #255
/*     */     //   27: invokespecial <init> : (IIII)V
/*     */     //   30: astore_1
/*     */     //   31: aload_1
/*     */     //   32: sipush #1024
/*     */     //   35: sipush #513
/*     */     //   38: invokevirtual createCompatibleWritableRaster : (II)Ljava/awt/image/WritableRaster;
/*     */     //   41: astore_2
/*     */     //   42: aload_2
/*     */     //   43: invokevirtual getDataBuffer : ()Ljava/awt/image/DataBuffer;
/*     */     //   46: checkcast java/awt/image/DataBufferInt
/*     */     //   49: astore_3
/*     */     //   50: aload_0
/*     */     //   51: aload_3
/*     */     //   52: invokevirtual getData : ()[I
/*     */     //   55: putfield ram : [I
/*     */     //   58: aload_0
/*     */     //   59: new java/awt/image/BufferedImage
/*     */     //   62: dup
/*     */     //   63: aload_1
/*     */     //   64: aload_2
/*     */     //   65: iconst_1
/*     */     //   66: aconst_null
/*     */     //   67: invokespecial <init> : (Ljava/awt/image/ColorModel;Ljava/awt/image/WritableRaster;ZLjava/util/Hashtable;)V
/*     */     //   70: putfield bufferedImage : Ljava/awt/image/BufferedImage;
/*     */     //   73: aload_0
/*     */     //   74: ldc 'x'
/*     */     //   76: iconst_m1
/*     */     //   77: invokevirtual getIntProperty : (Ljava/lang/String;I)I
/*     */     //   80: istore #4
/*     */     //   82: aload_0
/*     */     //   83: ldc 'y'
/*     */     //   85: iconst_m1
/*     */     //   86: invokevirtual getIntProperty : (Ljava/lang/String;I)I
/*     */     //   89: istore #5
/*     */     //   91: iload #4
/*     */     //   93: iconst_m1
/*     */     //   94: if_icmpeq -> 114
/*     */     //   97: iload #5
/*     */     //   99: iconst_m1
/*     */     //   100: if_icmpeq -> 114
/*     */     //   103: aload_0
/*     */     //   104: getfield frame : Ljava/awt/Frame;
/*     */     //   107: iload #4
/*     */     //   109: iload #5
/*     */     //   111: invokevirtual setLocation : (II)V
/*     */     //   114: aload_0
/*     */     //   115: getfield frame : Ljava/awt/Frame;
/*     */     //   118: invokevirtual show : ()V
/*     */     //   121: aload_0
/*     */     //   122: getfield frame : Ljava/awt/Frame;
/*     */     //   125: iconst_0
/*     */     //   126: invokevirtual setResizable : (Z)V
/*     */     //   129: aload_0
/*     */     //   130: invokevirtual sizeframe : ()V
/*     */     //   133: aload_0
/*     */     //   134: aload_0
/*     */     //   135: getfield frame : Ljava/awt/Frame;
/*     */     //   138: invokevirtual getGraphics : ()Ljava/awt/Graphics;
/*     */     //   141: putfield graphics : Ljava/awt/Graphics;
/*     */     //   144: aload_0
/*     */     //   145: aload_0
/*     */     //   146: getfield frame : Ljava/awt/Frame;
/*     */     //   149: aload_0
/*     */     //   150: getfield MAX_X : I
/*     */     //   153: aload_0
/*     */     //   154: getfield MAX_Y : I
/*     */     //   157: invokevirtual createVolatileImage : (II)Ljava/awt/image/VolatileImage;
/*     */     //   160: putfield volatileImage : Ljava/awt/image/VolatileImage;
/*     */     //   163: aload_0
/*     */     //   164: getfield frame : Ljava/awt/Frame;
/*     */     //   167: getstatic org/jpsx/runtime/RuntimeConnections.KEY_LISTENERS : Lorg/jpsx/bootstrap/connection/MultipleConnection;
/*     */     //   170: invokevirtual resolve : ()Ljava/lang/Object;
/*     */     //   173: checkcast java/awt/event/KeyListener
/*     */     //   176: invokevirtual addKeyListener : (Ljava/awt/event/KeyListener;)V
/*     */     //   179: aload_0
/*     */     //   180: getfield frame : Ljava/awt/Frame;
/*     */     //   183: new org/jpsx/runtime/components/hardware/gpu/DefaultDisplay$Closer
/*     */     //   186: dup
/*     */     //   187: aconst_null
/*     */     //   188: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gpu/DefaultDisplay$1;)V
/*     */     //   191: invokevirtual addWindowListener : (Ljava/awt/event/WindowListener;)V
/*     */     //   194: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #102	-> 0
/*     */     //   #109	-> 14
/*     */     //   #110	-> 31
/*     */     //   #111	-> 42
/*     */     //   #112	-> 50
/*     */     //   #113	-> 58
/*     */     //   #114	-> 73
/*     */     //   #115	-> 82
/*     */     //   #116	-> 91
/*     */     //   #117	-> 114
/*     */     //   #118	-> 121
/*     */     //   #119	-> 129
/*     */     //   #120	-> 133
/*     */     //   #121	-> 144
/*     */     //   #122	-> 163
/*     */     //   #123	-> 179
/*     */     //   #124	-> 194
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	195	0	this	Lorg/jpsx/runtime/components/hardware/gpu/DefaultDisplay;
/*     */     //   31	164	1	model	Ljava/awt/image/DirectColorModel;
/*     */     //   42	153	2	raster	Ljava/awt/image/WritableRaster;
/*     */     //   50	145	3	db	Ljava/awt/image/DataBufferInt;
/*     */     //   82	113	4	w	I
/*     */     //   91	104	5	h	I }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image getImage(int x, int y, int w, int h) {
/* 155 */     for (int i = 0; i < this.imageInfoCache.length; i++) {
/* 156 */       if (this.imageInfoCache[i].matches(x, y, w, h)) {
/* 157 */         return this.imageInfoCache[i].getImage();
/*     */       }
/*     */     } 
/* 160 */     this.cacheReplaceIndex = (this.cacheReplaceIndex + 1) % this.imageInfoCache.length;
/*     */ 
/*     */     
/* 163 */     if (x + w > 1024) {
/* 164 */       w = 1024 - x;
/*     */     }
/* 166 */     if (y + h > 512) {
/* 167 */       h = 512 - y;
/*     */     }
/* 169 */     if (log.isDebugEnabled()) {
/* 170 */       log.debug("Creating new image at slot " + this.cacheReplaceIndex + " " + x + "," + y + " " + w + "," + h);
/*     */     }
/* 172 */     return this.imageInfoCache[this.cacheReplaceIndex].update(x, y, w, h);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sizeframe() {
/* 177 */     if (this.displayVRAM) {
/* 178 */       this.frame.setSize(new Dimension(1024 + (this.frame.getInsets()).left + (this.frame.getInsets()).right, 512 + (this.frame.getInsets()).top + (this.frame.getInsets()).bottom));
/*     */     } else {
/* 180 */       this.frame.setSize(new Dimension(this.xres[this.resindex] + (this.frame.getInsets()).left + (this.frame.getInsets()).right, this.yres[this.resindex] + (this.frame.getInsets()).top + (this.frame.getInsets()).bottom));
/*     */     } 
/*     */   }
/*     */   protected void switchsize() {
/* 184 */     this.resindex++;
/* 185 */     if (this.resindex == this.xres.length) this.resindex = 0; 
/* 186 */     sizeframe();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 191 */   public int[] acquireDisplayBuffer() { return this.ram; }
/*     */ 
/*     */   
/*     */   public void releaseDisplayBuffer() {}
/*     */ 
/*     */   
/*     */   protected void stretchBlit(Graphics g) {
/* 198 */     int l = (this.frame.getInsets()).left;
/* 199 */     int t = (this.frame.getInsets()).top;
/* 200 */     long timeBasis = 0L;
/* 201 */     if (this.showBlitTime) {
/* 202 */       timeBasis = Timing.nanos();
/*     */     }
/* 204 */     if (this.displayVRAM) {
/* 205 */       if (this.antiAlias) ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR); 
/* 206 */       g.drawImage(this.bufferedImage, l, t, null);
/*     */     }
/* 208 */     else if (this.volatileImage != null && !this.volatileImage.contentsLost()) {
/* 209 */       if (this.antiAlias) ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR); 
/* 210 */       if (this.noStretch) {
/* 211 */         g.drawImage(this.volatileImage, l, t, l + this.sourceWidth, t + this.sourceHeight, 0, 0, this.sourceWidth, this.sourceHeight, null);
/*     */       } else {
/*     */         
/* 214 */         g.drawImage(this.volatileImage, l, t, l + this.xres[this.resindex], t + this.yres[this.resindex], 0, 0, this.sourceWidth, this.sourceHeight, null);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 220 */     this.blitTimeTotal += Timing.nanos() - timeBasis;
/* 221 */     if (this.showBlitTime && 100 == ++this.blitTimeCount) {
/* 222 */       this.frame.setTitle("JPSX - blitTime=" + ((this.blitTimeTotal / 10000000L) / 10.0D) + "ms");
/* 223 */       this.blitTimeCount = 0;
/* 224 */       this.blitTimeTotal = 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 230 */     boolean rgb24 = this.displayManager.getRGB24();
/* 231 */     if (this.funkyfudge) {
/* 232 */       GPU.setVRAMFormat(!rgb24);
/* 233 */       this.funkyfudge = false;
/*     */     } 
/* 235 */     GPU.setVRAMFormat(rgb24);
/*     */     
/* 237 */     this.sourceWidth = this.displayManager.getDefaultPixelWidth();
/* 238 */     if (rgb24) this.sourceWidth = this.sourceWidth * 3 / 2; 
/* 239 */     this.sourceHeight = this.displayManager.getDefaultPixelHeight();
/* 240 */     if (this.volatileImage.contentsLost()) {
/* 241 */       this.volatileImage.validate(null);
/*     */     }
/* 243 */     if (this.displayManager.getBlanked()) {
/* 244 */       g2 = this.volatileImage.createGraphics();
/*     */       try {
/* 246 */         g2.setColor(Color.BLACK);
/* 247 */         g2.fillRect(0, 0, this.sourceWidth, this.sourceHeight);
/*     */       } finally {
/* 249 */         g2.dispose();
/*     */       } 
/*     */     } else {
/* 252 */       g2 = this.volatileImage.createGraphics();
/* 253 */       int marginLeft = this.displayManager.getLeftMarginPixels();
/* 254 */       if (rgb24) marginLeft = marginLeft * 3 / 2; 
/* 255 */       int marginTop = this.displayManager.getTopMarginPixels();
/* 256 */       int pixelWidth = this.displayManager.getPixelWidth();
/* 257 */       if (rgb24) pixelWidth = pixelWidth * 3 / 2; 
/* 258 */       int pixelHeight = this.displayManager.getPixelHeight();
/* 259 */       int marginRight = this.sourceWidth - pixelWidth - marginLeft;
/* 260 */       int marginBottom = this.sourceHeight - pixelHeight - marginTop;
/*     */       try {
/* 262 */         if (pixelWidth > 0 && pixelHeight > 0) {
/* 263 */           g2.drawImage(getImage(this.displayManager.getXOrigin(), this.displayManager.getYOrigin(), pixelWidth, pixelHeight), marginLeft, marginTop, null);
/*     */         }
/*     */         
/* 266 */         g2.setColor(Color.BLACK);
/* 267 */         if (marginLeft > 0)
/*     */         {
/* 269 */           g2.fillRect(0, 0, marginLeft, this.sourceHeight);
/*     */         }
/* 271 */         if (marginRight > 0)
/*     */         {
/* 273 */           g2.fillRect(this.sourceWidth - marginRight, 0, marginRight, this.sourceHeight);
/*     */         }
/* 275 */         if (marginTop > 0)
/*     */         {
/* 277 */           g2.fillRect(0, 0, this.sourceWidth, marginTop);
/*     */         }
/* 279 */         if (marginBottom > 0)
/*     */         {
/* 281 */           g2.fillRect(0, this.sourceHeight - marginBottom, this.sourceWidth, marginBottom);
/*     */         }
/*     */       } finally {
/* 284 */         g2.dispose();
/*     */       } 
/*     */     } 
/* 287 */     stretchBlit(this.graphics);
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyTyped(KeyEvent e) {}
/*     */   
/*     */   public void keyPressed(KeyEvent e) {
/* 294 */     if (e.getKeyCode() == 123) {
/* 295 */       switchsize();
/*     */     }
/* 297 */     if (e.getKeyCode() == 122) {
/* 298 */       refresh();
/*     */     }
/* 300 */     if (e.getKeyCode() == 121) {
/* 301 */       this.funkyfudge = true;
/*     */     }
/* 303 */     if (e.getKeyCode() == 120) {
/* 304 */       this.displayVRAM = !this.displayVRAM;
/* 305 */       sizeframe();
/* 306 */       refresh();
/*     */     } 
/* 308 */     if (e.getKeyCode() == 119) {
/* 309 */       for (int i = 0; i < 524288; i++) {
/* 310 */         this.ram[i] = this.ram[i] & 0x1FFFFFF;
/*     */       }
/*     */     }
/* 313 */     if (e.getKeyCode() == 118)
/* 314 */       for (int i = 0; i < 524288; i++)
/* 315 */         this.ram[i] = this.ram[i] | 0xFE000000;  
/*     */   }
/*     */   
/*     */   public void keyReleased(KeyEvent e) {}
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\gpu\DefaultDisplay.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */