/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.sio;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*     */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*     */ import org.jpsx.api.components.hardware.sio.SerialDevice;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.sio.SIO0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SIO0
/*     */   extends SingletonJPSXComponent
/*     */   implements MemoryMapped
/*     */ {
/*  33 */   private static final Logger log = Logger.getLogger("SIO0");
/*     */   
/*     */   private static final boolean debugSIO = false;
/*     */   
/*     */   private static final int ADDR_SIO0_DATA = 528486464;
/*     */   
/*     */   private static final int ADDR_SIO0_STATUS = 528486468;
/*     */   
/*     */   private static final int ADDR_SIO0_MODE = 528486472;
/*     */   private static final int ADDR_SIO0_CTRL = 528486474;
/*     */   private static final int ADDR_SIO0_BAUD = 528486478;
/*     */   private static final int CTL_TX_ENABLE = 1;
/*     */   private static final int CTL_DTR = 2;
/*     */   private static final int CTL_RX_ENABLE = 4;
/*     */   private static final int CTL_ERR_RESET = 16;
/*     */   private static final int CTL_RESET = 64;
/*     */   private static final int CTL_DSR_IRQ = 4096;
/*     */   private static final int CTL_SELECT = 8192;
/*     */   private static final int STAT_TX_READY = 1;
/*     */   private static final int STAT_RX_READY = 2;
/*     */   private static final int STAT_TX_EMPTY = 4;
/*     */   private static final int STAT_PARITY_ERR = 8;
/*     */   private static final int STAT_RX_OVERRUN = 16;
/*     */   private static final int STAT_FRAMING_ERR = 32;
/*     */   private static final int STAT_SYNC_DETEXT = 64;
/*     */   private static final int STAT_DSR = 128;
/*     */   private static final int STAT_CTS = 256;
/*     */   private static final int STAT_IRQ = 512;
/*  61 */   private static SerialDevice[] devices = new SerialDevice[2]; private static IRQ irq;
/*     */   private static int m_baud;
/*     */   
/*  64 */   public SIO0() { super("JPSX Serial Controller 0"); }
/*     */   private static int m_mode; private static int m_ctrl; private static int m_status;
/*     */   
/*     */   public void init() {
/*  68 */     super.init();
/*  69 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*  70 */     HardwareComponentConnections.LEFT_PORT_INSTANCE.set(new Port(false));
/*  71 */     HardwareComponentConnections.RIGHT_PORT_INSTANCE.set(new Port(true));
/*  72 */     irq = new IRQ();
/*  73 */     CoreComponentConnections.IRQ_OWNERS.add(irq);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void connectDevice(int which, SerialDevice device) {
/*  93 */     devices[which] = device;
/*  94 */     log.info("Connected " + device.getDescription() + " to port " + which);
/*     */   }
/*     */ 
/*     */   
/*  98 */   private static void disconnectDevice(int which) { devices[which] = null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/* 110 */     registrar.registerWrite8Callback(528486464, SIO0.class, "writeData8");
/* 111 */     registrar.registerWrite16Callback(528486464, SIO0.class, "writeData16");
/* 112 */     registrar.registerWrite32Callback(528486464, SIO0.class, "writeData32");
/* 113 */     registrar.registerRead8Callback(528486464, SIO0.class, "readData8");
/* 114 */     registrar.registerRead16Callback(528486464, SIO0.class, "readData16");
/* 115 */     registrar.registerRead32Callback(528486464, SIO0.class, "readData32");
/*     */     
/* 117 */     registrar.registerWrite16Callback(528486472, SIO0.class, "writeMode16");
/* 118 */     registrar.registerRead16Callback(528486472, SIO0.class, "readMode16");
/* 119 */     registrar.registerWrite16Callback(528486474, SIO0.class, "writeCtrl16");
/* 120 */     registrar.registerRead16Callback(528486474, SIO0.class, "readCtrl16");
/* 121 */     registrar.registerWrite16Callback(528486478, SIO0.class, "writeBaud16");
/* 122 */     registrar.registerRead16Callback(528486478, SIO0.class, "readBaud16");
/* 123 */     registrar.registerRead16Callback(528486468, SIO0.class, "readStatus16");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean communicating = false;
/*     */ 
/*     */   
/*     */   private static SerialDevice currentDevice;
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeData8(int address, int value) {
/* 136 */     value &= 0xFF;
/*     */     
/* 138 */     if (!communicating) {
/* 139 */       if (value == 1) {
/* 140 */         currentDevice = (0 == (m_ctrl & 0x2000)) ? devices[0] : devices[1];
/* 141 */         if (currentDevice != null) {
/* 142 */           currentDevice.prepareForTransfer();
/*     */         }
/*     */ 
/*     */         
/* 146 */         communicating = true;
/* 147 */       } else if (value == 129 && 
/* 148 */         log.isDebugEnabled()) {
/* 149 */         log.debug("CARD SELECT " + (((m_ctrl & 0x2000) != 0) ? "1" : "0"));
/*     */       }
/*     */     
/*     */     }
/* 153 */     else if (currentDevice != null) {
/* 154 */       if (value == 67) {
/* 155 */         m_status |= 0x80;
/*     */       }
/* 157 */       currentDevice.send(value);
/*     */     } 
/*     */     
/* 160 */     m_status |= 0x2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeData16(int address, int value) {}
/*     */ 
/*     */   
/*     */   public static void writeData32(int address, int value) {}
/*     */ 
/*     */   
/*     */   public static int readData8(int address) {
/* 172 */     int rc = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     if (currentDevice != null) {
/* 186 */       rc = currentDevice.receive();
/*     */     }
/*     */     
/* 189 */     if (0 != (m_ctrl & 0x1000) && 
/* 190 */       currentDevice != null) {
/*     */ 
/*     */ 
/*     */       
/* 194 */       m_status |= 0x200;
/* 195 */       irq.raiseIRQ();
/*     */     } 
/*     */     
/* 198 */     m_status &= 0xFFFFFFFD;
/* 199 */     return rc;
/*     */   }
/*     */ 
/*     */   
/* 203 */   public static int readData16(int address) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public static int readData32(int address) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public static void writeMode16(int address, int value) { m_mode = value & 0xFFFF; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public static int readMode16(int address) { return m_mode; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeCtrl16(int address, int value) {
/* 226 */     m_ctrl = value & 0xFFFFFFEF;
/*     */     
/* 228 */     if (0 != (m_ctrl & 0x40)) {
/*     */       
/* 230 */       m_status |= 0x1;
/* 231 */       m_status &= 0xFFFFFF7F;
/* 232 */       communicating = false;
/*     */     } 
/* 234 */     if (0 != (value & 0x10)) {
/* 235 */       m_status &= 0xFFFFFDFF;
/*     */     }
/* 237 */     if (value == 0) {
/* 238 */       currentDevice = null;
/* 239 */       communicating = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 244 */   public static int readCtrl16(int address) { return m_ctrl; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   public static void writeBaud16(int address, int value) { m_baud = value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   public static int readBaud16(int address) { return m_baud; }
/*     */ 
/*     */ 
/*     */   
/* 260 */   public static int readStatus16(int address) { return m_status; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\sio\SIO0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */