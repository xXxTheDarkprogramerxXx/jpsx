/*      */ package classes.runtime.org.jpsx.runtime.components.hardware.gte;
/*      */ 
/*      */ import org.apache.bcel.generic.ConstantPoolGen;
/*      */ import org.apache.bcel.generic.GETFIELD;
/*      */ import org.apache.bcel.generic.GETSTATIC;
/*      */ import org.apache.bcel.generic.IAND;
/*      */ import org.apache.bcel.generic.ILOAD;
/*      */ import org.apache.bcel.generic.INVOKESTATIC;
/*      */ import org.apache.bcel.generic.IOR;
/*      */ import org.apache.bcel.generic.ISHL;
/*      */ import org.apache.bcel.generic.ISHR;
/*      */ import org.apache.bcel.generic.ISTORE;
/*      */ import org.apache.bcel.generic.InstructionList;
/*      */ import org.apache.bcel.generic.PUSH;
/*      */ import org.apache.bcel.generic.PUTFIELD;
/*      */ import org.apache.bcel.generic.PUTSTATIC;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*      */ import org.jpsx.api.components.core.cpu.CPUInstruction;
/*      */ import org.jpsx.api.components.core.cpu.CompilationContext;
/*      */ import org.jpsx.api.components.core.cpu.InstructionProvider;
/*      */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*      */ import org.jpsx.api.components.core.cpu.R3000;
/*      */ import org.jpsx.api.components.core.cpu.SCP;
/*      */ import org.jpsx.runtime.JPSXComponent;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.components.hardware.gte.GTE;
/*      */ import org.jpsx.runtime.util.ClassUtil;
/*      */ 
/*      */ public final class GTE extends JPSXComponent implements InstructionProvider {
/*   31 */   private static final Logger log = Logger.getLogger("GTE");
/*   32 */   private static final String CLASS = GTE.class.getName();
/*   33 */   private static final String VECTOR_CLASS = Vector.class.getName();
/*   34 */   private static final String VECTOR_SIGNATURE = ClassUtil.signatureOfClass(VECTOR_CLASS);
/*   35 */   private static final String MATRIX_CLASS = Matrix.class.getName();
/*   36 */   private static final String MATRIX_SIGNATURE = ClassUtil.signatureOfClass(MATRIX_CLASS);
/*      */   
/*      */   private static final int R_VXY0 = 0;
/*      */   
/*      */   private static final int R_VZ0 = 1;
/*      */   
/*      */   private static final int R_VXY1 = 2;
/*      */   
/*      */   private static final int R_VZ1 = 3;
/*      */   
/*      */   private static final int R_VXY2 = 4;
/*      */   
/*      */   private static final int R_VZ2 = 5;
/*      */   
/*      */   private static final int R_RGB = 6;
/*      */   
/*      */   private static final int R_OTZ = 7;
/*      */   
/*      */   private static final int R_IR0 = 8;
/*      */   
/*      */   private static final int R_IR1 = 9;
/*      */   
/*      */   private static final int R_IR2 = 10;
/*      */   
/*      */   private static final int R_IR3 = 11;
/*      */   
/*      */   private static final int R_SXY0 = 12;
/*      */   
/*      */   private static final int R_SXY1 = 13;
/*      */   
/*      */   private static final int R_SXY2 = 14;
/*      */   
/*      */   private static final int R_SXYP = 15;
/*      */   
/*      */   private static final int R_SZX = 16;
/*      */   
/*      */   private static final int R_SZ0 = 17;
/*      */   
/*      */   private static final int R_SZ1 = 18;
/*      */   
/*      */   private static final int R_SZ2 = 19;
/*      */   
/*      */   private static final int R_RGB0 = 20;
/*      */   
/*      */   private static final int R_RGB1 = 21;
/*      */   
/*      */   private static final int R_RGB2 = 22;
/*      */   
/*      */   private static final int R_RES1 = 23;
/*      */   
/*      */   private static final int R_MAC0 = 24;
/*      */   
/*      */   private static final int R_MAC1 = 25;
/*      */   
/*      */   private static final int R_MAC2 = 26;
/*      */   
/*      */   private static final int R_MAC3 = 27;
/*      */   
/*      */   private static final int R_IRGB = 28;
/*      */   
/*      */   private static final int R_ORGB = 29;
/*      */   
/*      */   private static final int R_LZCS = 30;
/*      */   
/*      */   private static final int R_LZCR = 31;
/*      */   
/*      */   private static final int R_R11R12 = 32;
/*      */   private static final int R_R13R21 = 33;
/*      */   private static final int R_R22R23 = 34;
/*      */   private static final int R_R31R32 = 35;
/*      */   private static final int R_R33 = 36;
/*      */   private static final int R_TRX = 37;
/*      */   private static final int R_TRY = 38;
/*      */   private static final int R_TRZ = 39;
/*      */   private static final int R_L11L12 = 40;
/*      */   private static final int R_L13L21 = 41;
/*      */   private static final int R_L22L23 = 42;
/*      */   private static final int R_L31L32 = 43;
/*      */   private static final int R_L33 = 44;
/*      */   private static final int R_RBK = 45;
/*      */   private static final int R_GBK = 46;
/*      */   private static final int R_BBK = 47;
/*      */   private static final int R_LR1LR2 = 48;
/*      */   private static final int R_LR3LG1 = 49;
/*      */   private static final int R_LG2LG3 = 50;
/*      */   private static final int R_LB1LB2 = 51;
/*      */   private static final int R_LB3 = 52;
/*      */   private static final int R_RFC = 53;
/*      */   private static final int R_GFC = 54;
/*      */   private static final int R_BFC = 55;
/*      */   private static final int R_OFX = 56;
/*      */   private static final int R_OFY = 57;
/*      */   private static final int R_H = 58;
/*      */   private static final int R_DQA = 59;
/*      */   private static final int R_DQB = 60;
/*      */   private static final int R_ZSF3 = 61;
/*      */   private static final int R_ZSF4 = 62;
/*      */   private static final int R_FLAG = 63;
/*      */   private static final int GTE_SF_MASK = 524288;
/*      */   private static final int GTE_MX_MASK = 393216;
/*      */   private static final int GTE_MX_ROTATION = 0;
/*      */   private static final int GTE_MX_LIGHT = 131072;
/*      */   private static final int GTE_MX_COLOR = 262144;
/*      */   private static final int GTE_V_MASK = 98304;
/*      */   private static final int GTE_V_V0 = 0;
/*      */   private static final int GTE_V_V1 = 32768;
/*      */   private static final int GTE_V_V2 = 65536;
/*      */   private static final int GTE_V_IR = 98304;
/*      */   private static final int GTE_CV_MASK = 24576;
/*      */   private static final int GTE_CV_TR = 0;
/*      */   private static final int GTE_CV_BK = 8192;
/*      */   private static final int GTE_CV_FC = 16384;
/*      */   private static final int GTE_CV_NONE = 24576;
/*      */   private static final int GTE_LM_MASK = 1024;
/*      */   private static final int GTE_ALL_MASKS = 1041408;
/*      */   private static final int FLAG_CHK = -2147483648;
/*      */   private static final int FLAG_A1P = -1073741824;
/*      */   private static final int FLAG_A2P = -1610612736;
/*      */   private static final int FLAG_A3P = -1879048192;
/*      */   private static final int FLAG_A1N = -2013265920;
/*      */   private static final int FLAG_A2N = -2080374784;
/*      */   private static final int FLAG_A3N = -2113929216;
/*      */   private static final int FLAG_B1 = -2130706432;
/*      */   private static final int FLAG_B2 = -2139095040;
/*      */   private static final int FLAG_B3 = -2143289344;
/*      */   private static final int FLAG_C1 = 2097152;
/*      */   private static final int FLAG_C2 = 1048576;
/*      */   private static final int FLAG_C3 = 524288;
/*      */   private static final int FLAG_D = -2147221504;
/*      */   private static final int FLAG_E = -2147352576;
/*      */   private static final int FLAG_FP = -2147418112;
/*      */   private static final int FLAG_FN = -2147450880;
/*      */   private static final int FLAG_G1 = -2147467264;
/*      */   private static final int FLAG_G2 = -2147475456;
/*      */   private static final int FLAG_H = 4096;
/*      */   private static final long BIT44 = 17592186044416L;
/*      */   private static final long BIT31 = 2147483648L;
/*      */   private static final long BIT47 = 140737488355328L;
/*  174 */   public static Vector reg_v0 = new Vector();
/*  175 */   public static Vector reg_v1 = new Vector();
/*  176 */   public static Vector reg_v2 = new Vector();
/*      */   
/*      */   public static int reg_rgb;
/*      */   
/*      */   public static int reg_otz;
/*      */   
/*      */   public static int reg_ir0;
/*      */   
/*      */   public static int reg_ir1;
/*      */   
/*      */   public static int reg_ir2;
/*      */   public static int reg_ir3;
/*      */   public static int reg_sx0;
/*      */   public static int reg_sy0;
/*      */   public static int reg_sx1;
/*      */   public static int reg_sy1;
/*      */   public static int reg_sx2;
/*      */   public static int reg_sy2;
/*      */   public static int reg_sxp;
/*      */   public static int reg_syp;
/*      */   public static int reg_szx;
/*      */   public static int reg_sz0;
/*      */   public static int reg_sz1;
/*      */   public static int reg_sz2;
/*      */   public static int reg_rgb0;
/*      */   public static int reg_rgb1;
/*      */   public static int reg_rgb2;
/*      */   public static int reg_res1;
/*      */   public static int reg_mac0;
/*      */   public static int reg_mac1;
/*      */   public static int reg_mac2;
/*      */   public static int reg_mac3;
/*      */   public static int reg_irgb;
/*      */   public static int reg_orgb;
/*      */   public static int reg_lzcr;
/*      */   public static int reg_lzcs;
/*  212 */   public static Matrix reg_rot = new Matrix();
/*      */   
/*      */   public static int reg_trx;
/*      */   
/*      */   public static int reg_try;
/*      */   public static int reg_trz;
/*  218 */   public static Matrix reg_ls = new Matrix();
/*      */   
/*      */   public static int reg_rbk;
/*      */   public static int reg_gbk;
/*      */   public static int reg_bbk;
/*  223 */   public static Matrix reg_lc = new Matrix(); public static int reg_rfc; public static int reg_gfc; public static int reg_bfc; public static int reg_ofx; public static int reg_ofy; public static int reg_h; public static int reg_dqa;
/*      */   public static int reg_dqb;
/*      */   public static int reg_zsf3;
/*      */   public static int reg_zsf4;
/*      */   public static int reg_flag;
/*      */   private static AddressSpace addressSpace;
/*      */   private static R3000 r3000;
/*      */   private static int[] r3000regs;
/*      */   private static CPUInstruction i_mfc2;
/*      */   private static CPUInstruction i_cfc2;
/*      */   private static CPUInstruction i_mtc2;
/*      */   private static CPUInstruction i_ctc2;
/*      */   private static CPUInstruction i_lwc2;
/*      */   private static CPUInstruction i_swc2;
/*      */   private static CPUInstruction i_rtpt;
/*      */   
/*  239 */   public GTE() { super("JPSX Geometry Transform Engine"); }
/*      */   private static CPUInstruction i_rtps; private static CPUInstruction i_mvmva; private static CPUInstruction i_op; private static CPUInstruction i_avsz3; private static CPUInstruction i_avsz4; private static CPUInstruction i_nclip;
/*      */   private static CPUInstruction i_ncct;
/*      */   private static CPUInstruction i_gpf;
/*      */   private static CPUInstruction i_dcpl;
/*      */   private static CPUInstruction i_dpcs;
/*      */   
/*      */   private static void emitReadReg(InstructionList il, CompilationContext context, int reg) {
/*  247 */     ConstantPoolGen cp = context.getConstantPoolGen();
/*      */     
/*  249 */     if (reg < 32) {
/*  250 */       switch (reg) {
/*      */         case 0:
/*  252 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v0", VECTOR_SIGNATURE)));
/*  253 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "x", "I")));
/*  254 */           il.append(new PUSH(cp, '￿'));
/*  255 */           il.append(new IAND());
/*  256 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v0", VECTOR_SIGNATURE)));
/*  257 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "y", "I")));
/*  258 */           il.append(new PUSH(cp, 16));
/*  259 */           il.append(new ISHL());
/*  260 */           il.append(new IOR());
/*      */           break;
/*      */         case 1:
/*  263 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v0", VECTOR_SIGNATURE)));
/*  264 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "z", "I")));
/*      */           break;
/*      */         case 2:
/*  267 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v1", VECTOR_SIGNATURE)));
/*  268 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "x", "I")));
/*  269 */           il.append(new PUSH(cp, '￿'));
/*  270 */           il.append(new IAND());
/*  271 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v1", VECTOR_SIGNATURE)));
/*  272 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "y", "I")));
/*  273 */           il.append(new PUSH(cp, 16));
/*  274 */           il.append(new ISHL());
/*  275 */           il.append(new IOR());
/*      */           break;
/*      */         case 3:
/*  278 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v1", VECTOR_SIGNATURE)));
/*  279 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "z", "I")));
/*      */           break;
/*      */         case 4:
/*  282 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v2", VECTOR_SIGNATURE)));
/*  283 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "x", "I")));
/*  284 */           il.append(new PUSH(cp, '￿'));
/*  285 */           il.append(new IAND());
/*  286 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v2", VECTOR_SIGNATURE)));
/*  287 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "y", "I")));
/*  288 */           il.append(new PUSH(cp, 16));
/*  289 */           il.append(new ISHL());
/*  290 */           il.append(new IOR());
/*      */           break;
/*      */         case 5:
/*  293 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v2", VECTOR_SIGNATURE)));
/*  294 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "z", "I")));
/*      */           break;
/*      */         case 6:
/*  297 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb", "I")));
/*      */           break;
/*      */         case 7:
/*  300 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_otz", "I")));
/*      */           break;
/*      */         case 8:
/*  303 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir0", "I")));
/*      */           break;
/*      */         case 9:
/*  306 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir1", "I")));
/*      */           break;
/*      */         case 10:
/*  309 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir2", "I")));
/*      */           break;
/*      */         case 11:
/*  312 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir3", "I")));
/*      */           break;
/*      */         case 12:
/*  315 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sx0", "I")));
/*  316 */           il.append(new PUSH(cp, '￿'));
/*  317 */           il.append(new IAND());
/*  318 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sy0", "I")));
/*  319 */           il.append(new PUSH(cp, 16));
/*  320 */           il.append(new ISHL());
/*  321 */           il.append(new IOR());
/*      */           break;
/*      */         case 13:
/*  324 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sx1", "I")));
/*  325 */           il.append(new PUSH(cp, '￿'));
/*  326 */           il.append(new IAND());
/*  327 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sy1", "I")));
/*  328 */           il.append(new PUSH(cp, 16));
/*  329 */           il.append(new ISHL());
/*  330 */           il.append(new IOR());
/*      */           break;
/*      */         case 14:
/*  333 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sx2", "I")));
/*  334 */           il.append(new PUSH(cp, '￿'));
/*  335 */           il.append(new IAND());
/*  336 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sy2", "I")));
/*  337 */           il.append(new PUSH(cp, 16));
/*  338 */           il.append(new ISHL());
/*  339 */           il.append(new IOR());
/*      */           break;
/*      */         case 15:
/*  342 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sxp", "I")));
/*  343 */           il.append(new PUSH(cp, '￿'));
/*  344 */           il.append(new IAND());
/*  345 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_syp", "I")));
/*  346 */           il.append(new PUSH(cp, 16));
/*  347 */           il.append(new ISHL());
/*  348 */           il.append(new IOR());
/*      */           break;
/*      */         case 16:
/*  351 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_szx", "I")));
/*      */           break;
/*      */         case 17:
/*  354 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sz0", "I")));
/*      */           break;
/*      */         case 18:
/*  357 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sz1", "I")));
/*      */           break;
/*      */         case 19:
/*  360 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sz2", "I")));
/*      */           break;
/*      */         case 20:
/*  363 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb0", "I")));
/*      */           break;
/*      */         case 21:
/*  366 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb1", "I")));
/*      */           break;
/*      */         case 22:
/*  369 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb2", "I")));
/*      */           break;
/*      */         case 23:
/*  372 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_res1", "I")));
/*      */           break;
/*      */         case 24:
/*  375 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac0", "I")));
/*      */           break;
/*      */         case 25:
/*  378 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac1", "I")));
/*      */           break;
/*      */         case 26:
/*  381 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac2", "I")));
/*      */           break;
/*      */         case 27:
/*  384 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac3", "I")));
/*      */           break;
/*      */         
/*      */         case 28:
/*  388 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_irgb", "I")));
/*      */           break;
/*      */         
/*      */         case 29:
/*  392 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_orgb", "I")));
/*      */           break;
/*      */         case 30:
/*  395 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lzcs", "I")));
/*      */           break;
/*      */         case 31:
/*  398 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lzcr", "I")));
/*      */           break;
/*      */       } 
/*      */     } else {
/*  402 */       switch (reg) {
/*      */         case 32:
/*  404 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  405 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m11", "I")));
/*  406 */           il.append(new PUSH(cp, '￿'));
/*  407 */           il.append(new IAND());
/*  408 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  409 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m12", "I")));
/*  410 */           il.append(new PUSH(cp, 16));
/*  411 */           il.append(new ISHL());
/*  412 */           il.append(new IOR());
/*      */           break;
/*      */         case 33:
/*  415 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  416 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/*  417 */           il.append(new PUSH(cp, '￿'));
/*  418 */           il.append(new IAND());
/*  419 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  420 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m21", "I")));
/*  421 */           il.append(new PUSH(cp, 16));
/*  422 */           il.append(new ISHL());
/*  423 */           il.append(new IOR());
/*      */           break;
/*      */         case 34:
/*  426 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  427 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m22", "I")));
/*  428 */           il.append(new PUSH(cp, '￿'));
/*  429 */           il.append(new IAND());
/*  430 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  431 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m23", "I")));
/*  432 */           il.append(new PUSH(cp, 16));
/*  433 */           il.append(new ISHL());
/*  434 */           il.append(new IOR());
/*      */           break;
/*      */         case 35:
/*  437 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  438 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m31", "I")));
/*  439 */           il.append(new PUSH(cp, '￿'));
/*  440 */           il.append(new IAND());
/*  441 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  442 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m32", "I")));
/*  443 */           il.append(new PUSH(cp, 16));
/*  444 */           il.append(new ISHL());
/*  445 */           il.append(new IOR());
/*      */           break;
/*      */         case 36:
/*  448 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  449 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m33", "I")));
/*  450 */           il.append(new PUSH(cp, '￿'));
/*  451 */           il.append(new IAND());
/*      */           break;
/*      */         case 37:
/*  454 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_trx", "I")));
/*      */           break;
/*      */         case 38:
/*  457 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_try", "I")));
/*      */           break;
/*      */         case 39:
/*  460 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_trz", "I")));
/*      */           break;
/*      */         case 40:
/*  463 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  464 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m11", "I")));
/*  465 */           il.append(new PUSH(cp, '￿'));
/*  466 */           il.append(new IAND());
/*  467 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  468 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m12", "I")));
/*  469 */           il.append(new PUSH(cp, 16));
/*  470 */           il.append(new ISHL());
/*  471 */           il.append(new IOR());
/*      */           break;
/*      */         case 41:
/*  474 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  475 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/*  476 */           il.append(new PUSH(cp, '￿'));
/*  477 */           il.append(new IAND());
/*  478 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  479 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m21", "I")));
/*  480 */           il.append(new PUSH(cp, 16));
/*  481 */           il.append(new ISHL());
/*  482 */           il.append(new IOR());
/*      */           break;
/*      */         case 42:
/*  485 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  486 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m22", "I")));
/*  487 */           il.append(new PUSH(cp, '￿'));
/*  488 */           il.append(new IAND());
/*  489 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  490 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m23", "I")));
/*  491 */           il.append(new PUSH(cp, 16));
/*  492 */           il.append(new ISHL());
/*  493 */           il.append(new IOR());
/*      */           break;
/*      */         case 43:
/*  496 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  497 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m31", "I")));
/*  498 */           il.append(new PUSH(cp, '￿'));
/*  499 */           il.append(new IAND());
/*  500 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  501 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m32", "I")));
/*  502 */           il.append(new PUSH(cp, 16));
/*  503 */           il.append(new ISHL());
/*  504 */           il.append(new IOR());
/*      */           break;
/*      */         case 44:
/*  507 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  508 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/*  509 */           il.append(new PUSH(cp, '￿'));
/*  510 */           il.append(new IAND());
/*      */           break;
/*      */         case 45:
/*  513 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rbk", "I")));
/*      */           break;
/*      */         case 46:
/*  516 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_gbk", "I")));
/*      */           break;
/*      */         case 47:
/*  519 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_bbk", "I")));
/*      */           break;
/*      */         case 48:
/*  522 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  523 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m11", "I")));
/*  524 */           il.append(new PUSH(cp, '￿'));
/*  525 */           il.append(new IAND());
/*  526 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  527 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m12", "I")));
/*  528 */           il.append(new PUSH(cp, 16));
/*  529 */           il.append(new ISHL());
/*  530 */           il.append(new IOR());
/*      */           break;
/*      */         case 49:
/*  533 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  534 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/*  535 */           il.append(new PUSH(cp, '￿'));
/*  536 */           il.append(new IAND());
/*  537 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  538 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m21", "I")));
/*  539 */           il.append(new PUSH(cp, 16));
/*  540 */           il.append(new ISHL());
/*  541 */           il.append(new IOR());
/*      */           break;
/*      */         case 50:
/*  544 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  545 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m22", "I")));
/*  546 */           il.append(new PUSH(cp, '￿'));
/*  547 */           il.append(new IAND());
/*  548 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  549 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m23", "I")));
/*  550 */           il.append(new PUSH(cp, 16));
/*  551 */           il.append(new ISHL());
/*  552 */           il.append(new IOR());
/*      */           break;
/*      */         case 51:
/*  555 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  556 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m31", "I")));
/*  557 */           il.append(new PUSH(cp, '￿'));
/*  558 */           il.append(new IAND());
/*  559 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  560 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m32", "I")));
/*  561 */           il.append(new PUSH(cp, 16));
/*  562 */           il.append(new ISHL());
/*  563 */           il.append(new IOR());
/*      */           break;
/*      */         case 52:
/*  566 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/*  567 */           il.append(new GETFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m33", "I")));
/*  568 */           il.append(new PUSH(cp, '￿'));
/*  569 */           il.append(new IAND());
/*      */           break;
/*      */         case 53:
/*  572 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rfc", "I")));
/*      */           break;
/*      */         case 54:
/*  575 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_gfc", "I")));
/*      */           break;
/*      */         case 55:
/*  578 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_bfc", "I")));
/*      */           break;
/*      */         case 56:
/*  581 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ofx", "I")));
/*      */           break;
/*      */         case 57:
/*  584 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ofy", "I")));
/*      */           break;
/*      */         case 58:
/*  587 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_h", "I")));
/*      */           break;
/*      */         case 59:
/*  590 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_dqa", "I")));
/*      */           break;
/*      */         case 60:
/*  593 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_dqb", "I")));
/*      */           break;
/*      */         case 61:
/*  596 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_zsf3", "I")));
/*      */           break;
/*      */         case 62:
/*  599 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_zsf4", "I")));
/*      */           break;
/*      */         case 63:
/*  602 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_flag", "I")));
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private static CPUInstruction i_intpl; private static CPUInstruction i_sqr; private static CPUInstruction i_ncs; private static CPUInstruction i_nct; private static CPUInstruction i_ncds; private static CPUInstruction i_ncdt; private static CPUInstruction i_dpct; private static CPUInstruction i_nccs; private static CPUInstruction i_cdp; private static CPUInstruction i_cc; private static CPUInstruction i_gpl;
/*      */   private static void emitWriteReg(InstructionList il, CompilationContext context, int reg) {
/*  609 */     ConstantPoolGen cp = context.getConstantPoolGen();
/*  610 */     int temp = context.getTempLocal(0);
/*      */     
/*  612 */     if (reg < 32) {
/*  613 */       switch (reg) {
/*      */         case 0:
/*  615 */           il.append(new ISTORE(temp));
/*  616 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v0", VECTOR_SIGNATURE)));
/*  617 */           il.append(new ILOAD(temp));
/*  618 */           il.append(new PUSH(cp, 16));
/*  619 */           il.append(new ISHL());
/*  620 */           il.append(new PUSH(cp, 16));
/*  621 */           il.append(new ISHR());
/*  622 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "x", "I")));
/*  623 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v0", VECTOR_SIGNATURE)));
/*  624 */           il.append(new ILOAD(temp));
/*  625 */           il.append(new PUSH(cp, 16));
/*  626 */           il.append(new ISHR());
/*  627 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "y", "I")));
/*      */           return;
/*      */         case 1:
/*  630 */           il.append(new ISTORE(temp));
/*  631 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v0", VECTOR_SIGNATURE)));
/*  632 */           il.append(new ILOAD(temp));
/*  633 */           il.append(new PUSH(cp, 16));
/*  634 */           il.append(new ISHL());
/*  635 */           il.append(new PUSH(cp, 16));
/*  636 */           il.append(new ISHR());
/*  637 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "z", "I")));
/*      */           return;
/*      */         case 2:
/*  640 */           il.append(new ISTORE(temp));
/*  641 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v1", VECTOR_SIGNATURE)));
/*  642 */           il.append(new ILOAD(temp));
/*  643 */           il.append(new PUSH(cp, 16));
/*  644 */           il.append(new ISHL());
/*  645 */           il.append(new PUSH(cp, 16));
/*  646 */           il.append(new ISHR());
/*  647 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "x", "I")));
/*  648 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v1", VECTOR_SIGNATURE)));
/*  649 */           il.append(new ILOAD(temp));
/*  650 */           il.append(new PUSH(cp, 16));
/*  651 */           il.append(new ISHR());
/*  652 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "y", "I")));
/*      */           return;
/*      */         case 3:
/*  655 */           il.append(new ISTORE(temp));
/*  656 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v1", VECTOR_SIGNATURE)));
/*  657 */           il.append(new ILOAD(temp));
/*  658 */           il.append(new PUSH(cp, 16));
/*  659 */           il.append(new ISHL());
/*  660 */           il.append(new PUSH(cp, 16));
/*  661 */           il.append(new ISHR());
/*  662 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "z", "I")));
/*      */           return;
/*      */         case 4:
/*  665 */           il.append(new ISTORE(temp));
/*  666 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v2", VECTOR_SIGNATURE)));
/*  667 */           il.append(new ILOAD(temp));
/*  668 */           il.append(new PUSH(cp, 16));
/*  669 */           il.append(new ISHL());
/*  670 */           il.append(new PUSH(cp, 16));
/*  671 */           il.append(new ISHR());
/*  672 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "x", "I")));
/*  673 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v2", VECTOR_SIGNATURE)));
/*  674 */           il.append(new ILOAD(temp));
/*  675 */           il.append(new PUSH(cp, 16));
/*  676 */           il.append(new ISHR());
/*  677 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "y", "I")));
/*      */           return;
/*      */         case 5:
/*  680 */           il.append(new ISTORE(temp));
/*  681 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_v2", VECTOR_SIGNATURE)));
/*  682 */           il.append(new ILOAD(temp));
/*  683 */           il.append(new PUSH(cp, 16));
/*  684 */           il.append(new ISHL());
/*  685 */           il.append(new PUSH(cp, 16));
/*  686 */           il.append(new ISHR());
/*  687 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(VECTOR_CLASS, "z", "I")));
/*      */           return;
/*      */         case 6:
/*  690 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb", "I")));
/*      */           return;
/*      */         case 7:
/*  693 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_otz", "I")));
/*      */           return;
/*      */         case 8:
/*  696 */           il.append(new PUSH(cp, 16));
/*  697 */           il.append(new ISHL());
/*  698 */           il.append(new PUSH(cp, 16));
/*  699 */           il.append(new ISHR());
/*  700 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir0", "I")));
/*      */           return;
/*      */         case 9:
/*  703 */           il.append(new PUSH(cp, 16));
/*  704 */           il.append(new ISHL());
/*  705 */           il.append(new PUSH(cp, 16));
/*  706 */           il.append(new ISHR());
/*  707 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir1", "I")));
/*      */           return;
/*      */         case 10:
/*  710 */           il.append(new PUSH(cp, 16));
/*  711 */           il.append(new ISHL());
/*  712 */           il.append(new PUSH(cp, 16));
/*  713 */           il.append(new ISHR());
/*  714 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir2", "I")));
/*      */           return;
/*      */         case 11:
/*  717 */           il.append(new PUSH(cp, 16));
/*  718 */           il.append(new ISHL());
/*  719 */           il.append(new PUSH(cp, 16));
/*  720 */           il.append(new ISHR());
/*  721 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ir3", "I")));
/*      */           return;
/*      */         case 12:
/*  724 */           il.append(new ISTORE(temp));
/*  725 */           il.append(new ILOAD(temp));
/*  726 */           il.append(new PUSH(cp, 16));
/*  727 */           il.append(new ISHL());
/*  728 */           il.append(new PUSH(cp, 16));
/*  729 */           il.append(new ISHR());
/*  730 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sx0", "I")));
/*  731 */           il.append(new ILOAD(temp));
/*  732 */           il.append(new PUSH(cp, 16));
/*  733 */           il.append(new ISHR());
/*  734 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sy0", "I")));
/*      */           return;
/*      */         case 13:
/*  737 */           il.append(new ISTORE(temp));
/*  738 */           il.append(new ILOAD(temp));
/*  739 */           il.append(new PUSH(cp, 16));
/*  740 */           il.append(new ISHL());
/*  741 */           il.append(new PUSH(cp, 16));
/*  742 */           il.append(new ISHR());
/*  743 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sx1", "I")));
/*  744 */           il.append(new ILOAD(temp));
/*  745 */           il.append(new PUSH(cp, 16));
/*  746 */           il.append(new ISHR());
/*  747 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sy1", "I")));
/*      */           return;
/*      */         case 14:
/*  750 */           il.append(new ISTORE(temp));
/*  751 */           il.append(new ILOAD(temp));
/*  752 */           il.append(new PUSH(cp, 16));
/*  753 */           il.append(new ISHL());
/*  754 */           il.append(new PUSH(cp, 16));
/*  755 */           il.append(new ISHR());
/*  756 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sx2", "I")));
/*  757 */           il.append(new ILOAD(temp));
/*  758 */           il.append(new PUSH(cp, 16));
/*  759 */           il.append(new ISHR());
/*  760 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sy2", "I")));
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 16:
/*  768 */           il.append(new PUSH(cp, '￿'));
/*  769 */           il.append(new IAND());
/*  770 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_szx", "I")));
/*      */           return;
/*      */         case 17:
/*  773 */           il.append(new PUSH(cp, '￿'));
/*  774 */           il.append(new IAND());
/*  775 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sz0", "I")));
/*      */           return;
/*      */         case 18:
/*  778 */           il.append(new PUSH(cp, '￿'));
/*  779 */           il.append(new IAND());
/*  780 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sz1", "I")));
/*      */           return;
/*      */         case 19:
/*  783 */           il.append(new PUSH(cp, '￿'));
/*  784 */           il.append(new IAND());
/*  785 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_sz2", "I")));
/*      */           return;
/*      */         case 20:
/*  788 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb0", "I")));
/*      */           return;
/*      */         case 21:
/*  791 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb1", "I")));
/*      */           return;
/*      */         case 22:
/*  794 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rgb2", "I")));
/*      */           return;
/*      */         case 23:
/*  797 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_res1", "I")));
/*      */           return;
/*      */         case 24:
/*  800 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac0", "I")));
/*      */           return;
/*      */         case 25:
/*  803 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac1", "I")));
/*      */           return;
/*      */         case 26:
/*  806 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac2", "I")));
/*      */           return;
/*      */         case 27:
/*  809 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_mac3", "I")));
/*      */           return;
/*      */         
/*      */         case 28:
/*  813 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_irgb", "I")));
/*      */           return;
/*      */         
/*      */         case 29:
/*  817 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_orgb", "I")));
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 31:
/*  838 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lzcr", "I")));
/*      */           return;
/*      */       } 
/*  841 */       il.append(new ISTORE(temp));
/*  842 */       il.append(new PUSH(cp, reg));
/*  843 */       il.append(new ILOAD(temp));
/*  844 */       il.append(new INVOKESTATIC(cp.addMethodref(CLASS, "writeRegister", "(II)V")));
/*      */     }
/*      */     else {
/*      */       
/*  848 */       switch (reg) {
/*      */         case 32:
/*  850 */           il.append(new ISTORE(temp));
/*  851 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  852 */           il.append(new ILOAD(temp));
/*  853 */           il.append(new PUSH(cp, 16));
/*  854 */           il.append(new ISHL());
/*  855 */           il.append(new PUSH(cp, 16));
/*  856 */           il.append(new ISHR());
/*  857 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m11", "I")));
/*  858 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  859 */           il.append(new ILOAD(temp));
/*  860 */           il.append(new PUSH(cp, 16));
/*  861 */           il.append(new ISHR());
/*  862 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m12", "I")));
/*      */           return;
/*      */         case 33:
/*  865 */           il.append(new ISTORE(temp));
/*  866 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  867 */           il.append(new ILOAD(temp));
/*  868 */           il.append(new PUSH(cp, 16));
/*  869 */           il.append(new ISHL());
/*  870 */           il.append(new PUSH(cp, 16));
/*  871 */           il.append(new ISHR());
/*  872 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/*  873 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  874 */           il.append(new ILOAD(temp));
/*  875 */           il.append(new PUSH(cp, 16));
/*  876 */           il.append(new ISHR());
/*  877 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m21", "I")));
/*      */           return;
/*      */         case 34:
/*  880 */           il.append(new ISTORE(temp));
/*  881 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  882 */           il.append(new ILOAD(temp));
/*  883 */           il.append(new PUSH(cp, 16));
/*  884 */           il.append(new ISHL());
/*  885 */           il.append(new PUSH(cp, 16));
/*  886 */           il.append(new ISHR());
/*  887 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m22", "I")));
/*  888 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  889 */           il.append(new ILOAD(temp));
/*  890 */           il.append(new PUSH(cp, 16));
/*  891 */           il.append(new ISHR());
/*  892 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m23", "I")));
/*      */           return;
/*      */         case 35:
/*  895 */           il.append(new ISTORE(temp));
/*  896 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  897 */           il.append(new ILOAD(temp));
/*  898 */           il.append(new PUSH(cp, 16));
/*  899 */           il.append(new ISHL());
/*  900 */           il.append(new PUSH(cp, 16));
/*  901 */           il.append(new ISHR());
/*  902 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m31", "I")));
/*  903 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  904 */           il.append(new ILOAD(temp));
/*  905 */           il.append(new PUSH(cp, 16));
/*  906 */           il.append(new ISHR());
/*  907 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m32", "I")));
/*      */           return;
/*      */         case 36:
/*  910 */           il.append(new ISTORE(temp));
/*  911 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rot", MATRIX_SIGNATURE)));
/*  912 */           il.append(new ILOAD(temp));
/*  913 */           il.append(new PUSH(cp, 16));
/*  914 */           il.append(new ISHL());
/*  915 */           il.append(new PUSH(cp, 16));
/*  916 */           il.append(new ISHR());
/*  917 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m33", "I")));
/*      */           return;
/*      */         case 37:
/*  920 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_trx", "I")));
/*      */           return;
/*      */         case 38:
/*  923 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_try", "I")));
/*      */           return;
/*      */         case 39:
/*  926 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_trz", "I")));
/*      */           return;
/*      */         case 40:
/*  929 */           il.append(new ISTORE(temp));
/*  930 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  931 */           il.append(new ILOAD(temp));
/*  932 */           il.append(new PUSH(cp, 16));
/*  933 */           il.append(new ISHL());
/*  934 */           il.append(new PUSH(cp, 16));
/*  935 */           il.append(new ISHR());
/*  936 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m11", "I")));
/*  937 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  938 */           il.append(new ILOAD(temp));
/*  939 */           il.append(new PUSH(cp, 16));
/*  940 */           il.append(new ISHR());
/*  941 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m12", "I")));
/*      */           return;
/*      */         case 41:
/*  944 */           il.append(new ISTORE(temp));
/*  945 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  946 */           il.append(new ILOAD(temp));
/*  947 */           il.append(new PUSH(cp, 16));
/*  948 */           il.append(new ISHL());
/*  949 */           il.append(new PUSH(cp, 16));
/*  950 */           il.append(new ISHR());
/*  951 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/*  952 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  953 */           il.append(new ILOAD(temp));
/*  954 */           il.append(new PUSH(cp, 16));
/*  955 */           il.append(new ISHR());
/*  956 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m21", "I")));
/*      */           return;
/*      */         case 42:
/*  959 */           il.append(new ISTORE(temp));
/*  960 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  961 */           il.append(new ILOAD(temp));
/*  962 */           il.append(new PUSH(cp, 16));
/*  963 */           il.append(new ISHL());
/*  964 */           il.append(new PUSH(cp, 16));
/*  965 */           il.append(new ISHR());
/*  966 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m22", "I")));
/*  967 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  968 */           il.append(new ILOAD(temp));
/*  969 */           il.append(new PUSH(cp, 16));
/*  970 */           il.append(new ISHR());
/*  971 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m23", "I")));
/*      */           return;
/*      */         case 43:
/*  974 */           il.append(new ISTORE(temp));
/*  975 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  976 */           il.append(new ILOAD(temp));
/*  977 */           il.append(new PUSH(cp, 16));
/*  978 */           il.append(new ISHL());
/*  979 */           il.append(new PUSH(cp, 16));
/*  980 */           il.append(new ISHR());
/*  981 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m31", "I")));
/*  982 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  983 */           il.append(new ILOAD(temp));
/*  984 */           il.append(new PUSH(cp, 16));
/*  985 */           il.append(new ISHR());
/*  986 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m32", "I")));
/*      */           return;
/*      */         case 44:
/*  989 */           il.append(new ISTORE(temp));
/*  990 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ls", MATRIX_SIGNATURE)));
/*  991 */           il.append(new ILOAD(temp));
/*  992 */           il.append(new PUSH(cp, 16));
/*  993 */           il.append(new ISHL());
/*  994 */           il.append(new PUSH(cp, 16));
/*  995 */           il.append(new ISHR());
/*  996 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m33", "I")));
/*      */           return;
/*      */         case 45:
/*  999 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rbk", "I")));
/*      */           return;
/*      */         case 46:
/* 1002 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_gbk", "I")));
/*      */           return;
/*      */         case 47:
/* 1005 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_bbk", "I")));
/*      */           return;
/*      */         case 48:
/* 1008 */           il.append(new ISTORE(temp));
/* 1009 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1010 */           il.append(new ILOAD(temp));
/* 1011 */           il.append(new PUSH(cp, 16));
/* 1012 */           il.append(new ISHL());
/* 1013 */           il.append(new PUSH(cp, 16));
/* 1014 */           il.append(new ISHR());
/* 1015 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m11", "I")));
/* 1016 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1017 */           il.append(new ILOAD(temp));
/* 1018 */           il.append(new PUSH(cp, 16));
/* 1019 */           il.append(new ISHR());
/* 1020 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m12", "I")));
/*      */           return;
/*      */         case 49:
/* 1023 */           il.append(new ISTORE(temp));
/* 1024 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1025 */           il.append(new ILOAD(temp));
/* 1026 */           il.append(new PUSH(cp, 16));
/* 1027 */           il.append(new ISHL());
/* 1028 */           il.append(new PUSH(cp, 16));
/* 1029 */           il.append(new ISHR());
/* 1030 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m13", "I")));
/* 1031 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1032 */           il.append(new ILOAD(temp));
/* 1033 */           il.append(new PUSH(cp, 16));
/* 1034 */           il.append(new ISHR());
/* 1035 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m21", "I")));
/*      */           return;
/*      */         case 50:
/* 1038 */           il.append(new ISTORE(temp));
/* 1039 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1040 */           il.append(new ILOAD(temp));
/* 1041 */           il.append(new PUSH(cp, 16));
/* 1042 */           il.append(new ISHL());
/* 1043 */           il.append(new PUSH(cp, 16));
/* 1044 */           il.append(new ISHR());
/* 1045 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m22", "I")));
/* 1046 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1047 */           il.append(new ILOAD(temp));
/* 1048 */           il.append(new PUSH(cp, 16));
/* 1049 */           il.append(new ISHR());
/* 1050 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m23", "I")));
/*      */           return;
/*      */         case 51:
/* 1053 */           il.append(new ISTORE(temp));
/* 1054 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1055 */           il.append(new ILOAD(temp));
/* 1056 */           il.append(new PUSH(cp, 16));
/* 1057 */           il.append(new ISHL());
/* 1058 */           il.append(new PUSH(cp, 16));
/* 1059 */           il.append(new ISHR());
/* 1060 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m31", "I")));
/* 1061 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1062 */           il.append(new ILOAD(temp));
/* 1063 */           il.append(new PUSH(cp, 16));
/* 1064 */           il.append(new ISHR());
/* 1065 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m32", "I")));
/*      */           return;
/*      */         case 52:
/* 1068 */           il.append(new ISTORE(temp));
/* 1069 */           il.append(new GETSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_lc", MATRIX_SIGNATURE)));
/* 1070 */           il.append(new ILOAD(temp));
/* 1071 */           il.append(new PUSH(cp, 16));
/* 1072 */           il.append(new ISHL());
/* 1073 */           il.append(new PUSH(cp, 16));
/* 1074 */           il.append(new ISHR());
/* 1075 */           il.append(new PUTFIELD(context.getConstantPoolGen().addFieldref(MATRIX_CLASS, "m33", "I")));
/*      */           return;
/*      */         case 53:
/* 1078 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_rfc", "I")));
/*      */           return;
/*      */         case 54:
/* 1081 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_gfc", "I")));
/*      */           return;
/*      */         case 55:
/* 1084 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_bfc", "I")));
/*      */           return;
/*      */         case 56:
/* 1087 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ofx", "I")));
/*      */           return;
/*      */         case 57:
/* 1090 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_ofy", "I")));
/*      */           return;
/*      */         case 58:
/* 1093 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_h", "I")));
/*      */           return;
/*      */         case 59:
/* 1096 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_dqa", "I")));
/*      */           return;
/*      */         case 60:
/* 1099 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_dqb", "I")));
/*      */           return;
/*      */         case 61:
/* 1102 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_zsf3", "I")));
/*      */           return;
/*      */         case 62:
/* 1105 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_zsf4", "I")));
/*      */           return;
/*      */         case 63:
/* 1108 */           il.append(new PUTSTATIC(context.getConstantPoolGen().addFieldref(CLASS, "reg_flag", "I")));
/*      */           return;
/*      */       } 
/* 1111 */       il.append(new ISTORE(temp));
/* 1112 */       il.append(new PUSH(cp, reg));
/* 1113 */       il.append(new ILOAD(temp));
/* 1114 */       il.append(new INVOKESTATIC(cp.addMethodref(CLASS, "writeRegister", "(II)V")));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/* 1121 */     super.init();
/* 1122 */     CoreComponentConnections.INSTRUCTION_PROVIDERS.add(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public void resolveConnections() {
/* 1127 */     super.resolveConnections();
/* 1128 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/* 1129 */     r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/* 1130 */     r3000regs = r3000.getInterpreterRegs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInstructions(InstructionRegistrar registrar) { // Byte code:
/*      */     //   0: getstatic org/jpsx/runtime/components/hardware/gte/GTE.log : Lorg/apache/log4j/Logger;
/*      */     //   3: ldc 'Adding COP2 instructions...'
/*      */     //   5: invokevirtual info : (Ljava/lang/Object;)V
/*      */     //   8: new org/jpsx/runtime/components/hardware/gte/GTE$1
/*      */     //   11: dup
/*      */     //   12: aload_0
/*      */     //   13: ldc 'mfc2'
/*      */     //   15: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   18: iconst_0
/*      */     //   19: sipush #1024
/*      */     //   22: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   25: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_mfc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   28: new org/jpsx/runtime/components/hardware/gte/GTE$2
/*      */     //   31: dup
/*      */     //   32: aload_0
/*      */     //   33: ldc 'cfc2'
/*      */     //   35: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   38: iconst_0
/*      */     //   39: sipush #1024
/*      */     //   42: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   45: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_cfc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   48: new org/jpsx/runtime/components/hardware/gte/GTE$3
/*      */     //   51: dup
/*      */     //   52: aload_0
/*      */     //   53: ldc 'mtc2'
/*      */     //   55: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   58: iconst_0
/*      */     //   59: sipush #512
/*      */     //   62: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   65: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_mtc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   68: new org/jpsx/runtime/components/hardware/gte/GTE$4
/*      */     //   71: dup
/*      */     //   72: aload_0
/*      */     //   73: ldc 'ctc2'
/*      */     //   75: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   78: iconst_0
/*      */     //   79: sipush #512
/*      */     //   82: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   85: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_ctc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   88: new org/jpsx/runtime/components/hardware/gte/GTE$5
/*      */     //   91: dup
/*      */     //   92: aload_0
/*      */     //   93: ldc 'lwc2'
/*      */     //   95: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   98: iconst_0
/*      */     //   99: ldc 33024
/*      */     //   101: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   104: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_lwc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   107: new org/jpsx/runtime/components/hardware/gte/GTE$6
/*      */     //   110: dup
/*      */     //   111: aload_0
/*      */     //   112: ldc 'swc2'
/*      */     //   114: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   117: iconst_0
/*      */     //   118: ldc 33024
/*      */     //   120: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   123: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_swc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   126: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   129: dup
/*      */     //   130: ldc 'rtpt'
/*      */     //   132: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   135: iconst_0
/*      */     //   136: iconst_0
/*      */     //   137: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   140: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_rtpt : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   143: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   146: dup
/*      */     //   147: ldc 'rtps'
/*      */     //   149: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   152: iconst_0
/*      */     //   153: iconst_0
/*      */     //   154: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   157: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_rtps : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   160: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   163: dup
/*      */     //   164: ldc 'mvmva'
/*      */     //   166: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   169: iconst_0
/*      */     //   170: iconst_0
/*      */     //   171: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   174: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_mvmva : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   177: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   180: dup
/*      */     //   181: ldc 'op'
/*      */     //   183: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   186: iconst_0
/*      */     //   187: iconst_0
/*      */     //   188: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   191: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_op : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   194: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   197: dup
/*      */     //   198: ldc 'avsz3'
/*      */     //   200: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   203: iconst_0
/*      */     //   204: iconst_0
/*      */     //   205: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   208: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_avsz3 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   211: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   214: dup
/*      */     //   215: ldc 'avsz4'
/*      */     //   217: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   220: iconst_0
/*      */     //   221: iconst_0
/*      */     //   222: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   225: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_avsz4 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   228: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   231: dup
/*      */     //   232: ldc 'nclip'
/*      */     //   234: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   237: iconst_0
/*      */     //   238: iconst_0
/*      */     //   239: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   242: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_nclip : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   245: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   248: dup
/*      */     //   249: ldc 'ncct'
/*      */     //   251: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   254: iconst_0
/*      */     //   255: iconst_0
/*      */     //   256: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   259: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_ncct : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   262: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   265: dup
/*      */     //   266: ldc 'gpf'
/*      */     //   268: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   271: iconst_0
/*      */     //   272: iconst_0
/*      */     //   273: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   276: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_gpf : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   279: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   282: dup
/*      */     //   283: ldc 'dcpl'
/*      */     //   285: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   288: iconst_0
/*      */     //   289: iconst_0
/*      */     //   290: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   293: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_dcpl : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   296: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   299: dup
/*      */     //   300: ldc 'dpcs'
/*      */     //   302: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   305: iconst_0
/*      */     //   306: iconst_0
/*      */     //   307: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   310: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_dpcs : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   313: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   316: dup
/*      */     //   317: ldc 'intpl'
/*      */     //   319: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   322: iconst_0
/*      */     //   323: iconst_0
/*      */     //   324: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   327: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_intpl : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   330: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   333: dup
/*      */     //   334: ldc 'sqr'
/*      */     //   336: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   339: iconst_0
/*      */     //   340: iconst_0
/*      */     //   341: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   344: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_sqr : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   347: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   350: dup
/*      */     //   351: ldc 'ncs'
/*      */     //   353: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   356: iconst_0
/*      */     //   357: iconst_0
/*      */     //   358: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   361: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_ncs : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   364: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   367: dup
/*      */     //   368: ldc 'nct'
/*      */     //   370: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   373: iconst_0
/*      */     //   374: iconst_0
/*      */     //   375: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   378: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_nct : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   381: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   384: dup
/*      */     //   385: ldc 'ncds'
/*      */     //   387: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   390: iconst_0
/*      */     //   391: iconst_0
/*      */     //   392: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   395: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_ncds : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   398: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   401: dup
/*      */     //   402: ldc 'ncdt'
/*      */     //   404: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   407: iconst_0
/*      */     //   408: iconst_0
/*      */     //   409: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   412: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_ncdt : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   415: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   418: dup
/*      */     //   419: ldc 'dpct'
/*      */     //   421: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   424: iconst_0
/*      */     //   425: iconst_0
/*      */     //   426: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   429: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_dpct : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   432: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   435: dup
/*      */     //   436: ldc 'nccs'
/*      */     //   438: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   441: iconst_0
/*      */     //   442: iconst_0
/*      */     //   443: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   446: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_nccs : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   449: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   452: dup
/*      */     //   453: ldc 'cdp'
/*      */     //   455: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   458: iconst_0
/*      */     //   459: iconst_0
/*      */     //   460: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   463: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_cdp : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   466: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   469: dup
/*      */     //   470: ldc 'cc'
/*      */     //   472: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   475: iconst_0
/*      */     //   476: iconst_0
/*      */     //   477: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   480: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_cc : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   483: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   486: dup
/*      */     //   487: ldc 'gpl'
/*      */     //   489: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   492: iconst_0
/*      */     //   493: iconst_0
/*      */     //   494: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   497: putstatic org/jpsx/runtime/components/hardware/gte/GTE.i_gpl : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   500: new org/jpsx/runtime/components/hardware/gte/GTE$7
/*      */     //   503: dup
/*      */     //   504: aload_0
/*      */     //   505: ldc 'cop2'
/*      */     //   507: ldc_w org/jpsx/runtime/components/hardware/gte/GTE
/*      */     //   510: iconst_0
/*      */     //   511: iconst_0
/*      */     //   512: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/gte/GTE;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   515: astore_2
/*      */     //   516: aload_1
/*      */     //   517: bipush #18
/*      */     //   519: aload_2
/*      */     //   520: invokeinterface setInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*      */     //   525: aload_1
/*      */     //   526: bipush #50
/*      */     //   528: getstatic org/jpsx/runtime/components/hardware/gte/GTE.i_lwc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   531: invokeinterface setInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*      */     //   536: aload_1
/*      */     //   537: bipush #58
/*      */     //   539: getstatic org/jpsx/runtime/components/hardware/gte/GTE.i_swc2 : Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   542: invokeinterface setInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*      */     //   547: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1134	-> 0
/*      */     //   #1135	-> 8
/*      */     //   #1146	-> 28
/*      */     //   #1158	-> 48
/*      */     //   #1175	-> 68
/*      */     //   #1190	-> 88
/*      */     //   #1204	-> 107
/*      */     //   #1220	-> 126
/*      */     //   #1221	-> 143
/*      */     //   #1222	-> 160
/*      */     //   #1223	-> 177
/*      */     //   #1224	-> 194
/*      */     //   #1225	-> 211
/*      */     //   #1226	-> 228
/*      */     //   #1227	-> 245
/*      */     //   #1228	-> 262
/*      */     //   #1229	-> 279
/*      */     //   #1230	-> 296
/*      */     //   #1231	-> 313
/*      */     //   #1232	-> 330
/*      */     //   #1233	-> 347
/*      */     //   #1234	-> 364
/*      */     //   #1235	-> 381
/*      */     //   #1236	-> 398
/*      */     //   #1237	-> 415
/*      */     //   #1238	-> 432
/*      */     //   #1239	-> 449
/*      */     //   #1240	-> 466
/*      */     //   #1241	-> 483
/*      */     //   #1242	-> 500
/*      */     //   #1309	-> 516
/*      */     //   #1310	-> 525
/*      */     //   #1311	-> 536
/*      */     //   #1312	-> 547
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	548	0	this	Lorg/jpsx/runtime/components/hardware/gte/GTE;
/*      */     //   0	548	1	registrar	Lorg/jpsx/api/components/core/cpu/InstructionRegistrar;
/*      */     //   516	32	2	i_cop2	Lorg/jpsx/api/components/core/cpu/CPUInstruction; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void interpret_mfc2(int ci) {
/* 1344 */     int rt = R3000.Util.bits_rt(ci);
/* 1345 */     int rd = R3000.Util.bits_rd(ci);
/* 1346 */     int value = readRegister(rd);
/* 1347 */     if (rt != 0) {
/* 1348 */       r3000regs[rt] = value;
/*      */     }
/*      */   }
/*      */   
/*      */   public static int readRegister(int reg) {
/* 1353 */     switch (reg) {
/*      */       case 0:
/* 1355 */         return reg_v0.x & 0xFFFF | reg_v0.y << 16 & 0xFFFF0000;
/*      */       
/*      */       case 1:
/* 1358 */         return reg_v0.z;
/*      */       
/*      */       case 2:
/* 1361 */         return reg_v1.x & 0xFFFF | reg_v1.y << 16 & 0xFFFF0000;
/*      */       
/*      */       case 3:
/* 1364 */         return reg_v1.z;
/*      */       
/*      */       case 4:
/* 1367 */         return reg_v2.x & 0xFFFF | reg_v2.y << 16 & 0xFFFF0000;
/*      */       
/*      */       case 5:
/* 1370 */         return reg_v2.z;
/*      */       
/*      */       case 6:
/* 1373 */         return reg_rgb;
/*      */       
/*      */       case 7:
/* 1376 */         return reg_otz;
/*      */       
/*      */       case 8:
/* 1379 */         return reg_ir0;
/*      */       
/*      */       case 9:
/* 1382 */         return reg_ir1;
/*      */       
/*      */       case 10:
/* 1385 */         return reg_ir2;
/*      */       
/*      */       case 11:
/* 1388 */         return reg_ir3;
/*      */       
/*      */       case 12:
/* 1391 */         return reg_sx0 & 0xFFFF | reg_sy0 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 13:
/* 1394 */         return reg_sx1 & 0xFFFF | reg_sy1 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 14:
/* 1397 */         return reg_sx2 & 0xFFFF | reg_sy2 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 15:
/* 1400 */         return reg_sxp & 0xFFFF | reg_syp << 16 & 0xFFFF0000;
/*      */       
/*      */       case 16:
/* 1403 */         return reg_szx;
/*      */       
/*      */       case 17:
/* 1406 */         return reg_sz0;
/*      */       
/*      */       case 18:
/* 1409 */         return reg_sz1;
/*      */       
/*      */       case 19:
/* 1412 */         return reg_sz2;
/*      */       
/*      */       case 20:
/* 1415 */         return reg_rgb0;
/*      */       
/*      */       case 21:
/* 1418 */         return reg_rgb1;
/*      */       
/*      */       case 22:
/* 1421 */         return reg_rgb2;
/*      */       
/*      */       case 23:
/* 1424 */         return reg_res1;
/*      */       
/*      */       case 24:
/* 1427 */         return reg_mac0;
/*      */       
/*      */       case 25:
/* 1430 */         return reg_mac1;
/*      */       
/*      */       case 26:
/* 1433 */         return reg_mac2;
/*      */       
/*      */       case 27:
/* 1436 */         return reg_mac3;
/*      */ 
/*      */       
/*      */       case 28:
/* 1440 */         return reg_irgb;
/*      */ 
/*      */       
/*      */       case 29:
/* 1444 */         return reg_orgb;
/*      */       
/*      */       case 30:
/* 1447 */         return reg_lzcs;
/*      */       
/*      */       case 31:
/* 1450 */         return reg_lzcr;
/*      */       
/*      */       case 32:
/* 1453 */         return reg_rot.m11 & 0xFFFF | reg_rot.m12 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 33:
/* 1456 */         return reg_rot.m13 & 0xFFFF | reg_rot.m21 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 34:
/* 1459 */         return reg_rot.m22 & 0xFFFF | reg_rot.m23 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 35:
/* 1462 */         return reg_rot.m31 & 0xFFFF | reg_rot.m32 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 36:
/* 1465 */         return reg_rot.m33 & 0xFFFF;
/*      */       
/*      */       case 37:
/* 1468 */         return reg_trx;
/*      */       
/*      */       case 38:
/* 1471 */         return reg_try;
/*      */       
/*      */       case 39:
/* 1474 */         return reg_trz;
/*      */       
/*      */       case 40:
/* 1477 */         return reg_ls.m11 & 0xFFFF | reg_ls.m12 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 41:
/* 1480 */         return reg_ls.m13 & 0xFFFF | reg_ls.m21 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 42:
/* 1483 */         return reg_ls.m21 & 0xFFFF | reg_ls.m23 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 43:
/* 1486 */         return reg_ls.m31 & 0xFFFF | reg_ls.m32 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 44:
/* 1489 */         return reg_ls.m33 & 0xFFFF;
/*      */       
/*      */       case 45:
/* 1492 */         return reg_rbk;
/*      */       
/*      */       case 46:
/* 1495 */         return reg_gbk;
/*      */       
/*      */       case 47:
/* 1498 */         return reg_bbk;
/*      */       
/*      */       case 48:
/* 1501 */         return reg_lc.m11 & 0xFFFF | reg_lc.m12 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 49:
/* 1504 */         return reg_lc.m13 & 0xFFFF | reg_lc.m21 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 50:
/* 1507 */         return reg_lc.m22 & 0xFFFF | reg_lc.m23 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 51:
/* 1510 */         return reg_lc.m31 & 0xFFFF | reg_lc.m32 << 16 & 0xFFFF0000;
/*      */       
/*      */       case 52:
/* 1513 */         return reg_lc.m33 & 0xFFFF;
/*      */       
/*      */       case 53:
/* 1516 */         return reg_rfc;
/*      */       
/*      */       case 54:
/* 1519 */         return reg_gfc;
/*      */       
/*      */       case 55:
/* 1522 */         return reg_bfc;
/*      */       
/*      */       case 56:
/* 1525 */         return reg_ofx;
/*      */       
/*      */       case 57:
/* 1528 */         return reg_ofy;
/*      */       
/*      */       case 58:
/* 1531 */         return reg_h;
/*      */       
/*      */       case 59:
/* 1534 */         return reg_dqa;
/*      */       
/*      */       case 60:
/* 1537 */         return reg_dqb;
/*      */       
/*      */       case 61:
/* 1540 */         return reg_zsf3;
/*      */       
/*      */       case 62:
/* 1543 */         return reg_zsf4;
/*      */       
/*      */       case 63:
/* 1546 */         return reg_flag;
/*      */     } 
/*      */     
/* 1549 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_cfc2(int ci)
/*      */   {
/* 1555 */     int rt = R3000.Util.bits_rt(ci);
/* 1556 */     int rd = R3000.Util.bits_rd(ci);
/* 1557 */     int value = readRegister(rd + 32);
/* 1558 */     if (rt != 0)
/* 1559 */       r3000regs[rt] = value;  } public static void writeRegister(int reg, int value) {
/*      */     int bits;
/*      */     int comp;
/*      */     int mask;
/* 1563 */     switch (reg) {
/*      */       case 0:
/* 1565 */         reg_v0.x = value << 16 >> 16;
/* 1566 */         reg_v0.y = value >> 16;
/*      */         break;
/*      */       case 1:
/* 1569 */         reg_v0.z = value << 16 >> 16;
/*      */         break;
/*      */       case 2:
/* 1572 */         reg_v1.x = value << 16 >> 16;
/* 1573 */         reg_v1.y = value >> 16;
/*      */         break;
/*      */       case 3:
/* 1576 */         reg_v1.z = value << 16 >> 16;
/*      */         break;
/*      */       case 4:
/* 1579 */         reg_v2.x = value << 16 >> 16;
/* 1580 */         reg_v2.y = value >> 16;
/*      */         break;
/*      */       case 5:
/* 1583 */         reg_v2.z = value << 16 >> 16;
/*      */         break;
/*      */       case 6:
/* 1586 */         reg_rgb = value;
/*      */         break;
/*      */       case 7:
/* 1589 */         reg_otz = value;
/*      */         break;
/*      */       case 8:
/* 1592 */         reg_ir0 = value << 16 >> 16;
/*      */         break;
/*      */       case 9:
/* 1595 */         reg_ir1 = value << 16 >> 16;
/*      */         break;
/*      */       case 10:
/* 1598 */         reg_ir2 = value << 16 >> 16;
/*      */         break;
/*      */       case 11:
/* 1601 */         reg_ir3 = value << 16 >> 16;
/*      */         break;
/*      */       case 12:
/* 1604 */         reg_sx0 = value << 16 >> 16;
/* 1605 */         reg_sy0 = value >> 16;
/*      */         break;
/*      */       case 13:
/* 1608 */         reg_sx1 = value << 16 >> 16;
/* 1609 */         reg_sy1 = value >> 16;
/*      */         break;
/*      */       case 14:
/* 1612 */         reg_sx2 = value << 16 >> 16;
/* 1613 */         reg_sy2 = value >> 16;
/*      */         break;
/*      */       
/*      */       case 15:
/* 1617 */         reg_sx0 = reg_sx1;
/* 1618 */         reg_sx1 = reg_sx2;
/* 1619 */         reg_sx2 = value << 16 >> 16;
/* 1620 */         reg_sy0 = reg_sy1;
/* 1621 */         reg_sy1 = reg_sy2;
/* 1622 */         reg_sy2 = value >> 16;
/*      */         break;
/*      */       case 16:
/* 1625 */         reg_szx = value & 0xFFFF;
/*      */         break;
/*      */       case 17:
/* 1628 */         reg_sz0 = value & 0xFFFF;
/*      */         break;
/*      */       case 18:
/* 1631 */         reg_sz1 = value & 0xFFFF;
/*      */         break;
/*      */       case 19:
/* 1634 */         reg_sz2 = value & 0xFFFF;
/*      */         break;
/*      */       case 20:
/* 1637 */         reg_rgb0 = value;
/*      */         break;
/*      */       case 21:
/* 1640 */         reg_rgb1 = value;
/*      */         break;
/*      */       case 22:
/* 1643 */         reg_rgb2 = value;
/*      */         break;
/*      */       case 23:
/* 1646 */         reg_res1 = value;
/*      */         break;
/*      */       case 24:
/* 1649 */         reg_mac0 = value;
/*      */         break;
/*      */       case 25:
/* 1652 */         reg_mac1 = value;
/*      */         break;
/*      */       case 26:
/* 1655 */         reg_mac2 = value;
/*      */         break;
/*      */       case 27:
/* 1658 */         reg_mac3 = value;
/*      */         break;
/*      */       
/*      */       case 28:
/* 1662 */         reg_irgb = value;
/*      */         break;
/*      */       
/*      */       case 29:
/* 1666 */         reg_orgb = value;
/*      */         break;
/*      */       case 30:
/* 1669 */         reg_lzcs = value;
/* 1670 */         mask = Integer.MIN_VALUE;
/* 1671 */         comp = value & 0x80000000;
/*      */ 
/*      */         
/* 1674 */         for (bits = 0; bits < 32 && (
/* 1675 */           value & mask) == comp; bits++) {
/*      */           
/* 1677 */           mask >>= 1;
/* 1678 */           comp >>= 1;
/*      */         } 
/* 1680 */         reg_lzcr = bits;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 31:
/* 1686 */         reg_lzcr = value;
/*      */         break;
/*      */       case 32:
/* 1689 */         reg_rot.m11 = value << 16 >> 16;
/* 1690 */         reg_rot.m12 = value >> 16;
/*      */         break;
/*      */       case 33:
/* 1693 */         reg_rot.m13 = value << 16 >> 16;
/* 1694 */         reg_rot.m21 = value >> 16;
/*      */         break;
/*      */       case 34:
/* 1697 */         reg_rot.m22 = value << 16 >> 16;
/* 1698 */         reg_rot.m23 = value >> 16;
/*      */         break;
/*      */       case 35:
/* 1701 */         reg_rot.m31 = value << 16 >> 16;
/* 1702 */         reg_rot.m32 = value >> 16;
/*      */         break;
/*      */       case 36:
/* 1705 */         reg_rot.m33 = value << 16 >> 16;
/*      */         break;
/*      */       case 37:
/* 1708 */         reg_trx = value;
/*      */         break;
/*      */       case 38:
/* 1711 */         reg_try = value;
/*      */         break;
/*      */       case 39:
/* 1714 */         reg_trz = value;
/*      */         break;
/*      */       case 40:
/* 1717 */         reg_ls.m11 = value << 16 >> 16;
/* 1718 */         reg_ls.m12 = value >> 16;
/*      */         break;
/*      */       case 41:
/* 1721 */         reg_ls.m13 = value << 16 >> 16;
/* 1722 */         reg_ls.m21 = value >> 16;
/*      */         break;
/*      */       case 42:
/* 1725 */         reg_ls.m22 = value << 16 >> 16;
/* 1726 */         reg_ls.m23 = value >> 16;
/*      */         break;
/*      */       case 43:
/* 1729 */         reg_ls.m31 = value << 16 >> 16;
/* 1730 */         reg_ls.m32 = value >> 16;
/*      */         break;
/*      */       case 44:
/* 1733 */         reg_ls.m33 = value << 16 >> 16;
/*      */         break;
/*      */       case 45:
/* 1736 */         reg_rbk = value;
/*      */         break;
/*      */       case 46:
/* 1739 */         reg_gbk = value;
/*      */         break;
/*      */       case 47:
/* 1742 */         reg_bbk = value;
/*      */         break;
/*      */       case 48:
/* 1745 */         reg_lc.m11 = value << 16 >> 16;
/* 1746 */         reg_lc.m12 = value >> 16;
/*      */         break;
/*      */       case 49:
/* 1749 */         reg_lc.m13 = value << 16 >> 16;
/* 1750 */         reg_lc.m21 = value >> 16;
/*      */         break;
/*      */       case 50:
/* 1753 */         reg_lc.m22 = value << 16 >> 16;
/* 1754 */         reg_lc.m23 = value >> 16;
/*      */         break;
/*      */       case 51:
/* 1757 */         reg_lc.m31 = value << 16 >> 16;
/* 1758 */         reg_lc.m32 = value >> 16;
/*      */         break;
/*      */       case 52:
/* 1761 */         reg_lc.m33 = value << 16 >> 16;
/*      */         break;
/*      */       case 53:
/* 1764 */         reg_rfc = value;
/*      */         break;
/*      */       case 54:
/* 1767 */         reg_gfc = value;
/*      */         break;
/*      */       case 55:
/* 1770 */         reg_bfc = value;
/*      */         break;
/*      */       case 56:
/* 1773 */         reg_ofx = value;
/*      */         break;
/*      */       case 57:
/* 1776 */         reg_ofy = value;
/*      */         break;
/*      */       case 58:
/* 1779 */         reg_h = value;
/*      */         break;
/*      */       case 59:
/* 1782 */         reg_dqa = value;
/*      */         break;
/*      */       case 60:
/* 1785 */         reg_dqb = value;
/*      */         break;
/*      */       case 61:
/* 1788 */         reg_zsf3 = value;
/*      */         break;
/*      */       case 62:
/* 1791 */         reg_zsf4 = value;
/*      */         break;
/*      */       case 63:
/* 1794 */         reg_flag = value;
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_mtc2(int ci) {
/* 1800 */     int rt = R3000.Util.bits_rt(ci);
/* 1801 */     int rd = R3000.Util.bits_rd(ci);
/* 1802 */     int value = r3000regs[rt];
/*      */     
/* 1804 */     writeRegister(rd, value);
/*      */   }
/*      */   
/*      */   public static void interpret_ctc2(int ci) {
/* 1808 */     int rt = R3000.Util.bits_rt(ci);
/* 1809 */     int rd = R3000.Util.bits_rd(ci);
/* 1810 */     int value = r3000regs[rt];
/*      */     
/* 1812 */     writeRegister(rd + 32, value);
/*      */   }
/*      */   
/*      */   public static void interpret_cop2(int ci) {
/* 1816 */     switch (R3000.Util.bits_rs(ci)) {
/*      */       case 0:
/* 1818 */         interpret_mfc2(ci);
/*      */         return;
/*      */       case 2:
/* 1821 */         interpret_cfc2(ci);
/*      */         return;
/*      */       case 4:
/* 1824 */         interpret_mtc2(ci);
/*      */         return;
/*      */       case 6:
/* 1827 */         interpret_ctc2(ci);
/*      */         return;
/*      */       case 1:
/*      */       case 3:
/*      */       case 5:
/*      */       case 7:
/*      */         break;
/*      */       default:
/* 1835 */         switch (ci & 0x3F) {
/*      */           case 1:
/* 1837 */             interpret_rtps(ci);
/*      */             return;
/*      */           case 6:
/* 1840 */             interpret_nclip(ci);
/*      */             return;
/*      */           case 12:
/* 1843 */             interpret_op(ci);
/*      */             return;
/*      */           case 16:
/* 1846 */             interpret_dpcs(ci);
/*      */             return;
/*      */           case 17:
/* 1849 */             interpret_intpl(ci);
/*      */             return;
/*      */           case 18:
/* 1852 */             interpret_mvmva(ci);
/*      */             return;
/*      */           case 19:
/* 1855 */             interpret_ncds(ci);
/*      */             return;
/*      */           case 20:
/* 1858 */             interpret_cdp(ci);
/*      */             return;
/*      */           case 22:
/* 1861 */             interpret_ncdt(ci);
/*      */             return;
/*      */           case 27:
/* 1864 */             interpret_nccs(ci);
/*      */             return;
/*      */           case 28:
/* 1867 */             interpret_cc(ci);
/*      */             return;
/*      */           case 30:
/* 1870 */             interpret_ncs(ci);
/*      */             return;
/*      */           case 32:
/* 1873 */             interpret_nct(ci);
/*      */             return;
/*      */           case 40:
/* 1876 */             interpret_sqr(ci);
/*      */             return;
/*      */           case 41:
/* 1879 */             interpret_dcpl(ci);
/*      */             return;
/*      */           case 42:
/* 1882 */             interpret_dpct(ci);
/*      */             return;
/*      */           case 45:
/* 1885 */             interpret_avsz3(ci);
/*      */             return;
/*      */           case 46:
/* 1888 */             interpret_avsz4(ci);
/*      */             return;
/*      */           case 48:
/* 1891 */             interpret_rtpt(ci);
/*      */             return;
/*      */           case 61:
/* 1894 */             interpret_gpf(ci);
/*      */             return;
/*      */           case 62:
/* 1897 */             interpret_gpl(ci);
/*      */             return;
/*      */           case 63:
/* 1900 */             interpret_ncct(ci); return;
/*      */         } 
/*      */         break;
/*      */     } 
/* 1904 */     ((SCP)CoreComponentConnections.SCP.resolve()).signalReservedInstructionException();
/*      */   }
/*      */   
/*      */   public static void interpret_lwc2(int ci) {
/* 1908 */     int base = R3000.Util.bits_rs(ci);
/* 1909 */     int rt = R3000.Util.bits_rt(ci);
/* 1910 */     int offset = ci << 16 >> 16;
/* 1911 */     int addr = r3000regs[base] + offset;
/* 1912 */     addressSpace.tagAddressAccessRead32(r3000.getPC(), addr);
/* 1913 */     writeRegister(rt, addressSpace.read32(addr));
/*      */   }
/*      */   
/*      */   public static void interpret_swc2(int ci) {
/* 1917 */     int base = R3000.Util.bits_rs(ci);
/* 1918 */     int rt = R3000.Util.bits_rt(ci);
/* 1919 */     int offset = ci << 16 >> 16;
/* 1920 */     int addr = r3000regs[base] + offset;
/* 1921 */     addressSpace.tagAddressAccessWrite(r3000.getPC(), addr);
/* 1922 */     addressSpace.write32(addr, readRegister(rt));
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_rtpt(int ci) {
/* 1927 */     reg_flag = 0;
/*      */     
/* 1929 */     reg_szx = reg_sz2;
/*      */     
/* 1931 */     long vx = reg_v0.x;
/* 1932 */     long vy = reg_v0.y;
/* 1933 */     long vz = reg_v0.z;
/*      */     
/* 1935 */     long ssx = reg_rot.m11 * vx + reg_rot.m12 * vy + reg_rot.m13 * vz + (reg_trx << 12);
/* 1936 */     long ssy = reg_rot.m21 * vx + reg_rot.m22 * vy + reg_rot.m23 * vz + (reg_try << 12);
/* 1937 */     long ssz = reg_rot.m31 * vx + reg_rot.m32 * vy + reg_rot.m33 * vz + (reg_trz << 12);
/*      */     
/* 1939 */     reg_mac1 = A1(ssx);
/* 1940 */     reg_mac2 = A2(ssy);
/* 1941 */     reg_mac3 = A3(ssz);
/*      */     
/* 1943 */     reg_ir1 = LiB1_0(reg_mac1);
/* 1944 */     reg_ir2 = LiB2_0(reg_mac2);
/*      */     
/* 1946 */     reg_sz0 = LiD(reg_mac3);
/*      */     
/* 1948 */     if (reg_sz0 != 0) {
/* 1949 */       long hsz = (reg_h & 0xFFFF) << 16;
/* 1950 */       hsz /= reg_sz0;
/* 1951 */       hsz = LiE((int)hsz);
/*      */       
/* 1953 */       reg_sx0 = LiG1(LiF(reg_ofx + reg_ir1 * hsz));
/*      */       
/* 1955 */       reg_sy0 = LiG2(LiF(reg_ofy + reg_ir2 * hsz));
/*      */       
/* 1957 */       reg_mac0 = LiF(reg_dqb + (reg_dqa * hsz >> 16));
/*      */     } else {
/* 1959 */       LiE(2147483647);
/* 1960 */       reg_sx0 = LiG1(LiF(reg_ofx + SIGNED_BIG(reg_ir1)));
/* 1961 */       reg_sy0 = LiG2(LiF(reg_ofy + SIGNED_BIG(reg_ir2)));
/* 1962 */       reg_mac0 = LiF(reg_dqb + SIGNED_BIG(reg_dqa));
/*      */     } 
/*      */ 
/*      */     
/* 1966 */     reg_ir0 = LiH(reg_mac0);
/*      */ 
/*      */ 
/*      */     
/* 1970 */     vx = reg_v1.x;
/* 1971 */     vy = reg_v1.y;
/* 1972 */     vz = reg_v1.z;
/*      */     
/* 1974 */     ssx = reg_rot.m11 * vx + reg_rot.m12 * vy + reg_rot.m13 * vz + (reg_trx << 12);
/* 1975 */     ssy = reg_rot.m21 * vx + reg_rot.m22 * vy + reg_rot.m23 * vz + (reg_try << 12);
/* 1976 */     ssz = reg_rot.m31 * vx + reg_rot.m32 * vy + reg_rot.m33 * vz + (reg_trz << 12);
/*      */     
/* 1978 */     reg_mac1 = A1(ssx);
/* 1979 */     reg_mac2 = A2(ssy);
/* 1980 */     reg_mac3 = A3(ssz);
/*      */     
/* 1982 */     reg_ir1 = LiB1_0(reg_mac1);
/* 1983 */     reg_ir2 = LiB2_0(reg_mac2);
/*      */     
/* 1985 */     reg_sz1 = LiD(reg_mac3);
/*      */     
/* 1987 */     if (reg_sz1 != 0) {
/* 1988 */       long hsz = (reg_h & 0xFFFF) << 16;
/* 1989 */       hsz /= reg_sz1;
/* 1990 */       hsz = LiE((int)hsz);
/*      */       
/* 1992 */       reg_sx1 = LiG1(LiF(reg_ofx + reg_ir1 * hsz));
/*      */       
/* 1994 */       reg_sy1 = LiG2(LiF(reg_ofy + reg_ir2 * hsz));
/*      */       
/* 1996 */       reg_mac0 = LiF(reg_dqb + (reg_dqa * hsz >> 16));
/*      */     } else {
/* 1998 */       LiE(2147483647);
/* 1999 */       reg_sx1 = LiG1(LiF(reg_ofx + SIGNED_BIG(reg_ir1)));
/* 2000 */       reg_sy1 = LiG2(LiF(reg_ofy + SIGNED_BIG(reg_ir2)));
/* 2001 */       reg_mac0 = LiF(reg_dqb + SIGNED_BIG(reg_dqa));
/*      */     } 
/*      */ 
/*      */     
/* 2005 */     reg_ir0 = LiH(reg_mac0);
/*      */ 
/*      */ 
/*      */     
/* 2009 */     vx = reg_v2.x;
/* 2010 */     vy = reg_v2.y;
/* 2011 */     vz = reg_v2.z;
/*      */     
/* 2013 */     ssx = reg_rot.m11 * vx + reg_rot.m12 * vy + reg_rot.m13 * vz + (reg_trx << 12);
/* 2014 */     ssy = reg_rot.m21 * vx + reg_rot.m22 * vy + reg_rot.m23 * vz + (reg_try << 12);
/* 2015 */     ssz = reg_rot.m31 * vx + reg_rot.m32 * vy + reg_rot.m33 * vz + (reg_trz << 12);
/*      */     
/* 2017 */     reg_mac1 = A1(ssx);
/* 2018 */     reg_mac2 = A2(ssy);
/* 2019 */     reg_mac3 = A3(ssz);
/*      */     
/* 2021 */     reg_ir1 = LiB1_0(reg_mac1);
/* 2022 */     reg_ir2 = LiB2_0(reg_mac2);
/* 2023 */     reg_ir3 = LiB3_0(reg_mac3);
/*      */     
/* 2025 */     reg_sz2 = LiD(reg_mac3);
/*      */     
/* 2027 */     if (reg_sz2 != 0) {
/* 2028 */       long hsz = (reg_h & 0xFFFF) << 16;
/* 2029 */       hsz /= reg_sz2;
/* 2030 */       hsz = LiE((int)hsz);
/*      */       
/* 2032 */       reg_sx2 = LiG1(LiF(reg_ofx + reg_ir1 * hsz));
/*      */       
/* 2034 */       reg_sy2 = LiG2(LiF(reg_ofy + reg_ir2 * hsz));
/*      */       
/* 2036 */       reg_mac0 = LiF(reg_dqb + (reg_dqa * hsz >> 16));
/*      */     } else {
/* 2038 */       LiE(2147483647);
/* 2039 */       reg_sx2 = LiG1(LiF(reg_ofx + SIGNED_BIG(reg_ir1)));
/* 2040 */       reg_sy2 = LiG2(LiF(reg_ofy + SIGNED_BIG(reg_ir2)));
/* 2041 */       reg_mac0 = LiF(reg_dqb + SIGNED_BIG(reg_dqa));
/*      */     } 
/*      */ 
/*      */     
/* 2045 */     reg_ir0 = LiH(reg_mac0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_rtps(int ci) {
/* 2050 */     reg_flag = 0;
/*      */     
/* 2052 */     long vx = reg_v0.x;
/* 2053 */     long vy = reg_v0.y;
/* 2054 */     long vz = reg_v0.z;
/*      */     
/* 2056 */     long ssx = reg_rot.m11 * vx + reg_rot.m12 * vy + reg_rot.m13 * vz + (reg_trx << 12);
/* 2057 */     long ssy = reg_rot.m21 * vx + reg_rot.m22 * vy + reg_rot.m23 * vz + (reg_try << 12);
/* 2058 */     long ssz = reg_rot.m31 * vx + reg_rot.m32 * vy + reg_rot.m33 * vz + (reg_trz << 12);
/*      */     
/* 2060 */     reg_mac1 = A1(ssx);
/* 2061 */     reg_mac2 = A2(ssy);
/* 2062 */     reg_mac3 = A3(ssz);
/*      */     
/* 2064 */     reg_ir1 = LiB1_0(reg_mac1);
/* 2065 */     reg_ir2 = LiB2_0(reg_mac2);
/* 2066 */     reg_ir3 = LiB3_0(reg_mac3);
/*      */     
/* 2068 */     reg_szx = reg_sz0;
/* 2069 */     reg_sz0 = reg_sz1;
/* 2070 */     reg_sz1 = reg_sz2;
/*      */     
/* 2072 */     reg_sz2 = LiD(reg_mac3);
/*      */     
/* 2074 */     reg_sx0 = reg_sx1;
/* 2075 */     reg_sy0 = reg_sy1;
/* 2076 */     reg_sx1 = reg_sx2;
/* 2077 */     reg_sy1 = reg_sy2;
/*      */     
/* 2079 */     if (reg_sz2 != 0) {
/* 2080 */       long hsz = (reg_h & 0xFFFF) << 16;
/* 2081 */       hsz /= reg_sz2;
/* 2082 */       hsz = LiE((int)hsz);
/*      */       
/* 2084 */       reg_sx2 = LiG1(LiF(reg_ofx + reg_ir1 * hsz));
/*      */       
/* 2086 */       reg_sy2 = LiG2(LiF(reg_ofy + reg_ir2 * hsz));
/*      */       
/* 2088 */       reg_mac0 = LiF(reg_dqb + (reg_dqa * hsz >> 16));
/*      */     } else {
/* 2090 */       LiE(2147483647);
/* 2091 */       reg_sx2 = LiG1(LiF(reg_ofx + SIGNED_BIG(reg_ir1)));
/* 2092 */       reg_sy2 = LiG2(LiF(reg_ofy + SIGNED_BIG(reg_ir2)));
/* 2093 */       reg_mac0 = LiF(reg_dqb + SIGNED_BIG(reg_dqa));
/*      */     } 
/*      */ 
/*      */     
/* 2097 */     reg_ir0 = LiH(reg_mac0);
/*      */   }
/*      */   
/*      */   public static long SIGNED_BIG(int src) {
/* 2101 */     if (src == 0)
/* 2102 */       return 0L; 
/* 2103 */     if (src > 0)
/* 2104 */       return 4503599627370496L; 
/* 2105 */     return -4503599627370496L;
/*      */   }
/*      */   
/*      */   public static void interpret_mvmva(int ci) {
/*      */     long vz, vy, vx;
/*      */     Matrix matrix;
/* 2111 */     reg_flag = 0;
/*      */ 
/*      */     
/* 2114 */     switch (ci & 0x60000) {
/*      */       case 131072:
/* 2116 */         matrix = reg_ls;
/*      */         break;
/*      */       case 262144:
/* 2119 */         matrix = reg_lc;
/*      */         break;
/*      */       default:
/* 2122 */         matrix = reg_rot;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2129 */     switch (ci & 0x18000) {
/*      */       
/*      */       case 98304:
/* 2132 */         vx = reg_ir1;
/* 2133 */         vy = reg_ir2;
/* 2134 */         vz = reg_ir3;
/*      */         break;
/*      */       
/*      */       case 65536:
/* 2138 */         vx = reg_v2.x;
/* 2139 */         vy = reg_v2.y;
/* 2140 */         vz = reg_v2.z;
/*      */         break;
/*      */       case 32768:
/* 2143 */         vx = reg_v1.x;
/* 2144 */         vy = reg_v1.y;
/* 2145 */         vz = reg_v1.z;
/*      */         break;
/*      */       default:
/* 2148 */         vx = reg_v0.x;
/* 2149 */         vy = reg_v0.y;
/* 2150 */         vz = reg_v0.z;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2156 */     long ssx = matrix.m11 * vx + matrix.m12 * vy + matrix.m13 * vz;
/* 2157 */     long ssy = matrix.m21 * vx + matrix.m22 * vy + matrix.m23 * vz;
/* 2158 */     long ssz = matrix.m31 * vx + matrix.m32 * vy + matrix.m33 * vz;
/*      */     
/* 2160 */     if (0 != (ci & 0x80000)) {
/* 2161 */       ssx >>= 12;
/* 2162 */       ssy >>= 12;
/* 2163 */       ssz >>= 12;
/*      */     } 
/*      */ 
/*      */     
/* 2167 */     switch (ci & 0x6000) {
/*      */       case 0:
/* 2169 */         ssx += reg_trx;
/* 2170 */         ssy += reg_try;
/* 2171 */         ssz += reg_trz;
/*      */         break;
/*      */       case 8192:
/* 2174 */         ssx += reg_rbk;
/* 2175 */         ssy += reg_gbk;
/* 2176 */         ssz += reg_bbk;
/*      */         break;
/*      */       case 16384:
/* 2179 */         ssx += reg_rfc;
/* 2180 */         ssy += reg_gfc;
/* 2181 */         ssz += reg_bfc;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2187 */     reg_mac1 = A1(ssx << 12);
/* 2188 */     reg_mac2 = A2(ssy << 12);
/* 2189 */     reg_mac3 = A3(ssz << 12);
/*      */     
/* 2191 */     if (0 != (ci & 0x400)) {
/* 2192 */       reg_ir1 = LiB1_1(reg_mac1);
/* 2193 */       reg_ir2 = LiB2_1(reg_mac2);
/* 2194 */       reg_ir3 = LiB3_1(reg_mac3);
/*      */     } else {
/* 2196 */       reg_ir1 = LiB1_0(reg_mac1);
/* 2197 */       reg_ir2 = LiB2_0(reg_mac2);
/* 2198 */       reg_ir3 = LiB3_0(reg_mac3);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static int LiB1_0(int src) {
/* 2204 */     if (src >= 32768) {
/* 2205 */       reg_flag |= 0x81000000;
/* 2206 */       return 32767;
/* 2207 */     }  if (src < -32768) {
/* 2208 */       reg_flag |= 0x81000000;
/* 2209 */       return -32768;
/*      */     } 
/* 2211 */     return src;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int LiB1_1(int src) {
/* 2217 */     if (src >= 32768) {
/* 2218 */       reg_flag |= 0x81000000;
/* 2219 */       return 32767;
/* 2220 */     }  if (src < 0) {
/* 2221 */       reg_flag |= 0x81000000;
/* 2222 */       return 0;
/*      */     } 
/* 2224 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiB2_0(int src) {
/* 2228 */     if (src >= 32768) {
/* 2229 */       reg_flag |= 0x80800000;
/* 2230 */       return 32767;
/* 2231 */     }  if (src < -32768) {
/* 2232 */       reg_flag |= 0x80800000;
/* 2233 */       return -32768;
/*      */     } 
/* 2235 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiB2_1(int src) {
/* 2239 */     if (src >= 32768) {
/* 2240 */       reg_flag |= 0x80800000;
/* 2241 */       return 32767;
/* 2242 */     }  if (src < 0) {
/* 2243 */       reg_flag |= 0x80800000;
/* 2244 */       return 0;
/*      */     } 
/* 2246 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiB3_0(int src) {
/* 2250 */     if (src >= 32768) {
/* 2251 */       reg_flag |= 0x80400000;
/* 2252 */       return 32767;
/* 2253 */     }  if (src < -32768) {
/* 2254 */       reg_flag |= 0x80400000;
/* 2255 */       return -32768;
/*      */     } 
/* 2257 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiB3_1(int src) {
/* 2261 */     if (src >= 32768) {
/* 2262 */       reg_flag |= 0x80400000;
/* 2263 */       return 32767;
/* 2264 */     }  if (src < 0) {
/* 2265 */       reg_flag |= 0x80400000;
/* 2266 */       return 0;
/*      */     } 
/* 2268 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiC1(int src) {
/* 2272 */     if (src < 0) {
/* 2273 */       reg_flag |= 0x200000;
/* 2274 */       return 0;
/* 2275 */     }  if (src > 255) {
/* 2276 */       reg_flag |= 0x200000;
/* 2277 */       return 255;
/*      */     } 
/* 2279 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiC2(int src) {
/* 2283 */     if (src < 0) {
/* 2284 */       reg_flag |= 0x100000;
/* 2285 */       return 0;
/* 2286 */     }  if (src > 255) {
/* 2287 */       reg_flag |= 0x100000;
/* 2288 */       return 255;
/*      */     } 
/* 2290 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiC3(int src) {
/* 2294 */     if (src < 0) {
/* 2295 */       reg_flag |= 0x80000;
/* 2296 */       return 0;
/* 2297 */     }  if (src > 255) {
/* 2298 */       reg_flag |= 0x80000;
/* 2299 */       return 255;
/*      */     } 
/* 2301 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiD(int src) {
/* 2305 */     if (src < 0) {
/* 2306 */       reg_flag |= 0x80040000;
/* 2307 */       return 0;
/* 2308 */     }  if (src >= 32768) {
/* 2309 */       reg_flag |= 0x80040000;
/* 2310 */       return 32767;
/*      */     } 
/* 2312 */     return src;
/*      */   }
/*      */   
/*      */   private static int LiE(int src) {
/* 2316 */     if (src >= 131072) {
/* 2317 */       reg_flag |= 0x80020000;
/*      */     }
/* 2319 */     return src;
/*      */   }
/*      */   
/*      */   private static int LiF(long src) {
/* 2323 */     if (src >= 140737488355328L) {
/* 2324 */       reg_flag |= 0x80010000;
/* 2325 */       return Integer.MAX_VALUE;
/* 2326 */     }  if (src <= -140737488355328L) {
/* 2327 */       reg_flag |= 0x80008000;
/* 2328 */       return Integer.MIN_VALUE;
/*      */     } 
/* 2330 */     return (int)(src >> 16);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int LiG1(int src) {
/* 2335 */     if (src >= 2048) {
/* 2336 */       reg_flag |= 0x80004000;
/* 2337 */       return 2047;
/* 2338 */     }  if (src < -2048) {
/* 2339 */       reg_flag |= 0x80004000;
/* 2340 */       return -2048;
/*      */     } 
/* 2342 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiG2(int src) {
/* 2346 */     if (src >= 2048) {
/* 2347 */       reg_flag |= 0x80002000;
/* 2348 */       return 2047;
/* 2349 */     }  if (src < -2048) {
/* 2350 */       reg_flag |= 0x80002000;
/* 2351 */       return -2048;
/*      */     } 
/* 2353 */     return src;
/*      */   }
/*      */   
/*      */   public static int LiH(int src) {
/* 2357 */     if (src >= 4096) {
/* 2358 */       reg_flag |= 0x1000;
/* 2359 */       return 4095;
/* 2360 */     }  if (src < 0) {
/* 2361 */       reg_flag |= 0x1000;
/* 2362 */       return 0;
/*      */     } 
/* 2364 */     return src;
/*      */   }
/*      */   
/*      */   private static int A1(long val) {
/* 2368 */     if (val >= 17592186044416L) {
/* 2369 */       reg_flag |= 0xC0000000;
/* 2370 */     } else if (val <= -17592186044416L) {
/* 2371 */       reg_flag |= 0x88000000;
/*      */     } 
/* 2373 */     return (int)(val >> 12);
/*      */   }
/*      */   
/*      */   private static int A2(long val) {
/* 2377 */     if (val >= 17592186044416L) {
/* 2378 */       reg_flag |= 0xA0000000;
/* 2379 */     } else if (val <= -17592186044416L) {
/* 2380 */       reg_flag |= 0x84000000;
/*      */     } 
/* 2382 */     return (int)(val >> 12);
/*      */   }
/*      */   
/*      */   private static int A3(long val) {
/* 2386 */     if (val >= 17592186044416L) {
/* 2387 */       reg_flag |= 0x90000000;
/* 2388 */     } else if (val <= -17592186044416L) {
/* 2389 */       reg_flag |= 0x82000000;
/*      */     } 
/* 2391 */     return (int)(val >> 12);
/*      */   }
/*      */   
/*      */   public static void interpret_op(int ci) {
/* 2395 */     reg_flag = 0;
/*      */     
/* 2397 */     long a1 = reg_rot.m11;
/* 2398 */     long a2 = reg_rot.m22;
/* 2399 */     long a3 = reg_rot.m33;
/*      */     
/* 2401 */     long ss1 = a2 * reg_ir3 - a3 * reg_ir2;
/* 2402 */     long ss2 = a3 * reg_ir1 - a1 * reg_ir3;
/* 2403 */     long ss3 = a1 * reg_ir2 - a2 * reg_ir1;
/*      */     
/* 2405 */     if (0 == (ci & 0x80000)) {
/* 2406 */       ss1 <<= 12;
/* 2407 */       ss2 <<= 12;
/* 2408 */       ss3 <<= 12;
/*      */     } 
/*      */     
/* 2411 */     reg_mac1 = A1(ss1);
/* 2412 */     reg_mac2 = A2(ss2);
/* 2413 */     reg_mac3 = A3(ss3);
/* 2414 */     reg_ir1 = LiB1_0(reg_mac1);
/* 2415 */     reg_ir2 = LiB2_0(reg_mac2);
/* 2416 */     reg_ir3 = LiB3_0(reg_mac3);
/*      */   }
/*      */   
/*      */   public static void interpret_avsz3(int ci) {
/* 2420 */     reg_flag = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2428 */     reg_mac0 = reg_zsf3 * (reg_sz0 + reg_sz1 + reg_sz2) >> 12;
/* 2429 */     reg_otz = LiD(reg_mac0);
/*      */   }
/*      */   
/*      */   public static void interpret_avsz4(int ci) {
/* 2433 */     reg_flag = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2442 */     reg_mac0 = reg_zsf4 * (reg_szx + reg_sz0 + reg_sz1 + reg_sz2) >> 12;
/* 2443 */     reg_otz = LiD(reg_mac0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2467 */   public static void interpret_nclip(int ci) { reg_mac0 = reg_sx0 * reg_sy1 + reg_sx1 * reg_sy2 + reg_sx2 * reg_sy0 - reg_sx0 * reg_sy2 - reg_sx1 * reg_sy0 - reg_sx2 * reg_sy1; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void interpret_ncct(int ci) {
/* 2473 */     reg_flag = 0;
/*      */     
/* 2475 */     int chi = reg_rgb & 0xFF000000;
/* 2476 */     int r = (reg_rgb & 0xFF) << 4;
/* 2477 */     int g = (reg_rgb & 0xFF00) >> 4;
/* 2478 */     int b = (reg_rgb & 0xFF0000) >> 12;
/*      */     
/* 2480 */     long m11 = reg_ls.m11;
/* 2481 */     long m12 = reg_ls.m12;
/* 2482 */     long m13 = reg_ls.m13;
/* 2483 */     long m21 = reg_ls.m21;
/* 2484 */     long m22 = reg_ls.m22;
/* 2485 */     long m23 = reg_ls.m23;
/* 2486 */     long m31 = reg_ls.m31;
/* 2487 */     long m32 = reg_ls.m32;
/* 2488 */     long m33 = reg_ls.m33;
/*      */     
/* 2490 */     long ss1 = m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z;
/* 2491 */     long ss2 = m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z;
/* 2492 */     long ss3 = m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z;
/*      */     
/* 2494 */     int mac1 = A1(ss1);
/* 2495 */     int mac2 = A2(ss2);
/* 2496 */     int mac3 = A3(ss3);
/*      */     
/* 2498 */     int ir1 = LiB1_1(mac1);
/* 2499 */     int ir2 = LiB2_1(mac2);
/* 2500 */     int ir3 = LiB3_1(mac3);
/*      */     
/* 2502 */     long c11 = reg_lc.m11;
/* 2503 */     long c12 = reg_lc.m12;
/* 2504 */     long c13 = reg_lc.m13;
/* 2505 */     long c21 = reg_lc.m21;
/* 2506 */     long c22 = reg_lc.m22;
/* 2507 */     long c23 = reg_lc.m23;
/* 2508 */     long c31 = reg_lc.m31;
/* 2509 */     long c32 = reg_lc.m32;
/* 2510 */     long c33 = reg_lc.m33;
/*      */     
/* 2512 */     long bkr = reg_rbk;
/* 2513 */     long bkg = reg_gbk;
/* 2514 */     long bkb = reg_bbk;
/*      */     
/* 2516 */     ss1 = c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12);
/* 2517 */     ss2 = c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12);
/* 2518 */     ss3 = c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12);
/*      */     
/* 2520 */     mac1 = A1(ss1);
/* 2521 */     mac2 = A2(ss2);
/* 2522 */     mac3 = A3(ss3);
/*      */     
/* 2524 */     ir1 = LiB1_1(mac1);
/* 2525 */     ir2 = LiB2_1(mac2);
/* 2526 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2528 */     mac1 = A1((r * ir1));
/* 2529 */     mac2 = A2((g * ir2));
/* 2530 */     mac3 = A3((b * ir3));
/*      */     
/* 2532 */     int rr = LiC1(mac1 >> 4);
/* 2533 */     int gg = LiC2(mac2 >> 4);
/* 2534 */     int bb = LiC3(mac3 >> 4);
/* 2535 */     reg_rgb0 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */     
/* 2538 */     ss1 = m11 * reg_v1.x + m12 * reg_v1.y + m13 * reg_v1.z;
/* 2539 */     ss2 = m21 * reg_v1.x + m22 * reg_v1.y + m23 * reg_v1.z;
/* 2540 */     ss3 = m31 * reg_v1.x + m32 * reg_v1.y + m33 * reg_v1.z;
/*      */     
/* 2542 */     mac1 = A1(ss1);
/* 2543 */     mac2 = A2(ss2);
/* 2544 */     mac3 = A3(ss3);
/*      */     
/* 2546 */     ir1 = LiB1_1(mac1);
/* 2547 */     ir2 = LiB2_1(mac2);
/* 2548 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2550 */     ss1 = c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12);
/* 2551 */     ss2 = c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12);
/* 2552 */     ss3 = c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12);
/*      */     
/* 2554 */     mac1 = A1(ss1);
/* 2555 */     mac2 = A2(ss2);
/* 2556 */     mac3 = A3(ss3);
/*      */     
/* 2558 */     ir1 = LiB1_1(mac1);
/* 2559 */     ir2 = LiB2_1(mac2);
/* 2560 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2562 */     mac1 = A1((r * ir1));
/* 2563 */     mac2 = A2((g * ir2));
/* 2564 */     mac3 = A3((b * ir3));
/*      */ 
/*      */     
/* 2567 */     rr = LiC1(mac1 >> 4);
/* 2568 */     gg = LiC2(mac2 >> 4);
/* 2569 */     bb = LiC3(mac3 >> 4);
/* 2570 */     reg_rgb1 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */     
/* 2573 */     ss1 = m11 * reg_v2.x + m12 * reg_v2.y + m13 * reg_v2.z;
/* 2574 */     ss2 = m21 * reg_v2.x + m22 * reg_v2.y + m23 * reg_v2.z;
/* 2575 */     ss3 = m31 * reg_v2.x + m32 * reg_v2.y + m33 * reg_v2.z;
/*      */     
/* 2577 */     mac1 = A1(ss1);
/* 2578 */     mac2 = A2(ss2);
/* 2579 */     mac3 = A3(ss3);
/*      */     
/* 2581 */     ir1 = LiB1_1(mac1);
/* 2582 */     ir2 = LiB2_1(mac2);
/* 2583 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2585 */     ss1 = c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12);
/* 2586 */     ss2 = c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12);
/* 2587 */     ss3 = c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12);
/*      */     
/* 2589 */     mac1 = A1(ss1);
/* 2590 */     mac2 = A2(ss2);
/* 2591 */     mac3 = A3(ss3);
/*      */     
/* 2593 */     ir1 = LiB1_1(mac1);
/* 2594 */     ir2 = LiB2_1(mac2);
/* 2595 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2597 */     reg_mac1 = A1((r * ir1));
/* 2598 */     reg_mac2 = A2((g * ir2));
/* 2599 */     reg_mac3 = A3((b * ir3));
/* 2600 */     reg_ir1 = LiB1_1(reg_mac1);
/* 2601 */     reg_ir2 = LiB2_1(reg_mac2);
/* 2602 */     reg_ir3 = LiB3_1(reg_mac3);
/*      */ 
/*      */     
/* 2605 */     rr = LiC1(reg_mac1 >> 4);
/* 2606 */     gg = LiC2(reg_mac2 >> 4);
/* 2607 */     bb = LiC3(reg_mac3 >> 4);
/* 2608 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */   
/*      */   public static void interpret_gpf(int ci) {
/* 2612 */     reg_flag = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2624 */     long m = reg_ir0;
/* 2625 */     if (0 != (ci & 0x80000)) {
/* 2626 */       reg_mac1 = A1(m * reg_ir1);
/* 2627 */       reg_mac2 = A2(m * reg_ir2);
/* 2628 */       reg_mac3 = A3(m * reg_ir3);
/*      */     } else {
/* 2630 */       reg_mac1 = A1(m * reg_ir1 << 12);
/* 2631 */       reg_mac2 = A2(m * reg_ir2 << 12);
/* 2632 */       reg_mac3 = A3(m * reg_ir3 << 12);
/*      */     } 
/* 2634 */     reg_ir1 = LiB1_0(reg_mac1);
/* 2635 */     reg_ir2 = LiB2_0(reg_mac2);
/* 2636 */     reg_ir3 = LiB3_0(reg_mac3);
/* 2637 */     int rr = LiC1(reg_mac1 >> 4);
/* 2638 */     int gg = LiC2(reg_mac2 >> 4);
/* 2639 */     int bb = LiC3(reg_mac3 >> 4);
/* 2640 */     reg_rgb0 = reg_rgb1;
/* 2641 */     reg_rgb1 = reg_rgb2;
/* 2642 */     reg_rgb2 = reg_rgb & 0xFF000000 | rr | gg << 8 | bb << 16;
/*      */   }
/*      */ 
/*      */   
/* 2646 */   public static void interpret_dcpl(int ci) { throw new IllegalStateException("GTE UNIMPLEMENTED: DCPL"); }
/*      */ 
/*      */   
/*      */   public static void interpret_dpcs(int ci) {
/* 2650 */     reg_flag = 0;
/* 2651 */     int chi = reg_rgb & 0xFF000000;
/* 2652 */     int r = (reg_rgb & 0xFF) << 4;
/* 2653 */     int g = (reg_rgb & 0xFF00) >> 4;
/* 2654 */     int b = (reg_rgb & 0xFF0000) >> 12;
/*      */ 
/*      */     
/* 2657 */     reg_mac1 = A1(((r << 12) + reg_ir0 * LiB1_0(reg_rfc - r)));
/* 2658 */     reg_mac2 = A2(((g << 12) + reg_ir0 * LiB1_0(reg_gfc - g)));
/* 2659 */     reg_mac3 = A3(((b << 12) + reg_ir0 * LiB1_0(reg_bfc - b)));
/*      */     
/* 2661 */     reg_ir1 = LiB1_0(reg_mac1);
/* 2662 */     reg_ir2 = LiB2_0(reg_mac2);
/* 2663 */     reg_ir3 = LiB3_0(reg_mac3);
/*      */     
/* 2665 */     int rr = LiC1(reg_mac1 >> 4);
/* 2666 */     int gg = LiC2(reg_mac2 >> 4);
/* 2667 */     int bb = LiC3(reg_mac3 >> 4);
/* 2668 */     reg_rgb0 = reg_rgb1;
/* 2669 */     reg_rgb1 = reg_rgb2;
/* 2670 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */   
/*      */   public static void interpret_intpl(int ci) {
/* 2674 */     reg_flag = 0;
/* 2675 */     int chi = reg_rgb & 0xFF000000;
/*      */     
/* 2677 */     long ir0 = reg_ir0;
/* 2678 */     reg_mac1 = A1((reg_ir1 << 12) + ir0 * LiB1_0(reg_rfc - reg_ir1));
/* 2679 */     reg_mac2 = A2((reg_ir2 << 12) + ir0 * LiB2_0(reg_gfc - reg_ir2));
/* 2680 */     reg_mac3 = A3((reg_ir3 << 12) + ir0 * LiB3_0(reg_bfc - reg_ir3));
/* 2681 */     reg_ir1 = LiB1_0(reg_mac1);
/* 2682 */     reg_ir2 = LiB2_0(reg_mac2);
/* 2683 */     reg_ir3 = LiB3_0(reg_mac3);
/*      */     
/* 2685 */     int rr = LiC1(reg_mac1 >> 4);
/* 2686 */     int gg = LiC2(reg_mac2 >> 4);
/* 2687 */     int bb = LiC3(reg_mac3 >> 4);
/* 2688 */     reg_rgb0 = reg_rgb1;
/* 2689 */     reg_rgb1 = reg_rgb2;
/* 2690 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */   
/*      */   public static void interpret_sqr(int ci) {
/* 2694 */     reg_flag = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2704 */     int i1 = reg_ir1 * reg_ir1;
/* 2705 */     int i2 = reg_ir2 * reg_ir2;
/* 2706 */     int i3 = reg_ir3 * reg_ir3;
/* 2707 */     if (0 != (ci & 0x80000)) {
/* 2708 */       i1 >>= 12;
/* 2709 */       i2 >>= 12;
/* 2710 */       i3 >>= 12;
/*      */     } 
/* 2712 */     reg_mac1 = i1;
/* 2713 */     reg_mac2 = i2;
/* 2714 */     reg_mac3 = i3;
/* 2715 */     reg_ir1 = LiB1_1(i1);
/* 2716 */     reg_ir2 = LiB1_1(i2);
/* 2717 */     reg_ir3 = LiB1_1(i3);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_ncs(int ci) {
/* 2722 */     reg_flag = 0;
/* 2723 */     int chi = reg_rgb & 0xFF000000;
/*      */     
/* 2725 */     long m11 = reg_ls.m11;
/* 2726 */     long m12 = reg_ls.m12;
/* 2727 */     long m13 = reg_ls.m13;
/* 2728 */     long m21 = reg_ls.m21;
/* 2729 */     long m22 = reg_ls.m22;
/* 2730 */     long m23 = reg_ls.m23;
/* 2731 */     long m31 = reg_ls.m31;
/* 2732 */     long m32 = reg_ls.m32;
/* 2733 */     long m33 = reg_ls.m33;
/*      */     
/* 2735 */     int mac1 = A1(m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z);
/* 2736 */     int mac2 = A2(m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z);
/* 2737 */     int mac3 = A3(m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z);
/*      */     
/* 2739 */     int ir1 = LiB1_1(mac1);
/* 2740 */     int ir2 = LiB2_1(mac2);
/* 2741 */     int ir3 = LiB3_1(mac3);
/*      */     
/* 2743 */     long c11 = reg_lc.m11;
/* 2744 */     long c12 = reg_lc.m12;
/* 2745 */     long c13 = reg_lc.m13;
/* 2746 */     long c21 = reg_lc.m21;
/* 2747 */     long c22 = reg_lc.m22;
/* 2748 */     long c23 = reg_lc.m23;
/* 2749 */     long c31 = reg_lc.m31;
/* 2750 */     long c32 = reg_lc.m32;
/* 2751 */     long c33 = reg_lc.m33;
/*      */     
/* 2753 */     long bkr = reg_rbk;
/* 2754 */     long bkg = reg_gbk;
/* 2755 */     long bkb = reg_bbk;
/*      */     
/* 2757 */     reg_mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 2758 */     reg_mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 2759 */     reg_mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 2761 */     reg_ir1 = LiB1_1(reg_mac1);
/* 2762 */     reg_ir2 = LiB2_1(reg_mac2);
/* 2763 */     reg_ir3 = LiB3_1(reg_mac3);
/*      */     
/* 2765 */     int rr = LiC1(reg_mac1 >> 4);
/* 2766 */     int gg = LiC2(reg_mac2 >> 4);
/* 2767 */     int bb = LiC3(reg_mac3 >> 4);
/* 2768 */     reg_rgb0 = reg_rgb1;
/* 2769 */     reg_rgb1 = reg_rgb2;
/* 2770 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_nct(int ci) {
/* 2775 */     reg_flag = 0;
/* 2776 */     int chi = reg_rgb & 0xFF000000;
/*      */     
/* 2778 */     long m11 = reg_ls.m11;
/* 2779 */     long m12 = reg_ls.m12;
/* 2780 */     long m13 = reg_ls.m13;
/* 2781 */     long m21 = reg_ls.m21;
/* 2782 */     long m22 = reg_ls.m22;
/* 2783 */     long m23 = reg_ls.m23;
/* 2784 */     long m31 = reg_ls.m31;
/* 2785 */     long m32 = reg_ls.m32;
/* 2786 */     long m33 = reg_ls.m33;
/*      */     
/* 2788 */     int mac1 = A1(m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z);
/* 2789 */     int mac2 = A2(m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z);
/* 2790 */     int mac3 = A3(m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z);
/*      */     
/* 2792 */     int ir1 = LiB1_1(mac1);
/* 2793 */     int ir2 = LiB2_1(mac2);
/* 2794 */     int ir3 = LiB3_1(mac3);
/*      */     
/* 2796 */     long c11 = reg_lc.m11;
/* 2797 */     long c12 = reg_lc.m12;
/* 2798 */     long c13 = reg_lc.m13;
/* 2799 */     long c21 = reg_lc.m21;
/* 2800 */     long c22 = reg_lc.m22;
/* 2801 */     long c23 = reg_lc.m23;
/* 2802 */     long c31 = reg_lc.m31;
/* 2803 */     long c32 = reg_lc.m32;
/* 2804 */     long c33 = reg_lc.m33;
/*      */     
/* 2806 */     long bkr = reg_rbk;
/* 2807 */     long bkg = reg_gbk;
/* 2808 */     long bkb = reg_bbk;
/*      */     
/* 2810 */     mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 2811 */     mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 2812 */     mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 2814 */     int rr = LiC1(mac1 >> 4);
/* 2815 */     int gg = LiC2(mac2 >> 4);
/* 2816 */     int bb = LiC3(mac3 >> 4);
/* 2817 */     reg_rgb0 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */ 
/*      */     
/* 2821 */     mac1 = A1(m11 * reg_v1.x + m12 * reg_v1.y + m13 * reg_v1.z);
/* 2822 */     mac2 = A2(m21 * reg_v1.x + m22 * reg_v1.y + m23 * reg_v1.z);
/* 2823 */     mac3 = A3(m31 * reg_v1.x + m32 * reg_v1.y + m33 * reg_v1.z);
/*      */     
/* 2825 */     ir1 = LiB1_1(mac1);
/* 2826 */     ir2 = LiB2_1(mac2);
/* 2827 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2829 */     mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 2830 */     mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 2831 */     mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 2833 */     rr = LiC1(mac1 >> 4);
/* 2834 */     gg = LiC2(mac2 >> 4);
/* 2835 */     bb = LiC3(mac3 >> 4);
/* 2836 */     reg_rgb1 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */ 
/*      */     
/* 2840 */     mac1 = A1(m11 * reg_v2.x + m12 * reg_v2.y + m13 * reg_v2.z);
/* 2841 */     mac2 = A2(m21 * reg_v2.x + m22 * reg_v2.y + m23 * reg_v2.z);
/* 2842 */     mac3 = A3(m31 * reg_v2.x + m32 * reg_v2.y + m33 * reg_v2.z);
/*      */     
/* 2844 */     ir1 = LiB1_1(mac1);
/* 2845 */     ir2 = LiB2_1(mac2);
/* 2846 */     ir3 = LiB3_1(mac3);
/*      */     
/* 2848 */     reg_mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 2849 */     reg_mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 2850 */     reg_mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 2852 */     reg_ir1 = LiB1_1(reg_mac1);
/* 2853 */     reg_ir2 = LiB2_1(reg_mac2);
/* 2854 */     reg_ir3 = LiB3_1(reg_mac3);
/*      */     
/* 2856 */     rr = LiC1(reg_mac1 >> 4);
/* 2857 */     gg = LiC2(reg_mac2 >> 4);
/* 2858 */     bb = LiC3(reg_mac3 >> 4);
/* 2859 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */   
/*      */   public static void interpret_ncds(int ci) {
/* 2863 */     reg_flag = 0;
/*      */     
/* 2865 */     int chi = reg_rgb & 0xFF000000;
/* 2866 */     int r = (reg_rgb & 0xFF) << 4;
/* 2867 */     int g = (reg_rgb & 0xFF00) >> 4;
/* 2868 */     int b = (reg_rgb & 0xFF0000) >> 12;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2877 */     long m11 = reg_ls.m11;
/* 2878 */     long m12 = reg_ls.m12;
/* 2879 */     long m13 = reg_ls.m13;
/* 2880 */     long m21 = reg_ls.m21;
/* 2881 */     long m22 = reg_ls.m22;
/* 2882 */     long m23 = reg_ls.m23;
/* 2883 */     long m31 = reg_ls.m31;
/* 2884 */     long m32 = reg_ls.m32;
/* 2885 */     long m33 = reg_ls.m33;
/*      */     
/* 2887 */     int mac1 = A1(m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z);
/* 2888 */     int mac2 = A2(m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z);
/* 2889 */     int mac3 = A3(m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z);
/* 2890 */     int ir1 = LiB1_1(mac1);
/* 2891 */     int ir2 = LiB2_1(mac2);
/* 2892 */     int ir3 = LiB3_1(mac3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2901 */     long c11 = reg_lc.m11;
/* 2902 */     long c12 = reg_lc.m12;
/* 2903 */     long c13 = reg_lc.m13;
/* 2904 */     long c21 = reg_lc.m21;
/* 2905 */     long c22 = reg_lc.m22;
/* 2906 */     long c23 = reg_lc.m23;
/* 2907 */     long c31 = reg_lc.m31;
/* 2908 */     long c32 = reg_lc.m32;
/* 2909 */     long c33 = reg_lc.m33;
/*      */     
/* 2911 */     long bkr = reg_rbk;
/* 2912 */     long bkg = reg_gbk;
/* 2913 */     long bkb = reg_bbk;
/*      */     
/* 2915 */     mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 2916 */     mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 2917 */     mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 2919 */     ir1 = LiB1_1(mac1);
/* 2920 */     ir2 = LiB2_1(mac2);
/* 2921 */     ir3 = LiB3_1(mac3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2929 */     long ir0 = reg_ir0;
/* 2930 */     reg_mac1 = A1((r * ir1) + (ir0 * LiB1_0((reg_rfc << 12) - r * ir1) >> 12));
/* 2931 */     reg_mac2 = A2((g * ir2) + (ir0 * LiB2_0((reg_gfc << 12) - g * ir2) >> 12));
/* 2932 */     reg_mac3 = A3((b * ir3) + (ir0 * LiB3_0((reg_bfc << 12) - b * ir3) >> 12));
/*      */     
/* 2934 */     reg_ir1 = LiB1_1(reg_mac1);
/* 2935 */     reg_ir2 = LiB2_1(reg_mac2);
/* 2936 */     reg_ir3 = LiB3_1(reg_mac3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2942 */     int rr = LiC1(reg_mac1 >> 4);
/* 2943 */     int gg = LiC2(reg_mac2 >> 4);
/* 2944 */     int bb = LiC3(reg_mac3 >> 4);
/* 2945 */     reg_rgb0 = reg_rgb1;
/* 2946 */     reg_rgb1 = reg_rgb2;
/* 2947 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */   
/*      */   public static void interpret_ncdt(int ci) {
/* 2951 */     reg_flag = 0;
/*      */     
/* 2953 */     int chi = reg_rgb & 0xFF000000;
/* 2954 */     int r = (reg_rgb & 0xFF) << 4;
/* 2955 */     int g = (reg_rgb & 0xFF00) >> 4;
/* 2956 */     int b = (reg_rgb & 0xFF0000) >> 12;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2965 */     long m11 = reg_ls.m11;
/* 2966 */     long m12 = reg_ls.m12;
/* 2967 */     long m13 = reg_ls.m13;
/* 2968 */     long m21 = reg_ls.m21;
/* 2969 */     long m22 = reg_ls.m22;
/* 2970 */     long m23 = reg_ls.m23;
/* 2971 */     long m31 = reg_ls.m31;
/* 2972 */     long m32 = reg_ls.m32;
/* 2973 */     long m33 = reg_ls.m33;
/*      */     
/* 2975 */     int mac1 = A1(m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z);
/* 2976 */     int mac2 = A2(m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z);
/* 2977 */     int mac3 = A3(m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z);
/* 2978 */     int ir1 = LiB1_1(mac1);
/* 2979 */     int ir2 = LiB2_1(mac2);
/* 2980 */     int ir3 = LiB3_1(mac3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2989 */     long c11 = reg_lc.m11;
/* 2990 */     long c12 = reg_lc.m12;
/* 2991 */     long c13 = reg_lc.m13;
/* 2992 */     long c21 = reg_lc.m21;
/* 2993 */     long c22 = reg_lc.m22;
/* 2994 */     long c23 = reg_lc.m23;
/* 2995 */     long c31 = reg_lc.m31;
/* 2996 */     long c32 = reg_lc.m32;
/* 2997 */     long c33 = reg_lc.m33;
/*      */     
/* 2999 */     long bkr = reg_rbk;
/* 3000 */     long bkg = reg_gbk;
/* 3001 */     long bkb = reg_bbk;
/*      */     
/* 3003 */     mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 3004 */     mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 3005 */     mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 3007 */     ir1 = LiB1_1(mac1);
/* 3008 */     ir2 = LiB2_1(mac2);
/* 3009 */     ir3 = LiB3_1(mac3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3017 */     long ir0 = reg_ir0;
/* 3018 */     reg_mac1 = A1((r * ir1) + (ir0 * LiB1_0((reg_rfc << 12) - r * ir1) >> 12));
/* 3019 */     reg_mac2 = A2((g * ir2) + (ir0 * LiB2_0((reg_gfc << 12) - g * ir2) >> 12));
/* 3020 */     reg_mac3 = A3((b * ir3) + (ir0 * LiB3_0((reg_bfc << 12) - b * ir3) >> 12));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3026 */     int rr = LiC1(reg_mac1 >> 4);
/* 3027 */     int gg = LiC2(reg_mac2 >> 4);
/* 3028 */     int bb = LiC3(reg_mac3 >> 4);
/* 3029 */     reg_rgb0 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */ 
/*      */     
/* 3033 */     mac1 = A1(m11 * reg_v1.x + m12 * reg_v1.y + m13 * reg_v1.z);
/* 3034 */     mac2 = A2(m21 * reg_v1.x + m22 * reg_v1.y + m23 * reg_v1.z);
/* 3035 */     mac3 = A3(m31 * reg_v1.x + m32 * reg_v1.y + m33 * reg_v1.z);
/* 3036 */     ir1 = LiB1_1(mac1);
/* 3037 */     ir2 = LiB2_1(mac2);
/* 3038 */     ir3 = LiB3_1(mac3);
/*      */     
/* 3040 */     mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 3041 */     mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 3042 */     mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 3044 */     ir1 = LiB1_1(mac1);
/* 3045 */     ir2 = LiB2_1(mac2);
/* 3046 */     ir3 = LiB3_1(mac3);
/*      */     
/* 3048 */     reg_mac1 = A1((r * ir1) + (ir0 * LiB1_0((reg_rfc << 12) - r * ir1) >> 12));
/* 3049 */     reg_mac2 = A2((g * ir2) + (ir0 * LiB2_0((reg_gfc << 12) - g * ir2) >> 12));
/* 3050 */     reg_mac3 = A3((b * ir3) + (ir0 * LiB3_0((reg_bfc << 12) - b * ir3) >> 12));
/*      */     
/* 3052 */     rr = LiC1(reg_mac1 >> 4);
/* 3053 */     gg = LiC2(reg_mac2 >> 4);
/* 3054 */     bb = LiC3(reg_mac3 >> 4);
/* 3055 */     reg_rgb1 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */ 
/*      */     
/* 3059 */     mac1 = A1(m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z);
/* 3060 */     mac2 = A2(m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z);
/* 3061 */     mac3 = A3(m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z);
/* 3062 */     ir1 = LiB1_1(mac1);
/* 3063 */     ir2 = LiB2_1(mac2);
/* 3064 */     ir3 = LiB3_1(mac3);
/*      */     
/* 3066 */     mac1 = A1(c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12));
/* 3067 */     mac2 = A2(c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12));
/* 3068 */     mac3 = A3(c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12));
/*      */     
/* 3070 */     ir1 = LiB1_1(mac1);
/* 3071 */     ir2 = LiB2_1(mac2);
/* 3072 */     ir3 = LiB3_1(mac3);
/*      */     
/* 3074 */     reg_mac1 = A1((r * ir1) + (ir0 * LiB1_0((reg_rfc << 12) - r * ir1) >> 12));
/* 3075 */     reg_mac2 = A2((g * ir2) + (ir0 * LiB2_0((reg_gfc << 12) - g * ir2) >> 12));
/* 3076 */     reg_mac3 = A3((b * ir3) + (ir0 * LiB3_0((reg_bfc << 12) - b * ir3) >> 12));
/*      */     
/* 3078 */     rr = LiC1(reg_mac1 >> 4);
/* 3079 */     gg = LiC2(reg_mac2 >> 4);
/* 3080 */     bb = LiC3(reg_mac3 >> 4);
/* 3081 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */   
/*      */   public static void interpret_dpct(int ci) {
/* 3085 */     reg_flag = 0;
/*      */     
/* 3087 */     int chi = reg_rgb & 0xFF000000;
/* 3088 */     int r = (reg_rgb & 0xFF) << 4;
/* 3089 */     int g = (reg_rgb & 0xFF00) >> 4;
/* 3090 */     int b = (reg_rgb & 0xFF0000) >> 12;
/*      */ 
/*      */     
/* 3093 */     reg_mac1 = A1(((r << 12) + reg_ir0 * LiB1_0(reg_rfc - r)));
/* 3094 */     reg_mac2 = A2(((g << 12) + reg_ir0 * LiB1_0(reg_gfc - g)));
/* 3095 */     reg_mac3 = A3(((b << 12) + reg_ir0 * LiB1_0(reg_bfc - b)));
/*      */     
/* 3097 */     int rr = LiC1(reg_mac1 >> 4);
/* 3098 */     int gg = LiC2(reg_mac2 >> 4);
/* 3099 */     int bb = LiC3(reg_mac3 >> 4);
/* 3100 */     reg_rgb0 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3105 */     reg_mac1 = A1(((r << 12) + reg_ir0 * LiB1_0(reg_rfc - r)));
/* 3106 */     reg_mac2 = A2(((g << 12) + reg_ir0 * LiB1_0(reg_gfc - g)));
/* 3107 */     reg_mac3 = A3(((b << 12) + reg_ir0 * LiB1_0(reg_bfc - b)));
/*      */     
/* 3109 */     rr = LiC1(reg_mac1 >> 4);
/* 3110 */     gg = LiC2(reg_mac2 >> 4);
/* 3111 */     bb = LiC3(reg_mac3 >> 4);
/*      */     
/* 3113 */     reg_rgb1 = rr | gg << 8 | bb << 16 | chi;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3118 */     reg_mac1 = A1(((r << 12) + reg_ir0 * LiB1_0(reg_rfc - r)));
/* 3119 */     reg_mac2 = A2(((g << 12) + reg_ir0 * LiB1_0(reg_gfc - g)));
/* 3120 */     reg_mac3 = A3(((b << 12) + reg_ir0 * LiB1_0(reg_bfc - b)));
/*      */     
/* 3122 */     reg_ir1 = LiB1_0(reg_mac1);
/* 3123 */     reg_ir2 = LiB2_0(reg_mac2);
/* 3124 */     reg_ir3 = LiB3_0(reg_mac3);
/*      */     
/* 3126 */     rr = LiC1(reg_mac1 >> 4);
/* 3127 */     gg = LiC2(reg_mac2 >> 4);
/* 3128 */     bb = LiC3(reg_mac3 >> 4);
/* 3129 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_nccs(int ci) {
/* 3134 */     reg_flag = 0;
/*      */     
/* 3136 */     int chi = reg_rgb & 0xFF000000;
/* 3137 */     int r = (reg_rgb & 0xFF) << 4;
/* 3138 */     int g = (reg_rgb & 0xFF00) >> 4;
/* 3139 */     int b = (reg_rgb & 0xFF0000) >> 12;
/*      */     
/* 3141 */     long m11 = reg_ls.m11;
/* 3142 */     long m12 = reg_ls.m12;
/* 3143 */     long m13 = reg_ls.m13;
/* 3144 */     long m21 = reg_ls.m21;
/* 3145 */     long m22 = reg_ls.m22;
/* 3146 */     long m23 = reg_ls.m23;
/* 3147 */     long m31 = reg_ls.m31;
/* 3148 */     long m32 = reg_ls.m32;
/* 3149 */     long m33 = reg_ls.m33;
/*      */     
/* 3151 */     long ss1 = m11 * reg_v0.x + m12 * reg_v0.y + m13 * reg_v0.z;
/* 3152 */     long ss2 = m21 * reg_v0.x + m22 * reg_v0.y + m23 * reg_v0.z;
/* 3153 */     long ss3 = m31 * reg_v0.x + m32 * reg_v0.y + m33 * reg_v0.z;
/*      */     
/* 3155 */     int mac1 = A1(ss1);
/* 3156 */     int mac2 = A2(ss2);
/* 3157 */     int mac3 = A3(ss3);
/*      */     
/* 3159 */     int ir1 = LiB1_1(mac1);
/* 3160 */     int ir2 = LiB2_1(mac2);
/* 3161 */     int ir3 = LiB3_1(mac3);
/*      */     
/* 3163 */     long c11 = reg_lc.m11;
/* 3164 */     long c12 = reg_lc.m12;
/* 3165 */     long c13 = reg_lc.m13;
/* 3166 */     long c21 = reg_lc.m21;
/* 3167 */     long c22 = reg_lc.m22;
/* 3168 */     long c23 = reg_lc.m23;
/* 3169 */     long c31 = reg_lc.m31;
/* 3170 */     long c32 = reg_lc.m32;
/* 3171 */     long c33 = reg_lc.m33;
/*      */     
/* 3173 */     long bkr = reg_rbk;
/* 3174 */     long bkg = reg_gbk;
/* 3175 */     long bkb = reg_bbk;
/*      */     
/* 3177 */     ss1 = c11 * ir1 + c12 * ir2 + c13 * ir3 + (bkr << 12);
/* 3178 */     ss2 = c21 * ir1 + c22 * ir2 + c23 * ir3 + (bkg << 12);
/* 3179 */     ss3 = c31 * ir1 + c32 * ir2 + c33 * ir3 + (bkb << 12);
/*      */     
/* 3181 */     mac1 = A1(ss1);
/* 3182 */     mac2 = A2(ss2);
/* 3183 */     mac3 = A3(ss3);
/*      */     
/* 3185 */     ir1 = LiB1_1(mac1);
/* 3186 */     ir2 = LiB2_1(mac2);
/* 3187 */     ir3 = LiB3_1(mac3);
/*      */     
/* 3189 */     reg_mac1 = A1((r * ir1));
/* 3190 */     reg_mac2 = A2((g * ir2));
/* 3191 */     reg_mac3 = A3((b * ir3));
/* 3192 */     reg_ir1 = LiB1_1(reg_mac1);
/* 3193 */     reg_ir2 = LiB2_1(reg_mac2);
/* 3194 */     reg_ir3 = LiB3_1(reg_mac3);
/*      */     
/* 3196 */     int rr = LiC1(reg_mac1 >> 4);
/* 3197 */     int gg = LiC2(reg_mac2 >> 4);
/* 3198 */     int bb = LiC3(reg_mac3 >> 4);
/* 3199 */     reg_rgb0 = reg_rgb1;
/* 3200 */     reg_rgb1 = reg_rgb2;
/* 3201 */     reg_rgb2 = rr | gg << 8 | bb << 16 | chi;
/*      */   }
/*      */ 
/*      */   
/* 3205 */   public static void interpret_cdp(int ci) { throw new IllegalStateException("GTE UNIMPLEMENTED: CDP"); }
/*      */ 
/*      */ 
/*      */   
/* 3209 */   public static void interpret_cc(int ci) { throw new IllegalStateException("GTE UNIMPLEMENTED: CC"); }
/*      */ 
/*      */   
/*      */   public static void interpret_gpl(int ci) {
/* 3213 */     reg_flag = 0;
/*      */     
/* 3215 */     long i = reg_ir0;
/* 3216 */     if (0 != (ci & 0x80000)) {
/* 3217 */       reg_mac1 = A1((reg_mac1 << 12) + i * reg_ir1);
/* 3218 */       reg_mac2 = A2((reg_mac2 << 12) + i * reg_ir2);
/* 3219 */       reg_mac3 = A3((reg_mac3 << 12) + i * reg_ir3);
/*      */     } else {
/* 3221 */       reg_mac1 = A1(reg_mac1 + i * reg_ir1 << 12);
/* 3222 */       reg_mac2 = A2(reg_mac2 + i * reg_ir2 << 12);
/* 3223 */       reg_mac3 = A3(reg_mac3 + i * reg_ir3 << 12);
/*      */     } 
/* 3225 */     reg_ir1 = LiB1_0(reg_mac1);
/* 3226 */     reg_ir2 = LiB2_0(reg_mac2);
/* 3227 */     reg_ir3 = LiB3_0(reg_mac3);
/* 3228 */     int rr = LiC1(reg_mac1 >> 4);
/* 3229 */     int gg = LiC2(reg_mac2 >> 4);
/* 3230 */     int bb = LiC3(reg_mac3 >> 4);
/* 3231 */     reg_rgb0 = reg_rgb1;
/* 3232 */     reg_rgb1 = reg_rgb2;
/* 3233 */     reg_rgb2 = reg_rgb & 0xFF000000 | rr | gg << 8 | bb << 16;
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\gte\GTE.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */