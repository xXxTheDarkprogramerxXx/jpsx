/*     */ package classes.runtime.org.jpsx.runtime.components.hardware.gpu;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.scheduler.Quartz;
/*     */ import org.jpsx.api.components.hardware.gpu.Display;
/*     */ import org.jpsx.api.components.hardware.gpu.DisplayManager;
/*     */ import org.jpsx.runtime.JPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*     */ import org.jpsx.runtime.components.hardware.gpu.DefaultDisplayManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDisplayManager
/*     */   extends JPSXComponent
/*     */   implements DisplayManager
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger("Display");
/*  33 */   private long lastRefreshTime = 0L; private boolean hadDirty = false; private static final long DIRTY_REFRESH_PERIOD = 100000000L;
/*     */   private static final long AUTO_REFRESH_PERIOD = 200000000L;
/*     */   private Quartz quartz;
/*     */   private Display display;
/*     */   protected State[] states;
/*     */   protected int currentState;
/*     */   protected boolean interlaceField;
/*     */   protected boolean forceUpdate;
/*     */   
/*  42 */   public DefaultDisplayManager() { super("JPSX Default GPU Display Manager");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     this.states = new State[] { new State(null), new State(null) };
/* 243 */     this.currentState = 0; }
/*     */    public void init() {
/*     */     super.init();
/*     */     HardwareComponentConnections.DISPLAY_MANAGER.set(this);
/*     */   }
/* 248 */   public void preAsync() { updateState(); }
/*     */   public void resolveConnections() {
/*     */     super.resolveConnections();
/*     */     this.display = (Display)HardwareComponentConnections.DISPLAY.resolve();
/*     */     this.quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/*     */   }
/*     */   
/* 255 */   public void vsync() { updateState(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrigin(int x, int y) {
/* 261 */     State s = getNextState();
/* 262 */     s.xOrigin = x;
/* 263 */     s.yOrigin = y;
/* 264 */     updateState();
/*     */   } private static boolean intersects(int x0, int y0, int w0, int h0, int x1, int y1, int w1, int h1) { if (w0 == 0 || h0 == 0 || w1 == 0 || h1 == 0)
/*     */       return false;  w0 += x0; w1 += x1; h0 += y0;
/*     */     h1 += y1;
/* 268 */     return (w0 > x1 && h0 > y1 && w1 > x0 && h1 > y0); } protected State getState() { return this.states[this.currentState]; }
/*     */ 
/*     */ 
/*     */   
/* 272 */   protected State getNextState() { return this.states[this.currentState ^ true]; }
/*     */ 
/*     */   
/*     */   protected void updateState() {
/* 276 */     this.currentState ^= 0x1;
/* 277 */     State s = getState();
/* 278 */     boolean refresh = (this.forceUpdate || !this.states[0].matches(this.states[1]));
/* 279 */     if (!refresh && s.isDirty()) {
/* 280 */       this.hadDirty = true;
/*     */     }
/* 282 */     long time = this.quartz.nanoTime();
/* 283 */     if (!refresh && this.hadDirty && 100000000L < time - this.lastRefreshTime) {
/* 284 */       if (log.isDebugEnabled()) {
/* 285 */         log.debug("UPDATING DISPLAY BECAUSE DIRTY");
/*     */       }
/* 287 */       refresh = true;
/* 288 */       this.hadDirty = false;
/*     */     } 
/* 290 */     if (!refresh && 200000000L < time - this.lastRefreshTime) {
/* 291 */       if (log.isDebugEnabled()) {
/* 292 */         log.debug("UPDATING DISPLAY BECAUSE HAVEN'T HAD ONE");
/*     */       }
/* 294 */       refresh = true;
/*     */     } 
/* 296 */     if (refresh) {
/* 297 */       this.lastRefreshTime = time;
/*     */       
/* 299 */       this.forceUpdate = false;
/* 300 */       this.display.refresh();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 305 */     getNextState().reset(s);
/*     */   }
/*     */   
/*     */   public void toggleInterlaceField() {
/* 309 */     this.interlaceField = !this.interlaceField;
/* 310 */     this.forceUpdate = true;
/*     */   }
/*     */ 
/*     */   
/* 314 */   public boolean getInterlaceField() { return this.interlaceField; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 322 */   public void dirtyRectangle(int x, int y, int w, int h) { getNextState().dirtyRectangle(x, y, w, h); }
/*     */ 
/*     */ 
/*     */   
/* 326 */   public void setPixelDivider(int divider) { (getNextState()).pixelDivider = divider; }
/*     */ 
/*     */ 
/*     */   
/* 330 */   public void setNTSC(boolean NTSC) { (getNextState()).NTSC = NTSC; }
/*     */ 
/*     */ 
/*     */   
/* 334 */   public boolean getNTSC() { return (getState()).NTSC; }
/*     */ 
/*     */ 
/*     */   
/* 338 */   public void setInterlaced(boolean interlaced) { (getNextState()).interlaced = interlaced; }
/*     */ 
/*     */ 
/*     */   
/* 342 */   public boolean getInterlaced() { return (getState()).interlaced; }
/*     */ 
/*     */ 
/*     */   
/* 346 */   public void setDoubleY(boolean doubleY) { (getNextState()).doubleY = doubleY; }
/*     */ 
/*     */ 
/*     */   
/* 350 */   public boolean getDoubleY() { return (getState()).doubleY; }
/*     */ 
/*     */ 
/*     */   
/* 354 */   public void setRGB24(boolean rgb24) { (getNextState()).rgb24 = rgb24; }
/*     */ 
/*     */ 
/*     */   
/* 358 */   public boolean getRGB24() { return (getState()).rgb24; }
/*     */ 
/*     */ 
/*     */   
/* 362 */   public void setBlanked(boolean blanked) { (getNextState()).blanked = blanked; }
/*     */ 
/*     */ 
/*     */   
/* 366 */   public boolean getBlanked() { return (getState()).blanked; }
/*     */ 
/*     */   
/*     */   public void setHorizontalTiming(int hStart, int hEnd) {
/* 370 */     State s = getNextState();
/* 371 */     s.hStart = hStart;
/* 372 */     s.hEnd = hEnd;
/*     */   }
/*     */   
/*     */   public void setVerticalTiming(int vStart, int vEnd) {
/* 376 */     State s = getNextState();
/* 377 */     s.vStart = vStart;
/* 378 */     s.vEnd = vEnd;
/*     */   }
/*     */ 
/*     */   
/* 382 */   public int getDefaultTimingWidth() { return getState().getDefaultTimingWidth(); }
/*     */ 
/*     */ 
/*     */   
/* 386 */   public int getDefaultTimingHeight() { return getState().getDefaultTimingHeight(); }
/*     */ 
/*     */ 
/*     */   
/* 390 */   public int getDefaultPixelWidth() { return getState().getDefaultPixelWidth(); }
/*     */ 
/*     */ 
/*     */   
/* 394 */   public int getDefaultPixelHeight() { return getState().getDefaultPixelHeight(); }
/*     */ 
/*     */ 
/*     */   
/* 398 */   public int getPixelWidth() { return getState().getPixelWidth(); }
/*     */ 
/*     */ 
/*     */   
/* 402 */   public int getPixelHeight() { return getState().getPixelHeight(); }
/*     */ 
/*     */ 
/*     */   
/* 406 */   public int getXOrigin() { return (getState()).xOrigin; }
/*     */ 
/*     */ 
/*     */   
/* 410 */   public int getYOrigin() { return (getState()).yOrigin; }
/*     */ 
/*     */ 
/*     */   
/* 414 */   public int getLeftMargin() { return getState().getLeftMargin(); }
/*     */ 
/*     */ 
/*     */   
/* 418 */   public int getLeftMarginPixels() { return getState().getLeftMarginPixels(); }
/*     */ 
/*     */ 
/*     */   
/* 422 */   public int getRightMargin() { return getState().getRightMargin(); }
/*     */ 
/*     */ 
/*     */   
/* 426 */   public int getRightMarginPixels() { return getState().getRightMarginPixels(); }
/*     */ 
/*     */ 
/*     */   
/* 430 */   public int getTopMargin() { return getState().getTopMargin(); }
/*     */ 
/*     */ 
/*     */   
/* 434 */   public int getTopMarginPixels() { return getState().getTopMarginPixels(); }
/*     */ 
/*     */ 
/*     */   
/* 438 */   public int getBottomMargin() { return getState().getBottomMargin(); }
/*     */ 
/*     */ 
/*     */   
/* 442 */   public int getBottomMarginPixels() { return getState().getBottomMarginPixels(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\gpu\DefaultDisplayManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */