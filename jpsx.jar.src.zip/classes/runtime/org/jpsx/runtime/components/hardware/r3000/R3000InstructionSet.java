/*      */ package classes.runtime.org.jpsx.runtime.components.hardware.r3000;
/*      */ 
/*      */ import org.apache.bcel.generic.ConstantPoolGen;
/*      */ import org.apache.bcel.generic.I2L;
/*      */ import org.apache.bcel.generic.InstructionList;
/*      */ import org.apache.bcel.generic.LAND;
/*      */ import org.apache.bcel.generic.PUSH;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.jpsx.api.components.core.cpu.InstructionProvider;
/*      */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*      */ import org.jpsx.runtime.JPSXComponent;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.components.hardware.r3000.R3000InstructionSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class R3000InstructionSet
/*      */   extends JPSXComponent
/*      */   implements InstructionProvider
/*      */ {
/*   31 */   public static final Logger log = Logger.getLogger("R3000 Instruction Set");
/*      */   
/*   33 */   private static final String R3000_CLASS = org.jpsx.runtime.components.core.R3000Impl.class.getName();
/*   34 */   private static final String CLASS = R3000InstructionSet.class.getName();
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean ignoreArithmeticOverflow = true;
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean breakHotspot;
/*      */ 
/*      */ 
/*      */   
/*   46 */   public R3000InstructionSet() { super("JPSX R3000 Instruction Set"); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*   51 */     super.init();
/*   52 */     CoreComponentConnections.INSTRUCTION_PROVIDERS.add(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInstructions(InstructionRegistrar registrar) { // Byte code:
/*      */     //   0: getstatic org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet.log : Lorg/apache/log4j/Logger;
/*      */     //   3: ldc 'Adding R3000 instructions...'
/*      */     //   5: invokevirtual info : (Ljava/lang/Object;)V
/*      */     //   8: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$1
/*      */     //   11: dup
/*      */     //   12: aload_0
/*      */     //   13: ldc 'add'
/*      */     //   15: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   18: iconst_0
/*      */     //   19: sipush #2848
/*      */     //   22: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   25: astore_2
/*      */     //   26: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$2
/*      */     //   29: dup
/*      */     //   30: aload_0
/*      */     //   31: ldc 'addi'
/*      */     //   33: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   36: iconst_0
/*      */     //   37: sipush #1312
/*      */     //   40: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   43: astore_3
/*      */     //   44: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$3
/*      */     //   47: dup
/*      */     //   48: aload_0
/*      */     //   49: ldc 'addiu'
/*      */     //   51: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   54: iconst_0
/*      */     //   55: sipush #1312
/*      */     //   58: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   61: astore #4
/*      */     //   63: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$4
/*      */     //   66: dup
/*      */     //   67: aload_0
/*      */     //   68: ldc 'addu'
/*      */     //   70: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   73: iconst_0
/*      */     //   74: sipush #2848
/*      */     //   77: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   80: astore #5
/*      */     //   82: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$5
/*      */     //   85: dup
/*      */     //   86: aload_0
/*      */     //   87: ldc 'and'
/*      */     //   89: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   92: iconst_0
/*      */     //   93: sipush #2848
/*      */     //   96: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   99: astore #6
/*      */     //   101: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$6
/*      */     //   104: dup
/*      */     //   105: aload_0
/*      */     //   106: ldc 'andi'
/*      */     //   108: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   111: iconst_0
/*      */     //   112: sipush #1312
/*      */     //   115: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   118: astore #7
/*      */     //   120: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$7
/*      */     //   123: dup
/*      */     //   124: aload_0
/*      */     //   125: ldc 'beq'
/*      */     //   127: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   130: iconst_0
/*      */     //   131: sipush #773
/*      */     //   134: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   137: astore #8
/*      */     //   139: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$8
/*      */     //   142: dup
/*      */     //   143: aload_0
/*      */     //   144: ldc 'bgez'
/*      */     //   146: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   149: iconst_0
/*      */     //   150: sipush #261
/*      */     //   153: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   156: astore #9
/*      */     //   158: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$9
/*      */     //   161: dup
/*      */     //   162: aload_0
/*      */     //   163: ldc 'bgezal'
/*      */     //   165: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   168: iconst_0
/*      */     //   169: sipush #277
/*      */     //   172: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   175: astore #10
/*      */     //   177: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$10
/*      */     //   180: dup
/*      */     //   181: aload_0
/*      */     //   182: ldc 'bgtz'
/*      */     //   184: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   187: iconst_0
/*      */     //   188: sipush #261
/*      */     //   191: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   194: astore #11
/*      */     //   196: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$11
/*      */     //   199: dup
/*      */     //   200: aload_0
/*      */     //   201: ldc 'blez'
/*      */     //   203: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   206: iconst_0
/*      */     //   207: sipush #261
/*      */     //   210: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   213: astore #12
/*      */     //   215: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$12
/*      */     //   218: dup
/*      */     //   219: aload_0
/*      */     //   220: ldc 'bltz'
/*      */     //   222: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   225: iconst_0
/*      */     //   226: sipush #261
/*      */     //   229: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   232: astore #13
/*      */     //   234: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$13
/*      */     //   237: dup
/*      */     //   238: aload_0
/*      */     //   239: ldc 'bltzal'
/*      */     //   241: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   244: iconst_0
/*      */     //   245: sipush #277
/*      */     //   248: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   251: astore #14
/*      */     //   253: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$14
/*      */     //   256: dup
/*      */     //   257: aload_0
/*      */     //   258: ldc 'bne'
/*      */     //   260: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   263: iconst_0
/*      */     //   264: sipush #261
/*      */     //   267: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   270: astore #15
/*      */     //   272: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   275: dup
/*      */     //   276: ldc 'break'
/*      */     //   278: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   281: iconst_0
/*      */     //   282: ldc 131072
/*      */     //   284: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   287: astore #16
/*      */     //   289: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$15
/*      */     //   292: dup
/*      */     //   293: aload_0
/*      */     //   294: ldc 'div'
/*      */     //   296: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   299: iconst_0
/*      */     //   300: sipush #768
/*      */     //   303: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   306: astore #17
/*      */     //   308: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$16
/*      */     //   311: dup
/*      */     //   312: aload_0
/*      */     //   313: ldc 'divu'
/*      */     //   315: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   318: iconst_0
/*      */     //   319: sipush #768
/*      */     //   322: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   325: astore #18
/*      */     //   327: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$17
/*      */     //   330: dup
/*      */     //   331: aload_0
/*      */     //   332: ldc 'j'
/*      */     //   334: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   337: iconst_0
/*      */     //   338: bipush #11
/*      */     //   340: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   343: astore #19
/*      */     //   345: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$18
/*      */     //   348: dup
/*      */     //   349: aload_0
/*      */     //   350: ldc 'jal'
/*      */     //   352: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   355: iconst_0
/*      */     //   356: bipush #27
/*      */     //   358: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   361: astore #20
/*      */     //   363: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$19
/*      */     //   366: dup
/*      */     //   367: aload_0
/*      */     //   368: ldc 'jalr'
/*      */     //   370: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   373: iconst_0
/*      */     //   374: sipush #2323
/*      */     //   377: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   380: astore #21
/*      */     //   382: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$20
/*      */     //   385: dup
/*      */     //   386: aload_0
/*      */     //   387: ldc 'jr'
/*      */     //   389: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   392: iconst_0
/*      */     //   393: sipush #259
/*      */     //   396: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   399: astore #22
/*      */     //   401: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$21
/*      */     //   404: dup
/*      */     //   405: aload_0
/*      */     //   406: ldc 'lb'
/*      */     //   408: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   411: iconst_0
/*      */     //   412: sipush #9472
/*      */     //   415: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   418: astore #23
/*      */     //   420: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$22
/*      */     //   423: dup
/*      */     //   424: aload_0
/*      */     //   425: ldc 'lbu'
/*      */     //   427: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   430: iconst_0
/*      */     //   431: sipush #9472
/*      */     //   434: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   437: astore #24
/*      */     //   439: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$23
/*      */     //   442: dup
/*      */     //   443: aload_0
/*      */     //   444: ldc 'lh'
/*      */     //   446: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   449: iconst_0
/*      */     //   450: sipush #17664
/*      */     //   453: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   456: astore #25
/*      */     //   458: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$24
/*      */     //   461: dup
/*      */     //   462: aload_0
/*      */     //   463: ldc 'lhu'
/*      */     //   465: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   468: iconst_0
/*      */     //   469: sipush #17664
/*      */     //   472: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   475: astore #26
/*      */     //   477: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$25
/*      */     //   480: dup
/*      */     //   481: aload_0
/*      */     //   482: ldc 'lui'
/*      */     //   484: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   487: iconst_0
/*      */     //   488: sipush #1056
/*      */     //   491: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   494: astore #27
/*      */     //   496: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$26
/*      */     //   499: dup
/*      */     //   500: aload_0
/*      */     //   501: ldc 'lw'
/*      */     //   503: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   506: iconst_0
/*      */     //   507: ldc 34048
/*      */     //   509: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   512: astore #28
/*      */     //   514: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   517: dup
/*      */     //   518: ldc 'lwc1'
/*      */     //   520: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   523: iconst_0
/*      */     //   524: ldc 131072
/*      */     //   526: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   529: astore #29
/*      */     //   531: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   534: dup
/*      */     //   535: ldc 'lwc3'
/*      */     //   537: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   540: iconst_0
/*      */     //   541: ldc 131072
/*      */     //   543: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   546: astore #30
/*      */     //   548: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$27
/*      */     //   551: dup
/*      */     //   552: aload_0
/*      */     //   553: ldc 'lwl'
/*      */     //   555: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   558: iconst_0
/*      */     //   559: ldc 34560
/*      */     //   561: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   564: astore #31
/*      */     //   566: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$28
/*      */     //   569: dup
/*      */     //   570: aload_0
/*      */     //   571: ldc 'lwr'
/*      */     //   573: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   576: iconst_0
/*      */     //   577: ldc 34560
/*      */     //   579: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   582: astore #32
/*      */     //   584: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$29
/*      */     //   587: dup
/*      */     //   588: aload_0
/*      */     //   589: ldc 'mfhi'
/*      */     //   591: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   594: iconst_0
/*      */     //   595: sipush #2048
/*      */     //   598: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   601: astore #33
/*      */     //   603: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$30
/*      */     //   606: dup
/*      */     //   607: aload_0
/*      */     //   608: ldc 'mflo'
/*      */     //   610: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   613: iconst_0
/*      */     //   614: sipush #2048
/*      */     //   617: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   620: astore #34
/*      */     //   622: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   625: dup
/*      */     //   626: ldc 'mthi'
/*      */     //   628: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   631: iconst_0
/*      */     //   632: sipush #256
/*      */     //   635: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   638: astore #35
/*      */     //   640: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   643: dup
/*      */     //   644: ldc 'mtlo'
/*      */     //   646: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   649: iconst_0
/*      */     //   650: sipush #256
/*      */     //   653: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   656: astore #36
/*      */     //   658: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$31
/*      */     //   661: dup
/*      */     //   662: aload_0
/*      */     //   663: ldc 'mult'
/*      */     //   665: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   668: iconst_0
/*      */     //   669: sipush #768
/*      */     //   672: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   675: astore #37
/*      */     //   677: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$32
/*      */     //   680: dup
/*      */     //   681: aload_0
/*      */     //   682: ldc 'multu'
/*      */     //   684: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   687: iconst_0
/*      */     //   688: sipush #768
/*      */     //   691: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   694: astore #38
/*      */     //   696: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$33
/*      */     //   699: dup
/*      */     //   700: aload_0
/*      */     //   701: ldc 'nor'
/*      */     //   703: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   706: iconst_0
/*      */     //   707: sipush #2848
/*      */     //   710: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   713: astore #39
/*      */     //   715: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$34
/*      */     //   718: dup
/*      */     //   719: aload_0
/*      */     //   720: ldc 'or'
/*      */     //   722: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   725: iconst_0
/*      */     //   726: sipush #2848
/*      */     //   729: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   732: astore #40
/*      */     //   734: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$35
/*      */     //   737: dup
/*      */     //   738: aload_0
/*      */     //   739: ldc 'ori'
/*      */     //   741: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   744: iconst_0
/*      */     //   745: sipush #1312
/*      */     //   748: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   751: astore #41
/*      */     //   753: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$36
/*      */     //   756: dup
/*      */     //   757: aload_0
/*      */     //   758: ldc 'sb'
/*      */     //   760: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   763: iconst_0
/*      */     //   764: sipush #17152
/*      */     //   767: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   770: astore #42
/*      */     //   772: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$37
/*      */     //   775: dup
/*      */     //   776: aload_0
/*      */     //   777: ldc 'sh'
/*      */     //   779: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   782: iconst_0
/*      */     //   783: sipush #8960
/*      */     //   786: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   789: astore #43
/*      */     //   791: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$38
/*      */     //   794: dup
/*      */     //   795: aload_0
/*      */     //   796: ldc 'sll'
/*      */     //   798: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   801: iconst_0
/*      */     //   802: sipush #2592
/*      */     //   805: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   808: astore #44
/*      */     //   810: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$39
/*      */     //   813: dup
/*      */     //   814: aload_0
/*      */     //   815: ldc 'sllv'
/*      */     //   817: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   820: iconst_0
/*      */     //   821: sipush #2848
/*      */     //   824: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   827: astore #45
/*      */     //   829: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$40
/*      */     //   832: dup
/*      */     //   833: aload_0
/*      */     //   834: ldc 'slt'
/*      */     //   836: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   839: iconst_0
/*      */     //   840: sipush #2848
/*      */     //   843: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   846: astore #46
/*      */     //   848: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$41
/*      */     //   851: dup
/*      */     //   852: aload_0
/*      */     //   853: ldc 'slti'
/*      */     //   855: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   858: iconst_0
/*      */     //   859: sipush #1312
/*      */     //   862: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   865: astore #47
/*      */     //   867: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$42
/*      */     //   870: dup
/*      */     //   871: aload_0
/*      */     //   872: ldc 'sltiu'
/*      */     //   874: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   877: iconst_0
/*      */     //   878: sipush #1312
/*      */     //   881: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   884: astore #48
/*      */     //   886: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$43
/*      */     //   889: dup
/*      */     //   890: aload_0
/*      */     //   891: ldc 'sltu'
/*      */     //   893: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   896: iconst_0
/*      */     //   897: sipush #2848
/*      */     //   900: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   903: astore #49
/*      */     //   905: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$44
/*      */     //   908: dup
/*      */     //   909: aload_0
/*      */     //   910: ldc 'sra'
/*      */     //   912: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   915: iconst_0
/*      */     //   916: sipush #2592
/*      */     //   919: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   922: astore #50
/*      */     //   924: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$45
/*      */     //   927: dup
/*      */     //   928: aload_0
/*      */     //   929: ldc 'srav'
/*      */     //   931: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   934: iconst_0
/*      */     //   935: sipush #2848
/*      */     //   938: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   941: astore #51
/*      */     //   943: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$46
/*      */     //   946: dup
/*      */     //   947: aload_0
/*      */     //   948: ldc 'srl'
/*      */     //   950: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   953: iconst_0
/*      */     //   954: sipush #2592
/*      */     //   957: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   960: astore #52
/*      */     //   962: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$47
/*      */     //   965: dup
/*      */     //   966: aload_0
/*      */     //   967: ldc 'srlv'
/*      */     //   969: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   972: iconst_0
/*      */     //   973: sipush #2848
/*      */     //   976: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   979: astore #53
/*      */     //   981: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$48
/*      */     //   984: dup
/*      */     //   985: aload_0
/*      */     //   986: ldc 'sub'
/*      */     //   988: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   991: iconst_0
/*      */     //   992: sipush #2848
/*      */     //   995: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   998: astore #54
/*      */     //   1000: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$49
/*      */     //   1003: dup
/*      */     //   1004: aload_0
/*      */     //   1005: ldc 'subu'
/*      */     //   1007: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1010: iconst_0
/*      */     //   1011: sipush #2848
/*      */     //   1014: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1017: astore #55
/*      */     //   1019: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$50
/*      */     //   1022: dup
/*      */     //   1023: aload_0
/*      */     //   1024: ldc 'sw'
/*      */     //   1026: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1029: iconst_0
/*      */     //   1030: ldc 33536
/*      */     //   1032: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1035: astore #56
/*      */     //   1037: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   1040: dup
/*      */     //   1041: ldc 'swc1'
/*      */     //   1043: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1046: iconst_0
/*      */     //   1047: ldc 131072
/*      */     //   1049: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1052: astore #57
/*      */     //   1054: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   1057: dup
/*      */     //   1058: ldc 'swc3'
/*      */     //   1060: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1063: iconst_0
/*      */     //   1064: ldc 131072
/*      */     //   1066: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1069: astore #58
/*      */     //   1071: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$51
/*      */     //   1074: dup
/*      */     //   1075: aload_0
/*      */     //   1076: ldc 'swl'
/*      */     //   1078: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1081: iconst_0
/*      */     //   1082: ldc 33536
/*      */     //   1084: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1087: astore #59
/*      */     //   1089: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$52
/*      */     //   1092: dup
/*      */     //   1093: aload_0
/*      */     //   1094: ldc 'swr'
/*      */     //   1096: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1099: iconst_0
/*      */     //   1100: ldc 33536
/*      */     //   1102: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1105: astore #60
/*      */     //   1107: new org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   1110: dup
/*      */     //   1111: ldc 'syscall'
/*      */     //   1113: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1116: iconst_0
/*      */     //   1117: ldc 131072
/*      */     //   1119: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1122: astore #61
/*      */     //   1124: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$53
/*      */     //   1127: dup
/*      */     //   1128: aload_0
/*      */     //   1129: ldc 'xor'
/*      */     //   1131: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1134: iconst_0
/*      */     //   1135: sipush #2848
/*      */     //   1138: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1141: astore #62
/*      */     //   1143: new org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet$54
/*      */     //   1146: dup
/*      */     //   1147: aload_0
/*      */     //   1148: ldc 'xori'
/*      */     //   1150: ldc_w org/jpsx/runtime/components/hardware/r3000/R3000InstructionSet
/*      */     //   1153: iconst_0
/*      */     //   1154: sipush #1312
/*      */     //   1157: invokespecial <init> : (Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;Ljava/lang/String;Ljava/lang/Class;II)V
/*      */     //   1160: astore #63
/*      */     //   1162: bipush #64
/*      */     //   1164: anewarray org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   1167: dup
/*      */     //   1168: iconst_0
/*      */     //   1169: aconst_null
/*      */     //   1170: aastore
/*      */     //   1171: dup
/*      */     //   1172: iconst_1
/*      */     //   1173: aconst_null
/*      */     //   1174: aastore
/*      */     //   1175: dup
/*      */     //   1176: iconst_2
/*      */     //   1177: aload #19
/*      */     //   1179: aastore
/*      */     //   1180: dup
/*      */     //   1181: iconst_3
/*      */     //   1182: aload #20
/*      */     //   1184: aastore
/*      */     //   1185: dup
/*      */     //   1186: iconst_4
/*      */     //   1187: aload #8
/*      */     //   1189: aastore
/*      */     //   1190: dup
/*      */     //   1191: iconst_5
/*      */     //   1192: aload #15
/*      */     //   1194: aastore
/*      */     //   1195: dup
/*      */     //   1196: bipush #6
/*      */     //   1198: aload #12
/*      */     //   1200: aastore
/*      */     //   1201: dup
/*      */     //   1202: bipush #7
/*      */     //   1204: aload #11
/*      */     //   1206: aastore
/*      */     //   1207: dup
/*      */     //   1208: bipush #8
/*      */     //   1210: aload_3
/*      */     //   1211: aastore
/*      */     //   1212: dup
/*      */     //   1213: bipush #9
/*      */     //   1215: aload #4
/*      */     //   1217: aastore
/*      */     //   1218: dup
/*      */     //   1219: bipush #10
/*      */     //   1221: aload #47
/*      */     //   1223: aastore
/*      */     //   1224: dup
/*      */     //   1225: bipush #11
/*      */     //   1227: aload #48
/*      */     //   1229: aastore
/*      */     //   1230: dup
/*      */     //   1231: bipush #12
/*      */     //   1233: aload #7
/*      */     //   1235: aastore
/*      */     //   1236: dup
/*      */     //   1237: bipush #13
/*      */     //   1239: aload #41
/*      */     //   1241: aastore
/*      */     //   1242: dup
/*      */     //   1243: bipush #14
/*      */     //   1245: aload #63
/*      */     //   1247: aastore
/*      */     //   1248: dup
/*      */     //   1249: bipush #15
/*      */     //   1251: aload #27
/*      */     //   1253: aastore
/*      */     //   1254: dup
/*      */     //   1255: bipush #16
/*      */     //   1257: aconst_null
/*      */     //   1258: aastore
/*      */     //   1259: dup
/*      */     //   1260: bipush #17
/*      */     //   1262: aconst_null
/*      */     //   1263: aastore
/*      */     //   1264: dup
/*      */     //   1265: bipush #18
/*      */     //   1267: aconst_null
/*      */     //   1268: aastore
/*      */     //   1269: dup
/*      */     //   1270: bipush #19
/*      */     //   1272: aconst_null
/*      */     //   1273: aastore
/*      */     //   1274: dup
/*      */     //   1275: bipush #20
/*      */     //   1277: aconst_null
/*      */     //   1278: aastore
/*      */     //   1279: dup
/*      */     //   1280: bipush #21
/*      */     //   1282: aconst_null
/*      */     //   1283: aastore
/*      */     //   1284: dup
/*      */     //   1285: bipush #22
/*      */     //   1287: aconst_null
/*      */     //   1288: aastore
/*      */     //   1289: dup
/*      */     //   1290: bipush #23
/*      */     //   1292: aconst_null
/*      */     //   1293: aastore
/*      */     //   1294: dup
/*      */     //   1295: bipush #24
/*      */     //   1297: aconst_null
/*      */     //   1298: aastore
/*      */     //   1299: dup
/*      */     //   1300: bipush #25
/*      */     //   1302: aconst_null
/*      */     //   1303: aastore
/*      */     //   1304: dup
/*      */     //   1305: bipush #26
/*      */     //   1307: aconst_null
/*      */     //   1308: aastore
/*      */     //   1309: dup
/*      */     //   1310: bipush #27
/*      */     //   1312: aconst_null
/*      */     //   1313: aastore
/*      */     //   1314: dup
/*      */     //   1315: bipush #28
/*      */     //   1317: aconst_null
/*      */     //   1318: aastore
/*      */     //   1319: dup
/*      */     //   1320: bipush #29
/*      */     //   1322: aconst_null
/*      */     //   1323: aastore
/*      */     //   1324: dup
/*      */     //   1325: bipush #30
/*      */     //   1327: aconst_null
/*      */     //   1328: aastore
/*      */     //   1329: dup
/*      */     //   1330: bipush #31
/*      */     //   1332: aconst_null
/*      */     //   1333: aastore
/*      */     //   1334: dup
/*      */     //   1335: bipush #32
/*      */     //   1337: aload #23
/*      */     //   1339: aastore
/*      */     //   1340: dup
/*      */     //   1341: bipush #33
/*      */     //   1343: aload #25
/*      */     //   1345: aastore
/*      */     //   1346: dup
/*      */     //   1347: bipush #34
/*      */     //   1349: aload #31
/*      */     //   1351: aastore
/*      */     //   1352: dup
/*      */     //   1353: bipush #35
/*      */     //   1355: aload #28
/*      */     //   1357: aastore
/*      */     //   1358: dup
/*      */     //   1359: bipush #36
/*      */     //   1361: aload #24
/*      */     //   1363: aastore
/*      */     //   1364: dup
/*      */     //   1365: bipush #37
/*      */     //   1367: aload #26
/*      */     //   1369: aastore
/*      */     //   1370: dup
/*      */     //   1371: bipush #38
/*      */     //   1373: aload #32
/*      */     //   1375: aastore
/*      */     //   1376: dup
/*      */     //   1377: bipush #39
/*      */     //   1379: aconst_null
/*      */     //   1380: aastore
/*      */     //   1381: dup
/*      */     //   1382: bipush #40
/*      */     //   1384: aload #42
/*      */     //   1386: aastore
/*      */     //   1387: dup
/*      */     //   1388: bipush #41
/*      */     //   1390: aload #43
/*      */     //   1392: aastore
/*      */     //   1393: dup
/*      */     //   1394: bipush #42
/*      */     //   1396: aload #59
/*      */     //   1398: aastore
/*      */     //   1399: dup
/*      */     //   1400: bipush #43
/*      */     //   1402: aload #56
/*      */     //   1404: aastore
/*      */     //   1405: dup
/*      */     //   1406: bipush #44
/*      */     //   1408: aconst_null
/*      */     //   1409: aastore
/*      */     //   1410: dup
/*      */     //   1411: bipush #45
/*      */     //   1413: aconst_null
/*      */     //   1414: aastore
/*      */     //   1415: dup
/*      */     //   1416: bipush #46
/*      */     //   1418: aload #60
/*      */     //   1420: aastore
/*      */     //   1421: dup
/*      */     //   1422: bipush #47
/*      */     //   1424: aconst_null
/*      */     //   1425: aastore
/*      */     //   1426: dup
/*      */     //   1427: bipush #48
/*      */     //   1429: aconst_null
/*      */     //   1430: aastore
/*      */     //   1431: dup
/*      */     //   1432: bipush #49
/*      */     //   1434: aload #29
/*      */     //   1436: aastore
/*      */     //   1437: dup
/*      */     //   1438: bipush #50
/*      */     //   1440: aconst_null
/*      */     //   1441: aastore
/*      */     //   1442: dup
/*      */     //   1443: bipush #51
/*      */     //   1445: aload #30
/*      */     //   1447: aastore
/*      */     //   1448: dup
/*      */     //   1449: bipush #52
/*      */     //   1451: aconst_null
/*      */     //   1452: aastore
/*      */     //   1453: dup
/*      */     //   1454: bipush #53
/*      */     //   1456: aconst_null
/*      */     //   1457: aastore
/*      */     //   1458: dup
/*      */     //   1459: bipush #54
/*      */     //   1461: aconst_null
/*      */     //   1462: aastore
/*      */     //   1463: dup
/*      */     //   1464: bipush #55
/*      */     //   1466: aconst_null
/*      */     //   1467: aastore
/*      */     //   1468: dup
/*      */     //   1469: bipush #56
/*      */     //   1471: aconst_null
/*      */     //   1472: aastore
/*      */     //   1473: dup
/*      */     //   1474: bipush #57
/*      */     //   1476: aload #57
/*      */     //   1478: aastore
/*      */     //   1479: dup
/*      */     //   1480: bipush #58
/*      */     //   1482: aconst_null
/*      */     //   1483: aastore
/*      */     //   1484: dup
/*      */     //   1485: bipush #59
/*      */     //   1487: aload #58
/*      */     //   1489: aastore
/*      */     //   1490: dup
/*      */     //   1491: bipush #60
/*      */     //   1493: aconst_null
/*      */     //   1494: aastore
/*      */     //   1495: dup
/*      */     //   1496: bipush #61
/*      */     //   1498: aconst_null
/*      */     //   1499: aastore
/*      */     //   1500: dup
/*      */     //   1501: bipush #62
/*      */     //   1503: aconst_null
/*      */     //   1504: aastore
/*      */     //   1505: dup
/*      */     //   1506: bipush #63
/*      */     //   1508: aconst_null
/*      */     //   1509: aastore
/*      */     //   1510: astore #64
/*      */     //   1512: iconst_0
/*      */     //   1513: istore #65
/*      */     //   1515: iload #65
/*      */     //   1517: bipush #64
/*      */     //   1519: if_icmpge -> 1550
/*      */     //   1522: aconst_null
/*      */     //   1523: aload #64
/*      */     //   1525: iload #65
/*      */     //   1527: aaload
/*      */     //   1528: if_acmpeq -> 1544
/*      */     //   1531: aload_1
/*      */     //   1532: iload #65
/*      */     //   1534: aload #64
/*      */     //   1536: iload #65
/*      */     //   1538: aaload
/*      */     //   1539: invokeinterface setInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*      */     //   1544: iinc #65, 1
/*      */     //   1547: goto -> 1515
/*      */     //   1550: bipush #64
/*      */     //   1552: anewarray org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   1555: dup
/*      */     //   1556: iconst_0
/*      */     //   1557: aload #44
/*      */     //   1559: aastore
/*      */     //   1560: dup
/*      */     //   1561: iconst_1
/*      */     //   1562: aconst_null
/*      */     //   1563: aastore
/*      */     //   1564: dup
/*      */     //   1565: iconst_2
/*      */     //   1566: aload #52
/*      */     //   1568: aastore
/*      */     //   1569: dup
/*      */     //   1570: iconst_3
/*      */     //   1571: aload #50
/*      */     //   1573: aastore
/*      */     //   1574: dup
/*      */     //   1575: iconst_4
/*      */     //   1576: aload #45
/*      */     //   1578: aastore
/*      */     //   1579: dup
/*      */     //   1580: iconst_5
/*      */     //   1581: aconst_null
/*      */     //   1582: aastore
/*      */     //   1583: dup
/*      */     //   1584: bipush #6
/*      */     //   1586: aload #53
/*      */     //   1588: aastore
/*      */     //   1589: dup
/*      */     //   1590: bipush #7
/*      */     //   1592: aload #51
/*      */     //   1594: aastore
/*      */     //   1595: dup
/*      */     //   1596: bipush #8
/*      */     //   1598: aload #22
/*      */     //   1600: aastore
/*      */     //   1601: dup
/*      */     //   1602: bipush #9
/*      */     //   1604: aload #21
/*      */     //   1606: aastore
/*      */     //   1607: dup
/*      */     //   1608: bipush #10
/*      */     //   1610: aconst_null
/*      */     //   1611: aastore
/*      */     //   1612: dup
/*      */     //   1613: bipush #11
/*      */     //   1615: aconst_null
/*      */     //   1616: aastore
/*      */     //   1617: dup
/*      */     //   1618: bipush #12
/*      */     //   1620: aload #61
/*      */     //   1622: aastore
/*      */     //   1623: dup
/*      */     //   1624: bipush #13
/*      */     //   1626: aload #16
/*      */     //   1628: aastore
/*      */     //   1629: dup
/*      */     //   1630: bipush #14
/*      */     //   1632: aconst_null
/*      */     //   1633: aastore
/*      */     //   1634: dup
/*      */     //   1635: bipush #15
/*      */     //   1637: aconst_null
/*      */     //   1638: aastore
/*      */     //   1639: dup
/*      */     //   1640: bipush #16
/*      */     //   1642: aload #33
/*      */     //   1644: aastore
/*      */     //   1645: dup
/*      */     //   1646: bipush #17
/*      */     //   1648: aload #35
/*      */     //   1650: aastore
/*      */     //   1651: dup
/*      */     //   1652: bipush #18
/*      */     //   1654: aload #34
/*      */     //   1656: aastore
/*      */     //   1657: dup
/*      */     //   1658: bipush #19
/*      */     //   1660: aload #36
/*      */     //   1662: aastore
/*      */     //   1663: dup
/*      */     //   1664: bipush #20
/*      */     //   1666: aconst_null
/*      */     //   1667: aastore
/*      */     //   1668: dup
/*      */     //   1669: bipush #21
/*      */     //   1671: aconst_null
/*      */     //   1672: aastore
/*      */     //   1673: dup
/*      */     //   1674: bipush #22
/*      */     //   1676: aconst_null
/*      */     //   1677: aastore
/*      */     //   1678: dup
/*      */     //   1679: bipush #23
/*      */     //   1681: aconst_null
/*      */     //   1682: aastore
/*      */     //   1683: dup
/*      */     //   1684: bipush #24
/*      */     //   1686: aload #37
/*      */     //   1688: aastore
/*      */     //   1689: dup
/*      */     //   1690: bipush #25
/*      */     //   1692: aload #38
/*      */     //   1694: aastore
/*      */     //   1695: dup
/*      */     //   1696: bipush #26
/*      */     //   1698: aload #17
/*      */     //   1700: aastore
/*      */     //   1701: dup
/*      */     //   1702: bipush #27
/*      */     //   1704: aload #18
/*      */     //   1706: aastore
/*      */     //   1707: dup
/*      */     //   1708: bipush #28
/*      */     //   1710: aconst_null
/*      */     //   1711: aastore
/*      */     //   1712: dup
/*      */     //   1713: bipush #29
/*      */     //   1715: aconst_null
/*      */     //   1716: aastore
/*      */     //   1717: dup
/*      */     //   1718: bipush #30
/*      */     //   1720: aconst_null
/*      */     //   1721: aastore
/*      */     //   1722: dup
/*      */     //   1723: bipush #31
/*      */     //   1725: aconst_null
/*      */     //   1726: aastore
/*      */     //   1727: dup
/*      */     //   1728: bipush #32
/*      */     //   1730: aload_2
/*      */     //   1731: aastore
/*      */     //   1732: dup
/*      */     //   1733: bipush #33
/*      */     //   1735: aload #5
/*      */     //   1737: aastore
/*      */     //   1738: dup
/*      */     //   1739: bipush #34
/*      */     //   1741: aload #54
/*      */     //   1743: aastore
/*      */     //   1744: dup
/*      */     //   1745: bipush #35
/*      */     //   1747: aload #55
/*      */     //   1749: aastore
/*      */     //   1750: dup
/*      */     //   1751: bipush #36
/*      */     //   1753: aload #6
/*      */     //   1755: aastore
/*      */     //   1756: dup
/*      */     //   1757: bipush #37
/*      */     //   1759: aload #40
/*      */     //   1761: aastore
/*      */     //   1762: dup
/*      */     //   1763: bipush #38
/*      */     //   1765: aload #62
/*      */     //   1767: aastore
/*      */     //   1768: dup
/*      */     //   1769: bipush #39
/*      */     //   1771: aload #39
/*      */     //   1773: aastore
/*      */     //   1774: dup
/*      */     //   1775: bipush #40
/*      */     //   1777: aconst_null
/*      */     //   1778: aastore
/*      */     //   1779: dup
/*      */     //   1780: bipush #41
/*      */     //   1782: aconst_null
/*      */     //   1783: aastore
/*      */     //   1784: dup
/*      */     //   1785: bipush #42
/*      */     //   1787: aload #46
/*      */     //   1789: aastore
/*      */     //   1790: dup
/*      */     //   1791: bipush #43
/*      */     //   1793: aload #49
/*      */     //   1795: aastore
/*      */     //   1796: dup
/*      */     //   1797: bipush #44
/*      */     //   1799: aconst_null
/*      */     //   1800: aastore
/*      */     //   1801: dup
/*      */     //   1802: bipush #45
/*      */     //   1804: aconst_null
/*      */     //   1805: aastore
/*      */     //   1806: dup
/*      */     //   1807: bipush #46
/*      */     //   1809: aconst_null
/*      */     //   1810: aastore
/*      */     //   1811: dup
/*      */     //   1812: bipush #47
/*      */     //   1814: aconst_null
/*      */     //   1815: aastore
/*      */     //   1816: dup
/*      */     //   1817: bipush #48
/*      */     //   1819: aconst_null
/*      */     //   1820: aastore
/*      */     //   1821: dup
/*      */     //   1822: bipush #49
/*      */     //   1824: aconst_null
/*      */     //   1825: aastore
/*      */     //   1826: dup
/*      */     //   1827: bipush #50
/*      */     //   1829: aconst_null
/*      */     //   1830: aastore
/*      */     //   1831: dup
/*      */     //   1832: bipush #51
/*      */     //   1834: aconst_null
/*      */     //   1835: aastore
/*      */     //   1836: dup
/*      */     //   1837: bipush #52
/*      */     //   1839: aconst_null
/*      */     //   1840: aastore
/*      */     //   1841: dup
/*      */     //   1842: bipush #53
/*      */     //   1844: aconst_null
/*      */     //   1845: aastore
/*      */     //   1846: dup
/*      */     //   1847: bipush #54
/*      */     //   1849: aconst_null
/*      */     //   1850: aastore
/*      */     //   1851: dup
/*      */     //   1852: bipush #55
/*      */     //   1854: aconst_null
/*      */     //   1855: aastore
/*      */     //   1856: dup
/*      */     //   1857: bipush #56
/*      */     //   1859: aconst_null
/*      */     //   1860: aastore
/*      */     //   1861: dup
/*      */     //   1862: bipush #57
/*      */     //   1864: aconst_null
/*      */     //   1865: aastore
/*      */     //   1866: dup
/*      */     //   1867: bipush #58
/*      */     //   1869: aconst_null
/*      */     //   1870: aastore
/*      */     //   1871: dup
/*      */     //   1872: bipush #59
/*      */     //   1874: aconst_null
/*      */     //   1875: aastore
/*      */     //   1876: dup
/*      */     //   1877: bipush #60
/*      */     //   1879: aconst_null
/*      */     //   1880: aastore
/*      */     //   1881: dup
/*      */     //   1882: bipush #61
/*      */     //   1884: aconst_null
/*      */     //   1885: aastore
/*      */     //   1886: dup
/*      */     //   1887: bipush #62
/*      */     //   1889: aconst_null
/*      */     //   1890: aastore
/*      */     //   1891: dup
/*      */     //   1892: bipush #63
/*      */     //   1894: aconst_null
/*      */     //   1895: aastore
/*      */     //   1896: astore #64
/*      */     //   1898: iconst_0
/*      */     //   1899: istore #65
/*      */     //   1901: iload #65
/*      */     //   1903: bipush #64
/*      */     //   1905: if_icmpge -> 1936
/*      */     //   1908: aconst_null
/*      */     //   1909: aload #64
/*      */     //   1911: iload #65
/*      */     //   1913: aaload
/*      */     //   1914: if_acmpeq -> 1930
/*      */     //   1917: aload_1
/*      */     //   1918: iload #65
/*      */     //   1920: aload #64
/*      */     //   1922: iload #65
/*      */     //   1924: aaload
/*      */     //   1925: invokeinterface setSPECIALInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*      */     //   1930: iinc #65, 1
/*      */     //   1933: goto -> 1901
/*      */     //   1936: bipush #32
/*      */     //   1938: anewarray org/jpsx/api/components/core/cpu/CPUInstruction
/*      */     //   1941: dup
/*      */     //   1942: iconst_0
/*      */     //   1943: aload #13
/*      */     //   1945: aastore
/*      */     //   1946: dup
/*      */     //   1947: iconst_1
/*      */     //   1948: aload #9
/*      */     //   1950: aastore
/*      */     //   1951: dup
/*      */     //   1952: iconst_2
/*      */     //   1953: aconst_null
/*      */     //   1954: aastore
/*      */     //   1955: dup
/*      */     //   1956: iconst_3
/*      */     //   1957: aconst_null
/*      */     //   1958: aastore
/*      */     //   1959: dup
/*      */     //   1960: iconst_4
/*      */     //   1961: aconst_null
/*      */     //   1962: aastore
/*      */     //   1963: dup
/*      */     //   1964: iconst_5
/*      */     //   1965: aconst_null
/*      */     //   1966: aastore
/*      */     //   1967: dup
/*      */     //   1968: bipush #6
/*      */     //   1970: aconst_null
/*      */     //   1971: aastore
/*      */     //   1972: dup
/*      */     //   1973: bipush #7
/*      */     //   1975: aconst_null
/*      */     //   1976: aastore
/*      */     //   1977: dup
/*      */     //   1978: bipush #8
/*      */     //   1980: aconst_null
/*      */     //   1981: aastore
/*      */     //   1982: dup
/*      */     //   1983: bipush #9
/*      */     //   1985: aconst_null
/*      */     //   1986: aastore
/*      */     //   1987: dup
/*      */     //   1988: bipush #10
/*      */     //   1990: aconst_null
/*      */     //   1991: aastore
/*      */     //   1992: dup
/*      */     //   1993: bipush #11
/*      */     //   1995: aconst_null
/*      */     //   1996: aastore
/*      */     //   1997: dup
/*      */     //   1998: bipush #12
/*      */     //   2000: aconst_null
/*      */     //   2001: aastore
/*      */     //   2002: dup
/*      */     //   2003: bipush #13
/*      */     //   2005: aconst_null
/*      */     //   2006: aastore
/*      */     //   2007: dup
/*      */     //   2008: bipush #14
/*      */     //   2010: aconst_null
/*      */     //   2011: aastore
/*      */     //   2012: dup
/*      */     //   2013: bipush #15
/*      */     //   2015: aconst_null
/*      */     //   2016: aastore
/*      */     //   2017: dup
/*      */     //   2018: bipush #16
/*      */     //   2020: aload #14
/*      */     //   2022: aastore
/*      */     //   2023: dup
/*      */     //   2024: bipush #17
/*      */     //   2026: aload #10
/*      */     //   2028: aastore
/*      */     //   2029: dup
/*      */     //   2030: bipush #18
/*      */     //   2032: aconst_null
/*      */     //   2033: aastore
/*      */     //   2034: dup
/*      */     //   2035: bipush #19
/*      */     //   2037: aconst_null
/*      */     //   2038: aastore
/*      */     //   2039: dup
/*      */     //   2040: bipush #20
/*      */     //   2042: aconst_null
/*      */     //   2043: aastore
/*      */     //   2044: dup
/*      */     //   2045: bipush #21
/*      */     //   2047: aconst_null
/*      */     //   2048: aastore
/*      */     //   2049: dup
/*      */     //   2050: bipush #22
/*      */     //   2052: aconst_null
/*      */     //   2053: aastore
/*      */     //   2054: dup
/*      */     //   2055: bipush #23
/*      */     //   2057: aconst_null
/*      */     //   2058: aastore
/*      */     //   2059: dup
/*      */     //   2060: bipush #24
/*      */     //   2062: aconst_null
/*      */     //   2063: aastore
/*      */     //   2064: dup
/*      */     //   2065: bipush #25
/*      */     //   2067: aconst_null
/*      */     //   2068: aastore
/*      */     //   2069: dup
/*      */     //   2070: bipush #26
/*      */     //   2072: aconst_null
/*      */     //   2073: aastore
/*      */     //   2074: dup
/*      */     //   2075: bipush #27
/*      */     //   2077: aconst_null
/*      */     //   2078: aastore
/*      */     //   2079: dup
/*      */     //   2080: bipush #28
/*      */     //   2082: aconst_null
/*      */     //   2083: aastore
/*      */     //   2084: dup
/*      */     //   2085: bipush #29
/*      */     //   2087: aconst_null
/*      */     //   2088: aastore
/*      */     //   2089: dup
/*      */     //   2090: bipush #30
/*      */     //   2092: aconst_null
/*      */     //   2093: aastore
/*      */     //   2094: dup
/*      */     //   2095: bipush #31
/*      */     //   2097: aconst_null
/*      */     //   2098: aastore
/*      */     //   2099: astore #64
/*      */     //   2101: iconst_0
/*      */     //   2102: istore #65
/*      */     //   2104: iload #65
/*      */     //   2106: bipush #32
/*      */     //   2108: if_icmpge -> 2139
/*      */     //   2111: aconst_null
/*      */     //   2112: aload #64
/*      */     //   2114: iload #65
/*      */     //   2116: aaload
/*      */     //   2117: if_acmpeq -> 2133
/*      */     //   2120: aload_1
/*      */     //   2121: iload #65
/*      */     //   2123: aload #64
/*      */     //   2125: iload #65
/*      */     //   2127: aaload
/*      */     //   2128: invokeinterface setREGIMMInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*      */     //   2133: iinc #65, 1
/*      */     //   2136: goto -> 2104
/*      */     //   2139: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #58	-> 0
/*      */     //   #61	-> 8
/*      */     //   #118	-> 26
/*      */     //   #155	-> 44
/*      */     //   #188	-> 63
/*      */     //   #240	-> 82
/*      */     //   #288	-> 101
/*      */     //   #322	-> 120
/*      */     //   #371	-> 139
/*      */     //   #394	-> 158
/*      */     //   #401	-> 177
/*      */     //   #424	-> 196
/*      */     //   #447	-> 215
/*      */     //   #470	-> 234
/*      */     //   #477	-> 253
/*      */     //   #524	-> 272
/*      */     //   #525	-> 289
/*      */     //   #564	-> 308
/*      */     //   #610	-> 327
/*      */     //   #619	-> 345
/*      */     //   #631	-> 363
/*      */     //   #647	-> 382
/*      */     //   #660	-> 401
/*      */     //   #688	-> 420
/*      */     //   #706	-> 439
/*      */     //   #734	-> 458
/*      */     //   #753	-> 477
/*      */     //   #770	-> 496
/*      */     //   #788	-> 514
/*      */     //   #789	-> 531
/*      */     //   #790	-> 548
/*      */     //   #883	-> 566
/*      */     //   #997	-> 584
/*      */     //   #1009	-> 603
/*      */     //   #1021	-> 622
/*      */     //   #1022	-> 640
/*      */     //   #1023	-> 658
/*      */     //   #1052	-> 677
/*      */     //   #1081	-> 696
/*      */     //   #1139	-> 715
/*      */     //   #1191	-> 734
/*      */     //   #1224	-> 753
/*      */     //   #1247	-> 772
/*      */     //   #1269	-> 791
/*      */     //   #1300	-> 810
/*      */     //   #1346	-> 829
/*      */     //   #1398	-> 848
/*      */     //   #1438	-> 867
/*      */     //   #1485	-> 886
/*      */     //   #1546	-> 905
/*      */     //   #1577	-> 924
/*      */     //   #1623	-> 943
/*      */     //   #1657	-> 962
/*      */     //   #1708	-> 981
/*      */     //   #1761	-> 1000
/*      */     //   #1811	-> 1019
/*      */     //   #1834	-> 1037
/*      */     //   #1835	-> 1054
/*      */     //   #1836	-> 1071
/*      */     //   #1927	-> 1089
/*      */     //   #2006	-> 1107
/*      */     //   #2007	-> 1124
/*      */     //   #2059	-> 1143
/*      */     //   #2094	-> 1162
/*      */     //   #2104	-> 1512
/*      */     //   #2105	-> 1522
/*      */     //   #2106	-> 1531
/*      */     //   #2104	-> 1544
/*      */     //   #2110	-> 1550
/*      */     //   #2120	-> 1898
/*      */     //   #2121	-> 1908
/*      */     //   #2122	-> 1917
/*      */     //   #2120	-> 1930
/*      */     //   #2126	-> 1936
/*      */     //   #2132	-> 2101
/*      */     //   #2133	-> 2111
/*      */     //   #2134	-> 2120
/*      */     //   #2132	-> 2133
/*      */     //   #2137	-> 2139
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   1515	35	65	i	I
/*      */     //   1901	35	65	i	I
/*      */     //   2104	35	65	i	I
/*      */     //   0	2140	0	this	Lorg/jpsx/runtime/components/hardware/r3000/R3000InstructionSet;
/*      */     //   0	2140	1	registrar	Lorg/jpsx/api/components/core/cpu/InstructionRegistrar;
/*      */     //   26	2114	2	i_add	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   44	2096	3	i_addi	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   63	2077	4	i_addiu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   82	2058	5	i_addu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   101	2039	6	i_and	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   120	2020	7	i_andi	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   139	2001	8	i_beq	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   158	1982	9	i_bgez	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   177	1963	10	i_bgezal	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   196	1944	11	i_bgtz	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   215	1925	12	i_blez	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   234	1906	13	i_bltz	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   253	1887	14	i_bltzal	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   272	1868	15	i_bne	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   289	1851	16	i_break	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   308	1832	17	i_div	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   327	1813	18	i_divu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   345	1795	19	i_j	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   363	1777	20	i_jal	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   382	1758	21	i_jalr	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   401	1739	22	i_jr	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   420	1720	23	i_lb	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   439	1701	24	i_lbu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   458	1682	25	i_lh	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   477	1663	26	i_lhu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   496	1644	27	i_lui	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   514	1626	28	i_lw	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   531	1609	29	i_lwc1	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   548	1592	30	i_lwc3	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   566	1574	31	i_lwl	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   584	1556	32	i_lwr	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   603	1537	33	i_mfhi	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   622	1518	34	i_mflo	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   640	1500	35	i_mthi	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   658	1482	36	i_mtlo	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   677	1463	37	i_mult	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   696	1444	38	i_multu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   715	1425	39	i_nor	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   734	1406	40	i_or	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   753	1387	41	i_ori	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   772	1368	42	i_sb	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   791	1349	43	i_sh	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   810	1330	44	i_sll	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   829	1311	45	i_sllv	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   848	1292	46	i_slt	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   867	1273	47	i_slti	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   886	1254	48	i_sltiu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   905	1235	49	i_sltu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   924	1216	50	i_sra	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   943	1197	51	i_srav	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   962	1178	52	i_srl	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   981	1159	53	i_srlv	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1000	1140	54	i_sub	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1019	1121	55	i_subu	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1037	1103	56	i_sw	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1054	1086	57	i_swc1	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1071	1069	58	i_swc3	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1089	1051	59	i_swl	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1107	1033	60	i_swr	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1124	1016	61	i_syscall	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1143	997	62	i_xor	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1162	978	63	i_xori	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*      */     //   1512	628	64	decoding	[Lorg/jpsx/api/components/core/cpu/CPUInstruction; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2140 */   private static final int bits_rs(int ci) { return ci >> 21 & 0x1F; }
/*      */ 
/*      */ 
/*      */   
/* 2144 */   private static final int bits_rt(int ci) { return ci >> 16 & 0x1F; }
/*      */ 
/*      */ 
/*      */   
/* 2148 */   private static final int bits_rd(int ci) { return ci >> 11 & 0x1F; }
/*      */ 
/*      */ 
/*      */   
/* 2152 */   private static final int bits_sa(int ci) { return ci >> 6 & 0x1F; }
/*      */ 
/*      */ 
/*      */   
/* 2156 */   private static final boolean mask_bit31(int x) { return (x < 0); }
/*      */ 
/*      */ 
/*      */   
/* 2160 */   private static final int bits25_6(int x) { return x >> 6 & 0xFFFFF; }
/*      */ 
/*      */ 
/*      */   
/* 2164 */   private static final int sign_extend(int x) { return x << 16 >> 16; }
/*      */ 
/*      */ 
/*      */   
/* 2168 */   private static final int signed_branch_delta(int x) { return sign_extend(x) << 2; }
/*      */ 
/*      */ 
/*      */   
/* 2172 */   private static final int lo(int x) { return x & 0xFFFF; }
/*      */ 
/*      */ 
/*      */   
/* 2176 */   private static final long longFromUnsigned(int x) { return x & 0xFFFFFFFFL; }
/*      */ 
/*      */   
/*      */   public static void interpret_add(int ci) {
/* 2180 */     int rs = bits_rs(ci);
/* 2181 */     int rt = bits_rt(ci);
/* 2182 */     int rd = bits_rd(ci);
/*      */     
/* 2184 */     int res = Refs.r3000Regs[rs] + Refs.r3000Regs[rt];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2194 */     if (rd != 0) {
/* 2195 */       Refs.r3000Regs[rd] = res;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_addi(int ci) {
/* 2200 */     int rs = bits_rs(ci);
/* 2201 */     int rt = bits_rt(ci);
/* 2202 */     int imm = sign_extend(ci);
/*      */     
/* 2204 */     int res = Refs.r3000Regs[rs] + imm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2214 */     if (rt != 0) {
/* 2215 */       Refs.r3000Regs[rt] = res;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void interpret_addiu(int ci) {
/* 2225 */     int rs = bits_rs(ci);
/* 2226 */     int rt = bits_rt(ci);
/* 2227 */     int imm = sign_extend(ci);
/*      */     
/* 2229 */     if (rt != 0) {
/* 2230 */       Refs.r3000Regs[rt] = Refs.r3000Regs[rs] + imm;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_addu(int ci) {
/* 2235 */     int rs = bits_rs(ci);
/* 2236 */     int rt = bits_rt(ci);
/* 2237 */     int rd = bits_rd(ci);
/*      */     
/* 2239 */     if (rd != 0) {
/* 2240 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rs] + Refs.r3000Regs[rt];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_and(int ci) {
/* 2245 */     int rs = bits_rs(ci);
/* 2246 */     int rt = bits_rt(ci);
/* 2247 */     int rd = bits_rd(ci);
/*      */     
/* 2249 */     if (rd != 0) {
/* 2250 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rs] & Refs.r3000Regs[rt];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_andi(int ci) {
/* 2255 */     int rs = bits_rs(ci);
/* 2256 */     int rt = bits_rt(ci);
/* 2257 */     int imm = lo(ci);
/*      */     
/* 2259 */     if (rt != 0) {
/* 2260 */       Refs.r3000Regs[rt] = Refs.r3000Regs[rs] & imm;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_beq(int ci) {
/* 2265 */     int rs = bits_rs(ci);
/* 2266 */     int rt = bits_rt(ci);
/*      */     
/* 2268 */     if (Refs.r3000Regs[rs] == Refs.r3000Regs[rt])
/* 2269 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci)); 
/*      */   }
/*      */   
/*      */   public static void interpret_bgez(int ci) {
/* 2273 */     int rs = bits_rs(ci);
/*      */     
/* 2275 */     if (Refs.r3000Regs[rs] >= 0)
/* 2276 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci)); 
/*      */   }
/*      */   
/*      */   public static void interpret_bgezal(int ci) {
/* 2280 */     int rs = bits_rs(ci);
/*      */     
/* 2282 */     if (Refs.r3000Regs[rs] >= 0) {
/* 2283 */       Refs.r3000Regs[31] = Refs.r3000.getPC() + 8;
/* 2284 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci));
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_bgtz(int ci) {
/* 2289 */     int rs = bits_rs(ci);
/*      */     
/* 2291 */     if (Refs.r3000Regs[rs] > 0)
/* 2292 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci)); 
/*      */   }
/*      */   
/*      */   public static void interpret_blez(int ci) {
/* 2296 */     int rs = bits_rs(ci);
/*      */     
/* 2298 */     if (Refs.r3000Regs[rs] <= 0)
/* 2299 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci)); 
/*      */   }
/*      */   
/*      */   public static void interpret_bltz(int ci) {
/* 2303 */     int rs = bits_rs(ci);
/*      */     
/* 2305 */     if (Refs.r3000Regs[rs] < 0)
/* 2306 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci)); 
/*      */   }
/*      */   
/*      */   public static void interpret_bltzal(int ci) {
/* 2310 */     int rs = bits_rs(ci);
/*      */     
/* 2312 */     if (Refs.r3000Regs[rs] < 0) {
/* 2313 */       Refs.r3000Regs[31] = Refs.r3000.getPC() + 8;
/* 2314 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci));
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_bne(int ci) {
/* 2319 */     int rs = bits_rs(ci);
/* 2320 */     int rt = bits_rt(ci);
/*      */     
/* 2322 */     if (Refs.r3000Regs[rs] != Refs.r3000Regs[rt]) {
/* 2323 */       Refs.r3000.interpreterBranch(signed_branch_delta(ci));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void interpret_break(int ci) {
/* 2331 */     breakHotspot = false;
/* 2332 */     Refs.scp.signalBreakException();
/*      */   }
/*      */   
/*      */   public static void interpret_div(int ci) {
/* 2336 */     int rs = bits_rs(ci);
/* 2337 */     int rt = bits_rt(ci);
/*      */ 
/*      */     
/* 2340 */     if (Refs.r3000Regs[rt] != 0) {
/* 2341 */       Refs.r3000.setLO(Refs.r3000Regs[rs] / Refs.r3000Regs[rt]);
/* 2342 */       Refs.r3000.setHI(Refs.r3000Regs[rs] % Refs.r3000Regs[rt]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_divu(int ci) {
/* 2347 */     int rs = bits_rs(ci);
/* 2348 */     int rt = bits_rt(ci);
/*      */ 
/*      */     
/* 2351 */     if (Refs.r3000Regs[rt] != 0) {
/* 2352 */       long a = longFromUnsigned(Refs.r3000Regs[rs]);
/* 2353 */       long b = longFromUnsigned(Refs.r3000Regs[rt]);
/* 2354 */       Refs.r3000.setLO((int)(a / b));
/* 2355 */       Refs.r3000.setHI((int)(a % b));
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_j(int ci) {
/* 2360 */     int delay = Refs.r3000.getPC() + 4;
/* 2361 */     int target = delay & 0xF0000000;
/* 2362 */     target += ((ci & 0x3FFFFFF) << 2);
/* 2363 */     Refs.r3000.interpreterBranch(target - delay);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void interpret_jal(int ci) {
/* 2368 */     int pc = Refs.r3000.getPC();
/* 2369 */     int delay = pc + 4;
/* 2370 */     int target = delay & 0xF0000000;
/* 2371 */     target += ((ci & 0x3FFFFFF) << 2);
/*      */     
/* 2373 */     Refs.addressSpace.tagClearPollCounters();
/* 2374 */     Refs.r3000Regs[31] = pc + 8;
/* 2375 */     Refs.r3000.interpreterJumpAndLink(target - delay, target, pc + 8);
/*      */   }
/*      */   
/*      */   public static void interpret_jalr(int ci) {
/* 2379 */     int rs = bits_rs(ci);
/* 2380 */     int rd = bits_rd(ci);
/* 2381 */     int pc = Refs.r3000.getPC();
/* 2382 */     if (rd != 0) {
/* 2383 */       Refs.r3000Regs[rd] = pc + 8;
/*      */     }
/* 2385 */     Refs.addressSpace.tagClearPollCounters();
/* 2386 */     int delay = pc + 4;
/* 2387 */     int target = Refs.r3000Regs[rs];
/* 2388 */     Refs.r3000.interpreterJumpAndLink(target - delay, target, pc + 8);
/*      */   }
/*      */   
/*      */   public static void interpret_jr(int ci) {
/* 2392 */     int rs = bits_rs(ci);
/*      */     
/* 2394 */     int target = Refs.r3000Regs[rs];
/* 2395 */     int delay = Refs.r3000.getPC() + 4;
/* 2396 */     Refs.r3000.interpreterJump(target - delay, target);
/*      */   }
/*      */   
/*      */   public static void interpret_lb(int ci) {
/* 2400 */     int base = bits_rs(ci);
/* 2401 */     int rt = bits_rt(ci);
/* 2402 */     int offset = sign_extend(ci);
/* 2403 */     int addr = Refs.r3000Regs[base] + offset;
/* 2404 */     if (base != 29) {
/* 2405 */       Refs.addressSpace.tagAddressAccessRead8(Refs.r3000.getPC(), addr);
/*      */     }
/* 2407 */     int value = Refs.addressSpace.read8(addr);
/*      */     
/* 2409 */     if (rt != 0) {
/* 2410 */       value = value << 24 >> 24;
/* 2411 */       Refs.r3000Regs[rt] = value;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_lbu(int ci) {
/* 2416 */     int base = bits_rs(ci);
/* 2417 */     int rt = bits_rt(ci);
/* 2418 */     int offset = sign_extend(ci);
/* 2419 */     int addr = Refs.r3000Regs[base] + offset;
/* 2420 */     if (base != 29) {
/* 2421 */       Refs.addressSpace.tagAddressAccessRead8(Refs.r3000.getPC(), addr);
/*      */     }
/* 2423 */     int value = Refs.addressSpace.read8(addr);
/*      */     
/* 2425 */     if (rt != 0) {
/* 2426 */       Refs.r3000Regs[rt] = value;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_lh(int ci) {
/* 2431 */     int base = bits_rs(ci);
/* 2432 */     int rt = bits_rt(ci);
/* 2433 */     int offset = sign_extend(ci);
/* 2434 */     int addr = Refs.r3000Regs[base] + offset;
/* 2435 */     if (base != 29) {
/* 2436 */       Refs.addressSpace.tagAddressAccessRead16(Refs.r3000.getPC(), addr);
/*      */     }
/* 2438 */     int value = Refs.addressSpace.read16(addr);
/*      */     
/* 2440 */     if (rt != 0) {
/* 2441 */       value = value << 16 >> 16;
/* 2442 */       Refs.r3000Regs[rt] = value;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void interpret_lhu(int ci) {
/* 2447 */     int base = bits_rs(ci);
/* 2448 */     int rt = bits_rt(ci);
/* 2449 */     int offset = sign_extend(ci);
/* 2450 */     int addr = Refs.r3000Regs[base] + offset;
/* 2451 */     if (base != 29) {
/* 2452 */       Refs.addressSpace.tagAddressAccessRead16(Refs.r3000.getPC(), addr);
/*      */     }
/* 2454 */     int value = Refs.addressSpace.read16(addr);
/*      */     
/* 2456 */     if (rt != 0) {
/* 2457 */       Refs.r3000Regs[rt] = value;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_lui(int ci) {
/* 2462 */     int rt = bits_rt(ci);
/* 2463 */     if (rt != 0) {
/* 2464 */       Refs.r3000Regs[rt] = ci << 16;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_lw(int ci) {
/* 2469 */     int base = bits_rs(ci);
/* 2470 */     int rt = bits_rt(ci);
/* 2471 */     int offset = sign_extend(ci);
/* 2472 */     int addr = Refs.r3000Regs[base] + offset;
/* 2473 */     if (base != 29) {
/* 2474 */       Refs.addressSpace.tagAddressAccessRead32(Refs.r3000.getPC(), addr);
/*      */     }
/* 2476 */     int value = Refs.addressSpace.read32(addr);
/* 2477 */     if (rt != 0) {
/* 2478 */       Refs.r3000Regs[rt] = value;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_lwc1(int ci) {
/* 2483 */     breakHotspot = false;
/* 2484 */     Refs.scp.signalReservedInstructionException();
/*      */   }
/*      */   
/*      */   public static void interpret_lwc3(int ci) {
/* 2488 */     breakHotspot = false;
/* 2489 */     Refs.scp.signalReservedInstructionException();
/*      */   }
/*      */   
/* 2492 */   private static final int[] lwl_mask = { 16777215, 65535, 255, 0 };
/* 2493 */   private static final int[] lwl_shift = { 24, 16, 8, 0 };
/*      */   
/*      */   public static void interpret_lwl(int ci) {
/* 2496 */     int base = bits_rs(ci);
/* 2497 */     int rt = bits_rt(ci);
/* 2498 */     int offset = sign_extend(ci);
/* 2499 */     int addr = Refs.r3000Regs[base] + offset;
/* 2500 */     if (base != 29) {
/* 2501 */       Refs.addressSpace.tagAddressAccessRead32(Refs.r3000.getPC(), addr);
/*      */     }
/* 2503 */     int value = Refs.addressSpace.read32(addr & 0xFFFFFFFC);
/* 2504 */     if (rt != 0) {
/* 2505 */       Refs.r3000Regs[rt] = Refs.r3000Regs[rt] & lwl_mask[addr & 0x3] | value << lwl_shift[addr & 0x3];
/*      */     }
/*      */   }
/*      */   
/* 2509 */   private static final int[] lwr_mask = { 0, -16777216, -65536, -256 };
/* 2510 */   private static final int[] lwr_shift = { 0, 8, 16, 24 };
/*      */   
/*      */   public static void interpret_lwr(int ci) {
/* 2513 */     int base = bits_rs(ci);
/* 2514 */     int rt = bits_rt(ci);
/* 2515 */     int offset = sign_extend(ci);
/* 2516 */     int addr = Refs.r3000Regs[base] + offset;
/* 2517 */     if (base != 29) {
/* 2518 */       Refs.addressSpace.tagAddressAccessRead32(Refs.r3000.getPC(), addr);
/*      */     }
/* 2520 */     int value = Refs.addressSpace.read32(addr & 0xFFFFFFFC);
/* 2521 */     if (rt != 0) {
/* 2522 */       Refs.r3000Regs[rt] = Refs.r3000Regs[rt] & lwr_mask[addr & 0x3] | value >> lwr_shift[addr & 0x3] & (lwr_mask[addr & 0x3] ^ 0xFFFFFFFF);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_mfhi(int ci) {
/* 2527 */     int rd = bits_rd(ci);
/* 2528 */     Refs.r3000Regs[rd] = Refs.r3000.getHI();
/*      */   }
/*      */   
/*      */   public static void interpret_mflo(int ci) {
/* 2532 */     int rd = bits_rd(ci);
/* 2533 */     Refs.r3000Regs[rd] = Refs.r3000.getLO();
/*      */   }
/*      */   
/*      */   public static void interpret_mthi(int ci) {
/* 2537 */     int rs = bits_rs(ci);
/* 2538 */     Refs.r3000.setHI(Refs.r3000Regs[rs]);
/*      */   }
/*      */   
/*      */   public static void interpret_mtlo(int ci) {
/* 2542 */     int rs = bits_rs(ci);
/* 2543 */     Refs.r3000.setLO(Refs.r3000Regs[rs]);
/*      */   }
/*      */   
/*      */   public static void interpret_mult(int ci) {
/* 2547 */     int rs = bits_rs(ci);
/* 2548 */     int rt = bits_rt(ci);
/*      */     
/* 2550 */     long result = Refs.r3000Regs[rs] * Refs.r3000Regs[rt];
/* 2551 */     Refs.r3000.setLO((int)result);
/* 2552 */     Refs.r3000.setHI((int)(result >> 32));
/*      */   }
/*      */   
/*      */   public static void interpret_multu(int ci) {
/* 2556 */     int rs = bits_rs(ci);
/* 2557 */     int rt = bits_rt(ci);
/*      */     
/* 2559 */     long result = longFromUnsigned(Refs.r3000Regs[rs]) * longFromUnsigned(Refs.r3000Regs[rt]);
/* 2560 */     Refs.r3000.setLO((int)result);
/* 2561 */     Refs.r3000.setHI((int)(result >> 32));
/*      */   }
/*      */   
/*      */   public static void interpret_nor(int ci) {
/* 2565 */     int rs = bits_rs(ci);
/* 2566 */     int rt = bits_rt(ci);
/* 2567 */     int rd = bits_rd(ci);
/* 2568 */     if (rd != 0) {
/* 2569 */       Refs.r3000Regs[rd] = (Refs.r3000Regs[rs] | Refs.r3000Regs[rt]) ^ 0xFFFFFFFF;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_or(int ci) {
/* 2574 */     int rs = bits_rs(ci);
/* 2575 */     int rt = bits_rt(ci);
/* 2576 */     int rd = bits_rd(ci);
/* 2577 */     if (rd != 0) {
/* 2578 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rs] | Refs.r3000Regs[rt];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_ori(int ci) {
/* 2583 */     int rs = bits_rs(ci);
/* 2584 */     int rt = bits_rt(ci);
/* 2585 */     if (rt != 0) {
/* 2586 */       Refs.r3000Regs[rt] = Refs.r3000Regs[rs] | lo(ci);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sb(int ci) {
/* 2591 */     int base = bits_rs(ci);
/* 2592 */     int rt = bits_rt(ci);
/* 2593 */     int offset = sign_extend(ci);
/* 2594 */     int addr = Refs.r3000Regs[base] + offset;
/* 2595 */     if (base != 29) {
/* 2596 */       Refs.addressSpace.tagAddressAccessWrite(Refs.r3000.getPC(), addr);
/*      */     }
/* 2598 */     Refs.addressSpace.write8(addr, Refs.r3000Regs[rt]);
/*      */   }
/*      */   
/*      */   public static void interpret_sh(int ci) {
/* 2602 */     int base = bits_rs(ci);
/* 2603 */     int rt = bits_rt(ci);
/* 2604 */     int offset = sign_extend(ci);
/* 2605 */     int addr = Refs.r3000Regs[base] + offset;
/* 2606 */     if (base != 29) {
/* 2607 */       Refs.addressSpace.tagAddressAccessWrite(Refs.r3000.getPC(), addr);
/*      */     }
/* 2609 */     Refs.addressSpace.write16(addr, Refs.r3000Regs[rt]);
/*      */   }
/*      */   
/*      */   public static void interpret_sll(int ci) {
/* 2613 */     if (ci == 0)
/*      */       return; 
/* 2615 */     int rd = bits_rd(ci);
/* 2616 */     int rt = bits_rt(ci);
/* 2617 */     int sa = bits_sa(ci);
/* 2618 */     if (rd != 0) {
/* 2619 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rt] << sa;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sllv(int ci) {
/* 2624 */     int rd = bits_rd(ci);
/* 2625 */     int rt = bits_rt(ci);
/* 2626 */     int rs = bits_rs(ci);
/* 2627 */     if (rd != 0) {
/* 2628 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rt] << (Refs.r3000Regs[rs] & 0x1F);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_slt(int ci) {
/* 2633 */     int rs = bits_rs(ci);
/* 2634 */     int rt = bits_rt(ci);
/* 2635 */     int rd = bits_rd(ci);
/* 2636 */     if (rd != 0) {
/* 2637 */       Refs.r3000Regs[rd] = (Refs.r3000Regs[rs] < Refs.r3000Regs[rt]) ? 1 : 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_slti(int ci) {
/* 2642 */     int rs = bits_rs(ci);
/* 2643 */     int rt = bits_rt(ci);
/* 2644 */     int imm = sign_extend(ci);
/* 2645 */     if (rt != 0) {
/* 2646 */       Refs.r3000Regs[rt] = (Refs.r3000Regs[rs] < imm) ? 1 : 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sltiu(int ci) {
/* 2651 */     int rs = bits_rs(ci);
/* 2652 */     int rt = bits_rt(ci);
/* 2653 */     int imm = lo(ci);
/* 2654 */     if (rt != 0) {
/* 2655 */       Refs.r3000Regs[rt] = (longFromUnsigned(Refs.r3000Regs[rs]) < imm) ? 1 : 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sltu(int ci) {
/* 2660 */     int rs = bits_rs(ci);
/* 2661 */     int rt = bits_rt(ci);
/* 2662 */     int rd = bits_rd(ci);
/* 2663 */     if (rd != 0) {
/* 2664 */       Refs.r3000Regs[rd] = (longFromUnsigned(Refs.r3000Regs[rs]) < longFromUnsigned(Refs.r3000Regs[rt])) ? 1 : 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_srl(int ci) {
/* 2669 */     int sa = bits_sa(ci);
/* 2670 */     int rt = bits_rt(ci);
/* 2671 */     int rd = bits_rd(ci);
/* 2672 */     if (rd != 0) {
/* 2673 */       Refs.r3000Regs[rd] = (int)(longFromUnsigned(Refs.r3000Regs[rt]) >> sa);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_srlv(int ci) {
/* 2678 */     int rs = bits_rs(ci);
/* 2679 */     int rt = bits_rt(ci);
/* 2680 */     int rd = bits_rd(ci);
/* 2681 */     if (rd != 0) {
/* 2682 */       Refs.r3000Regs[rd] = (int)(longFromUnsigned(Refs.r3000Regs[rt]) >> Refs.r3000Regs[rs]);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sra(int ci) {
/* 2687 */     int sa = bits_sa(ci);
/* 2688 */     int rt = bits_rt(ci);
/* 2689 */     int rd = bits_rd(ci);
/* 2690 */     if (rd != 0) {
/* 2691 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rt] >> sa;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_srav(int ci) {
/* 2696 */     int rs = bits_rs(ci);
/* 2697 */     int rt = bits_rt(ci);
/* 2698 */     int rd = bits_rd(ci);
/* 2699 */     if (rd != 0) {
/* 2700 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rt] >> Refs.r3000Regs[rs];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sub(int ci) {
/* 2705 */     int rs = bits_rs(ci);
/* 2706 */     int rt = bits_rt(ci);
/* 2707 */     int rd = bits_rd(ci);
/*      */     
/* 2709 */     int res = Refs.r3000Regs[rs] - Refs.r3000Regs[rt];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2719 */     if (rd != 0) {
/* 2720 */       Refs.r3000Regs[rd] = res;
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_subu(int ci) {
/* 2725 */     int rs = bits_rs(ci);
/* 2726 */     int rt = bits_rt(ci);
/* 2727 */     int rd = bits_rd(ci);
/*      */     
/* 2729 */     if (rd != 0) {
/* 2730 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rs] - Refs.r3000Regs[rt];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_sw(int ci) {
/* 2735 */     int base = bits_rs(ci);
/* 2736 */     int rt = bits_rt(ci);
/* 2737 */     int offset = sign_extend(ci);
/* 2738 */     int addr = Refs.r3000Regs[base] + offset;
/* 2739 */     if (base != 29) {
/* 2740 */       Refs.addressSpace.tagAddressAccessWrite(Refs.r3000.getPC(), addr);
/*      */     }
/* 2742 */     Refs.addressSpace.write32(addr, Refs.r3000Regs[rt]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void interpret_swc1(int ci) {
/* 2752 */     breakHotspot = false;
/* 2753 */     Refs.scp.signalReservedInstructionException();
/*      */   }
/*      */   
/*      */   public static void interpret_swc3(int ci) {
/* 2757 */     breakHotspot = false;
/* 2758 */     Refs.scp.signalReservedInstructionException();
/*      */   }
/*      */   
/* 2761 */   private static final int[] swl_mask = { -256, -65536, -16777216, 0 };
/* 2762 */   private static final int[] swl_shift = { 24, 16, 8, 0 };
/*      */   
/*      */   public static void interpret_swl(int ci) {
/* 2765 */     int base = bits_rs(ci);
/* 2766 */     int rt = bits_rt(ci);
/* 2767 */     int offset = sign_extend(ci);
/* 2768 */     int addr = Refs.r3000Regs[base] + offset;
/* 2769 */     Refs.addressSpace.tagAddressAccessWrite(Refs.r3000.getPC(), addr);
/* 2770 */     int value = Refs.addressSpace.read32(addr & 0xFFFFFFFC);
/* 2771 */     value = value & swl_mask[addr & 0x3] | Refs.r3000Regs[rt] >> swl_shift[addr & 0x3] & (swl_mask[addr & 0x3] ^ 0xFFFFFFFF);
/* 2772 */     Refs.addressSpace.write32(addr & 0xFFFFFFFC, value);
/*      */   }
/*      */   
/* 2775 */   private static final int[] swr_mask = { 0, 255, 65535, 16777215 };
/* 2776 */   private static final int[] swr_shift = { 0, 8, 16, 24 };
/*      */   
/*      */   public static void interpret_swr(int ci) {
/* 2779 */     int base = bits_rs(ci);
/* 2780 */     int rt = bits_rt(ci);
/* 2781 */     int offset = sign_extend(ci);
/* 2782 */     int addr = Refs.r3000Regs[base] + offset;
/* 2783 */     Refs.addressSpace.tagAddressAccessWrite(Refs.r3000.getPC(), addr);
/* 2784 */     int value = Refs.addressSpace.read32(addr & 0xFFFFFFFC);
/* 2785 */     value = value & swr_mask[addr & 0x3] | Refs.r3000Regs[rt] << swr_shift[addr & 0x3];
/* 2786 */     Refs.addressSpace.write32(addr & 0xFFFFFFFC, value);
/*      */   }
/*      */   
/*      */   public static void interpret_syscall(int ci) {
/* 2790 */     breakHotspot = false;
/* 2791 */     Refs.scp.signalSyscallException();
/*      */   }
/*      */   
/*      */   public static void interpret_xor(int ci) {
/* 2795 */     int rs = bits_rs(ci);
/* 2796 */     int rt = bits_rt(ci);
/* 2797 */     int rd = bits_rd(ci);
/* 2798 */     if (rd != 0) {
/* 2799 */       Refs.r3000Regs[rd] = Refs.r3000Regs[rs] ^ Refs.r3000Regs[rt];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void interpret_xori(int ci) {
/* 2804 */     int rs = bits_rs(ci);
/* 2805 */     int rt = bits_rt(ci);
/* 2806 */     if (rt != 0) {
/* 2807 */       Refs.r3000Regs[rt] = Refs.r3000Regs[rs] ^ lo(ci);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void emitLongFromUnsigned(ConstantPoolGen cp, InstructionList il) {
/* 2812 */     il.append(new I2L());
/* 2813 */     il.append(new PUSH(cp, 4294967295L));
/* 2814 */     il.append(new LAND());
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\r3000\R3000InstructionSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */