/*      */ package classes.runtime.org.jpsx.runtime.components.hardware.spu;
/*      */ 
/*      */ import javax.sound.sampled.AudioFormat;
/*      */ import javax.sound.sampled.AudioSystem;
/*      */ import javax.sound.sampled.DataLine;
/*      */ import javax.sound.sampled.FloatControl;
/*      */ import javax.sound.sampled.SourceDataLine;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*      */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*      */ import org.jpsx.api.components.core.scheduler.Quartz;
/*      */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*      */ import org.jpsx.api.components.hardware.cd.CDAudioSink;
/*      */ import org.jpsx.runtime.SingletonJPSXComponent;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*      */ import org.jpsx.runtime.components.hardware.spu.SPU;
/*      */ import org.jpsx.runtime.util.MiscUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SPU
/*      */   extends SingletonJPSXComponent
/*      */   implements MemoryMapped, CDAudioSink
/*      */ {
/*   44 */   private static final Logger log = Logger.getLogger("SPU");
/*      */   
/*      */   private static final boolean noVoices = false;
/*      */   
/*      */   private static final boolean debugEnvelope = false;
/*      */   
/*      */   private static final boolean debugVoiceOnOff = false;
/*      */   
/*      */   private static final boolean debugDMA = false;
/*      */   
/*      */   private static final int ADDR_VOICES = 528489472;
/*      */   
/*      */   private static final int ADDR_MAIN_VOL_L = 528489856;
/*      */   
/*      */   private static final int ADDR_MAIN_VOL_R = 528489858;
/*      */   
/*      */   private static final int ADDR_REVERB_L = 528489860;
/*      */   
/*      */   private static final int ADDR_REVERB_R = 528489862;
/*      */   
/*      */   private static final int ADDR_CHANNEL_ON0 = 528489864;
/*      */   
/*      */   private static final int ADDR_CHANNEL_ON1 = 528489866;
/*      */   private static final int ADDR_CHANNEL_OFF0 = 528489868;
/*      */   private static final int ADDR_CHANNEL_OFF1 = 528489870;
/*      */   private static final int ADDR_CHANNEL_FM0 = 528489872;
/*      */   private static final int ADDR_CHANNEL_FM1 = 528489874;
/*      */   private static final int ADDR_CHANNEL_NOISE0 = 528489876;
/*      */   private static final int ADDR_CHANNEL_NOISE1 = 528489878;
/*      */   private static final int ADDR_CHANNEL_REVERB0 = 528489880;
/*      */   private static final int ADDR_CHANNEL_REVERB1 = 528489882;
/*      */   private static final int ADDR_CHANNEL_MUTE0 = 528489884;
/*      */   private static final int ADDR_CHANNEL_MUTE1 = 528489886;
/*      */   private static final int ADDR_TRANSFER_ADDR = 528489894;
/*      */   private static final int ADDR_TRANSFER_DATA = 528489896;
/*      */   private static final int ADDR_SPU_CTRL = 528489898;
/*      */   private static final int ADDR_SPU_STATUS = 528489902;
/*      */   private static final int ADDR_CD_VOL_L = 528489904;
/*      */   private static final int ADDR_CD_VOL_R = 528489906;
/*      */   private static final int VOICES = 24;
/*      */   private static final int VOICE_VOL_L = 0;
/*      */   private static final int VOICE_VOL_R = 2;
/*      */   private static final int VOICE_PITCH = 4;
/*      */   private static final int VOICE_START_OFFSET = 6;
/*      */   private static final int VOICE_ADS_LEVEL = 8;
/*      */   private static final int VOICE_SR_RATE = 10;
/*      */   private static final int VOICE_ADSR_VOL = 12;
/*      */   private static final int VOICE_REPEAT_OFFSET = 14;
/*      */   private static final int SAMPLE_RATE = 44100;
/*      */   private static final int MIN_BUFFER_SAMPLE_RATE = 16000;
/*      */   private static final int BUFFER_MS = 240;
/*      */   private static final long BUFFER_REFILL_PERIOD_NS = 30000000L;
/*      */   private static final int BUFFER_MAX_FILL_MS = 240;
/*      */   private static final int BUFFER_MAX_REFILL_MS = 80;
/*      */   private static final int BUFFER_SAMPLES = 10584;
/*      */   private static final int CD_BUFFER_SAMPLES = 22050;
/*  100 */   private static final byte[] cdAudioBuffer = new byte[37632];
/*      */   private static SourceDataLine cdline;
/*      */   private static int cdlineFreq;
/*      */   private static FloatControl cdPanControl;
/*      */   private static FloatControl cdGainControl;
/*  105 */   private static int cdLeftVol = 0;
/*  106 */   private static int cdRightVol = 0;
/*  107 */   private static int cdLeftVolExternal = 16383;
/*  108 */   private static int cdRightVolExternal = 16383;
/*      */   
/*      */   private static int m_ctrl;
/*      */   
/*      */   private static int m_transferOffset;
/*      */   private static int m_dataTransferWordOffset;
/*  114 */   private static int[] m_ram = new int[131072];
/*  115 */   private static short[] m_decoded = new short[1048576];
/*      */ 
/*      */   
/*  118 */   private static Voice[] voices = new Voice[24];
/*      */   
/*      */   private static boolean cdAudio = true;
/*      */   
/*      */   private static boolean voiceAudio = true;
/*      */   
/*      */   public static final String PROPERTY_CD_AUDIO = "cdAudio";
/*      */   public static final String PROPERTY_VOICE_AUDIO = "voiceAudio";
/*      */   private static int mainLeftVol;
/*      */   private static int mainRightVol;
/*      */   private static AddressSpace addressSpace;
/*      */   private static Quartz quartz;
/*      */   private static Scheduler scheduler;
/*      */   static boolean toggle;
/*      */   
/*  133 */   public SPU() { super("JPSX JavaSound SPU"); }
/*      */ 
/*      */   
/*      */   public void init() {
/*  137 */     super.init();
/*  138 */     cdAudio = getBooleanProperty("cdAudio", true);
/*  139 */     voiceAudio = getBooleanProperty("voiceAudio", true);
/*  140 */     log.info("Voice Audio " + (voiceAudio ? "ON" : "OFF"));
/*  141 */     log.info("CD Audio " + (cdAudio ? "ON" : "OFF"));
/*  142 */     if (cdAudio) {
/*  143 */       HardwareComponentConnections.CD_AUDIO_SINK.set(this);
/*      */     }
/*  145 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*  146 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new SPUDMAChannel(null));
/*      */   }
/*      */   
/*      */   public void resolveConnections() {
/*  150 */     super.resolveConnections();
/*  151 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*  152 */     quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/*  153 */     scheduler = (Scheduler)CoreComponentConnections.SCHEDULER.resolve();
/*      */   }
/*      */   
/*      */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/*  157 */     for (int i = 0; i < 24; i++) {
/*  158 */       voices[i] = new Voice(i);
/*  159 */       int base = 528489472 + i * 16;
/*  160 */       registrar.registerWrite16Callback(base + 0, SPU.class, "writeVolLeft");
/*  161 */       registrar.registerWrite16Callback(base + 2, SPU.class, "writeVolRight");
/*  162 */       registrar.registerWrite16Callback(base + 4, SPU.class, "writePitch");
/*  163 */       registrar.registerWrite16Callback(base + 6, SPU.class, "writeStartOffset");
/*  164 */       registrar.registerWrite16Callback(base + 8, SPU.class, "writeADSLevel");
/*  165 */       registrar.registerWrite16Callback(base + 10, SPU.class, "writeSRRate");
/*  166 */       registrar.registerRead16Callback(base + 12, SPU.class, "readADSRVol");
/*  167 */       registrar.registerWrite16Callback(base + 14, SPU.class, "writeRepeatOffset");
/*      */       
/*  169 */       registrar.registerRead16Callback(base + 0, SPU.class, "readVolLeft");
/*  170 */       registrar.registerRead16Callback(base + 2, SPU.class, "readVolRight");
/*  171 */       registrar.registerRead16Callback(base + 4, SPU.class, "readPitch");
/*  172 */       registrar.registerRead16Callback(base + 6, SPU.class, "readStartOffset");
/*  173 */       registrar.registerRead16Callback(base + 8, SPU.class, "readADSLevel");
/*  174 */       registrar.registerRead16Callback(base + 10, SPU.class, "readSRRate");
/*  175 */       registrar.registerRead16Callback(base + 14, SPU.class, "readRepeatOffset");
/*      */     } 
/*  177 */     registrar.registerWrite16Callback(528489856, SPU.class, "writeMainVolLeft");
/*  178 */     registrar.registerWrite16Callback(528489858, SPU.class, "writeMainVolRight");
/*  179 */     registrar.registerWrite16Callback(528489860, SPU.class, "writeReverbLeft");
/*  180 */     registrar.registerWrite16Callback(528489862, SPU.class, "writeReverbRight");
/*  181 */     registrar.registerWrite16Callback(528489864, SPU.class, "writeChannelOn0");
/*  182 */     registrar.registerWrite16Callback(528489866, SPU.class, "writeChannelOn1");
/*  183 */     registrar.registerWrite16Callback(528489868, SPU.class, "writeChannelOff0");
/*  184 */     registrar.registerWrite16Callback(528489870, SPU.class, "writeChannelOff1");
/*  185 */     registrar.registerWrite16Callback(528489872, SPU.class, "writeChannelFM0");
/*  186 */     registrar.registerWrite16Callback(528489874, SPU.class, "writeChannelFM1");
/*  187 */     registrar.registerWrite16Callback(528489876, SPU.class, "writeChannelNoise0");
/*  188 */     registrar.registerWrite16Callback(528489878, SPU.class, "writeChannelNoise1");
/*  189 */     registrar.registerWrite16Callback(528489880, SPU.class, "writeChannelReverb0");
/*  190 */     registrar.registerWrite16Callback(528489882, SPU.class, "writeChannelReverb1");
/*  191 */     registrar.registerWrite16Callback(528489884, SPU.class, "writeChannelMute0");
/*  192 */     registrar.registerWrite16Callback(528489886, SPU.class, "writeChannelMute1");
/*      */     
/*  194 */     registrar.registerWrite16Callback(528489898, SPU.class, "writeSPUCtrl");
/*  195 */     registrar.registerRead16Callback(528489898, SPU.class, "readSPUCtrl");
/*      */     
/*  197 */     registrar.registerWrite16Callback(528489904, SPU.class, "writeCDVolL");
/*  198 */     registrar.registerWrite16Callback(528489906, SPU.class, "writeCDVolR");
/*      */     
/*  200 */     registrar.registerRead16Callback(528489902, SPU.class, "readSPUStatus");
/*      */     
/*  202 */     registrar.registerWrite16Callback(528489894, SPU.class, "writeTransferAddr");
/*  203 */     registrar.registerWrite16Callback(528489896, SPU.class, "writeTransferData");
/*  204 */     registrar.registerRead16Callback(528489894, SPU.class, "readTransferAddr");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  209 */   public void begin() { (new SPUCallback()).start(); }
/*      */ 
/*      */   
/*      */   public static void writeVolLeft(int address, int val) {
/*  213 */     int voice = address - 528489472 >> 4;
/*  214 */     voices[voice].setLeftVol(val);
/*      */   }
/*      */   
/*      */   public static void writeVolRight(int address, int val) {
/*  218 */     int voice = address - 528489472 >> 4;
/*  219 */     voices[voice].setRightVol(val);
/*      */   }
/*      */   
/*      */   public static void writePitch(int address, int val) {
/*  223 */     int voice = address - 528489472 >> 4;
/*  224 */     voices[voice].setPitch(val);
/*      */   }
/*      */   
/*      */   public static void writeStartOffset(int address, int val) {
/*  228 */     int voice = address - 528489472 >> 4;
/*  229 */     voices[voice].setStartOffset(val);
/*      */   }
/*      */   
/*      */   public static void writeADSLevel(int address, int val) {
/*  233 */     int voice = address - 528489472 >> 4;
/*  234 */     voices[voice].setADSLevel(val);
/*      */   }
/*      */   
/*      */   public static void writeSRRate(int address, int val) {
/*  238 */     int voice = address - 528489472 >> 4;
/*  239 */     voices[voice].setSRRate(val);
/*      */   }
/*      */   
/*      */   public static int readADSRVol(int address) {
/*  243 */     int voice = address - 528489472 >> 4;
/*  244 */     return voices[voice].getADSRVol();
/*      */   }
/*      */   
/*      */   public static void writeRepeatOffset(int address, int val) {
/*  248 */     int voice = address - 528489472 >> 4;
/*  249 */     voices[voice].setRepeatOffset(val);
/*      */   }
/*      */   
/*      */   public static int readVolLeft(int address) {
/*  253 */     int voice = address - 528489472 >> 4;
/*  254 */     return voices[voice].getLeftVol();
/*      */   }
/*      */   
/*      */   public static int readVolRight(int address) {
/*  258 */     int voice = address - 528489472 >> 4;
/*  259 */     return voices[voice].getRightVol();
/*      */   }
/*      */   
/*      */   public static int readPitch(int address) {
/*  263 */     int voice = address - 528489472 >> 4;
/*  264 */     return voices[voice].getPitch();
/*      */   }
/*      */   
/*      */   public static int readStartOffset(int address) {
/*  268 */     int voice = address - 528489472 >> 4;
/*  269 */     return voices[voice].getStartOffset();
/*      */   }
/*      */   
/*      */   public static int readADSLevel(int address) {
/*  273 */     int voice = address - 528489472 >> 4;
/*  274 */     return voices[voice].getADSLevel();
/*      */   }
/*      */   
/*      */   public static int readSRRate(int address) {
/*  278 */     int voice = address - 528489472 >> 4;
/*  279 */     return voices[voice].getSRRate();
/*      */   }
/*      */   
/*      */   public static int readRepeatOffset(int address) {
/*  283 */     int voice = address - 528489472 >> 4;
/*  284 */     return voices[voice].getRepeatOffset();
/*      */   }
/*      */   
/*      */   public static void writeMainVolLeft(int address, int val) {
/*  288 */     mainLeftVol = decodeVolume(val);
/*  289 */     for (int i = 0; i < 24; i++) {
/*  290 */       voices[i].updateVolume();
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeMainVolRight(int address, int val) {
/*  295 */     mainRightVol = decodeVolume(val);
/*  296 */     for (int i = 0; i < 24; i++) {
/*  297 */       voices[i].updateVolume();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void writeReverbLeft(int address, int val) {}
/*      */ 
/*      */   
/*      */   public static void writeReverbRight(int address, int val) {}
/*      */   
/*      */   public static void writeChannelOn0(int address, int val) {
/*  308 */     for (int i = 0; i < 16; i++) {
/*  309 */       if ((val & 1 << i) != 0) {
/*  310 */         voices[i].on();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void writeChannelOn1(int address, int val) {
/*  316 */     for (int i = 0; i < 8; i++) {
/*  317 */       if ((val & 1 << i) != 0) {
/*  318 */         voices[i + 16].on();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void writeChannelOff0(int address, int val) {
/*  324 */     for (int i = 0; i < 16; i++) {
/*  325 */       if ((val & 1 << i) != 0) {
/*  326 */         voices[i].off();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void writeChannelOff1(int address, int val) {
/*  332 */     for (int i = 0; i < 8; i++) {
/*  333 */       if ((val & 1 << i) != 0) {
/*  334 */         voices[i + 16].off();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void writeChannelFM0(int address, int val) {
/*  340 */     for (int i = 0; i < 16; i++) {
/*  341 */       voices[i].setFM(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelFM1(int address, int val) {
/*  346 */     for (int i = 0; i < 8; i++) {
/*  347 */       voices[i + 16].setFM(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelNoise0(int address, int val) {
/*  352 */     for (int i = 0; i < 16; i++) {
/*  353 */       voices[i].setNoise(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelNoise1(int address, int val) {
/*  358 */     for (int i = 0; i < 8; i++) {
/*  359 */       voices[i + 16].setNoise(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelReverb0(int address, int val) {
/*  364 */     for (int i = 0; i < 16; i++) {
/*  365 */       voices[i].setReverb(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelReverb1(int address, int val) {
/*  370 */     for (int i = 0; i < 8; i++) {
/*  371 */       voices[i + 16].setReverb(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelMute0(int address, int val) {
/*  376 */     for (int i = 0; i < 16; i++) {
/*  377 */       voices[i].setMute(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeChannelMute1(int address, int val) {
/*  382 */     for (int i = 0; i < 8; i++) {
/*  383 */       voices[i + 16].setMute(((val & 1 << i) != 0));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeSPUCtrl(int address, int val) {
/*  388 */     if (val == m_ctrl)
/*  389 */       return;  m_ctrl = val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  404 */   public static int readSPUCtrl(int address) { return m_ctrl; }
/*      */ 
/*      */   
/*      */   public static void writeCDVolL(int address, int val) {
/*  408 */     cdLeftVol = decodeVolume(val);
/*  409 */     updateCDVolume();
/*      */   }
/*      */   
/*      */   public static void writeCDVolR(int address, int val) {
/*  413 */     cdRightVol = decodeVolume(val);
/*  414 */     updateCDVolume();
/*      */   }
/*      */   
/*      */   public static void writeTransferAddr(int address, int val) {
/*  418 */     m_transferOffset = val & 0xFFFF;
/*  419 */     m_dataTransferWordOffset = m_transferOffset << 2;
/*      */   }
/*      */ 
/*      */   
/*  423 */   public static int readTransferAddr(int address) { return m_transferOffset; }
/*      */ 
/*      */   
/*      */   public static void writeTransferData(int address, int val) {
/*  427 */     int index = m_dataTransferWordOffset >> 1;
/*  428 */     m_decoded[m_dataTransferWordOffset << 2 & 0xFFFFFFF0] = 0;
/*      */     
/*  430 */     if (0 == (m_dataTransferWordOffset & true)) {
/*  431 */       m_ram[index] = m_ram[index] & 0xFFFF0000 | val & 0xFFFF;
/*      */     } else {
/*  433 */       m_ram[index] = m_ram[index] & 0xFFFF | val << 16;
/*      */     } 
/*  435 */     m_dataTransferWordOffset++;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int readSPUStatus(int address) {
/*  441 */     toggle = !toggle;
/*      */     
/*  443 */     return toggle ? 1024 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  518 */   private static byte[] debugbuffer = new byte[21168];
/*      */   
/*      */   public static void fill() {
/*  521 */     for (i = 0; i < 24; i++) {
/*  522 */       voices[i].fill(debugbuffer, 21168);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1032 */   private static final int[] predict1 = { 0, 60, 115, 98, 122 };
/*      */ 
/*      */ 
/*      */   
/* 1036 */   private static final int[] predict2 = { 0, 0, -52, -55, -60 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void decompressBlock(int blockOffset) {
/* 1042 */     int s_2, s_1, decodeIndex = blockOffset << 4;
/* 1043 */     int srcIndex = blockOffset << 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1083 */     if (decodeIndex < 32) {
/* 1084 */       s_1 = 0;
/* 1085 */       s_2 = 0;
/*      */     } else {
/* 1087 */       s_1 = (m_decoded[decodeIndex - 31] & 0xFFFF) + ((m_decoded[decodeIndex - 29] & 0xFF) << 16);
/* 1088 */       s_2 = (m_decoded[decodeIndex - 30] & 0xFFFF) + ((m_decoded[decodeIndex - 29] & 0xFF00) << 8);
/* 1089 */       s_1 = s_1 << 8 >> 8;
/* 1090 */       s_2 = s_2 << 8 >> 8;
/*      */     } 
/*      */     
/* 1093 */     int dword = m_ram[srcIndex];
/* 1094 */     int predictIndex = dword >> 4 & 0xF;
/* 1095 */     int shift = (dword & 0xF) + 12;
/*      */     
/* 1097 */     int ik0 = -predict1[predictIndex];
/* 1098 */     int ik1 = -predict2[predictIndex];
/* 1099 */     for (int i = 4; i < 32; i++) {
/* 1100 */       int i7 = i & 0x7;
/* 1101 */       int x0 = dword >> i7 << 2 & 0xF;
/* 1102 */       x0 = x0 << 28 >> shift;
/* 1103 */       x0 -= (ik0 * s_1 + ik1 * s_2 >> 6);
/* 1104 */       m_decoded[decodeIndex + i] = (short)(x0 >> 4);
/* 1105 */       s_2 = s_1;
/* 1106 */       s_1 = x0;
/* 1107 */       if (7 == i7) {
/* 1108 */         dword = m_ram[srcIndex + (i + 1 >> 3)];
/*      */       }
/*      */     } 
/*      */     
/* 1112 */     m_decoded[decodeIndex] = 1;
/* 1113 */     m_decoded[decodeIndex + 1] = (short)s_1;
/* 1114 */     m_decoded[decodeIndex + 2] = (short)s_2;
/* 1115 */     m_decoded[decodeIndex + 3] = (short)(s_1 >> 16 & 0xFF | s_2 >> 8 & 0xFF00);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1121 */   public int getCDAudioLatency() { return 0; }
/*      */   private static boolean reBuffer = false;
/*      */   private static final int SECTORS_TO_BUFFER = 10;
/*      */   private static final int SECTORS_TO_DELAY = 4;
/*      */   
/*      */   public void newCDAudio() {
/* 1127 */     this.sectorsSinceReset = 0;
/* 1128 */     base = System.nanoTime();
/* 1129 */     if (cdline != null) {
/* 1130 */       cdline.flush();
/* 1131 */       cdline.stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   int sectorsSinceReset;
/*      */   
/*      */   int bytesPerSector;
/*      */   static long base;
/*      */   
/*      */   public void setCDAudioRate(int hz) {
/* 1142 */     if (cdAudio && 
/* 1143 */       hz != cdlineFreq) {
/* 1144 */       newCDAudio();
/* 1145 */       cdline = null;
/* 1146 */       this.bytesPerSector = hz / 75 * 4;
/* 1147 */       int bytesToBuffer = this.bytesPerSector * 10;
/*      */       
/* 1149 */       DataLine.Info desiredCdLine = new DataLine.Info(SourceDataLine.class, new AudioFormat[] { new AudioFormat(hz, 16, 2, true, false) }bytesToBuffer * 4, bytesToBuffer * 4);
/*      */ 
/*      */       
/*      */       try {
/* 1153 */         cdline = (SourceDataLine)AudioSystem.getLine(desiredCdLine);
/* 1154 */         cdline.open();
/*      */         
/* 1156 */         reBuffer = true;
/* 1157 */         cdPanControl = (FloatControl)cdline.getControl(FloatControl.Type.PAN);
/* 1158 */         cdGainControl = (FloatControl)cdline.getControl(FloatControl.Type.MASTER_GAIN);
/* 1159 */         updateCDVolume();
/* 1160 */       } catch (Throwable t) {
/* 1161 */         throw new IllegalStateException("can't get line for media audio", t);
/*      */       } 
/* 1163 */       cdlineFreq = hz;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean cdAudioData(byte[] data, int offset, int length) {
/* 1171 */     long now = System.nanoTime();
/* 1172 */     double delta = (now - base) / 1000000.0D;
/* 1173 */     if (log.isDebugEnabled()) {
/* 1174 */       log.debug("AUDIO AT " + delta + " buffer space " + cdline.available() + " length " + length + " in sectors = " + (length / 1.0D * this.bytesPerSector));
/*      */     }
/* 1176 */     assert this.bytesPerSector > 0;
/* 1177 */     while (length > 0) {
/*      */       
/* 1179 */       int toWrite = (length > this.bytesPerSector) ? this.bytesPerSector : length;
/* 1180 */       cdline.write(data, offset, toWrite);
/* 1181 */       offset += toWrite;
/* 1182 */       length -= toWrite;
/* 1183 */       this.sectorsSinceReset++;
/* 1184 */       if (this.sectorsSinceReset == 4) {
/* 1185 */         cdline.start();
/*      */       }
/*      */     } 
/* 1188 */     return (this.sectorsSinceReset >= 4);
/*      */   }
/*      */   
/*      */   public void setExternalCDAudioVolumeLeft(int vol) {
/* 1192 */     vol /= 2;
/* 1193 */     if (vol > 16383) vol = 16383; 
/* 1194 */     cdLeftVolExternal = vol;
/* 1195 */     updateCDVolume();
/*      */   }
/*      */   
/*      */   public void setExternalCDAudioVolumeRight(int vol) {
/* 1199 */     vol /= 2;
/* 1200 */     if (vol > 16383) vol = 16383; 
/* 1201 */     cdRightVolExternal = vol;
/* 1202 */     updateCDVolume();
/*      */   }
/*      */   
/*      */   private static int volMul(int v1, int v2) {
/* 1206 */     if (v1 == 16383) v1++; 
/* 1207 */     if (v2 == 16383) v2++; 
/* 1208 */     return v1 * v2 >> 14;
/*      */   }
/*      */   
/*      */   private static void updateCDVolume() {
/* 1212 */     if (cdline != null) {
/* 1213 */       int vol; l = volMul(mainLeftVol, volMul(cdLeftVol, cdLeftVolExternal));
/* 1214 */       int r = volMul(mainRightVol, volMul(cdRightVol, cdRightVolExternal));
/* 1215 */       if (log.isDebugEnabled()) {
/* 1216 */         log.debug("CD Volume L=" + MiscUtil.toHex(mainLeftVol, 4) + "," + MiscUtil.toHex(cdLeftVol, 4) + "," + MiscUtil.toHex(cdLeftVolExternal, 4) + " R=" + MiscUtil.toHex(r, 4));
/*      */       }
/*      */       
/* 1219 */       if (l == r) {
/* 1220 */         vol = l;
/* 1221 */         cdPanControl.setValue(0.0F);
/* 1222 */       } else if (l > r) {
/* 1223 */         vol = l;
/* 1224 */         cdPanControl.setValue(r / l - 1.0F);
/*      */       } else {
/* 1226 */         vol = r;
/* 1227 */         cdPanControl.setValue(1.0F - l / r);
/*      */       } 
/*      */       
/* 1230 */       float db = -10.0F + (vol - 16384) / 512.0F;
/* 1231 */       if (db < -80.0F) db = -80.0F; 
/* 1232 */       cdGainControl.setValue(db);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1237 */   public boolean isCDAudible() { return (cdline != null); }
/*      */ 
/*      */   
/*      */   private static int decodeVolume(int vol) {
/*      */     int rc;
/* 1242 */     if (0 == (vol & 0x8000)) {
/*      */       
/* 1244 */       rc = vol & 0x3FFF;
/*      */     
/*      */     }
/* 1247 */     else if ((vol & 0x2000) == 0) {
/*      */       
/* 1249 */       rc = 16383;
/*      */     } else {
/*      */       
/* 1252 */       rc = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1256 */     return rc;
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\spu\SPU.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */