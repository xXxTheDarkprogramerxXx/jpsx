/*    */ package classes.runtime.org.jpsx.runtime.components.hardware.media;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jpsx.api.components.hardware.cd.CDDrive;
/*    */ import org.jpsx.api.components.hardware.cd.CDMedia;
/*    */ import org.jpsx.runtime.SingletonJPSXComponent;
/*    */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*    */ import org.jpsx.runtime.components.hardware.media.CueBinImageDrive;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CueBinImageDrive
/*    */   extends SingletonJPSXComponent
/*    */   implements CDDrive
/*    */ {
/*    */   public static final String PROPERTY_IMAGE_FILE = "image";
/*    */   private static final String CATEGORY = "CDImage";
/* 38 */   private static final Logger log = Logger.getLogger("CDImage");
/*    */   
/*    */   private static final String DEFAULT_CUE_FILE = "/rips/wipeoutxl.cue";
/*    */   
/*    */   private CDMedia currentMedia;
/*    */   private boolean refreshed = false;
/*    */   
/* 45 */   public CueBinImageDrive() { super("JPSX CUE/BIN Image CD Drive"); }
/*    */ 
/*    */   
/*    */   public void init() {
/* 49 */     super.init();
/* 50 */     HardwareComponentConnections.CD_DRIVE.set(this);
/*    */   }
/*    */   
/*    */   public CDMedia getCurrentMedia() {
/* 54 */     if (!this.refreshed) {
/* 55 */       refreshMedia();
/* 56 */       this.refreshed = true;
/*    */     } 
/* 58 */     return this.currentMedia;
/*    */   }
/*    */ 
/*    */   
/* 62 */   public boolean isDriveOpen() { return false; }
/*    */ 
/*    */   
/*    */   public void refreshMedia() {
/* 66 */     String cueFilename = getProperty("image", "/rips/wipeoutxl.cue");
/* 67 */     this.currentMedia = CueBinImageMedia.create(cueFilename);
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\media\CueBinImageDrive.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */