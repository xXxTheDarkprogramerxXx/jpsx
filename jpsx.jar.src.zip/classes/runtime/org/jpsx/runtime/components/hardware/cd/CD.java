/*      */ package classes.runtime.org.jpsx.runtime.components.hardware.cd;
/*      */ 
/*      */ import org.apache.log4j.Logger;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*      */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*      */ import org.jpsx.api.components.core.cpu.SCP;
/*      */ import org.jpsx.api.components.core.scheduler.Quartz;
/*      */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*      */ import org.jpsx.api.components.hardware.cd.CDAudioSink;
/*      */ import org.jpsx.api.components.hardware.cd.CDDrive;
/*      */ import org.jpsx.api.components.hardware.cd.CDMedia;
/*      */ import org.jpsx.runtime.JPSXComponent;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.components.hardware.HardwareComponentConnections;
/*      */ import org.jpsx.runtime.components.hardware.cd.CD;
/*      */ import org.jpsx.runtime.components.hardware.cd.XADecoder;
/*      */ import org.jpsx.runtime.util.CDUtil;
/*      */ import org.jpsx.runtime.util.MiscUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CD
/*      */   extends JPSXComponent
/*      */   implements MemoryMapped
/*      */ {
/*      */   private static boolean rateLimit1 = false;
/*      */   private static boolean rateLimit2 = true;
/*   64 */   private static final Logger log = Logger.getLogger("CD");
/*      */ 
/*      */ 
/*      */   
/*   68 */   private static final Logger cmdLog = Logger.getLogger("CD.CMD");
/*   69 */   private static final boolean cmdLogDebug = cmdLog.isDebugEnabled();
/*      */ 
/*      */ 
/*      */   
/*      */   private static CDDrive drive;
/*      */ 
/*      */ 
/*      */   
/*      */   private static CDMedia media;
/*      */ 
/*      */   
/*   80 */   private static XADecoder xaDecoder = new XADecoder();
/*      */   private static CDAudioSink cdAudioSink;
/*   82 */   private static int cdFreq = 0;
/*      */ 
/*      */   
/*      */   private static long rateLimitStartTime;
/*      */ 
/*      */   
/*      */   private static boolean rateLimitEnabled;
/*      */   
/*      */   private static int actualAudioBytes;
/*      */   
/*      */   private static int actualSectors;
/*      */   
/*   94 */   private static final boolean traceCD = log.isTraceEnabled();
/*      */   
/*      */   private static final boolean softwareCDDA = true;
/*      */   
/*      */   public static final int ADDR_CD_REG0 = 528488448;
/*      */   
/*      */   public static final int ADDR_CD_REG1 = 528488449;
/*      */   
/*      */   public static final int ADDR_CD_REG2 = 528488450;
/*      */   
/*      */   public static final int ADDR_CD_REG3 = 528488451;
/*      */   private static int regMode;
/*  106 */   private static int cdMode = 0;
/*      */   
/*  108 */   private static int filterFile = 0;
/*  109 */   private static int filterChannel = 0;
/*      */   
/*      */   private static final int STATE_NONE = 0;
/*      */   
/*      */   private static final int STATE_STANDBY = 1;
/*      */   
/*      */   private static final int STATE_READN = 2;
/*      */   
/*      */   private static final int STATE_READS = 3;
/*      */   
/*      */   private static final int STATE_PLAY = 4;
/*      */   private static final int STATE_SEEKL = 5;
/*      */   private static final int STATE_SEEKP = 6;
/*      */   private static final int STATE_PAUSE = 7;
/*      */   private static final int STATE_STOP = 8;
/*      */   private static int substate;
/*      */   private static int state;
/*      */   private static boolean interruptEnabled;
/*      */   private static boolean seeking;
/*      */   private static boolean sectorReady;
/*      */   private static boolean sectorDismissed;
/*      */   private static boolean someDataRead;
/*      */   private static boolean waitForDataRead;
/*      */   private static int waitForDataReadCounter;
/*      */   private static boolean resultCleared;
/*  134 */   private static int[] currentSector = new int[588];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int currentSectorOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int currentSectorEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG0_UNKNOWN_READY3 = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG0_UNKNOWN_READY4 = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG0_RESULTS_READY = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG0_DATA_READY = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_CDDA_PLAYING = 128;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_SEEKING = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_READING_DATA = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_SHELL_OPEN = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_SEEK_ERROR = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_STANDBY = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int REG3_ERROR = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_DOUBLE_SPEED = 128;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_XA = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_SIZE_MASK = 48;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_SIZE_2048 = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_SIZE_2340 = 32;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_FILTER = 8;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_REPORT = 4;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_AUTO_PAUSE = 2;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CD_MODE_DA = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRQ irq;
/*      */ 
/*      */ 
/*      */   
/*      */   private static AddressSpace addressSpace;
/*      */ 
/*      */ 
/*      */   
/*      */   private static SCP scp;
/*      */ 
/*      */ 
/*      */   
/*      */   private static Quartz quartz;
/*      */ 
/*      */ 
/*      */   
/*      */   private static Scheduler scheduler;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  263 */   public CD() { super("JPSX CD Controller"); }
/*      */ 
/*      */   
/*      */   public void init() {
/*  267 */     super.init();
/*  268 */     CoreComponentConnections.ALL_MEMORY_MAPPED.add(this);
/*  269 */     irq = new IRQ();
/*  270 */     CoreComponentConnections.IRQ_OWNERS.add(irq);
/*  271 */     CoreComponentConnections.DMA_CHANNEL_OWNERS.add(new CDDMAChannel(null));
/*      */   }
/*      */   
/*      */   public void resolveConnections() {
/*  275 */     drive = (CDDrive)HardwareComponentConnections.CD_DRIVE.resolve();
/*  276 */     media = drive.getCurrentMedia();
/*  277 */     cdAudioSink = (CDAudioSink)HardwareComponentConnections.CD_AUDIO_SINK.peek();
/*  278 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*  279 */     scp = (SCP)CoreComponentConnections.SCP.resolve();
/*  280 */     quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/*  281 */     scheduler = (Scheduler)CoreComponentConnections.SCHEDULER.resolve();
/*      */   }
/*      */ 
/*      */   
/*  285 */   private static String getModeDescription(int mode) { return "..."; }
/*      */ 
/*      */   
/*      */   private static void setCdMode(int newMode) {
/*  289 */     if (traceCD && newMode != cdMode) {
/*  290 */       log.trace("CD MODE: " + getModeDescription(cdMode));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  298 */     cdMode = newMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  324 */   private static CmdParameters params = new CmdParameters(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  366 */   private static CmdResult nullResult = new CmdResult(null);
/*      */ 
/*      */ 
/*      */   
/*  370 */   private static CmdResult currentResult = nullResult;
/*      */ 
/*      */   
/*  373 */   private static CmdResult[] resultQueue = new CmdResult[16];
/*      */   
/*  375 */   private static int resultQueueNextRead = 0;
/*  376 */   private static int resultQueueNextWrite = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SectorThread sectorThread;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  454 */   private static HeadLocation lastSetLocation = new HeadLocation();
/*      */   private static boolean setLocDone;
/*  456 */   private static HeadLocation currentLocation = new HeadLocation();
/*      */ 
/*      */   
/*      */   private static final int CdlNop = 1;
/*      */ 
/*      */   
/*      */   private static final int CdlSetLoc = 2;
/*      */ 
/*      */   
/*      */   private static final int CdlPlay = 3;
/*      */ 
/*      */   
/*      */   private static final int CdlFastForward = 4;
/*      */ 
/*      */   
/*      */   private static final int CdlRewind = 5;
/*      */ 
/*      */   
/*      */   private static final int CdlReadN = 6;
/*      */ 
/*      */   
/*      */   private static final int CdlStandby = 7;
/*      */ 
/*      */   
/*      */   private static final int CdlStop = 8;
/*      */ 
/*      */   
/*      */   private static final int CdlPause = 9;
/*      */ 
/*      */   
/*      */   private static final int CdlReset = 10;
/*      */ 
/*      */   
/*      */   private static final int CdlMute = 11;
/*      */ 
/*      */   
/*      */   private static final int CdlDemute = 12;
/*      */ 
/*      */   
/*      */   private static final int CdlSetFilter = 13;
/*      */ 
/*      */   
/*      */   private static final int CdlSetMode = 14;
/*      */ 
/*      */   
/*      */   private static final int CdlGetLocL = 16;
/*      */ 
/*      */   
/*      */   private static final int CdlGetLocP = 17;
/*      */ 
/*      */   
/*      */   private static final int CdlGetTN = 19;
/*      */ 
/*      */   
/*      */   private static final int CdlGetTD = 20;
/*      */ 
/*      */   
/*      */   private static final int CdlSeekL = 21;
/*      */ 
/*      */   
/*      */   private static final int CdlSeekP = 22;
/*      */ 
/*      */   
/*      */   private static final int CdlTest = 25;
/*      */ 
/*      */   
/*      */   private static final int CdlCheckID = 26;
/*      */ 
/*      */   
/*      */   private static final int CdlReadS = 27;
/*      */   
/*      */   private static final int CdlHardReset = 28;
/*      */   
/*      */   private static final int CdlReadTOC = 30;
/*      */ 
/*      */   
/*      */   public void registerAddresses(AddressSpaceRegistrar registration) {
/*  533 */     registration.registerWrite8Callback(528488448, CD.class, "cdReg0Write");
/*  534 */     registration.registerWrite8Callback(528488449, CD.class, "cdReg1Write");
/*  535 */     registration.registerWrite8Callback(528488450, CD.class, "cdReg2Write");
/*  536 */     registration.registerWrite8Callback(528488451, CD.class, "cdReg3Write");
/*  537 */     registration.registerRead8Callback(528488448, CD.class, "cdReg0Read");
/*  538 */     registration.registerRead8Callback(528488449, CD.class, "cdReg1Read");
/*  539 */     registration.registerRead8Callback(528488450, CD.class, "cdReg2Read");
/*  540 */     registration.registerRead8Callback(528488451, CD.class, "cdReg3Read");
/*      */   }
/*      */ 
/*      */   
/*  544 */   public void begin() { sectorThread = new SectorThread(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cdReg0Write(int address, int value) {
/*  550 */     if (traceCD) log.trace("CD_REG0_WRITE " + MiscUtil.toHex(value, 2));
/*      */     
/*  552 */     regMode = value & 0x3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  560 */     if (0 != (value & 0xFC)) {
/*  561 */       throw new IllegalStateException("CD: unknown reg0 write " + MiscUtil.toHex(value, 2));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static int cdReg0Read(int address) {
/*  567 */     int rc = regMode;
/*      */     
/*  569 */     if (currentResult.remaining()) {
/*  570 */       rc |= 0x20;
/*      */     }
/*      */     
/*  573 */     if (currentSectorOffset != currentSectorEnd) {
/*  574 */       rc |= 0x40;
/*      */     }
/*      */ 
/*      */     
/*  578 */     rc |= 0x8;
/*  579 */     rc |= 0x10;
/*      */     
/*  581 */     if (traceCD) log.trace("CD_REG0_READ " + MiscUtil.toHex(rc, 2)); 
/*  582 */     return rc;
/*      */   }
/*      */   
/*      */   public static void cdReg1Write(int address, int value) {
/*  586 */     if (traceCD) log.trace("CD_REG1_WRITE " + MiscUtil.toHex(value, 2));
/*      */     
/*  588 */     switch (regMode) {
/*      */       case 0:
/*  590 */         startCmd(value);
/*      */         return;
/*      */       case 3:
/*  593 */         log.trace("CD set right volume " + MiscUtil.toHex(value, 2));
/*  594 */         if (cdAudioSink != null) {
/*  595 */           cdAudioSink.setExternalCDAudioVolumeRight(value << 8);
/*      */         }
/*      */         return;
/*      */     } 
/*  599 */     throw new IllegalStateException("CD: unknown reg1 write: cdMode " + regMode + " " + MiscUtil.toHex(value, 2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static int cdReg1Read(int address) {
/*  604 */     int rc = 0;
/*      */     
/*  606 */     switch (regMode) {
/*      */       case 1:
/*  608 */         rc = currentResult.read();
/*      */         break;
/*      */       default:
/*  611 */         throw new IllegalStateException("CD: unknown reg1 read: cdMode " + regMode);
/*      */     } 
/*  613 */     if (traceCD) log.trace("CD_REG1_READ " + MiscUtil.toHex(rc, 2)); 
/*  614 */     return rc;
/*      */   }
/*      */   
/*      */   public static void cdReg2Write(int address, int value) {
/*  618 */     if (traceCD) log.trace("CD_REG2_WRITE " + MiscUtil.toHex(value, 2));
/*      */     
/*  620 */     switch (regMode) {
/*      */       
/*      */       case 0:
/*  623 */         params.add(value);
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  629 */         if (0 == (value & 0x7)) {
/*  630 */           if (traceCD) log.trace("CD: disabling interrupts"); 
/*  631 */           interruptEnabled = false;
/*  632 */         } else if (7 == (value & 0x7)) {
/*  633 */           if (traceCD) log.trace("CD: enabling interrupts"); 
/*  634 */           interruptEnabled = true;
/*      */         } else {
/*  636 */           throw new IllegalStateException("CD: unknown reg2 write: cdMode " + regMode + " " + MiscUtil.toHex(value, 2));
/*      */         } 
/*      */         
/*  639 */         if (0 != (value & 0xF8) && 
/*  640 */           24 != (value & 0xF8))
/*      */         {
/*  642 */           throw new IllegalStateException("CD: unknown reg2 write: cdMode " + regMode + " " + MiscUtil.toHex(value, 2));
/*      */         }
/*      */         return;
/*      */       case 2:
/*  646 */         log.trace("CD set left volume " + MiscUtil.toHex(value, 2));
/*  647 */         if (cdAudioSink != null) {
/*  648 */           cdAudioSink.setExternalCDAudioVolumeLeft(value << 8);
/*      */         }
/*      */         return;
/*      */     } 
/*  652 */     log.trace("CD ?set left volume low bits" + MiscUtil.toHex(value, 2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int cdReg2Read(int address) {
/*  658 */     if (currentSectorOffset < currentSectorEnd) {
/*  659 */       int val = currentSector[currentSectorOffset >> 2];
/*  660 */       switch (currentSectorOffset & 0x3) {
/*      */         case 0:
/*  662 */           val &= 0xFF;
/*      */           break;
/*      */         case 1:
/*  665 */           val = val >> 8 & 0xFF;
/*      */           break;
/*      */         case 2:
/*  668 */           val = val >> 16 & 0xFF;
/*      */           break;
/*      */         default:
/*  671 */           val = val >> 24 & 0xFF;
/*      */           break;
/*      */       } 
/*  674 */       if (traceCD) log.trace("Read sector byte " + MiscUtil.toHex(val, 8)); 
/*  675 */       currentSectorOffset++;
/*  676 */       setSomeDataRead();
/*  677 */       return val;
/*      */     } 
/*  679 */     throw new IllegalStateException("read off end of sector buffer via reg2");
/*      */   }
/*      */ 
/*      */   
/*      */   public static void cdReg3Write(int address, int value) {
/*  684 */     if (traceCD) log.trace("CD_REG3_WRITE " + MiscUtil.toHex(value, 2));
/*      */     
/*  686 */     switch (regMode) {
/*      */       case 0:
/*  688 */         if (value == 0) {
/*  689 */           if (traceCD) {
/*  690 */             log.trace("CD: dismiss sector");
/*      */           }
/*  692 */           dismissSector();
/*  693 */         } else if (value == 128) {
/*  694 */           if (traceCD) {
/*  695 */             log.trace("CD: prepare sector results");
/*      */           }
/*  697 */           prepareSector();
/*      */         } else {
/*  699 */           throw new IllegalStateException("CD: unknown reg3 write: cdMode " + regMode + " " + MiscUtil.toHex(value, 2));
/*      */         } 
/*      */         return;
/*      */       case 1:
/*  703 */         if (7 == (value & 0x7)) {
/*  704 */           if (traceCD) log.trace("CD: dismiss result"); 
/*  705 */           clearResult();
/*      */         } 
/*  707 */         if (0 != (value & 0x40))
/*      */         {
/*  709 */           if (traceCD) log.trace("CD: 0140"); 
/*      */         }
/*  711 */         if (0 != (value & 0xB8) && 24 != (value & 0xB8)) {
/*  712 */           throw new IllegalStateException("CD: unknown reg3 write: cdMode " + regMode + " " + MiscUtil.toHex(value, 2));
/*      */         }
/*      */         return;
/*      */       case 2:
/*  716 */         log.trace("CD ?set right volume low bits" + MiscUtil.toHex(value, 2));
/*      */         return;
/*      */     } 
/*  719 */     log.trace("CD ?commit volume");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int cdReg3Read(int address) {
/*  725 */     int rc = 0;
/*  726 */     switch (regMode) {
/*      */       case 0:
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  733 */         nextResult();
/*  734 */         rc = currentResult.type;
/*      */         break;
/*      */       default:
/*  737 */         throw new IllegalStateException("CD: unknown reg3 read: cdMode " + regMode);
/*      */     } 
/*  739 */     if (traceCD) log.trace("CD_REG3_READ " + MiscUtil.toHex(rc, 2)); 
/*  740 */     return rc;
/*      */   }
/*      */ 
/*      */   
/*  744 */   private static boolean resultQueueIsEmpty() { return (resultQueueNextWrite == resultQueueNextRead); }
/*      */ 
/*      */   
/*      */   private static void queueResult(CmdResult result) {
/*  748 */     int write = resultQueueNextWrite;
/*      */     
/*  750 */     if (traceCD) log.trace("CD: queuing result " + result); 
/*  751 */     resultQueueNextWrite = (resultQueueNextWrite + 1) % resultQueue.length;
/*  752 */     if (resultQueueNextWrite == resultQueueNextRead) {
/*  753 */       throw new IllegalStateException("result queue full");
/*      */     }
/*      */     
/*  756 */     resultQueue[write] = result;
/*  757 */     checkForIRQ();
/*      */   }
/*      */   
/*      */   private static void checkForIRQ() {
/*  761 */     if (interruptEnabled && resultQueueNextRead != resultQueueNextWrite) {
/*  762 */       if (traceCD) log.trace("CD: a result available; raising IRQ"); 
/*  763 */       irq.raiseIRQ();
/*  764 */       if (traceCD) log.trace("CD: done raising IRQ"); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void clearResult() {
/*  769 */     if (traceCD) log.trace("CD: clear result"); 
/*  770 */     resultCleared = true;
/*  771 */     checkForIRQ();
/*      */   }
/*      */   
/*      */   private static void nextResult() {
/*  775 */     if (!resultCleared) {
/*  776 */       if (traceCD) log.trace("CD: nextResult: previous not reset, so not shifting"); 
/*      */       return;
/*      */     } 
/*  779 */     if (resultQueueNextRead == resultQueueNextWrite) {
/*  780 */       if (traceCD) log.trace("CD: nextResult: none"); 
/*  781 */       currentResult = nullResult;
/*  782 */       resultCleared = true;
/*      */     }
/*  784 */     else if (currentResult.type == 1 && (resultQueue[resultQueueNextRead]).type == 1 && irq.isSet()) {
/*  785 */       if (traceCD) log.trace("CD: deferring sequential dataready with irq set"); 
/*  786 */       currentResult = nullResult;
/*  787 */       resultCleared = true;
/*      */     } else {
/*  789 */       currentResult = resultQueue[resultQueueNextRead];
/*  790 */       resultQueue[resultQueueNextRead] = null;
/*  791 */       resultQueueNextRead = (resultQueueNextRead + 1) % resultQueue.length;
/*  792 */       resultCleared = false;
/*  793 */       if (currentResult.type == 1) {
/*  794 */         sectorReady = true;
/*      */       }
/*  796 */       if (traceCD) log.trace("CD: nextResult: " + currentResult);
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void clearResults() {
/*  802 */     resultQueueNextRead = resultQueueNextWrite;
/*  803 */     currentResult = nullResult;
/*      */   }
/*      */   
/*      */   private static CmdResult newAckStatusResult() {
/*  807 */     res = new CmdResult(null);
/*  808 */     res.type = 3;
/*  809 */     res.add(getStatus());
/*  810 */     return res;
/*      */   }
/*      */   
/*      */   private static CmdResult newDataReadyStatusResult() {
/*  814 */     res = new CmdResult(null);
/*  815 */     res.type = 1;
/*  816 */     res.add(getStatus());
/*  817 */     return res;
/*      */   }
/*      */   
/*      */   private static CmdResult newCompleteStatusResult() {
/*  821 */     res = new CmdResult(null);
/*  822 */     res.type = 2;
/*  823 */     res.add(getStatus());
/*  824 */     return res;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void startCmd(int cmd) {
/*      */     int tr, f, s, m, msf, track, type;
/*      */     CmdResult res;
/*  831 */     switch (cmd) {
/*      */       case 1:
/*  833 */         if (cmdLogDebug) cmdLog.debug("CdlNop"); 
/*  834 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 10:
/*  838 */         if (cmdLogDebug) cmdLog.debug("CdlReset"); 
/*  839 */         clearResults();
/*      */         
/*  841 */         setState(1);
/*  842 */         setCdMode(0);
/*      */         
/*  844 */         queueResult(newAckStatusResult());
/*  845 */         queueResult(newCompleteStatusResult());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  850 */         lastSetLocation.init(CDUtil.fromBCD(params.get(0)), CDUtil.fromBCD(params.get(1)), CDUtil.fromBCD(params.get(2)));
/*  851 */         setLocDone = true;
/*  852 */         if (cmdLogDebug) cmdLog.debug("CdlSetLoc " + lastSetLocation); 
/*  853 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 25:
/*  857 */         switch (params.get(0)) {
/*      */           case 32:
/*  859 */             if (cmdLogDebug) cmdLog.debug("CdlTest: getVersion"); 
/*  860 */             res = new CmdResult(null);
/*  861 */             res.type = 3;
/*  862 */             res.add(152);
/*  863 */             res.add(6);
/*  864 */             res.add(16);
/*  865 */             res.add(195);
/*  866 */             queueResult(res);
/*      */             break;
/*      */         } 
/*  869 */         throw new IllegalStateException("Unknown CdlTest command 0x" + MiscUtil.toHex(params.get(0), 2));
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  874 */         if (cmdLogDebug) cmdLog.debug("CdlReadN"); 
/*  875 */         resetAudio();
/*  876 */         setState(2);
/*  877 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 8:
/*  881 */         if (cmdLogDebug) cmdLog.debug("CdlStop"); 
/*  882 */         setState(8);
/*  883 */         clearResults();
/*  884 */         resetAudio();
/*  885 */         queueResult(newAckStatusResult());
/*  886 */         queueResult(newCompleteStatusResult());
/*      */         break;
/*      */       
/*      */       case 7:
/*  890 */         if (cmdLogDebug) cmdLog.debug("CdlStandby"); 
/*  891 */         setState(1);
/*  892 */         clearResults();
/*  893 */         queueResult(newAckStatusResult());
/*  894 */         queueResult(newCompleteStatusResult());
/*      */         break;
/*      */       
/*      */       case 9:
/*  898 */         if (cmdLogDebug) cmdLog.debug("CdlPause"); 
/*  899 */         setState(7);
/*  900 */         clearResults();
/*  901 */         queueResult(newAckStatusResult());
/*  902 */         queueResult(newCompleteStatusResult());
/*      */         break;
/*      */       
/*      */       case 14:
/*  906 */         if (cmdLogDebug) cmdLog.debug("CdlSetMode " + MiscUtil.toHex(params.get(0), 2)); 
/*  907 */         setCdMode(params.get(0));
/*  908 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 26:
/*  914 */         if (cmdLogDebug) cmdLog.debug("CdlCheckID");
/*      */         
/*  916 */         queueResult(newAckStatusResult());
/*      */         
/*  918 */         res = new CmdResult(null);
/*  919 */         res.type = 3;
/*      */         
/*  921 */         type = CDUtil.getMediaType(media);
/*      */         
/*  923 */         if (0 != (type & true)) {
/*  924 */           boolean hasDataTracks = (0 != (type & 0x2));
/*  925 */           boolean hasAudioTracks = (0 != (type & 0x4));
/*      */           
/*  927 */           boolean isPlayStationDisc = hasDataTracks;
/*  928 */           boolean genuinePlayStationDisc = isPlayStationDisc;
/*  929 */           boolean isAudioDisk = (hasAudioTracks && !hasDataTracks);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  936 */           res.add(isAudioDisk ? 8 : 0);
/*  937 */           res.add((isAudioDisk ? 16 : 0) | (genuinePlayStationDisc ? 0 : 128));
/*  938 */           res.add(0);
/*  939 */           res.add(0);
/*  940 */           res.type = 2;
/*      */         } else {
/*  942 */           res.type = 5;
/*      */           
/*  944 */           res.add(0);
/*  945 */           res.add(0);
/*  946 */           res.add(0);
/*  947 */           res.add(0);
/*      */         } 
/*  949 */         res.add(74);
/*  950 */         res.add(80);
/*  951 */         res.add(83);
/*  952 */         res.add(88);
/*  953 */         queueResult(res);
/*      */         break;
/*      */       
/*      */       case 19:
/*  957 */         cmdLog.debug("CdlGetTN");
/*      */         
/*  959 */         res = new CmdResult(null);
/*      */         
/*  961 */         if (drive != null) {
/*  962 */           res.type = 3;
/*  963 */           res.add(getStatus());
/*  964 */           res.add(CDUtil.toBCD(media.getFirstTrack()));
/*  965 */           res.add(CDUtil.toBCD(media.getLastTrack()));
/*      */         } else {
/*  967 */           res.type = 3;
/*      */         } 
/*  969 */         queueResult(res);
/*      */         break;
/*      */       
/*      */       case 20:
/*  973 */         track = CDUtil.fromBCD(params.get(0));
/*      */         
/*  975 */         if (traceCD) cmdLog.debug("CdlGetTD " + track);
/*      */         
/*  977 */         msf = media.getTrackMSF(track);
/*      */         
/*  979 */         m = (msf & 0xFF0000) >> 16;
/*  980 */         s = (msf & 0xFF00) >> 8;
/*  981 */         f = msf & 0xFF;
/*      */         
/*  983 */         res = new CmdResult(null);
/*  984 */         res.type = 3;
/*  985 */         res.add(getStatus());
/*  986 */         res.add(m);
/*  987 */         res.add(s);
/*  988 */         res.add(f);
/*  989 */         queueResult(res);
/*      */         break;
/*      */       
/*      */       case 21:
/*  993 */         if (traceCD) cmdLog.debug("CdlSeekL");
/*      */         
/*  995 */         if (state == 2 || state == 3) {
/*  996 */           throw new IllegalStateException("SeekL while reading etc.");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1001 */         setState(5);
/* 1002 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 22:
/* 1006 */         if (traceCD) cmdLog.debug("CdlSeekP");
/*      */         
/* 1008 */         if (state == 2 || state == 3)
/* 1009 */           throw new IllegalStateException("SeekP while playing/reading etc."); 
/* 1010 */         setState(6);
/* 1011 */         queueResult(newAckStatusResult());
/* 1012 */         queueResult(newCompleteStatusResult());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 11:
/* 1017 */         if (cmdLogDebug) cmdLog.debug("CdlMute"); 
/* 1018 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 12:
/* 1023 */         if (cmdLogDebug) cmdLog.debug("CdlDemute"); 
/* 1024 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 13:
/* 1028 */         filterFile = params.get(0);
/* 1029 */         filterChannel = params.get(1);
/* 1030 */         if (cmdLogDebug) cmdLog.debug("CdlSetFilter " + filterFile + " " + filterChannel); 
/* 1031 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/* 1036 */         tr = params.get(0);
/* 1037 */         if (cmdLogDebug) cmdLog.debug("CdlPlay " + tr); 
/* 1038 */         if (media != null && tr >= media.getFirstTrack() && tr <= media.getLastTrack()) {
/* 1039 */           int playMSF = media.getTrackMSF(tr);
/* 1040 */           lastSetLocation.init(CDUtil.fromBCD(playMSF >> 16 & 0xFF), CDUtil.fromBCD(playMSF >> 8 & 0xFF), CDUtil.fromBCD(playMSF & 0xFF));
/* 1041 */           setLocDone = true;
/*      */         } 
/* 1043 */         resetAudio();
/* 1044 */         setState(4);
/* 1045 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 4:
/* 1049 */         if (cmdLogDebug) cmdLog.debug("CdlFastForward"); 
/* 1050 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       
/*      */       case 5:
/* 1054 */         if (cmdLogDebug) cmdLog.debug("CdlRewind"); 
/* 1055 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       case 16:
/* 1058 */         if (cmdLogDebug) cmdLog.debug("CdlGetLocL"); 
/* 1059 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 17:
/* 1064 */         if (cmdLogDebug) cmdLog.debug("CdlGetLocP");
/*      */ 
/*      */ 
/*      */         
/* 1068 */         res = new CmdResult(null);
/* 1069 */         res.type = 3;
/* 1070 */         res.add(CDUtil.toBCD(getTrack(currentLocation.getM(), currentLocation.getS(), currentLocation.getF())));
/* 1071 */         res.add((state == 4) ? 1 : 0);
/* 1072 */         res.add(CDUtil.toBCD(currentLocation.getM()));
/* 1073 */         res.add(CDUtil.toBCD(currentLocation.getS()));
/* 1074 */         res.add(CDUtil.toBCD(currentLocation.getF()));
/* 1075 */         queueResult(res);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 27:
/* 1080 */         if (cmdLogDebug) cmdLog.debug("CdlReadS"); 
/* 1081 */         resetAudio();
/* 1082 */         setState(3);
/* 1083 */         queueResult(newAckStatusResult());
/*      */         break;
/*      */       case 30:
/* 1086 */         if (cmdLogDebug) cmdLog.debug("CdlReadTOC"); 
/* 1087 */         drive.refreshMedia();
/* 1088 */         media = drive.getCurrentMedia();
/* 1089 */         queueResult(newAckStatusResult());
/* 1090 */         queueResult(newCompleteStatusResult());
/*      */         break;
/*      */       default:
/* 1093 */         throw new IllegalStateException("Unknown Cdl command " + cmd);
/*      */     } 
/*      */     
/* 1096 */     params.reset();
/*      */   }
/*      */   
/*      */   private static int getStatus() {
/* 1100 */     rc = 0;
/*      */     
/* 1102 */     if (state != 0) {
/* 1103 */       rc |= 0x2;
/*      */     }
/*      */     
/* 1106 */     if (seeking) {
/* 1107 */       rc |= 0x40;
/*      */     } else {
/* 1109 */       if (state == 4) {
/* 1110 */         rc |= 0x80;
/*      */       }
/* 1112 */       if (state == 2 || state == 3) {
/* 1113 */         rc |= 0x20;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1120 */     return rc;
/*      */   }
/*      */   
/*      */   private static void setState(int newState) {
/* 1124 */     log.trace("SET STATE " + newState);
/* 1125 */     state = newState;
/* 1126 */     substate = 0;
/*      */     
/* 1128 */     if (setLocDone) {
/* 1129 */       currentLocation.init(lastSetLocation);
/* 1130 */       setLocDone = false;
/*      */     } 
/* 1132 */     sectorThread.newState();
/* 1133 */     sectorReady = false;
/* 1134 */     sectorDismissed = true;
/* 1135 */     waitForDataReadCounter = 20;
/* 1136 */     someDataRead = true;
/* 1137 */     waitForDataRead = false;
/*      */     
/* 1139 */     currentSectorOffset = currentSectorEnd = 0;
/* 1140 */     updateCallback(quartz.nanoTime());
/* 1141 */     CD.class.notifyAll();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static long updateCallback(long baseTime) {
/* 1147 */     long nextTime = 0L;
/* 1148 */     if (state == 2 || state == 3 || state == 4 || state == 5 || state == 6) {
/*      */       long period;
/*      */       
/* 1151 */       if (0 == (cdMode & 0x80)) {
/* 1152 */         period = 6666666L;
/*      */       } else {
/*      */         
/* 1155 */         period = 3333333L;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1164 */       if (traceCD) log.info("adding clock callback"); 
/* 1165 */       nextTime = baseTime + period;
/* 1166 */       if (!scheduler.isScheduled(sectorTick))
/* 1167 */       { scheduler.schedule(baseTime + period, sectorTick); }
/*      */       
/* 1169 */       else if (traceCD) { log.debug("clock callback already exists; skipping add"); }
/*      */     
/*      */     } 
/* 1172 */     return nextTime;
/*      */   }
/*      */   
/* 1175 */   static int foobarCount = 0;
/*      */   
/*      */   static boolean toggle;
/*      */   
/*      */   private static long handleSectorTick(long currentTime) {
/* 1180 */     if (traceCD) log.info("enter callback; state=" + state); 
/* 1181 */     switch (state) {
/*      */       case 5:
/* 1183 */         if (substate == 0 && 
/* 1184 */           sectorThread.sectorsReady(true)) {
/* 1185 */           queueResult(newCompleteStatusResult());
/* 1186 */           substate = 1;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 6:
/* 1191 */         currentLocation.nextSpin();
/*      */         break;
/*      */       case 4:
/* 1194 */         if (sectorThread.sectorsReady((substate == 0))) {
/* 1195 */           substate = 1;
/* 1196 */           if (sectorThread.filterDASector())
/*      */           {
/* 1198 */             if (0 != (cdMode & 0x4) && resultQueueIsEmpty()) {
/* 1199 */               CmdResult res = new CmdResult(null);
/*      */               
/* 1201 */               int track = getTrack(currentLocation.getM(), currentLocation.getS(), currentLocation.getF());
/* 1202 */               int remainingM = 0;
/* 1203 */               int remainingS = 0;
/* 1204 */               if (media != null && 
/* 1205 */                 track >= media.getFirstTrack() && track <= media.getLastTrack()) {
/* 1206 */                 int endMSF = media.getTrackMSF((track == media.getLastTrack()) ? 0 : (track + 1));
/* 1207 */                 int endM = CDUtil.fromBCD(endMSF >> 16 & 0xFF);
/* 1208 */                 int endS = CDUtil.fromBCD(endMSF >> 8 & 0xFF);
/* 1209 */                 int endF = CDUtil.fromBCD(endMSF & 0xFF);
/* 1210 */                 int remainingSectors = (endM * 60 + endS) * 75 + endF - 150;
/* 1211 */                 remainingSectors -= currentLocation.getSector();
/* 1212 */                 remainingSectors /= 75;
/* 1213 */                 remainingS = remainingSectors % 60;
/* 1214 */                 remainingM = remainingSectors / 60;
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 1219 */               res.type = 1;
/* 1220 */               res.add(1);
/* 1221 */               res.add(track);
/* 1222 */               res.add(0);
/* 1223 */               toggle = !toggle;
/* 1224 */               if (toggle) {
/* 1225 */                 res.add(CDUtil.toBCD(remainingM));
/* 1226 */                 res.add(CDUtil.toBCD(remainingS));
/*      */               } else {
/* 1228 */                 res.add(CDUtil.toBCD(currentLocation.getM()));
/* 1229 */                 res.add(CDUtil.toBCD(currentLocation.getS()) | 0x80);
/*      */               } 
/* 1231 */               res.add(0);
/* 1232 */               res.add(0);
/* 1233 */               res.add(0);
/* 1234 */               queueResult(res);
/*      */             } 
/*      */           }
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1243 */         if (sectorThread.sectorsReady((substate == 0))) {
/* 1244 */           substate = 1;
/* 1245 */           if (!sectorThread.filterDataSector() || 
/* 1246 */             !sectorDismissed || 
/* 1247 */             !checkSomeDataRead() || 
/* 1248 */             rateLimit2Exceeded())
/* 1249 */             break;  if (rateLimit2) actualSectors++; 
/* 1250 */           someDataRead = false;
/* 1251 */           sectorDismissed = false;
/* 1252 */           if (traceCD) log.trace("ah.. setting data ready"); 
/* 1253 */           queueResult(newDataReadyStatusResult());
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1261 */         if (sectorThread.sectorsReady((substate == 0))) {
/* 1262 */           substate = 1;
/* 1263 */           if (!sectorThread.filterDataSector() || 
/* 1264 */             !sectorDismissed || 
/* 1265 */             !checkSomeDataRead() || 
/* 1266 */             rateLimit2Exceeded())
/* 1267 */             break;  if (rateLimit2) actualSectors++; 
/* 1268 */           someDataRead = false;
/* 1269 */           sectorDismissed = false;
/* 1270 */           if (traceCD) log.trace("ah.. setting data ready"); 
/* 1271 */           queueResult(newDataReadyStatusResult());
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1281 */     if (traceCD) log.trace("leave callback; state=" + state); 
/* 1282 */     return updateCallback(currentTime);
/*      */   }
/*      */   
/*      */   private static boolean checkSomeDataRead() {
/* 1286 */     if (waitForDataReadCounter > 0) {
/* 1287 */       waitForDataReadCounter--;
/* 1288 */       if (waitForDataReadCounter == 0) {
/* 1289 */         log.trace("DATA READ CHECK TIMEOUT!!!!!");
/*      */       }
/* 1291 */       return (waitForDataReadCounter == 19);
/*      */     } 
/* 1293 */     return (!waitForDataRead || someDataRead);
/*      */   }
/*      */   
/*      */   private static void setSomeDataRead() {
/* 1297 */     if (waitForDataReadCounter > 0) {
/* 1298 */       if (0 == scp.currentExceptionType()) {
/* 1299 */         log.trace("DATA READ FROM IRQ - don't need hack");
/*      */       } else {
/* 1301 */         log.trace("DATA READ FROM non-IRQ - NEED HACK");
/* 1302 */         waitForDataRead = true;
/*      */       } 
/* 1304 */       waitForDataReadCounter = 0;
/*      */     } 
/* 1306 */     someDataRead = true;
/*      */   }
/*      */   
/*      */   private static void dismissSector() {
/* 1310 */     if (sectorDismissed || !sectorReady) {
/*      */       return;
/*      */     }
/* 1313 */     sectorThread.copySector(currentSector);
/* 1314 */     switch (cdMode & 0x30) {
/*      */       case 0:
/* 1316 */         currentSectorOffset = 24;
/* 1317 */         currentSectorEnd = 2072;
/*      */         break;
/*      */       case 16:
/* 1320 */         currentSectorOffset = 12;
/* 1321 */         currentSectorEnd = 2340;
/*      */         break;
/*      */       case 32:
/* 1324 */         currentSectorOffset = 12;
/* 1325 */         currentSectorEnd = 2352;
/*      */         break;
/*      */       case 48:
/* 1328 */         currentSectorOffset = 24;
/* 1329 */         currentSectorEnd = 2352;
/*      */         break;
/*      */     } 
/* 1332 */     sectorDismissed = true;
/* 1333 */     sectorReady = false;
/*      */   }
/*      */   
/*      */   private static void prepareSector() {
/* 1337 */     if (currentSectorOffset == currentSectorEnd) {
/* 1338 */       dismissSector();
/*      */     }
/*      */   }
/*      */   
/* 1342 */   private static SectorTick sectorTick = new SectorTick(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void resetAudio() {
/* 1541 */     xaDecoder.reset();
/* 1542 */     cdFreq = 0;
/* 1543 */     rateLimitEnabled = false;
/*      */   }
/*      */   
/* 1546 */   private static final byte[] audioBuffer = new byte[16128];
/*      */   
/*      */   private static boolean handleXASector(byte[] sectorBuffer) {
/* 1549 */     int samples = 0;
/* 1550 */     if (cdFreq == 0) {
/* 1551 */       if (cdAudioSink != null) {
/* 1552 */         cdAudioSink.newCDAudio();
/*      */       }
/*      */       
/* 1555 */       samples = xaDecoder.decodeXAAudioSector(sectorBuffer, audioBuffer);
/* 1556 */       if (cdFreq != xaDecoder.getFrequency()) {
/* 1557 */         cdFreq = xaDecoder.getFrequency();
/* 1558 */         if (cdAudioSink != null) {
/* 1559 */           cdAudioSink.setCDAudioRate(cdFreq);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1564 */     if (rateLimit1Exceeded()) return false; 
/* 1565 */     if (rateLimit2Exceeded()) return false;
/*      */     
/* 1567 */     if (cdAudioSink != null && cdAudioSink.isCDAudible()) {
/* 1568 */       if (samples == 0) samples = xaDecoder.decodeXAAudioSector(sectorBuffer, audioBuffer); 
/* 1569 */       actualAudioBytes += samples * 4;
/*      */ 
/*      */ 
/*      */       
/* 1573 */       boolean started = cdAudioSink.cdAudioData(audioBuffer, 0, samples * 4);
/* 1574 */       if ((rateLimit1 || rateLimit2) && 
/* 1575 */         started) {
/* 1576 */         if (!rateLimitEnabled)
/* 1577 */         { rateLimitEnabled = true;
/* 1578 */           if (rateLimit1) actualAudioBytes = 0; 
/* 1579 */           if (rateLimit2) actualSectors = 0; 
/* 1580 */           rateLimitStartTime = quartz.nanoTime();
/*      */           
/* 1582 */           rateLimitEnabled = true; }
/*      */         
/* 1584 */         else if (rateLimit2) { actualSectors++; }
/*      */       
/*      */       }
/*      */     } 
/*      */     
/* 1589 */     return true;
/*      */   }
/*      */   
/*      */   private static boolean handleDASector(byte[] sectorBuffer) {
/* 1593 */     if (cdFreq == 0) {
/* 1594 */       cdFreq = 44100;
/* 1595 */       if (cdAudioSink != null) {
/* 1596 */         cdAudioSink.newCDAudio();
/* 1597 */         cdAudioSink.setCDAudioRate(cdFreq);
/*      */       } 
/*      */     } 
/*      */     
/* 1601 */     if (rateLimit1Exceeded()) return false; 
/* 1602 */     if (rateLimit2Exceeded()) return false;
/*      */     
/* 1604 */     if (cdAudioSink != null && cdAudioSink.isCDAudible()) {
/* 1605 */       boolean started = cdAudioSink.cdAudioData(sectorBuffer, 0, 2352);
/* 1606 */       if ((rateLimit1 || rateLimit2) && 
/* 1607 */         started) {
/* 1608 */         if (!rateLimitEnabled)
/* 1609 */         { rateLimitEnabled = true;
/* 1610 */           if (rateLimit1) actualAudioBytes = 0; 
/* 1611 */           if (rateLimit2) actualSectors = 0; 
/* 1612 */           rateLimitStartTime = quartz.nanoTime();
/*      */           
/* 1614 */           rateLimitEnabled = true; }
/*      */         
/* 1616 */         else if (rateLimit2) { actualSectors++; }
/*      */       
/*      */       }
/*      */     } 
/*      */     
/* 1621 */     return true;
/*      */   }
/*      */   
/*      */   private static boolean rateLimit1Exceeded() {
/* 1625 */     if (!rateLimitEnabled || !rateLimit1) return false; 
/* 1626 */     time = quartz.nanoTime();
/*      */     assert false;
/* 1628 */     int expectedAudioBytes = (int)(cdFreq * (time - rateLimitStartTime) / 4000L);
/* 1629 */     if (log.isDebugEnabled()) {
/* 1630 */       log.debug(expectedAudioBytes + " " + actualAudioBytes);
/*      */     }
/*      */     
/* 1633 */     return (actualAudioBytes > expectedAudioBytes);
/*      */   }
/*      */   
/*      */   private static boolean rateLimit2Exceeded() {
/* 1637 */     if (!rateLimitEnabled || !rateLimit2) return false; 
/* 1638 */     time = quartz.nanoTime();
/* 1639 */     int sps = ((cdMode & 0x80) != 0) ? 150 : 75;
/*      */     
/* 1641 */     int expectedSectors = (int)(sps * (time - rateLimitStartTime) / 1000000000L);
/* 1642 */     if (log.isDebugEnabled());
/*      */ 
/*      */ 
/*      */     
/* 1646 */     return (actualSectors > expectedSectors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getTrack(int m, int s, int f) {
/* 1656 */     int MSF = CDUtil.toMSF(m, s, f);
/* 1657 */     if (media != null) {
/* 1658 */       int rc = 0;
/* 1659 */       for (int i = media.getFirstTrack(); i <= media.getLastTrack(); i++) {
/* 1660 */         int trackMSF = media.getTrackMSF(i);
/* 1661 */         if (MSF < trackMSF) return rc; 
/* 1662 */         rc++;
/*      */       } 
/* 1664 */       if (MSF < media.getTrackMSF(0)) {
/* 1665 */         return rc;
/*      */       }
/*      */     } 
/* 1668 */     return 0;
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\hardware\cd\CD.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */