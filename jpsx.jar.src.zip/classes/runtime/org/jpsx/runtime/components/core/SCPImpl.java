/*     */ package classes.runtime.org.jpsx.runtime.components.core;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.ContinueExecutionException;
/*     */ import org.jpsx.api.components.core.ReturnFromExceptionException;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.cpu.InstructionProvider;
/*     */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.api.components.core.cpu.SCP;
/*     */ import org.jpsx.api.components.core.irq.IRQController;
/*     */ import org.jpsx.api.components.core.scheduler.Quartz;
/*     */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.core.SCPImpl;
/*     */ import org.jpsx.runtime.util.MiscUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SCPImpl
/*     */   extends SingletonJPSXComponent
/*     */   implements SCP, InstructionProvider
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger("SCP");
/*     */   
/*     */   private static long debugNextSecond;
/*     */   
/*     */   private static int vsyncsTaken;
/*  37 */   private static final boolean debugSCP = log.isDebugEnabled();
/*     */   
/*     */   private static final int STATUS_CU_3 = -2147483648;
/*     */   
/*     */   private static final int STATUS_CU_2 = 1073741824;
/*     */   
/*     */   private static final int STATUS_CU_1 = 536870912;
/*     */   
/*     */   private static final int STATUS_CU_0 = 268435456;
/*     */   
/*     */   private static final int STATUS_RE = 33554432;
/*     */   
/*     */   private static final int STATUS_BEV = 4194304;
/*     */   
/*     */   private static final int STATUS_TS = 2097152;
/*     */   
/*     */   private static final int STATUS_PE = 1048576;
/*     */   
/*     */   private static final int STATUS_CM = 524288;
/*     */   
/*     */   private static final int STATUS_PZ = 524288;
/*     */   private static final int STATUS_SWC = 131072;
/*     */   private static final int STATUS_ISC = 65536;
/*     */   private static final int STATUS_IM7 = 32768;
/*     */   private static final int STATUS_IM6 = 16384;
/*     */   private static final int STATUS_IM5 = 8192;
/*     */   private static final int STATUS_IM4 = 4096;
/*     */   private static final int STATUS_IM3 = 2048;
/*     */   private static final int STATUS_IM2 = 1024;
/*     */   private static final int STATUS_IM1 = 512;
/*     */   private static final int STATUS_IM0 = 256;
/*     */   private static final int STATUS_KUO = 32;
/*     */   private static final int STATUS_IEO = 16;
/*     */   private static final int STATUS_KUP = 8;
/*     */   private static final int STATUS_IEP = 4;
/*     */   private static final int STATUS_KUC = 2;
/*     */   private static final int STATUS_IEC = 1;
/*     */   private static final int STATUS_IMS = 65280;
/*     */   private static final int STATUS_W = -226754753;
/*     */   private static final int CAUSE_BD = -2147483648;
/*     */   private static final int CAUSE_CE = 805306368;
/*     */   private static final int CAUSE_CE_SHIFT = 28;
/*     */   private static final int CAUSE_IP7 = 32768;
/*     */   private static final int CAUSE_IP6 = 16384;
/*     */   private static final int CAUSE_IP5 = 8192;
/*     */   private static final int CAUSE_IP4 = 4096;
/*     */   private static final int CAUSE_IP3 = 2048;
/*     */   private static final int CAUSE_IP2 = 1024;
/*     */   private static final int CAUSE_IP1 = 512;
/*     */   private static final int CAUSE_IP0 = 256;
/*     */   private static final int CAUSE_CODE = 60;
/*     */   private static final int CAUSE_CODE_SHIFT = 2;
/*     */   private static final int CAUSE_W = 768;
/*     */   private static final int REG_INDEX = 0;
/*     */   private static final int REG_RAND = 1;
/*     */   private static final int REG_TLBLO = 2;
/*     */   private static final int REG_BPC = 3;
/*     */   private static final int REG_CTXT = 4;
/*     */   private static final int REG_BPA = 5;
/*     */   private static final int REG_PIDMASK = 6;
/*     */   private static final int REG_DGIC = 7;
/*     */   private static final int REG_BADVADDR = 8;
/*     */   private static final int REG_BDAM = 9;
/*     */   private static final int REG_TLBHI = 10;
/*     */   private static final int REG_BPCM = 11;
/*     */   private static final int REG_STATUS = 12;
/*     */   private static final int REG_CAUSE = 13;
/*     */   private static final int REG_EPC = 14;
/*     */   private static final int REG_PRID = 15;
/* 106 */   private static int status = 0;
/* 107 */   private static int cause = 0;
/*     */   
/* 109 */   private static int errorEPC = 0;
/* 110 */   private static int EPC = 0;
/*     */   
/*     */   private static boolean causeIV;
/*     */   
/*     */   private static boolean causeBD;
/*     */   
/*     */   private static int causeCE;
/*     */   private static int causeIPS;
/*     */   private static AddressSpace addressSpace;
/*     */   private static R3000 r3000;
/*     */   private static Quartz quartz;
/*     */   private static Scheduler scheduler;
/*     */   private static IRQController irqController;
/*     */   private static int[] interpreterRegs;
/*     */   
/* 125 */   public SCPImpl() { super("JPSX System Control Processor"); }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void begin() { signalResetException(); }
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/* 133 */     super.resolveConnections();
/* 134 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/* 135 */     r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/* 136 */     interpreterRegs = r3000.getInterpreterRegs();
/* 137 */     irqController = (IRQController)CoreComponentConnections.IRQ_CONTROLLER.resolve();
/* 138 */     quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/* 139 */     scheduler = (Scheduler)CoreComponentConnections.SCHEDULER.resolve();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInstructions(InstructionRegistrar registrar) { // Byte code:
/*     */     //   0: getstatic org/jpsx/runtime/components/core/SCPImpl.log : Lorg/apache/log4j/Logger;
/*     */     //   3: ldc 'Adding COP0 instructions...'
/*     */     //   5: invokevirtual info : (Ljava/lang/Object;)V
/*     */     //   8: new org/jpsx/api/components/core/cpu/CPUInstruction
/*     */     //   11: dup
/*     */     //   12: ldc 'eret'
/*     */     //   14: ldc_w org/jpsx/runtime/components/core/SCPImpl
/*     */     //   17: iconst_0
/*     */     //   18: ldc 131072
/*     */     //   20: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*     */     //   23: astore_2
/*     */     //   24: new org/jpsx/api/components/core/cpu/CPUInstruction
/*     */     //   27: dup
/*     */     //   28: ldc 'mfc0'
/*     */     //   30: ldc_w org/jpsx/runtime/components/core/SCPImpl
/*     */     //   33: iconst_0
/*     */     //   34: sipush #1024
/*     */     //   37: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*     */     //   40: astore_3
/*     */     //   41: new org/jpsx/api/components/core/cpu/CPUInstruction
/*     */     //   44: dup
/*     */     //   45: ldc 'mtc0'
/*     */     //   47: ldc_w org/jpsx/runtime/components/core/SCPImpl
/*     */     //   50: iconst_0
/*     */     //   51: ldc 66048
/*     */     //   53: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;II)V
/*     */     //   56: astore #4
/*     */     //   58: new org/jpsx/runtime/components/core/SCPImpl$1
/*     */     //   61: dup
/*     */     //   62: aload_0
/*     */     //   63: ldc 'cop0'
/*     */     //   65: ldc_w org/jpsx/runtime/components/core/SCPImpl
/*     */     //   68: iconst_0
/*     */     //   69: iconst_0
/*     */     //   70: aload_3
/*     */     //   71: aload #4
/*     */     //   73: aload_2
/*     */     //   74: invokespecial <init> : (Lorg/jpsx/runtime/components/core/SCPImpl;Ljava/lang/String;Ljava/lang/Class;IILorg/jpsx/api/components/core/cpu/CPUInstruction;Lorg/jpsx/api/components/core/cpu/CPUInstruction;Lorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*     */     //   77: astore #5
/*     */     //   79: aload_1
/*     */     //   80: bipush #16
/*     */     //   82: aload #5
/*     */     //   84: invokeinterface setInstruction : (ILorg/jpsx/api/components/core/cpu/CPUInstruction;)V
/*     */     //   89: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #143	-> 0
/*     */     //   #144	-> 8
/*     */     //   #145	-> 24
/*     */     //   #147	-> 41
/*     */     //   #149	-> 58
/*     */     //   #162	-> 79
/*     */     //   #163	-> 89
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	90	0	this	Lorg/jpsx/runtime/components/core/SCPImpl;
/*     */     //   0	90	1	registrar	Lorg/jpsx/api/components/core/cpu/InstructionRegistrar;
/*     */     //   24	66	2	i_eret	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*     */     //   41	49	3	i_mfc0	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*     */     //   58	32	4	i_mtc0	Lorg/jpsx/api/components/core/cpu/CPUInstruction;
/*     */     //   79	11	5	i_cop0	Lorg/jpsx/api/components/core/cpu/CPUInstruction; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void interpret_cop0(int ci) {
/* 166 */     switch (R3000.Util.bits_rs(ci)) {
/*     */       case 0:
/* 168 */         interpret_mfc0(ci);
/*     */         return;
/*     */       case 4:
/* 171 */         interpret_mtc0(ci);
/*     */         return;
/*     */       case 16:
/* 174 */         interpret_eret(ci);
/*     */         return;
/*     */     } 
/* 177 */     _signalReservedInstructionException();
/*     */   }
/*     */   
/*     */   public static void interpret_mtc0(int ci) {
/* 181 */     int rt = R3000.Util.bits_rt(ci);
/* 182 */     int rd = R3000.Util.bits_rd(ci);
/* 183 */     int sel = ci & 0x7;
/* 184 */     int value = interpreterRegs[rt];
/*     */     
/* 186 */     writeRegister(rd, sel, value);
/*     */   }
/*     */   
/*     */   public static void interpret_mfc0(int ci) {
/* 190 */     int rt = R3000.Util.bits_rt(ci);
/* 191 */     int rd = R3000.Util.bits_rd(ci);
/* 192 */     int sel = ci & 0x7;
/* 193 */     int value = readRegister(rd, sel);
/* 194 */     if (rt != 0)
/* 195 */       interpreterRegs[rt] = value; 
/*     */   }
/*     */   
/*     */   private static void writeRegister(int reg, int sel, int value) {
/* 199 */     switch ((sel << 16) + reg) {
/*     */       case 12:
/* 201 */         status = status & 0xD8400C0 | value & 0xF27BFF3F;
/* 202 */         addressSpace.enableMemoryWrite(((status & 0x10000) == 0));
/*     */         return;
/*     */       case 13:
/* 205 */         cause = cause & 0xFFFFFCFF | value & 0x300;
/*     */         return;
/*     */     } 
/* 208 */     if (log.isDebugEnabled()) {
/* 209 */       log.debug("SCP: write " + reg + ":" + sel + " " + MiscUtil.toHex(value, 8));
/*     */     }
/*     */   }
/*     */   
/*     */   private static int readRegister(int reg, int sel) {
/* 214 */     rc = 0;
/* 215 */     switch ((sel << 16) + reg) {
/*     */       case 12:
/* 217 */         return status;
/*     */       
/*     */       case 13:
/* 220 */         return cause;
/*     */       
/*     */       case 14:
/* 223 */         return EPC;
/*     */     } 
/*     */     
/* 226 */     if (log.isDebugEnabled()) {
/* 227 */       log.debug("SCP: read " + reg + ":" + sel);
/*     */     }
/*     */     
/* 230 */     return rc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void interpret_eret(int ci) {
/* 249 */     r3000.restoreInterpreterState();
/* 250 */     int prevci = addressSpace.internalRead32(r3000.getPC() - 4);
/* 251 */     if ((prevci & 0xFC1FFFFF) == 8) {
/* 252 */       EPC = interpreterRegs[R3000.Util.bits_rs(prevci)];
/*     */     } else {
/* 254 */       throw new IllegalStateException("Expected ERET preceeded by JR");
/*     */     } 
/* 256 */     returnFromException();
/*     */   }
/*     */   
/*     */   public void init() {
/* 260 */     super.init();
/* 261 */     status = 0;
/* 262 */     cause = 0;
/* 263 */     CoreComponentConnections.SCP.set(this);
/* 264 */     CoreComponentConnections.INSTRUCTION_PROVIDERS.add(this);
/*     */   }
/*     */   
/*     */   public void signalResetException() {
/* 268 */     status = 4194304;
/* 269 */     r3000.setPC(-1077936128);
/*     */   }
/*     */ 
/*     */   
/* 273 */   private static boolean getStatusBEV() { return (0 != (status & 0x400000)); }
/*     */ 
/*     */ 
/*     */   
/* 277 */   private static void setCauseCE(int val) { cause = cause & 0xCFFFFFFF | val << 28 & 0x30000000; }
/*     */ 
/*     */ 
/*     */   
/* 281 */   private static void setCauseExcCode(int val) { cause = cause & 0xFFFFFFC3 | val << 2 & 0x3C; }
/*     */ 
/*     */ 
/*     */   
/* 285 */   private static int getCauseExcCode() { return (cause & 0x3C) >> 2; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   private static int getCauseIPS() { return 0; }
/*     */ 
/*     */ 
/*     */   
/* 294 */   private static int getStatusIMS() { return 0; }
/*     */ 
/*     */ 
/*     */   
/* 298 */   public void signalIntegerOverflowException() { throw new IllegalStateException("INT OVERFLOW"); }
/*     */ 
/*     */ 
/*     */   
/* 302 */   public void signalBreakException() { throw new IllegalStateException("BREAK"); }
/*     */ 
/*     */ 
/*     */   
/* 306 */   public void signalReservedInstructionException() { _signalReservedInstructionException(); }
/*     */ 
/*     */ 
/*     */   
/* 310 */   public static void _signalReservedInstructionException() { throw new IllegalStateException("RESERVED INSTRUCTION"); }
/*     */ 
/*     */   
/*     */   public void signalSyscallException() {
/* 314 */     if (debugSCP) {
/* 315 */       r3000.restoreInterpreterState();
/* 316 */       log.debug("SYSCALL " + interpreterRegs[4]);
/*     */     } 
/* 318 */     signalExceptionHelper(8, 0, true);
/*     */   }
/*     */ 
/*     */   
/* 322 */   public boolean shouldInterrupt() { return _shouldInterrupt(); }
/*     */ 
/*     */ 
/*     */   
/* 326 */   private static boolean _shouldInterrupt() { return (0 != (cause & status & 0xFF00) && 0 != (status & true)); }
/*     */ 
/*     */   
/*     */   public void signalInterruptException() {
/* 330 */     if (debugSCP) log.debug("interrupt!");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     signalExceptionHelper(0, 0, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterruptLine(int line, boolean raised) {
/* 348 */     if (raised) {
/* 349 */       cause |= 1 << line + 8;
/*     */     } else {
/* 351 */       cause &= (1 << line + 8 ^ 0xFFFFFFFF);
/*     */     } 
/* 353 */     checkBreakout();
/*     */     
/* 355 */     scheduler.cpuThreadNotify();
/*     */   }
/*     */   
/*     */   protected static void checkBreakout() {
/* 359 */     if (_shouldInterrupt())
/*     */     {
/* 361 */       r3000.setBreakout();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void signalExceptionHelper(int type, int faultingCoprocessor, boolean expectSkip) {
/*     */     int pc;
/* 367 */     r3000.restoreInterpreterState();
/* 368 */     if (debugSCP) log.debug("Exception " + type); 
/* 369 */     int vectorOffset = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     cause &= Integer.MAX_VALUE;
/* 377 */     EPC = r3000.getPC();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 385 */     vectorOffset = 128;
/* 386 */     setCauseCE(faultingCoprocessor);
/* 387 */     setCauseExcCode(type);
/*     */     
/* 389 */     status = status & 0xFFFFFFC0 | status << 2 & 0x3C;
/*     */ 
/*     */     
/* 392 */     if (getStatusBEV()) {
/*     */       
/* 394 */       pc = -1077935616 + vectorOffset;
/*     */     } else {
/* 396 */       pc = -2147483520;
/*     */     } 
/*     */ 
/*     */     
/* 400 */     executeException(pc, expectSkip);
/*     */   }
/*     */   
/*     */   public int currentExceptionType() {
/* 404 */     if (0 != (status & 0x3)) {
/* 405 */       return -1;
/*     */     }
/* 407 */     return getCauseExcCode();
/*     */   }
/*     */   
/*     */   public static void executeException(int pc, boolean expectSkip) {
/* 411 */     int exppc = r3000.getPC();
/* 412 */     int expsp = interpreterRegs[29];
/*     */     
/* 414 */     if (debugSCP) {
/* 415 */       log.debug("take exception r_pc " + MiscUtil.toHex(r3000.getPC(), 8) + " sp " + MiscUtil.toHex(interpreterRegs[29], 8) + " go to " + MiscUtil.toHex(pc, 8));
/*     */     }
/*     */ 
/*     */     
/* 419 */     if (expectSkip) exppc += 4;
/*     */     
/* 421 */     r3000.setPC(pc);
/* 422 */     r3000.executeFromPC();
/*     */ 
/*     */ 
/*     */     
/* 426 */     if (r3000.getPC() != exppc || interpreterRegs[29] != expsp) {
/* 427 */       log.debug("unexpected execution flow: pc " + MiscUtil.toHex(r3000.getPC(), 8) + "," + MiscUtil.toHex(exppc, 8) + " sp " + MiscUtil.toHex(interpreterRegs[29], 8) + "," + MiscUtil.toHex(expsp, 8));
/* 428 */       throw ContinueExecutionException.DONT_SKIP_CURRENT;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     if (expectSkip) {
/* 435 */       r3000.setPC(r3000.getPC() - 4);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void returnFromException() {
/* 441 */     status = status & 0xFFFFFFC0 | status >> 2 & 0xF;
/*     */ 
/*     */     
/* 444 */     checkBreakout();
/* 445 */     r3000.setPC(EPC);
/* 446 */     throw ReturnFromExceptionException.INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\SCPImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */