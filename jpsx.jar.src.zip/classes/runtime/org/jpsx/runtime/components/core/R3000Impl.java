/*     */ package classes.runtime.org.jpsx.runtime.components.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.bcel.classfile.Method;
/*     */ import org.apache.bcel.generic.BIPUSH;
/*     */ import org.apache.bcel.generic.ClassGen;
/*     */ import org.apache.bcel.generic.ConstantPoolGen;
/*     */ import org.apache.bcel.generic.IAND;
/*     */ import org.apache.bcel.generic.ILOAD;
/*     */ import org.apache.bcel.generic.INVOKESTATIC;
/*     */ import org.apache.bcel.generic.ISHR;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.InstructionList;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.RETURN;
/*     */ import org.apache.bcel.generic.TABLESWITCH;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.CPUControl;
/*     */ import org.jpsx.api.CPUListener;
/*     */ import org.jpsx.api.InvalidConfigurationException;
/*     */ import org.jpsx.api.components.core.ContinueExecutionException;
/*     */ import org.jpsx.api.components.core.ReturnFromExceptionException;
/*     */ import org.jpsx.api.components.core.cpu.CPUInstruction;
/*     */ import org.jpsx.api.components.core.cpu.CPUInstructionDisassembler;
/*     */ import org.jpsx.api.components.core.cpu.InstructionProvider;
/*     */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*     */ import org.jpsx.api.components.core.cpu.NativeCompiler;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.bootstrap.classloader.ClassModifier;
/*     */ import org.jpsx.bootstrap.classloader.JPSXClassLoader;
/*     */ import org.jpsx.bootstrap.connection.SimpleConnection;
/*     */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.core.R3000Impl;
/*     */ import org.jpsx.runtime.util.ClassUtil;
/*     */ import org.jpsx.runtime.util.MiscUtil;
/*     */ 
/*     */ public final class R3000Impl
/*     */   extends SingletonJPSXComponent
/*     */   implements ClassModifier, R3000, CPUControl, InstructionRegistrar {
/*  45 */   private static final Logger logPrintf = Logger.getLogger("PRINTF");
/*  46 */   private static final Logger logCache = Logger.getLogger("Cache");
/*  47 */   private static final Logger log = Logger.getLogger("R3000");
/*     */   
/*  49 */   private static final String CLASS = R3000Impl.class.getName();
/*  50 */   private static final String UTIL_CLASS = R3000.Util.class.getName();
/*  51 */   private static final String DECODER_CLASS = ClassUtil.innerClassName(R3000Impl.class, "Decoder");
/*     */   
/*     */   private static final String INTERPRET_SIGNATURE = "(I)V";
/*  54 */   private static final Class[] INTERPRET_ARGS = { int.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean shellHit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MAX_EXECUTION_DEPTH = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private static final boolean[] inCompiler = new boolean[4];
/*  74 */   private static int executionDepth = -1;
/*  75 */   private static Map<String, CPUInstructionDisassembler> instructionDisassemblers = CollectionsFactory.newHashMap();
/*     */   
/*  77 */   public static final int[] regs = new int[32];
/*     */   
/*     */   public static int reg_lo;
/*     */   
/*     */   public static int reg_hi;
/*     */   public static int reg_pc;
/*  83 */   private static int delayedPCDelta = 4;
/*  84 */   private static int interpretedJumpAndLinkTarget = -1;
/*  85 */   private static int interpretedJumpAndLinkRetAddr = -1;
/*     */   
/*  87 */   private static int interpretedJumpTarget = -1;
/*     */   
/*     */   private static int currentPCDelta;
/*     */   
/*  91 */   private static final Object cpuControlSemaphore = new Object();
/*     */   
/*     */   private static boolean cpuReadyForCommand;
/*     */   
/*     */   private static int cpuCmd;
/*     */   
/*     */   private static final int CMD_NOP = 0;
/*     */   private static final int CMD_STEP = 1;
/*     */   private static final int CMD_RUN = 2;
/*     */   private static final int CMD_UPDATE_BREAKPOINTS = 3;
/*     */   private static CPUInstruction[] decoding;
/*     */   private static CPUInstruction[] decodingSPECIAL;
/*     */   private static CPUInstruction[] decodingREGIMM;
/* 104 */   private static List<Integer> breakpoints = CollectionsFactory.newArrayList(); private static NativeCompiler compiler; private static CPUListener executionListeners;
/*     */   private static int breakpointAdd;
/*     */   private static int breakpointRemove;
/*     */   private static CPUInstruction i_invalid;
/*     */   private static Thread executionThread;
/*     */   public static boolean breakout;
/*     */   private static int totalBreakouts;
/*     */   private static boolean breakHotspot;
/*     */   
/* 113 */   public R3000Impl() { super("JPSX Main Processor"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial init : ()V
/*     */     //   4: getstatic org/jpsx/runtime/RuntimeConnections.CPU_CONTROL : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual set : (Ljava/lang/Object;)V
/*     */     //   11: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.R3000 : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   14: aload_0
/*     */     //   15: invokevirtual set : (Ljava/lang/Object;)V
/*     */     //   18: getstatic org/jpsx/runtime/components/core/R3000Impl.DECODER_CLASS : Ljava/lang/String;
/*     */     //   21: aload_0
/*     */     //   22: invokestatic registerClassModifier : (Ljava/lang/String;Lorg/jpsx/bootstrap/classloader/ClassModifier;)V
/*     */     //   25: getstatic org/jpsx/runtime/RuntimeConnections.MACHINE : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   28: invokevirtual resolve : ()Ljava/lang/Object;
/*     */     //   31: checkcast org/jpsx/runtime/JPSXMachine
/*     */     //   34: astore_1
/*     */     //   35: aload_1
/*     */     //   36: ldc 50000
/*     */     //   38: new org/jpsx/runtime/components/core/R3000Impl$1
/*     */     //   41: dup
/*     */     //   42: aload_0
/*     */     //   43: invokespecial <init> : (Lorg/jpsx/runtime/components/core/R3000Impl;)V
/*     */     //   46: invokeinterface addInitializer : (ILjava/lang/Runnable;)V
/*     */     //   51: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.ADDRESS_SPACE_LISTENERS : Lorg/jpsx/bootstrap/connection/MultipleConnection;
/*     */     //   54: new org/jpsx/runtime/components/core/R3000Impl$2
/*     */     //   57: dup
/*     */     //   58: aload_0
/*     */     //   59: invokespecial <init> : (Lorg/jpsx/runtime/components/core/R3000Impl;)V
/*     */     //   62: invokevirtual add : (Ljava/lang/Object;)V
/*     */     //   65: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #118	-> 0
/*     */     //   #119	-> 4
/*     */     //   #120	-> 11
/*     */     //   #121	-> 18
/*     */     //   #122	-> 25
/*     */     //   #123	-> 35
/*     */     //   #128	-> 51
/*     */     //   #133	-> 65
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	66	0	this	Lorg/jpsx/runtime/components/core/R3000Impl;
/*     */     //   35	31	1	machine	Lorg/jpsx/runtime/JPSXMachine; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addInstructions() {
/* 136 */     i_invalid = new CPUInstruction("invalid", R3000Impl.class, false, 131072);
/* 137 */     decoding = new CPUInstruction[64];
/* 138 */     for (int i = 0; i < 64; i++) {
/* 139 */       decoding[i] = i_invalid;
/*     */     }
/* 141 */     decodingSPECIAL = new CPUInstruction[64];
/* 142 */     for (int i = 0; i < 64; i++) {
/* 143 */       decodingSPECIAL[i] = i_invalid;
/*     */     }
/* 145 */     decodingREGIMM = new CPUInstruction[32];
/* 146 */     for (int i = 0; i < 32; i++) {
/* 147 */       decodingREGIMM[i] = i_invalid;
/*     */     }
/*     */     
/* 150 */     SimpleConnection<InstructionRegistrar> connection = SimpleConnection.create("InstructionRegistrar", InstructionRegistrar.class);
/* 151 */     connection.set(this);
/* 152 */     ((InstructionProvider)CoreComponentConnections.INSTRUCTION_PROVIDERS.resolve()).addInstructions((InstructionRegistrar)connection.resolve());
/* 153 */     CoreComponentConnections.INSTRUCTION_PROVIDERS.close();
/* 154 */     connection.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public CPUInstruction getInvalidInstruction() { return i_invalid; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/* 171 */     super.resolveConnections();
/* 172 */     compiler = (NativeCompiler)CoreComponentConnections.NATIVE_COMPILER.peek();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void bootStatus(int address, int value) {}
/*     */ 
/*     */   
/*     */   public CPUInstruction decodeInstruction(int ci) {
/* 180 */     int index = ci >> 26;
/*     */     
/* 182 */     switch (index)
/*     */     { case 0:
/* 184 */         rc = decodingSPECIAL[ci & 0x3F];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 193 */         return rc.subDecode(ci);case 1: rc = decodingREGIMM[R3000.Util.bits_rt(ci)]; return rc.subDecode(ci); }  CPUInstruction rc = decoding[index & 0x3F]; return rc.subDecode(ci);
/*     */   }
/*     */ 
/*     */   
/* 197 */   public void setInstructionDisassembler(String name, CPUInstructionDisassembler disassembler) { instructionDisassemblers.put(name, disassembler); }
/*     */ 
/*     */ 
/*     */   
/* 201 */   public void setInstruction(int index, CPUInstruction inst) { decoding[index] = inst; }
/*     */ 
/*     */ 
/*     */   
/* 205 */   public void setSPECIALInstruction(int index, CPUInstruction inst) { decodingSPECIAL[index] = inst; }
/*     */ 
/*     */ 
/*     */   
/* 209 */   public void setREGIMMInstruction(int index, CPUInstruction inst) { decodingREGIMM[index] = inst; }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkInstruction(CPUInstruction inst) {
/*     */     try {
/* 215 */       Method method = inst.getInterpreterClass().getDeclaredMethod(inst.getInterpretMethodName(), INTERPRET_ARGS);
/* 216 */       if (!Modifier.isStatic(method.getModifiers())) {
/* 217 */         throw new InvalidConfigurationException("Interpreter method " + inst.getInterpretMethodName() + " on class " + inst.getInterpreterClass().getName() + " is not static");
/*     */       }
/* 219 */     } catch (Exception e) {
/* 220 */       throw new InvalidConfigurationException("Missing correct interpreter method " + inst.getInterpretMethodName() + " on class " + inst.getInterpreterClass().getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public boolean isExecutionThread() { return (Thread.currentThread() == executionThread); }
/*     */ 
/*     */   
/*     */   public void begin() {
/* 252 */     executionListeners = (CPUListener)CoreComponentConnections.CPU_LISTENERS.resolve();
/* 253 */     executionThread = new R3000Thread(this);
/* 254 */     cpuCmdPending = true;
/* 255 */     executionThread.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 267 */   public void pause() { sendCmd(0); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void sendCmd(int cmd) {
/* 272 */     synchronized (cpuControlSemaphore) {
/* 273 */       cpuCmdPending = true;
/* 274 */       ((R3000)CoreComponentConnections.R3000.resolve()).setBreakout();
/* 275 */       if (!cpuReadyForCommand) {
/*     */         
/*     */         try {
/* 278 */           cpuControlSemaphore.wait();
/* 279 */         } catch (InterruptedException e) {}
/*     */       }
/*     */       
/* 282 */       cpuCmd = cmd;
/*     */       
/* 284 */       cpuControlSemaphore.notify();
/*     */       
/*     */       try {
/* 287 */         cpuControlSemaphore.wait();
/* 288 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void step() {
/* 294 */     sendCmd(1);
/*     */     
/* 296 */     sendCmd(0);
/*     */   }
/*     */ 
/*     */   
/* 300 */   public void go() { sendCmd(2); }
/*     */ 
/*     */   
/*     */   private static void cpuWaitForCmd() {
/* 304 */     executionListeners.cpuPaused();
/* 305 */     synchronized (cpuControlSemaphore) {
/* 306 */       boolean done = false;
/* 307 */       while (!done) {
/*     */ 
/*     */         
/* 310 */         cpuReadyForCommand = true;
/* 311 */         cpuControlSemaphore.notify();
/*     */ 
/*     */         
/*     */         try {
/* 315 */           cpuControlSemaphore.wait();
/* 316 */         } catch (InterruptedException e) {}
/*     */         
/* 318 */         switch (cpuCmd) {
/*     */           case 0:
/* 320 */             cpuCmdPending = false;
/*     */             break;
/*     */           case 2:
/* 323 */             done = true;
/* 324 */             cpuCmdPending = false;
/* 325 */             executionListeners.cpuResumed();
/*     */             break;
/*     */           case 1:
/* 328 */             done = true;
/* 329 */             cpuCmdPending = true;
/*     */             break;
/*     */           case 3:
/* 332 */             updateBreakpoints();
/* 333 */             cpuCmdPending = false;
/*     */             break;
/*     */         } 
/* 336 */         cpuReadyForCommand = false;
/* 337 */         cpuControlSemaphore.notify();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void executeFromPC() {
/* 360 */     executionDepth++;
/* 361 */     assert executionDepth < 4;
/*     */     
/* 363 */     delayedPCDelta = currentPCDelta = 4;
/*     */     while (true) {
/*     */       try {
/*     */         while (true)
/* 367 */           interpreterLoop(); 
/* 368 */       } catch (ContinueExecutionException e) {
/* 369 */         if (inCompiler[executionDepth]) {
/* 370 */           compiler.exceptionInCompiler(e);
/* 371 */           inCompiler[executionDepth] = false;
/*     */         } 
/* 373 */         if (e.skipCurrentInstruction()) {
/* 374 */           reg_pc += 4;
/*     */         }
/*     */ 
/*     */         
/* 378 */         delayedPCDelta = currentPCDelta = 4;
/* 379 */       } catch (ReturnFromExceptionException rfe) {
/* 380 */         if (inCompiler[executionDepth]) {
/* 381 */           compiler.exceptionInCompiler(rfe);
/* 382 */           inCompiler[executionDepth] = false;
/*     */         } 
/*     */         
/* 385 */         assert delayedPCDelta == 4 : "rfe delayedPCDelta should be 4";
/* 386 */         currentPCDelta = 4;
/*     */         
/*     */         break;
/* 389 */       } catch (Throwable t) {
/* 390 */         boolean ok = false;
/* 391 */         if (inCompiler[executionDepth]) {
/* 392 */           ok = compiler.exceptionInCompiler(t);
/* 393 */           inCompiler[executionDepth] = false;
/*     */         } 
/* 395 */         if (!ok) {
/* 396 */           t.printStackTrace();
/* 397 */           System.out.println("Execution paused due to Java exception!");
/* 398 */           cpuWaitForCmd();
/*     */         } 
/*     */       } 
/*     */     } 
/* 402 */     executionDepth--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBreakout() {
/* 409 */     breakout = true;
/* 410 */     if (compiler != null) {
/* 411 */       compiler.interrupt();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final void handleInterpreterBreakout() {
/* 417 */     breakout = false;
/* 418 */     if (Refs.scp.shouldInterrupt()) {
/* 419 */       restoreInterpreterState();
/* 420 */       Refs.scp.signalInterruptException();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void compilerInterrupted() {
/* 425 */     handleInterpreterBreakout();
/* 426 */     if (cpuCmdPending)
/*     */     {
/* 428 */       throw ContinueExecutionException.DONT_SKIP_CURRENT;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void interpreterLoop() {
/*     */     while (true) {
/* 437 */       boolean checkBreakout = (currentPCDelta != 4 && delayedPCDelta == 4);
/*     */       
/* 439 */       currentPCDelta = delayedPCDelta;
/* 440 */       delayedPCDelta = 4;
/*     */       
/* 442 */       boolean shouldWait = cpuCmdPending;
/*     */ 
/*     */       
/* 445 */       for (int i = 0; i < breakpoints.size(); i++) {
/* 446 */         if (reg_pc == ((Integer)breakpoints.get(i)).intValue()) {
/* 447 */           shouldWait = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 452 */       if (shouldWait) {
/* 453 */         cpuWaitForCmd();
/*     */       }
/*     */ 
/*     */       
/* 457 */       if (checkBreakout && breakout)
/*     */       {
/*     */         
/* 460 */         if (!cpuCmdPending) {
/* 461 */           handleInterpreterBreakout();
/*     */         }
/*     */       }
/*     */       
/* 465 */       if (reg_pc == interpretedJumpAndLinkTarget) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 480 */         interpretedJumpAndLinkTarget = -1;
/*     */         
/* 482 */         if (!shouldWait && compiler != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 488 */           inCompiler[executionDepth] = true;
/* 489 */           if (compiler.jumpAndLink(reg_pc, interpretedJumpAndLinkRetAddr)) {
/*     */             
/* 491 */             inCompiler[executionDepth] = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 498 */             delayedPCDelta = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 527 */         if (reg_pc == -1077929760) {
/* 528 */           debugPrintf();
/*     */         }
/*     */       } 
/*     */       
/* 532 */       if (reg_pc != interpretedJumpTarget || reg_pc == regs[31]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 542 */       int ci = Refs.addressSpace.internalRead32(reg_pc);
/*     */       
/* 544 */       Decoder.invoke(ci);
/*     */       
/* 546 */       assert regs[0] == 0 : "instruction changed r0";
/*     */       
/* 548 */       reg_pc += currentPCDelta;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 556 */   public static boolean shouldDumpRegs(int addr) { return false; }
/*     */ 
/*     */   
/*     */   public static void tempHackForException() {
/* 560 */     currentPCDelta = 0;
/* 561 */     delayedPCDelta = 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addBreakpoint(int address) {
/* 566 */     breakpointAdd = address;
/* 567 */     breakpointRemove = -1;
/* 568 */     sendCmd(3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeBreakpoint(int address) {
/* 574 */     breakpointAdd = -1;
/* 575 */     breakpointRemove = address;
/* 576 */     sendCmd(3);
/*     */   }
/*     */   
/*     */   private static void updateBreakpoints() {
/* 580 */     if (breakpointAdd != -1) {
/* 581 */       if (!breakpoints.contains(Integer.valueOf(breakpointAdd))) {
/* 582 */         breakpoints.add(0, Integer.valueOf(breakpointAdd));
/* 583 */         if (compiler != null) {
/* 584 */           compiler.addBreakpoint(breakpointAdd);
/*     */         }
/*     */       } 
/* 587 */       breakpointAdd = -1;
/*     */     } 
/* 589 */     if (breakpointRemove != -1) {
/* 590 */       if (breakpointRemove >= 0 && breakpointRemove < breakpoints.size()) {
/* 591 */         address = ((Integer)breakpoints.remove(breakpointRemove)).intValue();
/* 592 */         if (compiler != null) {
/* 593 */           compiler.removeBreakpoint(address);
/*     */         }
/*     */       } else {
/* 596 */         index = breakpoints.indexOf(Integer.valueOf(breakpointRemove));
/* 597 */         if (index != -1) {
/* 598 */           breakpoints.remove(index);
/* 599 */           if (compiler != null) {
/* 600 */             compiler.removeBreakpoint(breakpointRemove);
/*     */           }
/*     */         } 
/*     */       } 
/* 604 */       breakpointRemove = -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int[] getBreakpoints() {
/* 609 */     int[] rc = new int[breakpoints.size()];
/* 610 */     for (int i = 0; i < rc.length; i++) {
/* 611 */       rc[i] = ((Integer)breakpoints.get(i)).intValue();
/*     */     }
/* 613 */     return rc;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getParam(int index) {
/* 618 */     if (index < 4) {
/* 619 */       return regs[4 + index];
/*     */     }
/* 621 */     return Refs.addressSpace.read32(regs[29] + 16 + 4 * (index - 4));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void debugPrintf() {
/* 626 */     if (logPrintf.isInfoEnabled()) {
/* 627 */       fmt = readString(regs[4]);
/* 628 */       StringBuilder s = new StringBuilder();
/*     */       
/* 630 */       int param = 1;
/* 631 */       int perc = fmt.indexOf('%');
/* 632 */       while (perc != -1) {
/* 633 */         s.append(fmt.substring(0, perc));
/*     */         
/* 635 */         boolean leadingZero = false;
/* 636 */         boolean firstDigit = false;
/* 637 */         int digits = 0;
/*     */ 
/*     */         
/*     */         while (true) {
/* 641 */           int c = fmt.charAt(++perc);
/* 642 */           switch (c) {
/*     */             case 115:
/* 644 */               s.append(readString(getParam(param++)));
/*     */               break;
/*     */             case 120:
/* 647 */               if (digits != 0) {
/* 648 */                 if (leadingZero) {
/* 649 */                   s.append(MiscUtil.toHex(getParam(param++), digits)); break;
/*     */                 } 
/* 651 */                 s.append(MiscUtil.toHex(getParam(param++), digits));
/*     */                 break;
/*     */               } 
/* 654 */               s.append(Integer.toHexString(getParam(param++)));
/*     */               break;
/*     */             
/*     */             case 100:
/* 658 */               s.append(getParam(param++));
/*     */               break;
/*     */             case 45:
/*     */             case 46:
/*     */             case 104:
/*     */               continue;
/*     */           } 
/* 665 */           if (c >= 48 && c <= 57) {
/* 666 */             if (firstDigit) {
/* 667 */               leadingZero = (c == 48);
/* 668 */               firstDigit = false;
/*     */             } 
/* 670 */             digits = digits * 10 + c - 48;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 678 */         fmt = fmt.substring(perc + 1);
/* 679 */         perc = fmt.indexOf('%');
/*     */       } 
/* 681 */       s.append(fmt);
/* 682 */       String str = s.toString();
/* 683 */       while (str.endsWith("\n") || str.endsWith("\r")) {
/* 684 */         str = str.substring(0, s.length() - 1);
/*     */       }
/* 686 */       logPrintf.info(s);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String readString(int address) {
/* 691 */     String rc = "";
/*     */     while (true) {
/* 693 */       int val = Refs.addressSpace.read8(address++);
/* 694 */       if (val != 0) {
/* 695 */         rc = rc + (char)val;
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 700 */     return rc;
/*     */   }
/*     */   
/*     */   public static void debugA0() {
/* 704 */     switch (regs[9]) {
/*     */       case 21:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/*     */       case 25:
/*     */       case 26:
/*     */       case 27:
/*     */       case 63:
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 718 */     System.out.println(MiscUtil.toHex(regs[31], 8) + " BIOS: A0 " + MiscUtil.toHex(regs[9], 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void debugB0() {
/* 723 */     switch (regs[9]) {
/*     */       case 61:
/*     */         return;
/*     */     } 
/*     */     
/* 728 */     System.out.println(MiscUtil.toHex(regs[31], 8) + " BIOS: B0 " + MiscUtil.toHex(regs[9], 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void debugC0() {
/* 733 */     switch (regs[9]) {
/*     */     
/* 735 */     }  System.out.println(MiscUtil.toHex(regs[31], 8) + " BIOS: C0 " + MiscUtil.toHex(regs[9], 2));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 740 */   public static void debugDeliverEvent() { System.out.println(MiscUtil.toHex(regs[31], 8) + "BIOS: DeliverEvent " + MiscUtil.toHex(regs[4], 8) + ", " + MiscUtil.toHex(regs[5], 8) + ", " + MiscUtil.toHex(regs[6], 8)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void cacheCleared() {
/* 757 */     totalBreakouts++;
/* 758 */     if (compiler != null) {
/* 759 */       compiler.clearCache();
/* 760 */       if (inCompiler[executionDepth]) {
/* 761 */         e = ContinueExecutionException.SKIP_CURRENT;
/* 762 */         if (logCache.isDebugEnabled()) {
/* 763 */           logCache.debug("cacheCleared in compiler depth=" + executionDepth + "; throwing ContinueExecutionException...");
/*     */         }
/* 765 */         throw e;
/*     */       } 
/* 767 */       if (logCache.isDebugEnabled()) {
/* 768 */         logCache.debug("cacheCleared in interpreter depth=" + executionDepth + "; continuing interpreting...");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassGen modifyClass(String classname, ClassGen cgen) {
/* 775 */     ConstantPoolGen cp = cgen.getConstantPool();
/*     */ 
/*     */ 
/*     */     
/* 779 */     Method m = cgen.containsMethod("invoke", "(I)V");
/* 780 */     MethodGen mg = JPSXClassLoader.emptyMethod(cgen, m);
/*     */     
/* 782 */     InstructionList il = mg.getInstructionList();
/* 783 */     il.append(new ILOAD(false));
/* 784 */     il.append(new BIPUSH(26));
/* 785 */     il.append(new ISHR());
/*     */     
/* 787 */     InstructionHandle[] handles = new InstructionHandle[64];
/* 788 */     int[] matches = new int[64];
/* 789 */     for (int i = -32; i < 32; i++) {
/* 790 */       int j = i;
/* 791 */       if (j < 0) j += 64; 
/* 792 */       matches[i + 32] = i;
/* 793 */       CPUInstruction inst = decoding[j];
/* 794 */       handles[i + 32] = il.append(new ILOAD(false));
/* 795 */       switch (j) {
/*     */         case 0:
/* 797 */           il.append(new INVOKESTATIC(cp.addMethodref(DECODER_CLASS, "invokeSpecial", "(I)V")));
/*     */           break;
/*     */         case 1:
/* 800 */           il.append(new INVOKESTATIC(cp.addMethodref(DECODER_CLASS, "invokeRegImm", "(I)V")));
/*     */           break;
/*     */         default:
/* 803 */           checkInstruction(inst);
/* 804 */           il.append(new INVOKESTATIC(cp.addMethodref(inst.getInterpreterClass().getName(), inst.getInterpretMethodName(), "(I)V")));
/*     */           break;
/*     */       } 
/* 807 */       il.append(new RETURN());
/*     */     } 
/* 809 */     InstructionHandle def = il.append(new ILOAD(false));
/* 810 */     il.append(new INVOKESTATIC(cp.addMethodref(CLASS, "interpret_invalid", "(I)V")));
/* 811 */     il.append(new RETURN());
/* 812 */     il.insert(handles[0], new TABLESWITCH(matches, handles, def));
/* 813 */     mg.setMaxLocals();
/* 814 */     mg.setMaxStack();
/* 815 */     cgen.replaceMethod(m, mg.getMethod());
/* 816 */     il.dispose();
/*     */ 
/*     */ 
/*     */     
/* 820 */     m = cgen.containsMethod("invokeSpecial", "(I)V");
/* 821 */     mg = JPSXClassLoader.emptyMethod(cgen, m);
/*     */     
/* 823 */     il = mg.getInstructionList();
/* 824 */     il.append(new ILOAD(false));
/* 825 */     il.append(new BIPUSH(63));
/* 826 */     il.append(new IAND());
/*     */     
/* 828 */     handles = new InstructionHandle[64];
/* 829 */     matches = new int[64];
/* 830 */     for (int i = 0; i < 64; i++) {
/* 831 */       matches[i] = i;
/* 832 */       CPUInstruction inst = decodingSPECIAL[i];
/* 833 */       handles[i] = il.append(new ILOAD(false));
/* 834 */       checkInstruction(inst);
/* 835 */       il.append(new INVOKESTATIC(cp.addMethodref(inst.getInterpreterClass().getName(), inst.getInterpretMethodName(), "(I)V")));
/* 836 */       il.append(new RETURN());
/*     */     } 
/* 838 */     def = il.append(new ILOAD(false));
/* 839 */     il.append(new INVOKESTATIC(cp.addMethodref(CLASS, "interpret_invalid", "(I)V")));
/* 840 */     il.append(new RETURN());
/* 841 */     il.insert(handles[0], new TABLESWITCH(matches, handles, def));
/* 842 */     mg.setMaxLocals();
/* 843 */     mg.setMaxStack();
/* 844 */     cgen.replaceMethod(m, mg.getMethod());
/* 845 */     il.dispose();
/*     */ 
/*     */ 
/*     */     
/* 849 */     m = cgen.containsMethod("invokeRegImm", "(I)V");
/* 850 */     mg = JPSXClassLoader.emptyMethod(cgen, m);
/*     */     
/* 852 */     il = mg.getInstructionList();
/* 853 */     il.append(new ILOAD(false));
/* 854 */     il.append(new INVOKESTATIC(cp.addMethodref(UTIL_CLASS, "bits_rt", "(I)I")));
/*     */     
/* 856 */     handles = new InstructionHandle[32];
/* 857 */     matches = new int[32];
/* 858 */     for (int i = 0; i < 32; i++) {
/* 859 */       matches[i] = i;
/* 860 */       CPUInstruction inst = decodingREGIMM[i];
/* 861 */       handles[i] = il.append(new ILOAD(false));
/* 862 */       checkInstruction(inst);
/* 863 */       il.append(new INVOKESTATIC(cp.addMethodref(inst.getInterpreterClass().getName(), inst.getInterpretMethodName(), "(I)V")));
/* 864 */       il.append(new RETURN());
/*     */     } 
/* 866 */     def = il.append(new ILOAD(false));
/* 867 */     il.append(new INVOKESTATIC(cp.addMethodref(CLASS, "interpret_invalid", "(I)V")));
/* 868 */     il.append(new RETURN());
/* 869 */     il.insert(handles[0], new TABLESWITCH(matches, handles, def));
/* 870 */     mg.setMaxLocals();
/* 871 */     mg.setMaxStack();
/* 872 */     cgen.replaceMethod(m, mg.getMethod());
/* 873 */     il.dispose();
/* 874 */     return cgen;
/*     */   }
/*     */   
/*     */   public void restoreInterpreterState() {
/* 878 */     if (inCompiler[executionDepth]) {
/* 879 */       compiler.restoreInterpreterState();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getReg(int reg) {
/* 885 */     if (inCompiler[executionDepth]) {
/* 886 */       return compiler.getReg(reg);
/*     */     }
/* 888 */     return regs[reg];
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setReg(int reg, int val) {
/* 893 */     if (inCompiler[executionDepth]) {
/* 894 */       compiler.setReg(reg, val);
/*     */     } else {
/* 896 */       regs[reg] = val;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void interpret_invalid(int ci) {
/* 904 */     breakHotspot = false;
/* 905 */     Refs.scp.signalReservedInstructionException();
/*     */   }
/*     */   
/*     */   public String disassemble(int address, int ci) {
/* 909 */     CPUInstruction inst = decodeInstruction(ci);
/* 910 */     CPUInstructionDisassembler disassembler = (CPUInstructionDisassembler)instructionDisassemblers.get(inst.getName());
/* 911 */     if (disassembler != null) {
/* 912 */       return disassembler.disassemble(inst, address, ci);
/*     */     }
/* 914 */     return "(" + inst.getName() + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void safeReturn() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dumpRegs() {
/* 927 */     s = MiscUtil.toHex(reg_pc, 8);
/* 928 */     for (int i = 0; i < 32; i++) {
/* 929 */       s = s + " " + MiscUtil.toHex(regs[i], 8);
/*     */     }
/* 931 */     System.out.println(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 940 */   public void interpreterBranch(int relativeToDelay) { delayedPCDelta = relativeToDelay; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpreterJump(int relativeToDelay, int target) {
/* 950 */     delayedPCDelta = relativeToDelay;
/* 951 */     interpretedJumpTarget = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpreterJumpAndLink(int relativeToDelay, int target, int retAddr) {
/* 962 */     delayedPCDelta = relativeToDelay;
/* 963 */     interpretedJumpAndLinkTarget = target;
/* 964 */     interpretedJumpAndLinkRetAddr = retAddr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 969 */   public int[] getInterpreterRegs() { return regs; }
/*     */ 
/*     */ 
/*     */   
/* 973 */   public final int getPC() { return reg_pc; }
/*     */ 
/*     */ 
/*     */   
/* 977 */   public final int getLO() { return reg_lo; }
/*     */ 
/*     */ 
/*     */   
/* 981 */   public final int getHI() { return reg_hi; }
/*     */ 
/*     */ 
/*     */   
/* 985 */   public final void setPC(int pc) { reg_pc = pc; }
/*     */ 
/*     */ 
/*     */   
/* 989 */   public final void setLO(int lo) { reg_lo = lo; }
/*     */ 
/*     */ 
/*     */   
/* 993 */   public final void setHI(int hi) { reg_hi = hi; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\R3000Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */