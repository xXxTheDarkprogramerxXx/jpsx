/*     */ package classes.runtime.org.jpsx.runtime.components.core;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*     */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*     */ import org.jpsx.api.components.core.cpu.SCP;
/*     */ import org.jpsx.api.components.core.irq.IRQController;
/*     */ import org.jpsx.api.components.core.irq.IRQOwner;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.core.IRQControllerImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IRQControllerImpl
/*     */   extends SingletonJPSXComponent
/*     */   implements MemoryMapped, IRQController
/*     */ {
/*     */   static final String CATEGORY = "IRQ";
/*  33 */   private static final Logger log = Logger.getLogger("IRQ");
/*     */   
/*  35 */   private static int IRQ_COUNT = 8;
/*  36 */   private static IRQOwner[] owners = new IRQOwner[IRQ_COUNT];
/*     */   
/*     */   private static final int ALL_INTERRUPTS = 255;
/*     */   
/*     */   private static final int ADDR_IRQ_REQUEST = 528486512;
/*     */   
/*     */   private static final int ADDR_IRQ_MASK = 528486516;
/*     */   private static int irqRequest;
/*     */   private static int irqMask;
/*     */   private static SCP scp;
/*     */   private static int oldRequest;
/*     */   
/*  48 */   public IRQControllerImpl() { super("JPSX IRQ Controller"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial init : ()V
/*     */     //   4: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.IRQ_CONTROLLER : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual set : (Ljava/lang/Object;)V
/*     */     //   11: getstatic org/jpsx/runtime/RuntimeConnections.MACHINE : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   14: invokevirtual resolve : ()Ljava/lang/Object;
/*     */     //   17: checkcast org/jpsx/runtime/JPSXMachine
/*     */     //   20: astore_1
/*     */     //   21: aload_1
/*     */     //   22: ldc 35000
/*     */     //   24: new org/jpsx/runtime/components/core/IRQControllerImpl$1
/*     */     //   27: dup
/*     */     //   28: aload_0
/*     */     //   29: invokespecial <init> : (Lorg/jpsx/runtime/components/core/IRQControllerImpl;)V
/*     */     //   32: invokeinterface addInitializer : (ILjava/lang/Runnable;)V
/*     */     //   37: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.ALL_MEMORY_MAPPED : Lorg/jpsx/bootstrap/connection/MultipleConnection;
/*     */     //   40: aload_0
/*     */     //   41: invokevirtual add : (Ljava/lang/Object;)V
/*     */     //   44: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #53	-> 0
/*     */     //   #54	-> 4
/*     */     //   #55	-> 11
/*     */     //   #56	-> 21
/*     */     //   #63	-> 37
/*     */     //   #64	-> 44
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	45	0	this	Lorg/jpsx/runtime/components/core/IRQControllerImpl;
/*     */     //   21	24	1	machine	Lorg/jpsx/runtime/JPSXMachine; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/*  68 */     super.resolveConnections();
/*  69 */     scp = (SCP)CoreComponentConnections.SCP.resolve();
/*     */   }
/*     */   
/*     */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/*  73 */     registrar.registerWrite32Callback(528486512, IRQControllerImpl.class, "irqRequestWrite32", true);
/*  74 */     registrar.registerRead32Callback(528486512, IRQControllerImpl.class, "irqRequestRead32", true);
/*     */     
/*  76 */     registrar.registerWrite32Callback(528486516, IRQControllerImpl.class, "irqMaskWrite32", true);
/*  77 */     registrar.registerRead32Callback(528486516, IRQControllerImpl.class, "irqMaskRead32", true);
/*     */   }
/*     */   
/*     */   public void registerIRQOwner(IRQOwner owner) {
/*  81 */     int irq = owner.getIRQ();
/*  82 */     owners[irq] = owner;
/*     */   }
/*     */   
/*     */   public static void irqRequestWrite32(int addr, int value, int mask) {
/*  86 */     irqRequest &= (mask ^ 0xFFFFFFFF | value & mask);
/*  87 */     updateInterruptLine();
/*     */   }
/*     */ 
/*     */   
/*  91 */   public static int irqRequestRead32(int addr) { return irqRequest; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static void irqMaskWrite32(int addr, int value, int mask) { irqMask = irqMask & (mask ^ 0xFFFFFFFF) | value & mask; }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static int irqMaskRead32(int addr) { return irqMask; }
/*     */ 
/*     */   
/*     */   public void raiseIRQ(int irq) {
/* 103 */     irqRequest |= 1 << irq;
/* 104 */     updateInterruptLine();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void updateInterruptLine() {
/* 110 */     assert Thread.holdsLock(IRQControllerImpl.class);
/* 111 */     changes = oldRequest ^ irqRequest;
/* 112 */     oldRequest = irqRequest;
/* 113 */     int irq = 0;
/* 114 */     while (irq < IRQ_COUNT && changes != 0) {
/* 115 */       if (0 != (changes & true)) {
/* 116 */         IRQOwner owner = owners[irq];
/* 117 */         if (owner != null) {
/* 118 */           if (0 != (irqRequest & 1 << irq)) {
/* 119 */             owner.irqSet();
/*     */           } else {
/* 121 */             owner.irqCleared();
/*     */           } 
/*     */         }
/*     */       } 
/* 125 */       changes >>= 1;
/* 126 */       irq++;
/*     */     } 
/* 128 */     scp.setInterruptLine(2, (0 != (irqMask & irqRequest & 0xFF)));
/*     */   }
/*     */ 
/*     */   
/* 132 */   public int getIRQRequest() { return irqRequest; }
/*     */ 
/*     */ 
/*     */   
/* 136 */   public int getIRQMask() { return irqMask; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\IRQControllerImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */