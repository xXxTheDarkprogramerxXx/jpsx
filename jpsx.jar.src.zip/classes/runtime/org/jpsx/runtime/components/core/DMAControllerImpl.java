/*     */ package classes.runtime.org.jpsx.runtime.components.core;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*     */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*     */ import org.jpsx.api.components.core.dma.DMAChannelOwner;
/*     */ import org.jpsx.api.components.core.dma.DMAController;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.core.DMAControllerImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMAControllerImpl
/*     */   extends SingletonJPSXComponent
/*     */   implements DMAController, MemoryMapped
/*     */ {
/*     */   protected static final String CATEGORY = "DMA";
/*  39 */   private static final Logger log = Logger.getLogger("DMA");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   protected static final String CLASS = DMAControllerImpl.class.getName();
/*     */   
/*     */   public static final boolean debugDMA = false;
/*     */   
/*     */   private static AddressSpace addressSpace;
/*     */   
/*     */   private static final int ADDR_DMA_PCR = 528486640;
/*     */   
/*     */   private static final int ADDR_DMA_ICR = 528486644;
/*     */   
/*     */   private static final int CHANNEL_COUNT = 7;
/*     */   private static final int DMA_CTRL_TO_DEVICE = 1;
/*     */   private static final int DMA_CTRL_BUSY = 16777216;
/*     */   private static final int ADDR_DMA0_ADDR = 528486528;
/*     */   private static final int ADDR_DMA0_SIZE = 528486532;
/*     */   private static final int ADDR_DMA0_CTRL = 528486536;
/*  64 */   private static final DMAChannelOwner[] dmaChannelOwners = new DMAChannelOwner[7];
/*     */   
/*     */   private static int pcr;
/*     */   
/*     */   private static int icr;
/*     */   
/*     */   private static IRQ irq;
/*     */ 
/*     */   
/*  73 */   public DMAControllerImpl() { super("JPSX DMA Controller"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial init : ()V
/*     */     //   4: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.DMA_CONTROLLER : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual set : (Ljava/lang/Object;)V
/*     */     //   11: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.ALL_MEMORY_MAPPED : Lorg/jpsx/bootstrap/connection/MultipleConnection;
/*     */     //   14: aload_0
/*     */     //   15: invokevirtual add : (Ljava/lang/Object;)V
/*     */     //   18: getstatic org/jpsx/runtime/RuntimeConnections.MACHINE : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   21: invokevirtual resolve : ()Ljava/lang/Object;
/*     */     //   24: checkcast org/jpsx/runtime/JPSXMachine
/*     */     //   27: astore_1
/*     */     //   28: aload_1
/*     */     //   29: ldc 40000
/*     */     //   31: new org/jpsx/runtime/components/core/DMAControllerImpl$1
/*     */     //   34: dup
/*     */     //   35: aload_0
/*     */     //   36: invokespecial <init> : (Lorg/jpsx/runtime/components/core/DMAControllerImpl;)V
/*     */     //   39: invokeinterface addInitializer : (ILjava/lang/Runnable;)V
/*     */     //   44: new org/jpsx/runtime/components/core/DMAControllerImpl$IRQ
/*     */     //   47: dup
/*     */     //   48: invokespecial <init> : ()V
/*     */     //   51: putstatic org/jpsx/runtime/components/core/DMAControllerImpl.irq : Lorg/jpsx/runtime/components/core/DMAControllerImpl$IRQ;
/*     */     //   54: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.IRQ_OWNERS : Lorg/jpsx/bootstrap/connection/MultipleConnection;
/*     */     //   57: getstatic org/jpsx/runtime/components/core/DMAControllerImpl.irq : Lorg/jpsx/runtime/components/core/DMAControllerImpl$IRQ;
/*     */     //   60: invokevirtual add : (Ljava/lang/Object;)V
/*     */     //   63: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #84	-> 0
/*     */     //   #85	-> 4
/*     */     //   #86	-> 11
/*     */     //   #87	-> 18
/*     */     //   #88	-> 28
/*     */     //   #95	-> 44
/*     */     //   #96	-> 54
/*     */     //   #97	-> 63
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	64	0	this	Lorg/jpsx/runtime/components/core/DMAControllerImpl;
/*     */     //   28	36	1	machine	Lorg/jpsx/runtime/JPSXMachine; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerAddresses(AddressSpaceRegistrar registrar) {
/* 100 */     registrar.registerWrite32Callback(528486644, DMAControllerImpl.class, "dmaICRWrite32", true);
/* 101 */     registrar.registerWrite32Callback(528486640, DMAControllerImpl.class, "dmaPCRWrite32");
/* 102 */     registrar.registerRead32Callback(528486644, DMAControllerImpl.class, "dmaICRRead32", true);
/* 103 */     registrar.registerRead32Callback(528486640, DMAControllerImpl.class, "dmaPCRRead32", true);
/* 104 */     for (int i = 0; i < 7; i++) {
/* 105 */       if (dmaChannelOwners[i] != null) {
/* 106 */         registrar.registerWrite32Callback(528486536 + i * 16, DMAControllerImpl.class, "dmaChannelCtrlWrite32");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/* 113 */     super.resolveConnections();
/* 114 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*     */   }
/*     */   
/*     */   public void registerDMAChannel(DMAChannelOwner owner) {
/* 118 */     int channel = owner.getDMAChannel();
/* 119 */     dmaChannelOwners[channel] = owner;
/*     */   }
/*     */   
/*     */   public static void dmaICRWrite32(int address, int value, int mask) {
/* 123 */     assert address == 528486644;
/*     */     
/* 125 */     int oldICR = icr;
/*     */     
/* 127 */     int newICR = icr & (value ^ 0xFFFFFFFF) & 0xFF000000 | value & 0xFFFFFF;
/*     */     
/* 129 */     newICR = oldICR & (mask ^ 0xFFFFFFFF) | newICR & mask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     icr = newICR;
/*     */   }
/*     */ 
/*     */   
/* 151 */   public static int dmaICRRead32(int address) { return icr; }
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static int dmaPCRRead32(int address) { return pcr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public static void dmaPCRWrite32(int address, int value) { pcr = value; }
/*     */ 
/*     */   
/*     */   public static void dmaChannelCtrlWrite32(int address, int ctrl) {
/* 178 */     int channel = (address - 528486536) / 16;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     addressSpace.internalWrite32(address, ctrl);
/* 184 */     if (dmaChannelOwners[channel] != null) {
/* 185 */       if ((ctrl & 0x1000000) != 0) {
/* 186 */         int base = addressSpace.internalRead32(address + 528486528 - 528486536);
/* 187 */         int size = addressSpace.internalRead32(address + 528486532 - 528486536);
/* 188 */         int blockSize = size & 0xFFFF;
/* 189 */         int blocks = size >> 16 & 0xFFFF;
/*     */         
/* 191 */         if ((ctrl & true) != 0) {
/* 192 */           dmaChannelOwners[channel].beginDMATransferToDevice(base, blocks, blockSize, ctrl);
/*     */         } else {
/* 194 */           dmaChannelOwners[channel].beginDMATransferFromDevice(base, blocks, blockSize, ctrl);
/*     */         } 
/*     */       } else {
/* 197 */         dmaChannelOwners[channel].cancelDMATransfer(ctrl);
/*     */       }
/*     */     
/* 200 */     } else if ((ctrl & 0x1000000) != 0) {
/* 201 */       if ((ctrl & true) != 0) {
/* 202 */         System.out.println("DMA to Unknown channel " + channel);
/*     */       } else {
/* 204 */         System.out.println("DMA from Unknown channel " + channel);
/*     */       } 
/*     */     } else {
/* 207 */       System.out.println("DMA cancel Unknown channel " + channel);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 213 */   public void dmaChannelTransferComplete(DMAChannelOwner owner) { dmaChannelTransferComplete(owner, true); }
/*     */ 
/*     */   
/*     */   public void dmaChannelTransferComplete(DMAChannelOwner owner, boolean interrupt) {
/* 217 */     int channel = owner.getDMAChannel();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     int address = 528486536 + channel * 16;
/*     */ 
/*     */     
/* 225 */     addressSpace.internalWrite32(address, addressSpace.internalRead32(address) & 0xFEFFFFFF);
/*     */     
/* 227 */     if (interrupt && 
/* 228 */       0 != (icr & 1 << channel + 16)) {
/*     */ 
/*     */       
/* 231 */       icr |= 1 << channel + 24;
/*     */ 
/*     */       
/* 234 */       irq.raiseIRQ();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\DMAControllerImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */