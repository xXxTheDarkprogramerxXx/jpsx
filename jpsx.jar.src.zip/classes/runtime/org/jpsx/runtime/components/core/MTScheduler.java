/*     */ package classes.runtime.org.jpsx.runtime.components.core;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.cpu.PollBlockListener;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.api.components.core.scheduler.Quartz;
/*     */ import org.jpsx.api.components.core.scheduler.ScheduledAction;
/*     */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.core.MTScheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MTScheduler
/*     */   extends SingletonJPSXComponent
/*     */   implements Scheduler
/*     */ {
/*  29 */   private static final Logger log = Logger.getLogger("Scheduler");
/*  30 */   private static final boolean logTraceEnabled = log.isTraceEnabled();
/*     */   private Quartz quartz;
/*     */   
/*  33 */   public MTScheduler() { super("JPSX Multi-threaded Scheduler"); }
/*     */ 
/*     */   
/*     */   private R3000 r3000;
/*     */   
/*     */   private PollBlockListener pollBlockListeners;
/*     */   
/*     */   private static TickGeneratorThread tickThread;
/*     */   
/*     */   private static ActionThread actionThread;
/*  43 */   private static final Object cpuControlMonitor = new Object();
/*     */ 
/*     */   
/*     */   public void init() {
/*  47 */     super.init();
/*  48 */     tickThread = new TickGeneratorThread(null);
/*  49 */     actionThread = new ActionThread(this);
/*  50 */     CoreComponentConnections.SCHEDULER.set(this);
/*     */   }
/*     */   
/*     */   public void resolveConnections() {
/*  54 */     super.resolveConnections();
/*  55 */     this.quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/*  56 */     this.r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/*  57 */     this.pollBlockListeners = (PollBlockListener)CoreComponentConnections.POLL_BLOCK_LISTENERS.resolve();
/*     */   }
/*     */   
/*     */   public void begin() {
/*  61 */     tickThread.start();
/*  62 */     actionThread.start();
/*     */   }
/*     */ 
/*     */   
/*  66 */   public void schedule(long time, ScheduledAction action) { schedule(time, 1000000L, action); }
/*     */ 
/*     */   
/*     */   public void schedule(long time, long jitter, ScheduledAction action) {
/*  70 */     if (jitter < 1000000L)
/*     */     {
/*  72 */       throw new IllegalStateException("jitter <1 msec not yet supported");
/*     */     }
/*  74 */     actionThread.schedule(time, action);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public boolean isScheduled(ScheduledAction action) { return actionThread.isScheduled(action); }
/*     */ 
/*     */   
/*     */   public void cpuThreadWait() {
/*  83 */     assert this.r3000.isExecutionThread();
/*  84 */     this.pollBlockListeners.aboutToBlock();
/*  85 */     int count = cpuResumeCount;
/*  86 */     synchronized (cpuControlMonitor) {
/*     */       
/*  88 */       if (count == cpuResumeCount) {
/*     */         try {
/*  90 */           cpuControlMonitor.wait();
/*  91 */         } catch (InterruptedException e) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cpuThreadNotify() {
/*  98 */     synchronized (cpuControlMonitor) {
/*  99 */       cpuResumeCount++;
/* 100 */       cpuControlMonitor.notify();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   private static String traceTime(long time) { return String.valueOf(time / 1000000L); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\MTScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */