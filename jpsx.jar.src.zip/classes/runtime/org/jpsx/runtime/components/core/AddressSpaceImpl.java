/*      */ package classes.runtime.org.jpsx.runtime.components.core;
/*      */ 
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import org.apache.bcel.classfile.Method;
/*      */ import org.apache.bcel.generic.ClassGen;
/*      */ import org.apache.bcel.generic.ConstantPoolGen;
/*      */ import org.apache.bcel.generic.IAND;
/*      */ import org.apache.bcel.generic.ILOAD;
/*      */ import org.apache.bcel.generic.INVOKESTATIC;
/*      */ import org.apache.bcel.generic.IRETURN;
/*      */ import org.apache.bcel.generic.ISHL;
/*      */ import org.apache.bcel.generic.ISHR;
/*      */ import org.apache.bcel.generic.InstructionList;
/*      */ import org.apache.bcel.generic.MethodGen;
/*      */ import org.apache.bcel.generic.PUSH;
/*      */ import org.apache.bcel.generic.RETURN;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpaceListener;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpaceRegistrar;
/*      */ import org.jpsx.api.components.core.addressspace.Pollable;
/*      */ import org.jpsx.api.components.core.cpu.R3000;
/*      */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*      */ import org.jpsx.bootstrap.classloader.ClassModifier;
/*      */ import org.jpsx.bootstrap.classloader.JPSXClassLoader;
/*      */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*      */ import org.jpsx.runtime.SingletonJPSXComponent;
/*      */ import org.jpsx.runtime.components.core.AddressSpaceImpl;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.util.ByteCodeUtil;
/*      */ import org.jpsx.runtime.util.ClassUtil;
/*      */ import org.jpsx.runtime.util.MiscUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class AddressSpaceImpl
/*      */   extends SingletonJPSXComponent
/*      */   implements ClassModifier, AddressSpace, AddressSpaceRegistrar
/*      */ {
/*   47 */   private static final Logger log = Logger.getLogger("AddressSpace");
/*   48 */   private static final Logger logPoll = Logger.getLogger("AddressSpace.poll");
/*   49 */   private static final Logger logUnknown = Logger.getLogger("AddressSpace.unknown");
/*      */   
/*   51 */   private static final String HARDWARE_CLASS = ClassUtil.innerClassName(AddressSpaceImpl.class, "Hardware");
/*      */   
/*   53 */   private static final boolean logUnknownDebug = logUnknown.isDebugEnabled();
/*   54 */   private static final boolean logPollDebug = logPoll.isDebugEnabled();
/*   55 */   private static final boolean logPollTrace = logPoll.isTraceEnabled();
/*      */   
/*      */   public static final int[] ram;
/*      */   
/*      */   public static int[] ramD;
/*      */   
/*      */   public static final int[] scratch;
/*      */   
/*      */   public static final int[] bios;
/*      */   
/*      */   public static final int[] hw;
/*      */   
/*      */   public static final int[] par;
/*      */   
/*      */   private static int[] ramDummy;
/*      */   
/*      */   private static byte[] ramTags;
/*      */   
/*      */   private static byte[] biosTags;
/*      */   
/*   75 */   private static int lastPoll32Address = 0;
/*   76 */   private static int lastPoll32Count = 0;
/*      */   private static boolean writeEnabled = true;
/*      */   private static final int OFFSET_MASK = 262143999;
/*      */   private static final int SCRATCH_MASK = 4095;
/*      */   private static final int PAR_MASK = 65535;
/*      */   private static final int BIOS_MASK = 524287; private static final int HW_MASK = 8191; private static int readPC0; private static int readPC1; private static int readPC2; private static int readAddress0; private static int readAddress1; private static int readAddress2; private static AddressSpaceListener addressSpaceListeners; private static R3000 r3000; private static Scheduler scheduler; private static Map<Integer, Method> read8Callbacks; private static Map<Integer, Method> read16Callbacks; private static Map<Integer, Method> subRead16Callbacks; private static Map<Integer, Method> read32Callbacks; private static Map<Integer, Method> subRead32Callbacks; private static Map<Integer, Method> write8Callbacks; private static Map<Integer, Method> write16Callbacks; private static Map<Integer, Method> subWrite16Callbacks; private static Map<Integer, Method> write32Callbacks; private static Map<Integer, Method> subWrite32Callbacks; private static Map<Integer, Pollable> poll8Callbacks; private static Map<Integer, Pollable> poll16Callbacks; private static Map<Integer, Pollable> poll32Callbacks; private static final Class[] READ_CALLBACK_PARAMS; private static final Class[] WRITE_CALLBACK_PARAMS; private static final Class[] SUBWRITE_CALLBACK_PARAMS; public AddressSpaceImpl() { super("JPSX Address Space"); } public void resolveConnections() { super.resolveConnections(); addressSpaceListeners = (AddressSpaceListener)CoreComponentConnections.ADDRESS_SPACE_LISTENERS.resolve(); r3000 = (R3000)CoreComponentConnections.R3000.resolve(); scheduler = (Scheduler)CoreComponentConnections.SCHEDULER.resolve(); } public void init() { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokespecial init : ()V
/*      */     //   4: getstatic org/jpsx/runtime/components/core/AddressSpaceImpl.HARDWARE_CLASS : Ljava/lang/String;
/*      */     //   7: aload_0
/*      */     //   8: invokestatic registerClassModifier : (Ljava/lang/String;Lorg/jpsx/bootstrap/classloader/ClassModifier;)V
/*      */     //   11: getstatic org/jpsx/runtime/RuntimeConnections.MACHINE : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*      */     //   14: invokevirtual resolve : ()Ljava/lang/Object;
/*      */     //   17: checkcast org/jpsx/runtime/JPSXMachine
/*      */     //   20: astore_1
/*      */     //   21: getstatic org/jpsx/runtime/components/core/CoreComponentConnections.ADDRESS_SPACE : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*      */     //   24: aload_0
/*      */     //   25: invokevirtual set : (Ljava/lang/Object;)V
/*      */     //   28: aload_1
/*      */     //   29: sipush #30000
/*      */     //   32: new org/jpsx/runtime/components/core/AddressSpaceImpl$1
/*      */     //   35: dup
/*      */     //   36: aload_0
/*      */     //   37: invokespecial <init> : (Lorg/jpsx/runtime/components/core/AddressSpaceImpl;)V
/*      */     //   40: invokeinterface addInitializer : (ILjava/lang/Runnable;)V
/*      */     //   45: aload_1
/*      */     //   46: sipush #10000
/*      */     //   49: new org/jpsx/runtime/components/core/AddressSpaceImpl$2
/*      */     //   52: dup
/*      */     //   53: aload_0
/*      */     //   54: invokespecial <init> : (Lorg/jpsx/runtime/components/core/AddressSpaceImpl;)V
/*      */     //   57: invokeinterface addInitializer : (ILjava/lang/Runnable;)V
/*      */     //   62: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #125	-> 0
/*      */     //   #126	-> 4
/*      */     //   #127	-> 11
/*      */     //   #128	-> 21
/*      */     //   #129	-> 28
/*      */     //   #141	-> 45
/*      */     //   #148	-> 62
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	63	0	this	Lorg/jpsx/runtime/components/core/AddressSpaceImpl;
/*      */     //   21	42	1	machine	Lorg/jpsx/runtime/JPSXMachine; } private void rewriteHWMethod(ClassGen cgen, String name, String signature, SortedMap<Integer, InstructionList> cases, InstructionList suffix, int resolution) { ConstantPoolGen cp = cgen.getConstantPool(); Method m = cgen.containsMethod(name, signature); MethodGen mg = JPSXClassLoader.emptyMethod(cgen, m); InstructionList il = mg.getInstructionList(); ByteCodeUtil.emitSwitch(cp, il, 0, cases, resolution, 528486400, 528494592 - resolution); il.append(suffix); mg.setMaxLocals(); mg.setMaxStack(); cgen.replaceMethod(m, mg.getMethod()); il.dispose(); } public ClassGen modifyClass(String classname, ClassGen cgen) { ConstantPoolGen cp = cgen.getConstantPool(); InstructionList suffix = new InstructionList(); InstructionList il = new InstructionList(); TreeMap<Integer, InstructionList> cases = new TreeMap<Integer, InstructionList>(); Iterator<Integer> addresses; for (addresses = read32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); Method m = (Method)read32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new IRETURN()); cases.put(address, il); }  for (addresses = subRead32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subRead32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new IRETURN()); cases.put(address, il); }  suffix.append(new ILOAD(false)); suffix.append(new INVOKESTATIC(cp.addMethodref(classname, "defaultRead32", "(I)I"))); suffix.append(new IRETURN()); rewriteHWMethod(cgen, "read32", "(I)I", cases, suffix, 4); cases.clear(); for (addresses = write32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); Method m = (Method)write32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(II)V"))); il.append(new RETURN()); cases.put(address, il); }  for (addresses = subWrite32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new PUSH(cp, -1)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(address, il); }  suffix.append(new ILOAD(false)); suffix.append(new ILOAD(true)); suffix.append(new INVOKESTATIC(cp.addMethodref(classname, "defaultWrite32", "(II)V"))); suffix.append(new RETURN()); rewriteHWMethod(cgen, "write32", "(II)V", cases, suffix, 4); cases.clear(); for (addresses = read16Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); Method m = (Method)read16Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, '￿')); il.append(new IAND()); il.append(new IRETURN()); cases.put(address, il); }  for (addresses = subRead16Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subRead16Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, '￿')); il.append(new IAND()); il.append(new IRETURN()); cases.put(address, il); }  for (addresses = subRead32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); int iAddress = address.intValue() & 0xFFFFFFFC; assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subRead32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, '￿')); il.append(new IAND()); il.append(new IRETURN()); cases.put(address, il); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 16)); il.append(new ISHR()); il.append(new IRETURN()); cases.put(Integer.valueOf(iAddress + 2), il); }  suffix.append(new ILOAD(false)); suffix.append(new INVOKESTATIC(cp.addMethodref(classname, "defaultRead16", "(I)I"))); suffix.append(new IRETURN()); rewriteHWMethod(cgen, "read16", "(I)I", cases, suffix, 2); cases.clear(); for (addresses = write16Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); Method m = (Method)write16Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(II)V"))); il.append(new RETURN()); cases.put(address, il); }  for (addresses = subWrite16Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subWrite16Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new PUSH(cp, '￿')); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(address, il); }  for (addresses = subWrite32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); int iAddress = address.intValue() & 0xFFFFFFFC; assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new PUSH(cp, '￿')); il.append(new IAND()); il.append(new PUSH(cp, '￿')); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(address, il); m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 16)); il.append(new ISHL()); il.append(new PUSH(cp, -65536)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(Integer.valueOf(iAddress + 2), il); }  suffix.append(new ILOAD(false)); suffix.append(new ILOAD(true)); suffix.append(new INVOKESTATIC(cp.addMethodref(classname, "defaultWrite16", "(II)V"))); suffix.append(new RETURN()); rewriteHWMethod(cgen, "write16", "(II)V", cases, suffix, 2); cases.clear(); for (addresses = read8Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); Method m = (Method)read8Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new IRETURN()); cases.put(address, il); }  for (addresses = subRead16Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); int iAddress = address.intValue() & 0xFFFFFFFE; assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subRead16Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new IRETURN()); cases.put(address, il); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 8)); il.append(new ISHR()); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new IRETURN()); cases.put(Integer.valueOf(iAddress + 1), il); }  for (addresses = subRead32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); int iAddress = address.intValue() & 0xFFFFFFFC; assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subRead32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new IRETURN()); cases.put(address, il); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 8)); il.append(new ISHR()); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new IRETURN()); cases.put(Integer.valueOf(iAddress + 1), il); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 16)); il.append(new ISHR()); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new IRETURN()); cases.put(Integer.valueOf(iAddress + 2), il); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(I)I"))); il.append(new PUSH(cp, 24)); il.append(new ISHR()); il.append(new IRETURN()); cases.put(Integer.valueOf(iAddress + 3), il); }  suffix.append(new ILOAD(false)); suffix.append(new INVOKESTATIC(cp.addMethodref(classname, "defaultRead8", "(I)I"))); suffix.append(new IRETURN()); rewriteHWMethod(cgen, "read8", "(I)I", cases, suffix, 1); cases.clear(); for (addresses = write8Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); Method m = (Method)write8Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(II)V"))); il.append(new RETURN()); cases.put(address, il); }  for (addresses = subWrite16Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); int iAddress = address.intValue() & 0xFFFFFFFE; assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subWrite16Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new PUSH(cp, 'ÿ')); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(address, il); m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 8)); il.append(new ISHL()); il.append(new PUSH(cp, '＀')); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(Integer.valueOf(iAddress + 1), il); }  for (addresses = subWrite32Callbacks.keySet().iterator(); addresses.hasNext(); ) { Integer address = (Integer)addresses.next(); int iAddress = address.intValue() & 0xFFFFFFFC; assert null == cases.get(address) : MiscUtil.toHex(address.intValue(), 8); Method m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new PUSH(cp, 'ÿ')); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(address, il); m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new PUSH(cp, 8)); il.append(new ISHL()); il.append(new PUSH(cp, '＀')); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(Integer.valueOf(iAddress + 1), il); m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 'ÿ')); il.append(new IAND()); il.append(new PUSH(cp, 16)); il.append(new ISHL()); il.append(new PUSH(cp, 16711680)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(Integer.valueOf(iAddress + 2), il); m = (Method)subWrite32Callbacks.get(address); il = new InstructionList(); il.append(new PUSH(cp, iAddress)); il.append(new ILOAD(true)); il.append(new PUSH(cp, 24)); il.append(new ISHL()); il.append(new PUSH(cp, -16777216)); il.append(new INVOKESTATIC(cp.addMethodref(m.getDeclaringClass().getName(), m.getName(), "(III)V"))); il.append(new RETURN()); cases.put(Integer.valueOf(iAddress + 3), il); }  suffix.append(new ILOAD(false)); suffix.append(new ILOAD(true)); suffix.append(new INVOKESTATIC(cp.addMethodref(classname, "defaultWrite8", "(II)V"))); suffix.append(new RETURN()); rewriteHWMethod(cgen, "write8", "(II)V", cases, suffix, 1); return cgen; } public void tagClearPollCounters() { _tagClearPollCounters(); } public static void _tagClearPollCounters() { readPC0 = readPC1 = readPC2 = -1; } public void tagAddressAccessRead8(int pc, int address) { _tagAddressAccessRead8(pc, address); } public static void _tagAddressAccessRead8(int pc, int address) { byte[] tags; if (pc < -1077936128 || pc >= -1077411840) { tags = ramTags; } else { tags = biosTags; }  byte tag = 0; int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { tag = 1; } else if (address < 528486400 && address >= 528482304) { tag = 2; } else if (prefix == 0 && offset < 2097152) { tag = 1; } else if (prefix == -6 && offset < 2097152) { tag = 1; }
/*      */     else if (address < 528494592 && address >= 528486400) { tag = 4; }
/*      */     else if (address < 520159232 && address >= 520093696) { tag = 16; }
/*      */     else if (address >= -1077936128 && address < -1077411840) { tag = 8; }
/*      */      int index = (pc & 0x1FFFFF) >> 2; int oldTag = tags[index]; if (0 != (oldTag & 0x20)) { _checkPoll8(address); }
/*      */     else if ((pc == readPC0 && address == readAddress0) || (pc == readPC1 && address == readAddress1) || (pc == readPC2 && address == readAddress2)) { tag = (byte)(tag | 0x20); if (logPollDebug)
/*      */         logPoll.debug("possible poll at " + MiscUtil.toHex(pc, 8) + " of " + MiscUtil.toHex(address, 8));  }
/*      */      readPC0 = readPC1; readPC1 = readPC2; readPC2 = pc; readAddress0 = readAddress1; readAddress1 = readAddress2; readAddress2 = address; tags[index] = (byte)(tags[index] | tag); } public void tagAddressAccessRead16(int pc, int address) { _tagAddressAccessRead16(pc, address); } public static void _tagAddressAccessRead16(int pc, int address) { byte[] tags; if (pc < -1077936128 || pc >= -1077411840) { tags = ramTags; }
/*      */     else { tags = biosTags; }
/*      */      byte tag = 0; int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { tag = 1; }
/*      */     else if (address < 528486400 && address >= 528482304) { tag = 2; }
/*      */     else if (prefix == 0 && offset < 2097152) { tag = 1; }
/*      */     else if (prefix == -6 && offset < 2097152) { tag = 1; }
/*      */     else if (address < 528494592 && address >= 528486400) { tag = 4; }
/*      */     else if (address < 520159232 && address >= 520093696) { tag = 16; }
/*      */     else if (address >= -1077936128 && address < -1077411840) { tag = 8; }
/*      */      int index = (pc & 0x1FFFFF) >> 2; int oldTag = tags[index]; if (0 != (oldTag & 0x20)) { _checkPoll16(address); }
/*      */     else if ((pc == readPC0 && address == readAddress0) || (pc == readPC1 && address == readAddress1) || (pc == readPC2 && address == readAddress2)) { tag = (byte)(tag | 0x20); if (logPollDebug)
/*      */         logPoll.debug("possible poll at " + MiscUtil.toHex(pc, 8) + " of " + MiscUtil.toHex(address, 8));  }
/*  100 */      readPC0 = readPC1; readPC1 = readPC2; readPC2 = pc; readAddress0 = readAddress1; readAddress1 = readAddress2; readAddress2 = address; tags[index] = (byte)(tags[index] | tag); } public void tagAddressAccessRead32(int pc, int address) { _tagAddressAccessRead32(pc, address); } static  { ram = new int[524288];
/*      */     
/*  102 */     ramDummy = new int[1024];
/*  103 */     ramD = ram;
/*  104 */     ramTags = new byte[524288];
/*  105 */     biosTags = new byte[131072];
/*  106 */     scratch = new int[1024];
/*  107 */     bios = new int[131072];
/*  108 */     hw = new int[2048];
/*  109 */     par = new int[16384];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1283 */     read8Callbacks = CollectionsFactory.newHashMap();
/* 1284 */     read16Callbacks = CollectionsFactory.newHashMap();
/* 1285 */     subRead16Callbacks = CollectionsFactory.newHashMap();
/* 1286 */     read32Callbacks = CollectionsFactory.newHashMap();
/* 1287 */     subRead32Callbacks = CollectionsFactory.newHashMap();
/* 1288 */     write8Callbacks = CollectionsFactory.newHashMap();
/* 1289 */     write16Callbacks = CollectionsFactory.newHashMap();
/* 1290 */     subWrite16Callbacks = CollectionsFactory.newHashMap();
/* 1291 */     write32Callbacks = CollectionsFactory.newHashMap();
/* 1292 */     subWrite32Callbacks = CollectionsFactory.newHashMap();
/*      */     
/* 1294 */     poll8Callbacks = CollectionsFactory.newHashMap();
/* 1295 */     poll16Callbacks = CollectionsFactory.newHashMap();
/* 1296 */     poll32Callbacks = CollectionsFactory.newHashMap();
/*      */     
/* 1298 */     READ_CALLBACK_PARAMS = new Class[] { int.class };
/* 1299 */     WRITE_CALLBACK_PARAMS = new Class[] { int.class, int.class };
/* 1300 */     SUBWRITE_CALLBACK_PARAMS = new Class[] { int.class, int.class, int.class }; }
/*      */   public static void _tagAddressAccessRead32(int pc, int address) { byte[] tags; if (pc < -1077936128 || pc >= -1077411840) { tags = ramTags; } else { tags = biosTags; }  byte tag = 0; int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { tag = 1; } else if (address < 528486400 && address >= 528482304) { tag = 2; } else if (prefix == 0 && offset < 2097152) { tag = 1; } else if (prefix == -6 && offset < 2097152) { tag = 1; } else if (address < 528494592 && address >= 528486400) { tag = 4; } else if (address < 520159232 && address >= 520093696) { tag = 16; } else if (address >= -1077936128 && address < -1077411840) { tag = 8; }  int index = (pc & 0x1FFFFF) >> 2; int oldTag = tags[index]; if (0 != (oldTag & 0x20)) { _checkPoll32(address); } else if ((pc == readPC0 && address == readAddress0) || (pc == readPC1 && address == readAddress1) || (pc == readPC2 && address == readAddress2)) { tag = (byte)(tag | 0x20); if (logPollDebug) logPoll.debug("possible poll at " + MiscUtil.toHex(pc, 8) + " of " + MiscUtil.toHex(address, 8));  }  readPC0 = readPC1; readPC1 = readPC2; readPC2 = pc; readAddress0 = readAddress1; readAddress1 = readAddress2; readAddress2 = address; tags[index] = (byte)(tags[index] | tag); }
/*      */   public void tagAddressAccessWrite(int pc, int address) { _tagAddressAccessWrite(pc, address); }
/*      */   public static void _tagAddressAccessWrite(int pc, int address) { byte[] tags; if (pc < -1077936128 || pc >= -1077411840) { tags = ramTags; } else { tags = biosTags; }  int prefix = address >> 28; int offset = address & 0xF9FFFFF; byte tag = 0; if (prefix == -8 && offset < 2097152) { tag = 1; } else if (address < 528486400 && address >= 528482304) { tag = 2; } else if (prefix == 0 && offset < 2097152) { tag = 1; } else if (prefix == -6 && offset < 2097152) { tag = 1; } else if (address < 528494592 && address >= 528486400) { tag = 4; } else if (address < 520159232 && address >= 520093696) { tag = 16; } else if (address >= -1077936128 && address < -1077411840) { tag = 8; }  tags[(pc & 0x1FFFFF) >> 2] = (byte)(tags[(pc & 0x1FFFFF) >> 2] | tag); }
/*      */   public byte getTag(int pc) { byte[] tags; if (pc < -1077936128 || pc >= -1077411840) { tags = ramTags; } else { tags = biosTags; }  int index = (pc & 0x1FFFFF) >> 2; return tags[index]; }
/* 1305 */   public void orTag(int pc, byte val) { byte[] tags; if (pc < -1077936128 || pc >= -1077411840) { tags = ramTags; } else { tags = biosTags; }  int index = (pc & 0x1FFFFF) >> 2; tags[index] = (byte)(tags[index] | val); } public int read8(int address) { return _read8(address); } public static int _read8(int address) { int value, prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { value = ramD[offset >> 2]; } else if (address < 528486400 && address >= 528482304) { value = scratch[(offset & 0xFFF) >> 2]; } else if (prefix == 0 && offset < 2097152) { value = ramD[offset >> 2]; } else if (prefix == -6 && offset < 2097152) { value = ramD[offset >> 2]; } else { if (address < 528494592 && address >= 528486400) return Hardware.read8(address);  if (address < 520159232 && address >= 520093696) return _parRead8(address);  if (address >= -1077936128 && address < -1077411840) { value = bios[(offset & 0x7FFFF) >> 2]; } else { throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); }  }  switch (address & 0x3) { case 3: return value >> 24 & 0xFF;case 2: return value >> 16 & 0xFF;case 1: return value >> 8 & 0xFF; }  return value & 0xFF; } public static int _read8Ram(int address) { int value = ramD[(address & 0x5FFFFFFF) >> 2]; switch (address & 0x3) { case 3: return value >> 24 & 0xFF;case 2: return value >> 16 & 0xFF;case 1: return value >> 8 & 0xFF; }  return value & 0xFF; } public static int _read8Scratch(int address) { int value = scratch[(address ^ 0x1F800000) >> 2]; switch (address & 0x3) { case 3: return value >> 24 & 0xFF;case 2: return value >> 16 & 0xFF;case 1: return value >> 8 & 0xFF; }  return value & 0xFF; } public static int _read8Bios(int address) { int value = bios[(address ^ 0xBFC00000) >> 2]; switch (address & 0x3) { case 3: return value >> 24 & 0xFF;case 2: return value >> 16 & 0xFF;case 1: return value >> 8 & 0xFF; }  return value & 0xFF; } public static void _write8Bios(int address, int value) { int dummy = bios[(address ^ 0xBFC00000) >> 2]; } private void registerCallback(Map<Integer, Method> map, int address, Class clazz, String methodName, Class[] params) { try { Method m = clazz.getMethod(methodName, params);
/* 1306 */       map.put(Integer.valueOf(address), m); }
/* 1307 */     catch (Throwable t)
/* 1308 */     { StringBuilder desc = new StringBuilder();
/* 1309 */       desc.append("Cannot find method ");
/* 1310 */       desc.append(clazz.getName());
/* 1311 */       desc.append(".");
/* 1312 */       desc.append(methodName);
/* 1313 */       desc.append("(");
/* 1314 */       for (int i = 0; i < params.length; i++) {
/* 1315 */         if (i != 0) desc.append(","); 
/* 1316 */         desc.append(params[i].getName());
/*      */       } 
/* 1318 */       desc.append(")");
/* 1319 */       throw new IllegalStateException(desc.toString()); }  } public static void _write16Bios(int address, int value) { int dummy = bios[(address ^ 0xBFC00000) >> 2]; } public static void _write32Bios(int address, int value) { int dummy = bios[(address ^ 0xBFC00000) >> 2]; } public int read16(int address) { return _read16(address); } public static int _read16(int address) { int value, prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { value = ramD[offset >> 2]; } else if (address < 528486400 && address >= 528482304) { value = scratch[(offset & 0xFFF) >> 2]; } else if (prefix == 0 && offset < 2097152) { value = ramD[offset >> 2]; } else if (prefix == -6 && offset < 2097152) { value = ramD[offset >> 2]; } else { if (address < 528494592 && address >= 528486400) return Hardware.read16(address);  if (address < 520159232 && address >= 520093696) return _parRead16(address);  if (address >= -1077936128 && address < -1077411840) { value = bios[(offset & 0x7FFFF) >> 2]; } else { throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); }  }  switch (address & 0x2) { case 2: return value >> 16 & 0xFFFF; }  return value & 0xFFFF; } public static int _read16Ram(int address) { int value = ramD[(address & 0x5FFFFFFF) >> 2]; switch (address & 0x2) { case 2: return value >> 16 & 0xFFFF; }  return value & 0xFFFF; } public static int _read16Scratch(int address) { int value = scratch[(address ^ 0x1F800000) >> 2]; switch (address & 0x2) { case 2: return value >> 16 & 0xFFFF; }  return value & 0xFFFF; } public static int _read16Bios(int address) { int value = bios[(address ^ 0xBFC00000) >> 2]; switch (address & 0x2) { case 2: return value >> 16 & 0xFFFF; }  return value & 0xFFFF; } public int read32(int address) { return _read32(address); } public static int _read32(int address) { int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) return ramD[offset >> 2];  if (address < 528486400 && address >= 528482304) return scratch[(offset & 0xFFF) >> 2];  if (prefix == -6 && offset < 2097152) return ramD[offset >> 2];  if (prefix == 0 && offset < 2097152) return ramD[offset >> 2];  if (address < 528494592 && address >= 528486400) return Hardware.read32(address);  if (address < 520159232 && address >= 520093696) return _parRead32(address);  if (address >= -1077936128 && address < -1077411840) return bios[(offset & 0x7FFFF) >> 2];  throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); } public void write8(int address, int value) { _write8(address, value); } public static void _write8(int address, int value) { int nvalue, mask, prefix = address >> 28; int offset = address & 0xF9FFFFF; switch (address & 0x3) { case 0: mask = -256; nvalue = value & 0xFF; break;case 1: mask = -65281; nvalue = (value & 0xFF) << 8; break;case 2: mask = -16711681; nvalue = (value & 0xFF) << 16; break;default: mask = 16777215; nvalue = value << 24; break; }  if (prefix == -8 && offset < 2097152) { ramD[offset >> 2] = ramD[offset >> 2] & mask | nvalue; } else if (address < 528486400 && address >= 528482304) { scratch[(offset & 0xFFF) >> 2] = scratch[(offset & 0xFFF) >> 2] & mask | nvalue; } else if (prefix == 0 && offset < 2097152) { ramD[offset >> 2] = ramD[offset >> 2] & mask | nvalue; } else if (prefix == -6 && offset < 2097152) { ramD[offset >> 2] = ramD[offset >> 2] & mask | nvalue; } else if (address < 528494592 && address >= 528486400) { Hardware.write8(address, value); } else if (address < 520159232 && address >= 520093696) { if (!_parWrite8(address, value)) par[(offset & 0xFFFF) >> 2] = par[(offset & 0xFFFF) >> 2] & mask | nvalue;  } else if (address < -1077936128 || address >= -1077411840) { throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); }  } public static void _write8Ram(int address, int value) { int nvalue, mask; switch (address & 0x3) { case 0: mask = -256; nvalue = value & 0xFF; break;case 1: mask = -65281; nvalue = (value & 0xFF) << 8; break;case 2: mask = -16711681; nvalue = (value & 0xFF) << 16; break;default: mask = 16777215; nvalue = value << 24; break; }  address = (address & 0x5FFFFFFF) >> 2; ramD[address] = ramD[address] & mask | nvalue; } public static void _write8Scratch(int address, int value) { int nvalue, mask; switch (address & 0x3) { case 0: mask = -256; nvalue = value & 0xFF; break;case 1: mask = -65281; nvalue = (value & 0xFF) << 8; break;case 2: mask = -16711681; nvalue = (value & 0xFF) << 16; break;default: mask = 16777215; nvalue = value << 24; break; }  address = (address ^ 0x1F800000) >> 2; scratch[address] = scratch[address] & mask | nvalue; } public void write16(int address, int value) { _write16(address, value); } public static void _write16(int address, int value) { int nvalue, mask, prefix = address >> 28; int offset = address & 0xF9FFFFF; switch (address & 0x3) { case 0: mask = -65536; nvalue = value & 0xFFFF; break;default: mask = 65535; nvalue = value << 16; break; }  if (prefix == -8 && offset < 2097152) { ramD[offset >> 2] = ramD[offset >> 2] & mask | nvalue; } else if (address < 528486400 && address >= 528482304) { scratch[(offset & 0xFFF) >> 2] = scratch[(offset & 0xFFF) >> 2] & mask | nvalue; } else if (prefix == 0 && offset < 2097152) { ramD[offset >> 2] = ramD[offset >> 2] & mask | nvalue; } else if (prefix == -6 && offset < 2097152) { ramD[offset >> 2] = ramD[offset >> 2] & mask | nvalue; } else if (address < 528494592 && address >= 528486400) { Hardware.write16(address, value); } else if (address < 520159232 && address >= 520093696) { if (!_parWrite16(address, value)) par[(offset & 0xFFFF) >> 2] = par[(offset & 0xFFFF) >> 2] & mask | nvalue;  } else if (address < -1077936128 || address >= -1077411840) { throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); }  } public static void _write16Ram(int address, int value) { int nvalue, mask; switch (address & 0x3) { case 0: mask = -65536; nvalue = value & 0xFFFF; break;default: mask = 65535; nvalue = value << 16; break; }  address = (address & 0x5FFFFFFF) >> 2; ramD[address] = ramD[address] & mask | nvalue; } public static void _write16Scratch(int address, int value) { int nvalue, mask; switch (address & 0x3) { case 0: mask = -65536; nvalue = value & 0xFFFF; break;default: mask = 65535; nvalue = value << 16; break; }  address = (address ^ 0x1F800000) >> 2; scratch[address] = scratch[address] & mask | nvalue; } public void write32(int address, int value) { _write32(address, value); } public static void _write32(int address, int value) { int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { ramD[offset >> 2] = value; } else if (address < 528486400 && address >= 528482304) { scratch[(offset & 0xFFF) >> 2] = value; } else if (prefix == 0 && offset < 2097152) { ramD[offset >> 2] = value; } else if (prefix == -6 && offset < 2097152) { ramD[offset >> 2] = value; } else if (address < 528494592 && address >= 528486400) { Hardware.write32(address, value); } else if (address < 520159232 && address >= 520093696) { if (!_parWrite32(address, value)) par[(offset & 0xFFFF) >> 2] = value;  } else if ((address < -1077936128 || address >= -1077411840) && address != -130768) { throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); }  }
/*      */   public int internalRead32(int address) { return _internalRead32(address); }
/*      */   public static int _internalRead32(int address) { int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) return ram[offset >> 2];  if (address < 528486400 && address >= 528482304) return scratch[(offset & 0xFFF) >> 2];  if (address >= -1077936128 && address < -1077411840) return bios[(offset & 0x7FFFF) >> 2];  if (address < 528494592 && address >= 528486400) return hw[(offset & 0x1FFF) >> 2];  if (address < 520159232 && address >= 520093696) return par[(offset & 0xFFFF) >> 2];  if (prefix == 0 && offset < 2097152) return ram[offset >> 2];  if (prefix == -6 && offset < 2097152) return ram[offset >> 2];  throw new IllegalStateException("ACK unknown address " + MiscUtil.toHex(address, 8)); }
/*      */   public void internalWrite32(int address, int value) { _internalWrite32(address, value); }
/*      */   public static void _internalWrite32(int address, int value) { int prefix = address >> 28; int offset = address & 0xF9FFFFF; if (prefix == -8 && offset < 2097152) { ram[offset >> 2] = value; } else if (address < 528486400 && address >= 528482304) { scratch[(offset & 0xFFF) >> 2] = value; } else if (address < 528494592 && address >= 528486400) { hw[(offset & 0x1FFF) >> 2] = value; } else if (address < 520159232 && address >= 520093696) { par[(offset & 0xFFFF) >> 2] = value; } else if (address >= -1077936128 && address < -1077411840) { bios[(offset & 0x7FFFF) >> 2] = value; } else if (prefix == 0 && offset < 2097152) { ram[offset >> 2] = value; } else if (prefix == -6 && offset < 2097152) { ram[offset >> 2] = value; }  }
/* 1324 */   public void registerRead8Callback(int address, Class clazz, String methodName) { registerCallback(read8Callbacks, address, clazz, methodName, READ_CALLBACK_PARAMS); }
/*      */ 
/*      */ 
/*      */   
/* 1328 */   public void registerRead16Callback(int address, Class clazz, String methodName) { registerRead16Callback(address, clazz, methodName, false); }
/*      */ 
/*      */   
/*      */   public void registerRead16Callback(int address, Class clazz, String methodName, boolean allowSubRead) {
/* 1332 */     assert 0 == (address & true);
/* 1333 */     if (allowSubRead) {
/* 1334 */       registerCallback(subRead16Callbacks, address, clazz, methodName, READ_CALLBACK_PARAMS);
/*      */     } else {
/* 1336 */       registerCallback(read16Callbacks, address, clazz, methodName, READ_CALLBACK_PARAMS);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void registerRead32Callback(int address, Class clazz, String methodName, boolean allowSubRead) {
/* 1341 */     assert 0 == (address & 0x3);
/* 1342 */     if (allowSubRead) {
/* 1343 */       registerCallback(subRead32Callbacks, address, clazz, methodName, READ_CALLBACK_PARAMS);
/*      */     } else {
/* 1345 */       registerCallback(read32Callbacks, address, clazz, methodName, READ_CALLBACK_PARAMS);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1350 */   public void registerPoll32Callback(int address, Pollable pollable) { poll32Callbacks.put(Integer.valueOf(address), pollable); }
/*      */ 
/*      */ 
/*      */   
/* 1354 */   public void registerRead32Callback(int address, Class clazz, String methodName) { registerRead32Callback(address, clazz, methodName, false); }
/*      */ 
/*      */ 
/*      */   
/* 1358 */   public void registerWrite8Callback(int address, Class clazz, String methodName) { registerCallback(write8Callbacks, address, clazz, methodName, WRITE_CALLBACK_PARAMS); }
/*      */ 
/*      */ 
/*      */   
/* 1362 */   public void registerWrite16Callback(int address, Class clazz, String methodName) { registerWrite16Callback(address, clazz, methodName, false); }
/*      */ 
/*      */   
/*      */   public void registerWrite16Callback(int address, Class clazz, String methodName, boolean allowSubWrite) {
/* 1366 */     assert 0 == (address & true);
/* 1367 */     if (allowSubWrite) {
/* 1368 */       registerCallback(subWrite16Callbacks, address, clazz, methodName, SUBWRITE_CALLBACK_PARAMS);
/*      */     } else {
/* 1370 */       registerCallback(write16Callbacks, address, clazz, methodName, WRITE_CALLBACK_PARAMS);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1375 */   public void registerWrite32Callback(int address, Class clazz, String methodName) { registerWrite32Callback(address, clazz, methodName, false); }
/*      */ 
/*      */   
/*      */   public void registerWrite32Callback(int address, Class clazz, String methodName, boolean allowSubWrite) {
/* 1379 */     assert 0 == (address & 0x3);
/* 1380 */     if (allowSubWrite) {
/* 1381 */       registerCallback(subWrite32Callbacks, address, clazz, methodName, SUBWRITE_CALLBACK_PARAMS);
/*      */     } else {
/* 1383 */       registerCallback(write32Callbacks, address, clazz, methodName, WRITE_CALLBACK_PARAMS);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void resolve(int address, AddressSpace.ResolveResult result) {
/* 1388 */     result.address = address;
/* 1389 */     result.low2 = address & 0x3;
/*      */     
/* 1391 */     int prefix = address >> 28;
/* 1392 */     int offset = address & 0xF9FFFFF;
/* 1393 */     if ((prefix == 0 || prefix == -8 || prefix == -6) && offset < 2097152) {
/* 1394 */       result.mem = ram;
/* 1395 */       result.offset = offset >> 2;
/* 1396 */       result.tag = 1; return;
/*      */     } 
/* 1398 */     if (address < 528486400 && address >= 528482304) {
/* 1399 */       result.mem = scratch;
/* 1400 */       result.offset = (offset & 0xFFF) >> 2;
/* 1401 */       result.tag = 2; return;
/*      */     } 
/* 1403 */     if (address < 528494592 && address >= 528486400) {
/* 1404 */       result.mem = hw;
/* 1405 */       result.offset = (offset & 0x1FFF) >> 2;
/* 1406 */       result.tag = 4; return;
/*      */     } 
/* 1408 */     if (address >= -1077936128 && address < -1077411840) {
/* 1409 */       result.mem = bios;
/* 1410 */       result.offset = (offset & 0x7FFFF) >> 2;
/* 1411 */       result.tag = 8;
/*      */       return;
/*      */     } 
/* 1414 */     result.mem = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(int address, int end, AddressSpace.ResolveResult result) {
/* 1420 */     result.address = address;
/* 1421 */     result.low2 = address & 0x3;
/*      */ 
/*      */ 
/*      */     
/* 1425 */     int prefix = address >> 28;
/* 1426 */     int prefix2 = end >> 28;
/* 1427 */     if (prefix == prefix2) {
/* 1428 */       int offset = address & 0xF9FFFFF;
/* 1429 */       int offset2 = end & 0xF9FFFFF;
/* 1430 */       if ((prefix == 0 || prefix == -8 || prefix == -6) && offset < 2097152 && offset2 < 2097152) {
/* 1431 */         result.mem = ram;
/* 1432 */         result.offset = offset >> 2;
/* 1433 */         result.tag = 1; return;
/*      */       } 
/* 1435 */       if (address < 528486400 && address >= 528482304 && end < 528486400) {
/* 1436 */         result.mem = scratch;
/* 1437 */         result.offset = (offset & 0xFFF) >> 2;
/* 1438 */         result.tag = 2; return;
/*      */       } 
/* 1440 */       if (address < 528494592 && address >= 528486400 && end < 528494592) {
/* 1441 */         result.mem = hw;
/* 1442 */         result.offset = (offset & 0x1FFF) >> 2;
/* 1443 */         result.tag = 4; return;
/*      */       } 
/* 1445 */       if (address >= -1077936128 && address < -1077411840 && end < -1077411840) {
/* 1446 */         result.mem = bios;
/* 1447 */         result.offset = (offset & 0x7FFFF) >> 2;
/* 1448 */         result.tag = 8;
/*      */         return;
/*      */       } 
/*      */     } 
/* 1452 */     result.mem = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1459 */   public static int _parRead8(int address) { return 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1464 */   public static int _parRead16(int address) { return 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1469 */   public static int _parRead32(int address) { return 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1474 */   public static boolean _parWrite8(int address, int value) { return false; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1479 */   public static boolean _parWrite16(int address, int value) { return false; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1484 */   public static boolean _parWrite32(int address, int value) { return false; }
/*      */ 
/*      */   
/*      */   public void enableMemoryWrite(boolean enableWrite) {
/* 1488 */     ramD = enableWrite ? ram : ramDummy;
/* 1489 */     if (!enableWrite && writeEnabled) {
/*      */       
/* 1491 */       for (int i = 0; i < 524288; i++) {
/* 1492 */         ramTags[i] = 0;
/*      */       }
/* 1494 */       addressSpaceListeners.cacheCleared();
/*      */     } 
/* 1496 */     writeEnabled = enableWrite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _checkPoll8(int address) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _checkPoll16(int address) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _checkPoll32(int address) {
/* 1516 */     if (address == lastPoll32Address) {
/* 1517 */       lastPoll32Count++;
/* 1518 */       if (lastPoll32Count == 256) {
/* 1519 */         if (logPollTrace) {
/* 1520 */           logPoll.trace("Poll of " + MiscUtil.toHex(address, 8));
/*      */         }
/*      */         
/* 1523 */         if ((address & 0x50000000) == 0) {
/*      */           
/* 1525 */           scheduler.cpuThreadWait();
/*      */         } else {
/* 1527 */           Pollable p = (Pollable)poll32Callbacks.get(Integer.valueOf(address));
/* 1528 */           if (p != null)
/* 1529 */             p.poll(address, 4); 
/*      */         } 
/* 1531 */         lastPoll32Count = 0;
/*      */       } 
/*      */     } else {
/* 1534 */       lastPoll32Address = address;
/* 1535 */       lastPoll32Count = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1735 */   public int[] getMainRAM() { return ram; }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\AddressSpaceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */