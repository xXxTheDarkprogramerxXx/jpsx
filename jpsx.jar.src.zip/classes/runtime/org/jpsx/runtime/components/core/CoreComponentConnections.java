/*    */ package classes.runtime.org.jpsx.runtime.components.core;
/*    */ 
/*    */ import org.jpsx.api.CPUListener;
/*    */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*    */ import org.jpsx.api.components.core.addressspace.AddressSpaceListener;
/*    */ import org.jpsx.api.components.core.addressspace.MemoryMapped;
/*    */ import org.jpsx.api.components.core.cpu.InstructionProvider;
/*    */ import org.jpsx.api.components.core.cpu.NativeCompiler;
/*    */ import org.jpsx.api.components.core.cpu.PollBlockListener;
/*    */ import org.jpsx.api.components.core.cpu.R3000;
/*    */ import org.jpsx.api.components.core.cpu.SCP;
/*    */ import org.jpsx.api.components.core.dma.DMAChannelOwner;
/*    */ import org.jpsx.api.components.core.dma.DMAController;
/*    */ import org.jpsx.api.components.core.irq.IRQController;
/*    */ import org.jpsx.api.components.core.irq.IRQOwner;
/*    */ import org.jpsx.api.components.core.scheduler.Quartz;
/*    */ import org.jpsx.api.components.core.scheduler.Scheduler;
/*    */ import org.jpsx.bootstrap.connection.MultipleConnection;
/*    */ import org.jpsx.bootstrap.connection.SimpleConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreComponentConnections
/*    */ {
/* 35 */   public static final SimpleConnection<R3000> R3000 = SimpleConnection.create("R3000", R3000.class);
/* 36 */   public static final SimpleConnection<SCP> SCP = SimpleConnection.create("SCP", SCP.class);
/* 37 */   public static final SimpleConnection<Quartz> QUARTZ = SimpleConnection.create("QUARTZ", Quartz.class);
/* 38 */   public static final SimpleConnection<Scheduler> SCHEDULER = SimpleConnection.create("Scheduler", Scheduler.class);
/* 39 */   public static final SimpleConnection<AddressSpace> ADDRESS_SPACE = SimpleConnection.create("Address Space", AddressSpace.class);
/* 40 */   public static final SimpleConnection<IRQController> IRQ_CONTROLLER = SimpleConnection.create("IRQ Controller", IRQController.class);
/* 41 */   public static final SimpleConnection<DMAController> DMA_CONTROLLER = SimpleConnection.create("DMA Controller", DMAController.class);
/* 42 */   public static final SimpleConnection<NativeCompiler> NATIVE_COMPILER = SimpleConnection.create("Native Compiler", NativeCompiler.class);
/*    */   
/* 44 */   public static final MultipleConnection<CPUListener> CPU_LISTENERS = MultipleConnection.create("CPU Listeners", CPUListener.class);
/* 45 */   public static final MultipleConnection<InstructionProvider> INSTRUCTION_PROVIDERS = MultipleConnection.create("Instruction Providers", InstructionProvider.class);
/* 46 */   public static final MultipleConnection<AddressSpaceListener> ADDRESS_SPACE_LISTENERS = MultipleConnection.create("Address Space Listeners", AddressSpaceListener.class);
/* 47 */   public static final MultipleConnection<IRQOwner> IRQ_OWNERS = MultipleConnection.create("IRQ Owners", IRQOwner.class);
/* 48 */   public static final MultipleConnection<DMAChannelOwner> DMA_CHANNEL_OWNERS = MultipleConnection.create("DMA Channel Owners", DMAChannelOwner.class);
/* 49 */   public static final MultipleConnection<MemoryMapped> ALL_MEMORY_MAPPED = MultipleConnection.create("Memory Mapped", MemoryMapped.class);
/* 50 */   public static final MultipleConnection<Runnable> ALL_POPULATORS = MultipleConnection.create("Memory Populators", Runnable.class);
/* 51 */   public static final MultipleConnection<PollBlockListener> POLL_BLOCK_LISTENERS = MultipleConnection.create("Poll Block Listeners", PollBlockListener.class);
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\CoreComponentConnections.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */