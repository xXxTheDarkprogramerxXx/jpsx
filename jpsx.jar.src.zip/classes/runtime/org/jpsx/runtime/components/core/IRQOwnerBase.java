/*    */ package classes.runtime.org.jpsx.runtime.components.core;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jpsx.api.components.core.irq.IRQController;
/*    */ import org.jpsx.api.components.core.irq.IRQOwner;
/*    */ import org.jpsx.runtime.components.core.IRQOwnerBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class IRQOwnerBase
/*    */   implements IRQOwner
/*    */ {
/* 25 */   public static final Logger log = Logger.getLogger("IRQ");
/*    */   protected int irq;
/*    */   protected String name;
/*    */   private IRQController controller;
/*    */   
/*    */   public IRQOwnerBase(int irq, String name) {
/* 31 */     this.irq = irq;
/* 32 */     this.name = name;
/*    */   }
/*    */   
/*    */   public void register(IRQController controller) {
/* 36 */     this.controller = controller;
/* 37 */     log.info("registering IRQ " + getName());
/* 38 */     controller.registerIRQOwner(this);
/*    */   }
/*    */ 
/*    */   
/* 42 */   public final int getIRQ() { return this.irq; }
/*    */ 
/*    */ 
/*    */   
/* 46 */   public final String getName() { return this.name; }
/*    */ 
/*    */ 
/*    */   
/* 50 */   public void raiseIRQ() { this.controller.raiseIRQ(getIRQ()); }
/*    */   
/*    */   public void irqSet() {}
/*    */   
/*    */   public void irqCleared() {}
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\IRQOwnerBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */