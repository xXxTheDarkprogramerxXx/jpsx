/*    */ package classes.runtime.org.jpsx.runtime.components.core;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jpsx.api.components.core.dma.DMAChannelOwner;
/*    */ import org.jpsx.api.components.core.dma.DMAController;
/*    */ import org.jpsx.runtime.components.core.DMAChannelOwnerBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DMAChannelOwnerBase
/*    */   implements DMAChannelOwner
/*    */ {
/* 26 */   public static final Logger log = Logger.getLogger("DMA");
/*    */   
/*    */   private DMAController dmaController;
/*    */   
/*    */   public abstract int getDMAChannel();
/*    */   
/*    */   public void register(DMAController controller) {
/* 33 */     log.info("Registering channel " + getName());
/* 34 */     this.dmaController = controller;
/* 35 */     controller.registerDMAChannel(this);
/*    */   }
/*    */ 
/*    */   
/* 39 */   public String getName() { return "DMA device " + getDMAChannel(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public void beginDMATransferToDevice(int base, int blocks, int blockSize, int ctrl) { signalTransferComplete(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public void beginDMATransferFromDevice(int base, int blocks, int blockSize, int ctrl) { signalTransferComplete(); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void cancelDMATransfer(int ctrl) {}
/*    */ 
/*    */ 
/*    */   
/* 59 */   public final void signalTransferComplete() { this.dmaController.dmaChannelTransferComplete(this); }
/*    */ 
/*    */ 
/*    */   
/* 63 */   public final void signalTransferComplete(boolean interrupt) { this.dmaController.dmaChannelTransferComplete(this, interrupt); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\DMAChannelOwnerBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */