/*    */ package classes.runtime.org.jpsx.runtime.components.core;
/*    */ 
/*    */ import org.jpsx.api.CPUListener;
/*    */ import org.jpsx.api.components.core.scheduler.Quartz;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*    */ import org.jpsx.runtime.components.core.DefaultQuartz;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultQuartz
/*    */   extends JPSXComponent
/*    */   implements Quartz, CPUListener
/*    */ {
/*    */   private long base;
/*    */   private long stoppedAt;
/*    */   
/*    */   public void init() {
/* 32 */     super.init();
/* 33 */     this.base = System.nanoTime();
/* 34 */     cpuPaused();
/* 35 */     CoreComponentConnections.QUARTZ.set(this);
/* 36 */     CoreComponentConnections.CPU_LISTENERS.add(this);
/*    */   }
/*    */ 
/*    */   
/* 40 */   public DefaultQuartz() { super("JPSX System.nanoTime() Quartz"); }
/*    */ 
/*    */   
/*    */   public long nanoTime() {
/* 44 */     if (this.stoppedAt != 0L) return this.stoppedAt - this.base; 
/* 45 */     return System.nanoTime() - this.base;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 50 */   public long bestGranularity() { return 1L; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public long nanoTime(long granularity) { return nanoTime(); }
/*    */ 
/*    */   
/*    */   public void cpuResumed() {
/* 59 */     if (this.stoppedAt != 0L) {
/* 60 */       this.base += System.nanoTime() - this.stoppedAt;
/* 61 */       this.stoppedAt = 0L;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void cpuPaused() {
/* 66 */     if (this.stoppedAt == 0L) {
/* 67 */       this.stoppedAt = System.nanoTime();
/*    */       
/* 69 */       if (this.stoppedAt == 0L) this.stoppedAt = 1L; 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\core\DefaultQuartz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */