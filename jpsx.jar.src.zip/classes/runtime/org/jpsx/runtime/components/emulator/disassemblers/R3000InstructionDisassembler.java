/*     */ package classes.runtime.org.jpsx.runtime.components.emulator.disassemblers;
/*     */ 
/*     */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*     */ import org.jpsx.runtime.components.emulator.disassemblers.DisassemblerComponent;
/*     */ import org.jpsx.runtime.components.emulator.disassemblers.R3000InstructionDisassembler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class R3000InstructionDisassembler
/*     */   extends DisassemblerComponent
/*     */ {
/*  30 */   public R3000InstructionDisassembler() { super("JPSX Disassembler for R3000 Instructions"); }
/*     */ 
/*     */   
/*     */   public void addInstructions(InstructionRegistrar registrar) {
/*  34 */     DIS_TSB disTSB = new DIS_TSB();
/*  35 */     DIS_SB disSB = new DIS_SB();
/*  36 */     DIS_TSI disTSI = new DIS_TSI();
/*  37 */     DIS_TSIU disTSIU = new DIS_TSIU();
/*  38 */     DIS_TIU disTIU = new DIS_TIU();
/*  39 */     DIS_TSA disTSA = new DIS_TSA();
/*  40 */     DIS_SAT disSAT = new DIS_SAT();
/*  41 */     DIS_ST disST = new DIS_ST();
/*  42 */     DIS_DTH disDTH = new DIS_DTH();
/*  43 */     DIS_DST disDST = new DIS_DST();
/*  44 */     DIS_DTS disDTS = new DIS_DTS();
/*  45 */     DIS_J disJ = new DIS_J();
/*  46 */     DIS_S disS = new DIS_S();
/*  47 */     DIS_D disD = new DIS_D();
/*  48 */     DIS_SD disSD = new DIS_SD();
/*  49 */     DIS_C disC = new DIS_C();
/*  50 */     DisassemblerComponent.DIS dis = new DisassemblerComponent.DIS();
/*     */     
/*  52 */     registrar.setInstructionDisassembler("bne", disTSB);
/*  53 */     registrar.setInstructionDisassembler("beq", disTSB);
/*  54 */     registrar.setInstructionDisassembler("addi", disTSI);
/*  55 */     registrar.setInstructionDisassembler("addiu", disTSI);
/*  56 */     registrar.setInstructionDisassembler("slti", disTSI);
/*  57 */     registrar.setInstructionDisassembler("sltiu", disTSI);
/*  58 */     registrar.setInstructionDisassembler("andi", disTSIU);
/*  59 */     registrar.setInstructionDisassembler("ori", disTSIU);
/*  60 */     registrar.setInstructionDisassembler("xori", disTSIU);
/*  61 */     registrar.setInstructionDisassembler("sll", disDTH);
/*  62 */     registrar.setInstructionDisassembler("srl", disDTH);
/*  63 */     registrar.setInstructionDisassembler("sra", disDTH);
/*  64 */     registrar.setInstructionDisassembler("bltz", disSB);
/*  65 */     registrar.setInstructionDisassembler("bgez", disSB);
/*  66 */     registrar.setInstructionDisassembler("blez", disSB);
/*  67 */     registrar.setInstructionDisassembler("bgtz", disSB);
/*  68 */     registrar.setInstructionDisassembler("bltzal", disSB);
/*  69 */     registrar.setInstructionDisassembler("bgezal", disSB);
/*  70 */     registrar.setInstructionDisassembler("add", disDST);
/*  71 */     registrar.setInstructionDisassembler("addu", disDST);
/*  72 */     registrar.setInstructionDisassembler("sub", disDST);
/*  73 */     registrar.setInstructionDisassembler("subu", disDST);
/*  74 */     registrar.setInstructionDisassembler("and", disDST);
/*  75 */     registrar.setInstructionDisassembler("or", disDST);
/*  76 */     registrar.setInstructionDisassembler("xor", disDST);
/*  77 */     registrar.setInstructionDisassembler("nor", disDST);
/*  78 */     registrar.setInstructionDisassembler("slt", disDST);
/*  79 */     registrar.setInstructionDisassembler("sltu", disDST);
/*  80 */     registrar.setInstructionDisassembler("lb", disTSA);
/*  81 */     registrar.setInstructionDisassembler("lh", disTSA);
/*  82 */     registrar.setInstructionDisassembler("lwl", disTSA);
/*  83 */     registrar.setInstructionDisassembler("lw", disTSA);
/*  84 */     registrar.setInstructionDisassembler("lbu", disTSA);
/*  85 */     registrar.setInstructionDisassembler("lhu", disTSA);
/*  86 */     registrar.setInstructionDisassembler("lwr", disTSA);
/*  87 */     registrar.setInstructionDisassembler("sb", disSAT);
/*  88 */     registrar.setInstructionDisassembler("sh", disSAT);
/*  89 */     registrar.setInstructionDisassembler("swl", disSAT);
/*  90 */     registrar.setInstructionDisassembler("sw", disSAT);
/*  91 */     registrar.setInstructionDisassembler("swr", disSAT);
/*  92 */     registrar.setInstructionDisassembler("lui", disTIU);
/*  93 */     registrar.setInstructionDisassembler("sllv", disDTS);
/*  94 */     registrar.setInstructionDisassembler("srlv", disDTS);
/*  95 */     registrar.setInstructionDisassembler("srav", disDTS);
/*  96 */     registrar.setInstructionDisassembler("mult", disST);
/*  97 */     registrar.setInstructionDisassembler("multu", disST);
/*  98 */     registrar.setInstructionDisassembler("div", disST);
/*  99 */     registrar.setInstructionDisassembler("divu", disST);
/* 100 */     registrar.setInstructionDisassembler("j", disJ);
/* 101 */     registrar.setInstructionDisassembler("jal", disJ);
/* 102 */     registrar.setInstructionDisassembler("jr", disS);
/* 103 */     registrar.setInstructionDisassembler("mthi", disS);
/* 104 */     registrar.setInstructionDisassembler("mtlo", disS);
/* 105 */     registrar.setInstructionDisassembler("mfhi", disD);
/* 106 */     registrar.setInstructionDisassembler("mflo", disD);
/* 107 */     registrar.setInstructionDisassembler("jalr", disSD);
/*     */     
/* 109 */     registrar.setInstructionDisassembler("syscall", disC);
/* 110 */     registrar.setInstructionDisassembler("break", disC);
/* 111 */     registrar.setInstructionDisassembler("eret", dis);
/* 112 */     registrar.setInstructionDisassembler("mtc0", new DIS_MTC0());
/* 113 */     registrar.setInstructionDisassembler("mfc0", new DIS_MFC0());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getCOP0Name(int reg, int sel) {
/* 225 */     switch ((sel << 16) + reg) {
/*     */       case 0:
/* 227 */         return "index";
/*     */       case 1:
/* 229 */         return "random";
/*     */       case 2:
/* 231 */         return "entryLow0";
/*     */       case 3:
/* 233 */         return "entryLow1";
/*     */       case 4:
/* 235 */         return "context";
/*     */       case 5:
/* 237 */         return "pageMask";
/*     */       case 6:
/* 239 */         return "wired";
/*     */       case 8:
/* 241 */         return "badVAddr";
/*     */       case 9:
/* 243 */         return "count";
/*     */       case 10:
/* 245 */         return "entryHi";
/*     */       case 11:
/* 247 */         return "compare";
/*     */       case 12:
/* 249 */         return "status";
/*     */       case 13:
/* 251 */         return "cause";
/*     */       case 14:
/* 253 */         return "epc";
/*     */       case 15:
/* 255 */         return "progId";
/*     */       case 16:
/* 257 */         return "config";
/*     */       case 65552:
/* 259 */         return "config1";
/*     */       case 131088:
/* 261 */         return "config2";
/*     */       case 196624:
/* 263 */         return "config3";
/*     */       case 30:
/* 265 */         return "errorEPC";
/*     */     } 
/* 267 */     return reg + ":" + sel;
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\disassemblers\R3000InstructionDisassembler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */