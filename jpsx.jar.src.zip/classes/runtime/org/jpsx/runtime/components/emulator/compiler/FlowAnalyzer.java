/*     */ package classes.runtime.org.jpsx.runtime.components.emulator.compiler;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.cpu.CPUInstruction;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.emulator.compiler.FlowAnalyzer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlowAnalyzer
/*     */ {
/*     */   private static final boolean debugFlow = false;
/*  40 */   private final BasicBlock[] blocks = new BasicBlock[8000];
/*  41 */   private final BasicBlock[] branchTargets = new BasicBlock[8000];
/*     */ 
/*     */   
/*  44 */   private final int[] timeStamps = new int[8000];
/*  45 */   private final byte[] flags = new byte[8000];
/*     */   
/*     */   private static final byte VISITED = 1;
/*     */   
/*     */   private static final byte BLOCK_START = 2;
/*     */   
/*     */   private static final byte DELAY_SLOT = 4;
/*     */   private static final byte CONDITIONAL_BRANCH = 8;
/*     */   private static final byte UNCONDITIONAL_BRANCH = 16;
/*     */   private int currentTimeStamp;
/*     */   private int currentBase;
/*     */   private int blockCount;
/*  57 */   private Stack<Integer> pendingPaths = new Stack();
/*  58 */   private static final Integer i0 = Integer.valueOf(0);
/*     */   
/*  60 */   private final AddressSpace addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*  61 */   private final R3000 r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/*     */ 
/*     */   
/*  64 */   public final BasicBlock UNKNOWN_BRANCH_TARGET = new BasicBlock(false, 1073741824, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public FlowInfo buildFlowGraph(int base) { return buildFlowGraph(base, 800); }
/*     */ 
/*     */   
/*     */   public FlowInfo buildFlowGraph(int base, int maxBlockSize) {
/*  88 */     int instructionCount = 0;
/*     */     
/*  90 */     this.currentBase = base;
/*     */     
/*  92 */     assert 0 == (base & 0x3);
/*     */     
/*  94 */     this.currentTimeStamp++;
/*  95 */     this.blockCount = 0;
/*     */     
/*  97 */     BasicBlock firstExtraBlock = null;
/*  98 */     BasicBlock lastExtraBlock = null;
/*     */     
/* 100 */     this.pendingPaths.push(i0);
/*     */     
/* 102 */     int max = 0;
/* 103 */     while (!this.pendingPaths.isEmpty()) {
/* 104 */       int offset = ((Integer)this.pendingPaths.pop()).intValue();
/*     */       
/* 106 */       if (this.timeStamps[offset] == this.currentTimeStamp && 0 != (this.flags[offset] & true)) {
/* 107 */         if (0 != (this.flags[offset] & 0x4)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 117 */           offset++;
/*     */         } else {
/*     */           continue;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 125 */       getBlock(offset);
/*     */       
/* 127 */       boolean flowOut = false;
/* 128 */       int end = 7999;
/* 129 */       int blockLimit = offset + maxBlockSize;
/* 130 */       byte nextFlags = 0;
/*     */       
/* 132 */       for (; offset < end; offset++) {
/* 133 */         if (offset >= blockLimit && 0 == nextFlags) {
/*     */ 
/*     */           
/* 136 */           this.pendingPaths.push(Integer.valueOf(offset));
/*     */           break;
/*     */         } 
/* 139 */         if (this.timeStamps[offset] == this.currentTimeStamp) {
/*     */           
/* 141 */           this.flags[offset] = (byte)(this.flags[offset] | nextFlags);
/*     */ 
/*     */ 
/*     */           
/* 145 */           if (0 != (this.flags[offset] & true)) {
/*     */             break;
/*     */           }
/* 148 */           this.flags[offset] = (byte)(this.flags[offset] | true);
/*     */         } else {
/* 150 */           this.timeStamps[offset] = this.currentTimeStamp;
/* 151 */           this.flags[offset] = (byte)(nextFlags | true);
/*     */         } 
/* 153 */         nextFlags = 0;
/* 154 */         int address = base + (offset << 2);
/* 155 */         int ci = this.addressSpace.internalRead32(address);
/* 156 */         CPUInstruction inst = this.r3000.decodeInstruction(ci);
/*     */         
/* 158 */         if (inst != null) {
/* 159 */           int iFlags = inst.getFlags();
/*     */           
/* 161 */           if (0 != (iFlags & true)) {
/* 162 */             int branchType = inst.getBranchType(ci);
/* 163 */             if (0 == (iFlags & 0x10)) {
/*     */ 
/*     */ 
/*     */               
/* 167 */               if (0 != (iFlags & 0xC)) {
/*     */                 int target;
/* 169 */                 if (0 != (iFlags & 0x4)) {
/* 170 */                   target = address + 4 + R3000.Util.signed_branch_delta(ci);
/*     */                 } else {
/*     */                   
/* 173 */                   target = address + 4 & 0xF0000000 | (ci & 0x3FFFFF) << 2;
/*     */                 } 
/* 175 */                 int targetOffset = target - base >> 2;
/* 176 */                 if (targetOffset < 0 || targetOffset >= 8000) {
/* 177 */                   this.branchTargets[offset] = new BasicBlock(this.currentBase, targetOffset, true);
/* 178 */                   if (firstExtraBlock == null) {
/* 179 */                     firstExtraBlock = lastExtraBlock = this.branchTargets[offset];
/*     */                   } else {
/* 181 */                     lastExtraBlock.next = this.branchTargets[offset];
/* 182 */                     lastExtraBlock = this.branchTargets[offset];
/*     */                   } 
/* 184 */                   this.blockCount++;
/*     */                 } else {
/* 186 */                   this.branchTargets[offset] = getBlock(targetOffset);
/*     */                   
/* 188 */                   this.pendingPaths.push(Integer.valueOf(targetOffset));
/*     */                 } 
/*     */               } else {
/* 191 */                 this.branchTargets[offset] = this.UNKNOWN_BRANCH_TARGET;
/*     */               } 
/*     */               
/* 194 */               if (branchType == 2) {
/* 195 */                 this.flags[offset] = (byte)(this.flags[offset] | 0x10);
/*     */               } else {
/* 197 */                 this.flags[offset] = (byte)(this.flags[offset] | 0x8);
/* 198 */                 flowOut = true;
/*     */               } 
/*     */ 
/*     */               
/* 202 */               end = offset + 2;
/* 203 */               nextFlags = 4;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 208 */       if (offset > max) {
/* 209 */         max = offset;
/*     */       }
/* 211 */       if (flowOut)
/*     */       {
/* 213 */         this.pendingPaths.push(Integer.valueOf(offset));
/*     */       }
/*     */     } 
/*     */     
/* 217 */     BasicBlock block = null;
/* 218 */     BasicBlock flowingInBlock = null;
/*     */     
/* 220 */     for (int offset = 0; offset < max; offset++) {
/* 221 */       if (this.timeStamps[offset] == this.currentTimeStamp) {
/* 222 */         assert 0 != (this.flags[offset] & true);
/*     */         
/* 224 */         if (0 != (this.flags[offset] & 0x2)) {
/* 225 */           if (block != null) {
/* 226 */             block.next = this.blocks[offset];
/*     */           }
/* 228 */           block = this.blocks[offset];
/* 229 */           if (flowingInBlock != null) {
/* 230 */             flowingInBlock.flowOut = block;
/*     */           }
/* 232 */           flowingInBlock = block;
/*     */         } 
/* 234 */         if (0 != (this.flags[offset] & 0x4)) {
/* 235 */           block.includesDelaySlot = true;
/*     */         }
/* 237 */         block.size++;
/* 238 */         instructionCount++;
/* 239 */         if (0 != (this.flags[offset] & 0x18)) {
/* 240 */           block.branchOffset = offset;
/* 241 */           block.branchOut = this.branchTargets[offset];
/* 242 */           if (0 != (this.flags[offset] & 0x10)) {
/* 243 */             flowingInBlock = null;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     assert block.next == null;
/* 284 */     block.next = firstExtraBlock;
/*     */     
/* 286 */     FlowInfo rc = new FlowInfo();
/* 287 */     rc.root = this.blocks[0];
/* 288 */     rc.instructionCount = instructionCount;
/* 289 */     rc.blockCount = this.blockCount;
/* 290 */     rc.base = base;
/* 291 */     rc.end = base + max * 4;
/* 292 */     return rc;
/*     */   }
/*     */   
/*     */   protected BasicBlock getBlock(int offset) {
/* 296 */     if (this.timeStamps[offset] != this.currentTimeStamp) {
/* 297 */       this.timeStamps[offset] = this.currentTimeStamp;
/* 298 */       this.flags[offset] = 0;
/*     */     } 
/* 300 */     if (0 == (this.flags[offset] & 0x2)) {
/* 301 */       this.flags[offset] = (byte)(this.flags[offset] | 0x2);
/* 302 */       this.blocks[offset] = new BasicBlock(this.currentBase, offset);
/* 303 */       this.blockCount++;
/*     */     } 
/* 305 */     return this.blocks[offset];
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\FlowAnalyzer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */