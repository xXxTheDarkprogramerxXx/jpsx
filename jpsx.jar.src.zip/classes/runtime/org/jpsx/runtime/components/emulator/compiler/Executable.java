package classes.runtime.org.jpsx.runtime.components.emulator.compiler;

public interface Executable {
  int e(int paramInt, boolean paramBoolean);
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\Executable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */