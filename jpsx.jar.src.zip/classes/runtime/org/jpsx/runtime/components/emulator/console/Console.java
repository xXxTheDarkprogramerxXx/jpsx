/*     */ package classes.runtime.org.jpsx.runtime.components.emulator.console;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import org.jpsx.api.CPUControl;
/*     */ import org.jpsx.api.CPUListener;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.api.components.core.irq.IRQController;
/*     */ import org.jpsx.api.components.core.scheduler.Quartz;
/*     */ import org.jpsx.runtime.JPSXComponent;
/*     */ import org.jpsx.runtime.RuntimeConnections;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.emulator.console.Console;
/*     */ import org.jpsx.runtime.components.hardware.gte.GTE;
/*     */ import org.jpsx.runtime.util.MiscUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Console
/*     */   extends JPSXComponent
/*     */   implements Runnable, CPUListener
/*     */ {
/*     */   protected int lastDisAddress;
/*     */   protected boolean skipShow = true;
/*     */   private AddressSpace addressSpace;
/*     */   private R3000 r3000;
/*     */   private CPUControl cpuControl;
/*     */   private Quartz quartz;
/*     */   
/*     */   public void init() {
/*  46 */     super.init();
/*  47 */     RuntimeConnections.MAIN.set(this);
/*  48 */     CoreComponentConnections.CPU_LISTENERS.add(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/*  53 */     super.resolveConnections();
/*  54 */     this.addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*  55 */     this.r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/*  56 */     this.cpuControl = (CPUControl)RuntimeConnections.CPU_CONTROL.resolve();
/*  57 */     this.quartz = (Quartz)CoreComponentConnections.QUARTZ.resolve();
/*     */   }
/*     */ 
/*     */   
/*  61 */   public Console() { super("JPSX Basic Console"); }
/*     */ 
/*     */   
/*     */   public void run() {
/*  65 */     dumpMainRegs();
/*     */     
/*  67 */     int lastDumpAddress = 0;
/*  68 */     DataInputStream input = new DataInputStream(System.in);
/*  69 */     boolean quit = false;
/*     */     
/*  71 */     long msBase = System.currentTimeMillis();
/*  72 */     long clockBase = this.quartz.nanoTime();
/*  73 */     showCurrentInstruction();
/*     */     try {
/*  75 */       while (!quit) {
/*  76 */         int address, count; String parse; int i, sp, base, pos, base, type; String addr; int type; String parse; long deltaClock, deltans; String line = input.readLine();
/*  77 */         if (line == null || line.length() == 0) {
/*     */           continue;
/*     */         }
/*  80 */         switch (line.charAt(0)) {
/*     */           case 'r':
/*  82 */             dumpMainRegs();
/*     */           
/*     */           case '2':
/*  85 */             dumpGTERegs();
/*     */           
/*     */           case 't':
/*  88 */             deltans = 1000000L * (System.currentTimeMillis() - msBase);
/*  89 */             deltaClock = this.quartz.nanoTime() - clockBase;
/*  90 */             System.out.println("Clocks: " + deltans + " " + deltaClock + " " + (1.0D * deltaClock / deltans));
/*  91 */             msBase = System.currentTimeMillis();
/*  92 */             clockBase = this.quartz.nanoTime();
/*     */           
/*     */           case 'g':
/*  95 */             this.cpuControl.go();
/*     */           
/*     */           case 'u':
/*  98 */             addr = line.substring(1).trim();
/*  99 */             if (addr.length() > 0)
/* 100 */               this.lastDisAddress = MiscUtil.parseHex(addr); 
/* 101 */             for (i = 0; i < 20; i++) {
/* 102 */               int ci = this.addressSpace.internalRead32(this.lastDisAddress);
/* 103 */               String dis = this.r3000.disassemble(this.lastDisAddress, ci);
/* 104 */               System.out.println(MiscUtil.toHex(this.lastDisAddress, 8) + ": " + MiscUtil.toHex(ci, 8) + " " + dis);
/* 105 */               this.lastDisAddress += 4;
/*     */             } 
/*     */ 
/*     */           
/*     */           case 'o':
/* 110 */             sStart = line.substring(1).trim();
/* 111 */             pos = sStart.indexOf(' ');
/* 112 */             if (pos != -1) {
/* 113 */               int start = MiscUtil.parseHex(sStart);
/* 114 */               int end = MiscUtil.parseHex(sStart.substring(pos).trim());
/*     */               try {
/* 116 */                 PrintWriter fw = new PrintWriter(new FileOutputStream("o.dis"));
/* 117 */                 for (int i = start; i < end; i += 4) {
/* 118 */                   int ci = this.addressSpace.internalRead32(i);
/* 119 */                   String dis = MiscUtil.toHex(i, 8) + ": " + MiscUtil.toHex(ci, 8) + " " + this.r3000.disassemble(i, ci);
/* 120 */                   fw.println(dis);
/*     */                 } 
/* 122 */                 fw.close();
/* 123 */               } catch (IOException e) {}
/*     */             } 
/*     */ 
/*     */ 
/*     */           
/*     */           case 'b':
/* 129 */             if (line.length() > 1) {
/* 130 */               int i; int[] bps; int address; int address; switch (line.charAt(1)) {
/*     */                 case 'l':
/* 132 */                   bps = this.cpuControl.getBreakpoints();
/* 133 */                   for (i = 0; i < bps.length; i++) {
/* 134 */                     System.out.println(Integer.toHexString(i) + ": " + MiscUtil.toHex(bps[i], 8));
/*     */                   }
/*     */                   continue;
/*     */                 
/*     */                 case ' ':
/*     */                 case 'p':
/* 140 */                   address = MiscUtil.parseHex(line.substring(2));
/* 141 */                   this.cpuControl.addBreakpoint(address);
/*     */                   continue;
/*     */                 
/*     */                 case 'c':
/* 145 */                   address = MiscUtil.parseHex(line.substring(2));
/* 146 */                   this.cpuControl.removeBreakpoint(address);
/*     */                   continue;
/*     */               } 
/*     */               continue;
/*     */             } 
/* 151 */             this.cpuControl.pause();
/*     */ 
/*     */           
/*     */           case 'c':
/* 155 */             System.out.println("calling for gc");
/* 156 */             System.gc();
/*     */           
/*     */           case 'i':
/*     */             try {
/* 160 */               int i = Integer.parseInt(line.substring(1).trim());
/* 161 */               System.out.println("Raising IRQ " + i);
/* 162 */               ((IRQController)CoreComponentConnections.IRQ_CONTROLLER.resolve()).raiseIRQ(i);
/* 163 */             } catch (Throwable sStart) {
/*     */               Throwable t;
/*     */             } 
/*     */           case 'w':
/* 167 */             type = 100;
/* 168 */             base = 1;
/* 169 */             if (base < line.length()) {
/* 170 */               if (line.charAt(base) == 'w') {
/* 171 */                 type = 119;
/* 172 */                 base++;
/* 173 */               } else if (line.charAt(base) == 'b') {
/* 174 */                 type = 98;
/* 175 */                 base++;
/*     */               } 
/*     */             }
/* 178 */             parse = line.substring(base);
/* 179 */             parse = parse.trim();
/* 180 */             if (parse.length() > 0) {
/* 181 */               int split = parse.indexOf(' ');
/*     */               try {
/* 183 */                 if (split >= 0) {
/* 184 */                   int address = MiscUtil.parseHex(parse.substring(0, split).trim());
/* 185 */                   int value = MiscUtil.parseHex(parse.substring(split).trim());
/*     */                   
/* 187 */                   switch (type) {
/*     */                     case 100:
/* 189 */                       this.addressSpace.write32(address, value);
/*     */                     
/*     */                     case 119:
/* 192 */                       this.addressSpace.write16(address, value & 0xFFFF);
/*     */                     
/*     */                     case 98:
/* 195 */                       this.addressSpace.write8(address, value & 0xFF);
/*     */                   } 
/*     */                 
/*     */                 } 
/* 199 */               } catch (Throwable t) {}
/*     */             } 
/*     */ 
/*     */ 
/*     */           
/*     */           case 'd':
/* 205 */             type = 100;
/* 206 */             base = 1;
/* 207 */             if (base < line.length()) {
/* 208 */               if (line.charAt(base) == 'w') {
/* 209 */                 type = 119;
/* 210 */                 base++;
/* 211 */               } else if (line.charAt(base) == 'b') {
/* 212 */                 type = 98;
/* 213 */                 base++;
/*     */               } 
/*     */             }
/* 216 */             parse = line.substring(base);
/* 217 */             parse = parse.trim();
/* 218 */             count = 6;
/* 219 */             address = lastDumpAddress;
/* 220 */             if (parse.length() > 0) {
/* 221 */               int split = parse.indexOf(' ');
/*     */               try {
/* 223 */                 if (split >= 0) {
/* 224 */                   count = Integer.parseInt(parse.substring(split).trim());
/*     */                 }
/* 226 */               } catch (Throwable t) {}
/*     */               
/* 228 */               address = MiscUtil.parseHex(parse);
/*     */             } 
/* 230 */             if (count > 0) {
/* 231 */               for (int i = 0; i < count; i++, address += 16) {
/*     */                 
/* 233 */                 String val = MiscUtil.toHex(address, 8) + ": ";
/* 234 */                 switch (type) {
/*     */                   case 100:
/* 236 */                     if (0 != (address & 0x3))
/* 237 */                       address &= 0xFFFFFFFC; 
/* 238 */                     for (j = 0; j < 4; j++) {
/* 239 */                       val = val + MiscUtil.toHex(this.addressSpace.read32(address + j * 4), 8) + " ";
/*     */                     }
/*     */                     break;
/*     */                   case 119:
/* 243 */                     if (0 != (address & true))
/* 244 */                       address &= 0xFFFFFFFE; 
/* 245 */                     for (j = 0; j < 8; j++) {
/* 246 */                       val = val + MiscUtil.toHex(this.addressSpace.read16(address + j * 2), 4) + " ";
/*     */                     }
/*     */                     break;
/*     */                   case 98:
/* 250 */                     for (j = 0; j < 16; j++) {
/* 251 */                       val = val + MiscUtil.toHex(this.addressSpace.read8(address + j), 2) + " ";
/*     */                     }
/*     */                     break;
/*     */                 } 
/* 255 */                 val = val + " ";
/* 256 */                 for (int j = 0; j < 16; j++) {
/* 257 */                   int b = this.addressSpace.read8(address + j);
/* 258 */                   if (b >= 32 && b < 127) {
/* 259 */                     val = val + (char)b;
/*     */                   } else {
/* 261 */                     val = val + " ";
/*     */                   } 
/*     */                 } 
/* 264 */                 System.out.println(val);
/*     */               } 
/* 266 */               lastDumpAddress = address;
/*     */             } 
/*     */ 
/*     */           
/*     */           case 's':
/* 271 */             this.cpuControl.step();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 'q':
/* 277 */             quit = true;
/*     */           
/*     */           case 'v':
/* 280 */             parse = line.substring(2);
/* 281 */             parse = parse.trim();
/* 282 */             if (parse.startsWith("fill")) {
/*     */               continue;
/*     */             }
/*     */             
/* 286 */             sp = parse.indexOf(' ');
/* 287 */             if (sp > 0) {
/*     */               try {
/* 289 */                 int voice = Integer.parseInt(parse.substring(0, sp));
/* 290 */                 parse = parse.substring(sp + 1);
/* 291 */                 if (voice >= 0 && voice < 24) {
/* 292 */                   if (parse.startsWith("on")) {
/* 293 */                     if (voice < 16) {
/* 294 */                       this.addressSpace.write16(528489864, 1 << voice);
/*     */                     } else {
/* 296 */                       this.addressSpace.write16(528489866, 1 << voice - 16);
/*     */                     } 
/* 298 */                     System.out.println("voice " + voice + " on"); continue;
/* 299 */                   }  if (parse.startsWith("off")) {
/* 300 */                     if (voice < 16) {
/* 301 */                       this.addressSpace.write16(528489868, 1 << voice);
/*     */                     } else {
/* 303 */                       this.addressSpace.write16(528489870, 1 << voice - 16);
/*     */                     } 
/* 305 */                     System.out.println("voice " + voice + " off"); continue;
/* 306 */                   }  if (parse.startsWith("freq")) {
/* 307 */                     int freq = MiscUtil.parseHex(parse.substring(5));
/* 308 */                     this.addressSpace.write16(528489476 + voice * 16, freq);
/* 309 */                     System.out.println("voice " + voice + " freq set to " + MiscUtil.toHex(freq, 4));
/*     */                   } 
/*     */                 } 
/* 312 */               } catch (Throwable parse) {
/*     */                 Throwable t;
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 319 */     } catch (Throwable t) {
/* 320 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void showCurrentInstruction() {
/* 325 */     if (this.skipShow) {
/* 326 */       this.skipShow = false;
/*     */     } else {
/* 328 */       int pc = this.r3000.getPC();
/* 329 */       int ci = this.addressSpace.internalRead32(pc);
/* 330 */       String dis = this.r3000.disassemble(pc, ci);
/* 331 */       System.out.println(MiscUtil.toHex(pc, 8) + ": " + MiscUtil.toHex(ci, 8) + " " + dis);
/* 332 */       this.lastDisAddress = pc + 4;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dumpGTERegs() {
/* 337 */     System.out.println("vxy0   " + MiscUtil.toHex(GTE.readRegister(0), 8) + " vz0    " + MiscUtil.toHex(GTE.readRegister(1), 8) + " vxy1   " + MiscUtil.toHex(GTE.readRegister(2), 8) + " vz1    " + MiscUtil.toHex(GTE.readRegister(3), 8));
/* 338 */     System.out.println("vxy2   " + MiscUtil.toHex(GTE.readRegister(4), 8) + " vz2    " + MiscUtil.toHex(GTE.readRegister(5), 8) + " rgb    " + MiscUtil.toHex(GTE.readRegister(6), 8) + " otz    " + MiscUtil.toHex(GTE.readRegister(7), 8));
/* 339 */     System.out.println("ir0    " + MiscUtil.toHex(GTE.readRegister(8), 8) + " ir1    " + MiscUtil.toHex(GTE.readRegister(9), 8) + " ir2    " + MiscUtil.toHex(GTE.readRegister(10), 8) + " ir3    " + MiscUtil.toHex(GTE.readRegister(11), 8));
/* 340 */     System.out.println("sxy0   " + MiscUtil.toHex(GTE.readRegister(12), 8) + " sxy1   " + MiscUtil.toHex(GTE.readRegister(13), 8) + " sxy2   " + MiscUtil.toHex(GTE.readRegister(14), 8) + " sxyp   " + MiscUtil.toHex(GTE.readRegister(15), 8));
/* 341 */     System.out.println("sz0    " + MiscUtil.toHex(GTE.readRegister(16), 8) + " sz1    " + MiscUtil.toHex(GTE.readRegister(17), 8) + " sz2    " + MiscUtil.toHex(GTE.readRegister(18), 8) + " sz3    " + MiscUtil.toHex(GTE.readRegister(19), 8));
/* 342 */     System.out.println("rgb0   " + MiscUtil.toHex(GTE.readRegister(20), 8) + " rgb1   " + MiscUtil.toHex(GTE.readRegister(21), 8) + " rgb2   " + MiscUtil.toHex(GTE.readRegister(22), 8) + " res1   " + MiscUtil.toHex(GTE.readRegister(23), 8));
/* 343 */     System.out.println("mac0   " + MiscUtil.toHex(GTE.readRegister(24), 8) + " mac1   " + MiscUtil.toHex(GTE.readRegister(25), 8) + " mac2   " + MiscUtil.toHex(GTE.readRegister(26), 8) + " mac3   " + MiscUtil.toHex(GTE.readRegister(27), 8));
/* 344 */     System.out.println("irgb   " + MiscUtil.toHex(GTE.readRegister(28), 8) + " orgb   " + MiscUtil.toHex(GTE.readRegister(29), 8) + " lzcs   " + MiscUtil.toHex(GTE.readRegister(30), 8) + " lzcr   " + MiscUtil.toHex(GTE.readRegister(31), 8));
/* 345 */     System.out.println("r11r12 " + MiscUtil.toHex(GTE.readRegister(32), 8) + " r13r21 " + MiscUtil.toHex(GTE.readRegister(33), 8) + " r22r23 " + MiscUtil.toHex(GTE.readRegister(34), 8) + " r31r32 " + MiscUtil.toHex(GTE.readRegister(35), 8));
/* 346 */     System.out.println("r33    " + MiscUtil.toHex(GTE.readRegister(36), 8) + " trx    " + MiscUtil.toHex(GTE.readRegister(37), 8) + " try    " + MiscUtil.toHex(GTE.readRegister(38), 8) + " trz    " + MiscUtil.toHex(GTE.readRegister(39), 8));
/* 347 */     System.out.println("l11r12 " + MiscUtil.toHex(GTE.readRegister(40), 8) + " l13r21 " + MiscUtil.toHex(GTE.readRegister(41), 8) + " l22r23 " + MiscUtil.toHex(GTE.readRegister(42), 8) + " l31r32 " + MiscUtil.toHex(GTE.readRegister(43), 8));
/* 348 */     System.out.println("l33    " + MiscUtil.toHex(GTE.readRegister(44), 8) + " rbk    " + MiscUtil.toHex(GTE.readRegister(45), 8) + " gbk    " + MiscUtil.toHex(GTE.readRegister(46), 8) + " bbk    " + MiscUtil.toHex(GTE.readRegister(47), 8));
/* 349 */     System.out.println("lr1lr2 " + MiscUtil.toHex(GTE.readRegister(48), 8) + " lr3lg1 " + MiscUtil.toHex(GTE.readRegister(49), 8) + " lg2lg3 " + MiscUtil.toHex(GTE.readRegister(50), 8) + " lb1lb2 " + MiscUtil.toHex(GTE.readRegister(51), 8));
/* 350 */     System.out.println("lb3    " + MiscUtil.toHex(GTE.readRegister(52), 8) + " rfc    " + MiscUtil.toHex(GTE.readRegister(53), 8) + " gfc    " + MiscUtil.toHex(GTE.readRegister(54), 8) + " bfc    " + MiscUtil.toHex(GTE.readRegister(55), 8));
/* 351 */     System.out.println("ofx    " + MiscUtil.toHex(GTE.readRegister(56), 8) + " ofy    " + MiscUtil.toHex(GTE.readRegister(57), 8) + " h      " + MiscUtil.toHex(GTE.readRegister(58), 8) + " dqa    " + MiscUtil.toHex(GTE.readRegister(59), 8));
/* 352 */     System.out.println("dqb    " + MiscUtil.toHex(GTE.readRegister(60), 8) + " zsf3   " + MiscUtil.toHex(GTE.readRegister(61), 8) + " zsf4   " + MiscUtil.toHex(GTE.readRegister(62), 8) + " flag   " + MiscUtil.toHex(GTE.readRegister(63), 8));
/*     */   }
/*     */   
/*     */   public void dumpMainRegs() {
/* 356 */     System.out.println("r0  " + MiscUtil.toHex(this.r3000.getReg(0), 8) + " r1  " + MiscUtil.toHex(this.r3000.getReg(1), 8) + " r2  " + MiscUtil.toHex(this.r3000.getReg(2), 8) + " r3  " + MiscUtil.toHex(this.r3000.getReg(3), 8) + " pc  " + MiscUtil.toHex(this.r3000.getPC(), 8));
/* 357 */     System.out.println("r4  " + MiscUtil.toHex(this.r3000.getReg(4), 8) + " r5  " + MiscUtil.toHex(this.r3000.getReg(5), 8) + " r6  " + MiscUtil.toHex(this.r3000.getReg(6), 8) + " r7  " + MiscUtil.toHex(this.r3000.getReg(7), 8) + " lo  " + MiscUtil.toHex(this.r3000.getLO(), 8));
/* 358 */     System.out.println("r8  " + MiscUtil.toHex(this.r3000.getReg(8), 8) + " r9  " + MiscUtil.toHex(this.r3000.getReg(9), 8) + " r10 " + MiscUtil.toHex(this.r3000.getReg(10), 8) + " r11 " + MiscUtil.toHex(this.r3000.getReg(11), 8) + " hi  " + MiscUtil.toHex(this.r3000.getHI(), 8));
/* 359 */     System.out.println("r12 " + MiscUtil.toHex(this.r3000.getReg(12), 8) + " r13 " + MiscUtil.toHex(this.r3000.getReg(13), 8) + " r14 " + MiscUtil.toHex(this.r3000.getReg(14), 8) + " r15 " + MiscUtil.toHex(this.r3000.getReg(15), 8));
/* 360 */     System.out.println("r16 " + MiscUtil.toHex(this.r3000.getReg(16), 8) + " r17 " + MiscUtil.toHex(this.r3000.getReg(17), 8) + " r18 " + MiscUtil.toHex(this.r3000.getReg(18), 8) + " r19 " + MiscUtil.toHex(this.r3000.getReg(19), 8));
/* 361 */     System.out.println("r20 " + MiscUtil.toHex(this.r3000.getReg(20), 8) + " r21 " + MiscUtil.toHex(this.r3000.getReg(21), 8) + " r22 " + MiscUtil.toHex(this.r3000.getReg(22), 8) + " r23 " + MiscUtil.toHex(this.r3000.getReg(23), 8));
/* 362 */     System.out.println("r24 " + MiscUtil.toHex(this.r3000.getReg(24), 8) + " r25 " + MiscUtil.toHex(this.r3000.getReg(25), 8) + " r26 " + MiscUtil.toHex(this.r3000.getReg(26), 8) + " r27 " + MiscUtil.toHex(this.r3000.getReg(27), 8));
/* 363 */     System.out.println("r28 " + MiscUtil.toHex(this.r3000.getReg(28), 8) + " r29 " + MiscUtil.toHex(this.r3000.getReg(29), 8) + " r30 " + MiscUtil.toHex(this.r3000.getReg(30), 8) + " r31 " + MiscUtil.toHex(this.r3000.getReg(31), 8));
/*     */   }
/*     */ 
/*     */   
/*     */   public void cpuResumed() {}
/*     */ 
/*     */   
/* 370 */   public void cpuPaused() { showCurrentInstruction(); }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\console\Console.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */