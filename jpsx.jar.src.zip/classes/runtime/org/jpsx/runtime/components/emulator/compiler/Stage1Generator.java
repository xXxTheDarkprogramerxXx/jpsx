/*      */ package classes.runtime.org.jpsx.runtime.components.emulator.compiler;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.HashMap;
/*      */ import org.apache.bcel.classfile.ConstantPool;
/*      */ import org.apache.bcel.classfile.JavaClass;
/*      */ import org.apache.bcel.classfile.Method;
/*      */ import org.apache.bcel.generic.ClassGen;
/*      */ import org.apache.bcel.generic.ConstantPoolGen;
/*      */ import org.apache.bcel.generic.FieldGen;
/*      */ import org.apache.bcel.generic.GETFIELD;
/*      */ import org.apache.bcel.generic.GETSTATIC;
/*      */ import org.apache.bcel.generic.GOTO;
/*      */ import org.apache.bcel.generic.IADD;
/*      */ import org.apache.bcel.generic.IALOAD;
/*      */ import org.apache.bcel.generic.IAND;
/*      */ import org.apache.bcel.generic.IASTORE;
/*      */ import org.apache.bcel.generic.IFEQ;
/*      */ import org.apache.bcel.generic.IFLE;
/*      */ import org.apache.bcel.generic.IF_ICMPEQ;
/*      */ import org.apache.bcel.generic.ILOAD;
/*      */ import org.apache.bcel.generic.INVOKESTATIC;
/*      */ import org.apache.bcel.generic.IOR;
/*      */ import org.apache.bcel.generic.IRETURN;
/*      */ import org.apache.bcel.generic.ISHL;
/*      */ import org.apache.bcel.generic.ISHR;
/*      */ import org.apache.bcel.generic.ISTORE;
/*      */ import org.apache.bcel.generic.InstructionHandle;
/*      */ import org.apache.bcel.generic.InstructionList;
/*      */ import org.apache.bcel.generic.MethodGen;
/*      */ import org.apache.bcel.generic.NOP;
/*      */ import org.apache.bcel.generic.PUSH;
/*      */ import org.apache.bcel.generic.PUTSTATIC;
/*      */ import org.apache.bcel.generic.SWAP;
/*      */ import org.apache.bcel.generic.Type;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*      */ import org.jpsx.api.components.core.cpu.CPUInstruction;
/*      */ import org.jpsx.api.components.core.cpu.R3000;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.components.emulator.compiler.CodeUnit;
/*      */ import org.jpsx.runtime.components.emulator.compiler.FlowAnalyzer;
/*      */ import org.jpsx.runtime.components.emulator.compiler.MultiStageCompiler;
/*      */ import org.jpsx.runtime.components.emulator.compiler.Stage1Generator;
/*      */ import org.jpsx.runtime.util.ClassUtil;
/*      */ import org.jpsx.runtime.util.MiscUtil;
/*      */ 
/*      */ public class Stage1Generator implements CompilationContext {
/*   48 */   public static final Logger log = Logger.getLogger("Stage1"); protected static final String CLASS_NAME_PREFIX = "_1"; protected static final String STATIC_METHOD = "s"; protected static final String NORMAL_METHOD = "e"; protected static final String UNINLINED_METHOD_PREFIX = "_"; FlowAnalyzer analyzer; protected final int[] opCodes; protected final CPUInstruction[] instructions; protected final int[] regsRead; protected final int[] regsWritten; protected final int[] flags; protected PrintStream codeWriter; private final int[] simulateRegs; private final InstructionList[] instructionLists; private final HashMap extraInstructionLists;
/*      */   private final InstructionHandle[] endHandles;
/*      */   private final InstructionList printCodeIL;
/*      */   private String codeFilename;
/*      */   private final AddressSpace addressSpace;
/*      */   private final R3000 r3000;
/*      */   
/*   55 */   public Stage1Generator(String codeFilename) { this.analyzer = new FlowAnalyzer();
/*      */ 
/*      */     
/*   58 */     this.opCodes = new int[8000];
/*   59 */     this.instructions = new CPUInstruction[8000];
/*   60 */     this.regsRead = new int[8000];
/*   61 */     this.regsWritten = new int[8000];
/*   62 */     this.flags = new int[8000];
/*      */ 
/*      */     
/*   65 */     this.simulateRegs = new int[32];
/*   66 */     this.instructionLists = new InstructionList[8000];
/*   67 */     this.extraInstructionLists = new HashMap();
/*   68 */     this.endHandles = MultiStageCompiler.Settings.printCode ? new InstructionHandle[8000] : null;
/*   69 */     this.printCodeIL = new InstructionList();
/*      */ 
/*      */ 
/*      */     
/*   73 */     this.addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*   74 */     this.r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  676 */     this.rr = new AddressSpace.ResolveResult();
/*      */     this.codeFilename = codeFilename;
/*      */     if (MultiStageCompiler.Settings.printCode)
/*      */       try {
/*      */         this.codeWriter = new PrintStream(new FileOutputStream(codeFilename));
/*      */       } catch (IOException e) {
/*      */         throw new InvalidConfigurationException("can't open " + codeFilename + " for output", e);
/*      */       }   }
/*      */ 
/*      */   
/*      */   protected static final String R3000_CLASS = org.jpsx.runtime.components.core.R3000Impl.class.getName(); protected static final String COMPILER_CLASS = MultiStageCompiler.class.getName(); protected static final String ADDRESS_SPACE_CLASS = org.jpsx.runtime.components.core.AddressSpaceImpl.class.getName(); protected static final String HW_CLASS = ClassUtil.innerClassName(org.jpsx.runtime.components.core.AddressSpaceImpl.class, "Hardware"); protected static final String EXECUTABLE_CLASS = org.jpsx.runtime.components.emulator.compiler.Executable.class.getName(); protected static final String CODEUNIT_CLASS = CodeUnit.class.getName(); protected static final String CODEUNIT_SIGNATURE = ClassUtil.signatureOfClass(CODEUNIT_CLASS); protected static final int LOCAL_RETADDR = 0; protected static final int LOCAL_JUMP = 1; protected static final int LOCAL_PRIVATE_TEMP = 2; protected static final int LOCAL_TEMP0 = 3; protected static final int LOCAL_LAST = 8; protected static final int MAX_METHOD_INSTRUCTION_COUNT = 800; protected static final int MINIMUM_INSRUCTIONS_PER_METHOD = 4; protected static final int ALL_REGS = -1; protected static final int WRITABLE_REGS = -2; protected boolean noInterruptCheck; protected FlowAnalyzer.BasicBlock contextBlock; protected int contextBase; protected int contextOffset; protected int contextAddress; protected MethodGen contextMethodGen; protected ConstantPoolGen contextCP; protected ClassGen contextClassGen; protected AddressSpace.ResolveResult rr; protected boolean contextDelaySlotEmitted; protected boolean contextIsDelaySlot;
/*  687 */   public void emitInterpretedInstruction(InstructionList il, int ci, String clazz, String method) { if (0 != (this.flags[this.contextOffset] & 0x40000)) {
/*  688 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "compilerToInterpreter", "()V")));
/*      */     } else {
/*  690 */       int readsReg = getReadsReg();
/*  691 */       for (int r = 1; r < 32; r++) {
/*  692 */         if (0 != (readsReg & 1 << r)) {
/*      */           
/*  694 */           il.append(new GETSTATIC(this.contextCP.addFieldref(R3000_CLASS, "regs", "[I")));
/*      */           
/*  696 */           il.append(new PUSH(this.contextCP, r));
/*  697 */           if (0 != (getConstantRegs() & 1 << r)) {
/*  698 */             il.append(new PUSH(this.contextCP, getRegValue(r)));
/*      */           } else {
/*  700 */             emitGetReg(il, r);
/*      */           } 
/*  702 */           il.append(new IASTORE());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  707 */     il.append(new PUSH(this.contextCP, ci));
/*  708 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(clazz, method, "(I)V")));
/*      */     
/*  710 */     if (0 != (this.flags[this.contextOffset] & 0x40000))
/*  711 */     { il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "interpreterToCompiler", "()V"))); }
/*      */     else
/*  713 */     { int writesReg = getWritesReg();
/*  714 */       for (int r = 1; r < 32; r++)
/*  715 */       { if (0 != (writesReg & 1 << r))
/*      */         
/*  717 */         { il.append(new GETSTATIC(this.contextCP.addFieldref(R3000_CLASS, "regs", "[I")));
/*  718 */           il.append(new PUSH(this.contextCP, r));
/*  719 */           il.append(new IALOAD());
/*  720 */           emitSetReg(il, r); }  }  }  }
/*      */   protected CodeUnit contextUnit;
/*      */   protected String getClassNamePrefix(CodeUnit unit) { return "_1"; }
/*      */   protected int getMaxMethodInstructionCount() { return 800; }
/*      */   protected boolean shouldPrintCode() { return true; }
/*      */   protected void emitMethodHeader(InstructionList il) { FieldGen fg = new FieldGen(9, Type.getType(CODEUNIT_SIGNATURE), "unit", this.contextCP); this.contextClassGen.addField(fg.getField()); il.append(new GETSTATIC(this.contextCP.addFieldref(this.contextClassGen.getClassName(), "unit", CODEUNIT_SIGNATURE))); il.append(new GETFIELD(this.contextCP.addFieldref(CODEUNIT_CLASS, "useStage2", "Z"))); IFEQ ifeq = new IFEQ(null); il.append(ifeq); il.append(new ILOAD(false)); il.append(new ILOAD(true)); il.append(new INVOKESTATIC(this.contextCP.addMethodref(getClassName(Stage2Generator.CLASS_NAME_PREFIX, this.contextBase), "s", "(IZ)I"))); il.append(new IRETURN()); ifeq.setTarget(il.append(new GETSTATIC(this.contextCP.addFieldref(this.contextClassGen.getClassName(), "unit", CODEUNIT_SIGNATURE)))); il.append(new GETFIELD(this.contextCP.addFieldref(CODEUNIT_CLASS, "count", "I"))); il.append(new ISTORE(3)); il.append(new ILOAD(3)); IFLE ifle = new IFLE(null); il.append(ifle); il.append(new IINC(3, -1)); il.append(new GETSTATIC(this.contextCP.addFieldref(this.contextClassGen.getClassName(), "unit", CODEUNIT_SIGNATURE))); il.append(new ILOAD(3)); il.append(new PUTFIELD(this.contextCP.addFieldref(CODEUNIT_CLASS, "count", "I"))); GOTO gt = new GOTO(null); il.append(gt); ifle.setTarget(il.append(new GETSTATIC(this.contextCP.addFieldref(this.contextClassGen.getClassName(), "unit", CODEUNIT_SIGNATURE)))); il.append(new INVOKEVIRTUAL(this.contextCP.addMethodref(CODEUNIT_CLASS, "countComplete", "()V"))); gt.setTarget(il.append(new NOP())); }
/*      */   protected void emitBlockHeader(InstructionList il) { this.contextDelaySlotEmitted = false; }
/*      */   protected void emitBlockFooter(InstructionList il) { if (MultiStageCompiler.Settings.printCode && shouldPrintCode()) { int size = this.contextBlock.size; if (size != 0) { if (this.contextBlock.branchOut != null && this.contextBlock.includesDelaySlot) size--;  assert size > 0; this.endHandles[this.contextBlock.offset + size - 1] = il.getEnd(); }  }  this.contextDelaySlotEmitted = false; } protected void initBlockStructures(FlowAnalyzer.FlowInfo flowInfo) { this.noInterruptCheck = false; this.extraInstructionLists.clear(); for (FlowAnalyzer.BasicBlock block = flowInfo.root; block != null; block = block.next) { if (block.size != 0) if (this.instructionLists[block.offset] == null) { this.instructionLists[block.offset] = new InstructionList(); } else { assert null == this.instructionLists[block.offset].getStart(); }   for (int offset = block.offset; offset < block.offset + block.size; offset++) { int address = flowInfo.base + offset * 4; int ci = this.addressSpace.internalRead32(address); this.opCodes[offset] = ci; CPUInstruction inst = this.r3000.decodeInstruction(ci); this.instructions[offset] = inst; int iFlags = inst.getFlags(); this.flags[offset] = iFlags; this.regsRead[offset] = 0; this.regsWritten[offset] = 0; if (0 != (iFlags & 0x100)) this.regsRead[offset] = this.regsRead[offset] | 1 << R3000.Util.bits_rs(ci);  if (0 != (iFlags & 0x200)) this.regsRead[offset] = this.regsRead[offset] | 1 << R3000.Util.bits_rt(ci);  if (0 != (iFlags & 0x400)) this.regsWritten[offset] = this.regsWritten[offset] | 1 << R3000.Util.bits_rt(ci);  if (0 != (iFlags & 0x800)) this.regsWritten[offset] = this.regsWritten[offset] | 1 << R3000.Util.bits_rd(ci);  if (0 != (this.regsWritten[offset] & 0xC000000)) this.noInterruptCheck = true;  if (0 != (iFlags & 0x40000)) { this.regsRead[offset] = -1; this.regsWritten[offset] = this.regsWritten[offset] | 0xFFFFFFFE; } else if (0 != (iFlags & 0x10)) { this.regsRead[offset] = -1; this.regsWritten[offset] = this.regsWritten[offset] | 0xCF00FFFE; }  this.regsWritten[offset] = this.regsWritten[offset] & 0xFFFFFFFE; }  }  if (this.noInterruptCheck && log.isDebugEnabled()) log.debug("*** BIOS BUG WORKAROUND FOR " + MiscUtil.toHex(flowInfo.base, 8));  } public String getClassName(String prefix, int base) { return prefix + MiscUtil.toHex(base, 8); } protected void emitICodeUnitMethods() { this.contextClassGen.addInterface(EXECUTABLE_CLASS); InstructionList il = new InstructionList(); MethodGen mg = new MethodGen(true, Type.INT, new Type[] { Type.INT, Type.BOOLEAN }, new String[] { "retAddr", "jump" }, "e", this.contextClassGen.getClassName(), il, this.contextCP); il.append(new ILOAD(true)); il.append(new ILOAD(2)); il.append(new INVOKESTATIC(this.contextCP.addMethodref(this.contextClassGen.getClassName(), "s", "(IZ)I"))); il.append(new IRETURN()); mg.setMaxLocals(); mg.setMaxStack(); this.contextClassGen.addMethod(mg.getMethod()); il.dispose(); } protected void emitMethods(FlowAnalyzer.FlowInfo flowInfo) { emitICodeUnitMethods(); emitStaticExecuteMethod(flowInfo); } protected void emitStaticExecuteMethod(FlowAnalyzer.FlowInfo flowInfo) { // Byte code:
/*      */     //   0: new org/apache/bcel/generic/InstructionList
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_2
/*      */     //   8: new org/apache/bcel/generic/MethodGen
/*      */     //   11: dup
/*      */     //   12: bipush #9
/*      */     //   14: getstatic org/apache/bcel/generic/Type.INT : Lorg/apache/bcel/generic/BasicType;
/*      */     //   17: iconst_2
/*      */     //   18: anewarray org/apache/bcel/generic/Type
/*      */     //   21: dup
/*      */     //   22: iconst_0
/*      */     //   23: getstatic org/apache/bcel/generic/Type.INT : Lorg/apache/bcel/generic/BasicType;
/*      */     //   26: aastore
/*      */     //   27: dup
/*      */     //   28: iconst_1
/*      */     //   29: getstatic org/apache/bcel/generic/Type.BOOLEAN : Lorg/apache/bcel/generic/BasicType;
/*      */     //   32: aastore
/*      */     //   33: iconst_2
/*      */     //   34: anewarray java/lang/String
/*      */     //   37: dup
/*      */     //   38: iconst_0
/*      */     //   39: ldc 'retAddr'
/*      */     //   41: aastore
/*      */     //   42: dup
/*      */     //   43: iconst_1
/*      */     //   44: ldc 'jump'
/*      */     //   46: aastore
/*      */     //   47: ldc 's'
/*      */     //   49: aload_0
/*      */     //   50: getfield contextClassGen : Lorg/apache/bcel/generic/ClassGen;
/*      */     //   53: invokevirtual getClassName : ()Ljava/lang/String;
/*      */     //   56: aload_2
/*      */     //   57: aload_0
/*      */     //   58: getfield contextCP : Lorg/apache/bcel/generic/ConstantPoolGen;
/*      */     //   61: invokespecial <init> : (ILorg/apache/bcel/generic/Type;[Lorg/apache/bcel/generic/Type;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/apache/bcel/generic/InstructionList;Lorg/apache/bcel/generic/ConstantPoolGen;)V
/*      */     //   64: astore_3
/*      */     //   65: aload_0
/*      */     //   66: aload_2
/*      */     //   67: invokevirtual emitDebugs : (Lorg/apache/bcel/generic/InstructionList;)V
/*      */     //   70: aload_0
/*      */     //   71: aload_2
/*      */     //   72: invokevirtual emitMethodHeader : (Lorg/apache/bcel/generic/InstructionList;)V
/*      */     //   75: invokestatic newHashSet : ()Ljava/util/Set;
/*      */     //   78: astore #4
/*      */     //   80: aload_0
/*      */     //   81: invokevirtual getMaxMethodInstructionCount : ()I
/*      */     //   84: istore #5
/*      */     //   86: aload_1
/*      */     //   87: getfield instructionCount : I
/*      */     //   90: iload #5
/*      */     //   92: if_icmple -> 221
/*      */     //   95: aload_1
/*      */     //   96: getfield blockCount : I
/*      */     //   99: anewarray org/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock
/*      */     //   102: astore #6
/*      */     //   104: iconst_0
/*      */     //   105: istore #7
/*      */     //   107: aload_1
/*      */     //   108: getfield root : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   111: astore #8
/*      */     //   113: aload #8
/*      */     //   115: ifnull -> 138
/*      */     //   118: aload #6
/*      */     //   120: iload #7
/*      */     //   122: iinc #7, 1
/*      */     //   125: aload #8
/*      */     //   127: aastore
/*      */     //   128: aload #8
/*      */     //   130: getfield next : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   133: astore #8
/*      */     //   135: goto -> 113
/*      */     //   138: aload #6
/*      */     //   140: new org/jpsx/runtime/components/emulator/compiler/Stage1Generator$1
/*      */     //   143: dup
/*      */     //   144: aload_0
/*      */     //   145: invokespecial <init> : (Lorg/jpsx/runtime/components/emulator/compiler/Stage1Generator;)V
/*      */     //   148: invokestatic sort : ([Ljava/lang/Object;Ljava/util/Comparator;)V
/*      */     //   151: aload_1
/*      */     //   152: getfield instructionCount : I
/*      */     //   155: istore #8
/*      */     //   157: iconst_0
/*      */     //   158: istore #9
/*      */     //   160: iload #9
/*      */     //   162: aload #6
/*      */     //   164: arraylength
/*      */     //   165: if_icmpge -> 221
/*      */     //   168: iload #8
/*      */     //   170: iload #5
/*      */     //   172: if_icmple -> 221
/*      */     //   175: aload_0
/*      */     //   176: aload #6
/*      */     //   178: iload #9
/*      */     //   180: aaload
/*      */     //   181: invokevirtual getSizeWithoutBranch : (Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;)I
/*      */     //   184: istore #10
/*      */     //   186: iload #10
/*      */     //   188: iconst_4
/*      */     //   189: if_icmpge -> 195
/*      */     //   192: goto -> 221
/*      */     //   195: iload #8
/*      */     //   197: iload #10
/*      */     //   199: isub
/*      */     //   200: istore #8
/*      */     //   202: aload #4
/*      */     //   204: aload #6
/*      */     //   206: iload #9
/*      */     //   208: aaload
/*      */     //   209: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   214: pop
/*      */     //   215: iinc #9, 1
/*      */     //   218: goto -> 160
/*      */     //   221: aload_0
/*      */     //   222: aload_3
/*      */     //   223: putfield contextMethodGen : Lorg/apache/bcel/generic/MethodGen;
/*      */     //   226: aload_1
/*      */     //   227: getfield root : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   230: astore #6
/*      */     //   232: aload #6
/*      */     //   234: ifnull -> 652
/*      */     //   237: aload_0
/*      */     //   238: aload #6
/*      */     //   240: putfield contextBlock : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   243: aload_0
/*      */     //   244: aload #6
/*      */     //   246: invokevirtual getInstructionList : (Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;)Lorg/apache/bcel/generic/InstructionList;
/*      */     //   249: astore #7
/*      */     //   251: aload_0
/*      */     //   252: aload #7
/*      */     //   254: invokevirtual emitBlockHeader : (Lorg/apache/bcel/generic/InstructionList;)V
/*      */     //   257: aload #6
/*      */     //   259: getfield type : I
/*      */     //   262: ifne -> 609
/*      */     //   265: aload #6
/*      */     //   267: getfield size : I
/*      */     //   270: istore #8
/*      */     //   272: aload #6
/*      */     //   274: getfield branchOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   277: ifnull -> 291
/*      */     //   280: aload #6
/*      */     //   282: getfield includesDelaySlot : Z
/*      */     //   285: ifeq -> 291
/*      */     //   288: iinc #8, -1
/*      */     //   291: aload #4
/*      */     //   293: aload #6
/*      */     //   295: invokeinterface contains : (Ljava/lang/Object;)Z
/*      */     //   300: ifeq -> 472
/*      */     //   303: new java/lang/StringBuilder
/*      */     //   306: dup
/*      */     //   307: invokespecial <init> : ()V
/*      */     //   310: ldc '_'
/*      */     //   312: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   315: aload #6
/*      */     //   317: getfield offset : I
/*      */     //   320: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*      */     //   323: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   326: astore #9
/*      */     //   328: new org/apache/bcel/generic/InstructionList
/*      */     //   331: dup
/*      */     //   332: invokespecial <init> : ()V
/*      */     //   335: astore #10
/*      */     //   337: new org/apache/bcel/generic/MethodGen
/*      */     //   340: dup
/*      */     //   341: bipush #9
/*      */     //   343: getstatic org/apache/bcel/generic/Type.VOID : Lorg/apache/bcel/generic/BasicType;
/*      */     //   346: iconst_0
/*      */     //   347: anewarray org/apache/bcel/generic/Type
/*      */     //   350: iconst_0
/*      */     //   351: anewarray java/lang/String
/*      */     //   354: aload #9
/*      */     //   356: aload_0
/*      */     //   357: getfield contextClassGen : Lorg/apache/bcel/generic/ClassGen;
/*      */     //   360: invokevirtual getClassName : ()Ljava/lang/String;
/*      */     //   363: aload #10
/*      */     //   365: aload_0
/*      */     //   366: getfield contextCP : Lorg/apache/bcel/generic/ConstantPoolGen;
/*      */     //   369: invokespecial <init> : (ILorg/apache/bcel/generic/Type;[Lorg/apache/bcel/generic/Type;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/apache/bcel/generic/InstructionList;Lorg/apache/bcel/generic/ConstantPoolGen;)V
/*      */     //   372: astore #11
/*      */     //   374: aload_0
/*      */     //   375: aload #6
/*      */     //   377: invokevirtual getSizeWithoutBranch : (Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;)I
/*      */     //   380: istore #12
/*      */     //   382: aload_0
/*      */     //   383: aload #11
/*      */     //   385: putfield contextMethodGen : Lorg/apache/bcel/generic/MethodGen;
/*      */     //   388: aload_0
/*      */     //   389: aload #10
/*      */     //   391: iconst_0
/*      */     //   392: iload #12
/*      */     //   394: invokevirtual emitCode : (Lorg/apache/bcel/generic/InstructionList;II)V
/*      */     //   397: aload #10
/*      */     //   399: new org/apache/bcel/generic/RETURN
/*      */     //   402: dup
/*      */     //   403: invokespecial <init> : ()V
/*      */     //   406: invokevirtual append : (Lorg/apache/bcel/generic/Instruction;)Lorg/apache/bcel/generic/InstructionHandle;
/*      */     //   409: pop
/*      */     //   410: aload_0
/*      */     //   411: aload_3
/*      */     //   412: putfield contextMethodGen : Lorg/apache/bcel/generic/MethodGen;
/*      */     //   415: aload_0
/*      */     //   416: aload #11
/*      */     //   418: invokevirtual addMethod : (Lorg/apache/bcel/generic/MethodGen;)V
/*      */     //   421: aload #7
/*      */     //   423: new org/apache/bcel/generic/INVOKESTATIC
/*      */     //   426: dup
/*      */     //   427: aload_0
/*      */     //   428: getfield contextCP : Lorg/apache/bcel/generic/ConstantPoolGen;
/*      */     //   431: aload_0
/*      */     //   432: getfield contextClassGen : Lorg/apache/bcel/generic/ClassGen;
/*      */     //   435: invokevirtual getClassName : ()Ljava/lang/String;
/*      */     //   438: aload #9
/*      */     //   440: ldc '()V'
/*      */     //   442: invokevirtual addMethodref : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
/*      */     //   445: invokespecial <init> : (I)V
/*      */     //   448: invokevirtual append : (Lorg/apache/bcel/generic/Instruction;)Lorg/apache/bcel/generic/InstructionHandle;
/*      */     //   451: pop
/*      */     //   452: iload #12
/*      */     //   454: iload #8
/*      */     //   456: if_icmpeq -> 469
/*      */     //   459: aload_0
/*      */     //   460: aload #7
/*      */     //   462: iload #12
/*      */     //   464: iload #8
/*      */     //   466: invokevirtual emitCode : (Lorg/apache/bcel/generic/InstructionList;II)V
/*      */     //   469: goto -> 481
/*      */     //   472: aload_0
/*      */     //   473: aload #7
/*      */     //   475: iconst_0
/*      */     //   476: iload #8
/*      */     //   478: invokevirtual emitCode : (Lorg/apache/bcel/generic/InstructionList;II)V
/*      */     //   481: aload #6
/*      */     //   483: getfield branchOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   486: ifnull -> 606
/*      */     //   489: aload #6
/*      */     //   491: getfield includesDelaySlot : Z
/*      */     //   494: ifne -> 606
/*      */     //   497: aload #6
/*      */     //   499: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   502: ifnull -> 606
/*      */     //   505: getstatic org/jpsx/runtime/components/emulator/compiler/Stage1Generator.$assertionsDisabled : Z
/*      */     //   508: ifne -> 531
/*      */     //   511: aload #6
/*      */     //   513: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   516: getfield size : I
/*      */     //   519: iconst_1
/*      */     //   520: if_icmpeq -> 531
/*      */     //   523: new java/lang/AssertionError
/*      */     //   526: dup
/*      */     //   527: invokespecial <init> : ()V
/*      */     //   530: athrow
/*      */     //   531: getstatic org/jpsx/runtime/components/emulator/compiler/Stage1Generator.$assertionsDisabled : Z
/*      */     //   534: ifne -> 556
/*      */     //   537: aload #6
/*      */     //   539: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   542: getfield branchOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   545: ifnull -> 556
/*      */     //   548: new java/lang/AssertionError
/*      */     //   551: dup
/*      */     //   552: invokespecial <init> : ()V
/*      */     //   555: athrow
/*      */     //   556: getstatic org/jpsx/runtime/components/emulator/compiler/Stage1Generator.$assertionsDisabled : Z
/*      */     //   559: ifne -> 581
/*      */     //   562: aload #6
/*      */     //   564: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   567: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   570: ifnonnull -> 581
/*      */     //   573: new java/lang/AssertionError
/*      */     //   576: dup
/*      */     //   577: invokespecial <init> : ()V
/*      */     //   580: athrow
/*      */     //   581: aload #7
/*      */     //   583: new org/apache/bcel/generic/GOTO
/*      */     //   586: dup
/*      */     //   587: aload_0
/*      */     //   588: aload #6
/*      */     //   590: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   593: getfield flowOut : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   596: invokevirtual getStartHandle : (Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;)Lorg/apache/bcel/generic/InstructionHandle;
/*      */     //   599: invokespecial <init> : (Lorg/apache/bcel/generic/InstructionHandle;)V
/*      */     //   602: invokevirtual append : (Lorg/apache/bcel/generic/BranchInstruction;)Lorg/apache/bcel/generic/BranchHandle;
/*      */     //   605: pop
/*      */     //   606: goto -> 636
/*      */     //   609: aload #6
/*      */     //   611: getfield type : I
/*      */     //   614: iconst_1
/*      */     //   615: if_icmpne -> 636
/*      */     //   618: aload_0
/*      */     //   619: aload #7
/*      */     //   621: aload_0
/*      */     //   622: getfield contextBase : I
/*      */     //   625: aload #6
/*      */     //   627: getfield offset : I
/*      */     //   630: iconst_2
/*      */     //   631: ishl
/*      */     //   632: iadd
/*      */     //   633: invokevirtual emitJump : (Lorg/apache/bcel/generic/InstructionList;I)V
/*      */     //   636: aload_0
/*      */     //   637: aload #7
/*      */     //   639: invokevirtual emitBlockFooter : (Lorg/apache/bcel/generic/InstructionList;)V
/*      */     //   642: aload #6
/*      */     //   644: getfield next : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   647: astore #6
/*      */     //   649: goto -> 232
/*      */     //   652: aload_1
/*      */     //   653: getfield root : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   656: astore #6
/*      */     //   658: aload #6
/*      */     //   660: ifnull -> 684
/*      */     //   663: aload_2
/*      */     //   664: aload_0
/*      */     //   665: aload #6
/*      */     //   667: invokevirtual getInstructionList : (Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;)Lorg/apache/bcel/generic/InstructionList;
/*      */     //   670: invokevirtual append : (Lorg/apache/bcel/generic/InstructionList;)Lorg/apache/bcel/generic/InstructionHandle;
/*      */     //   673: pop
/*      */     //   674: aload #6
/*      */     //   676: getfield next : Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   679: astore #6
/*      */     //   681: goto -> 658
/*      */     //   684: aload_2
/*      */     //   685: new org/apache/bcel/generic/ILOAD
/*      */     //   688: dup
/*      */     //   689: iconst_0
/*      */     //   690: invokespecial <init> : (I)V
/*      */     //   693: invokevirtual append : (Lorg/apache/bcel/generic/Instruction;)Lorg/apache/bcel/generic/InstructionHandle;
/*      */     //   696: pop
/*      */     //   697: aload_2
/*      */     //   698: new org/apache/bcel/generic/IRETURN
/*      */     //   701: dup
/*      */     //   702: invokespecial <init> : ()V
/*      */     //   705: invokevirtual append : (Lorg/apache/bcel/generic/Instruction;)Lorg/apache/bcel/generic/InstructionHandle;
/*      */     //   708: pop
/*      */     //   709: aload_0
/*      */     //   710: aload_3
/*      */     //   711: invokevirtual addMethod : (Lorg/apache/bcel/generic/MethodGen;)V
/*      */     //   714: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #256	-> 0
/*      */     //   #257	-> 8
/*      */     //   #264	-> 65
/*      */     //   #266	-> 70
/*      */     //   #268	-> 75
/*      */     //   #270	-> 80
/*      */     //   #271	-> 86
/*      */     //   #276	-> 95
/*      */     //   #277	-> 104
/*      */     //   #278	-> 107
/*      */     //   #279	-> 118
/*      */     //   #278	-> 128
/*      */     //   #281	-> 138
/*      */     //   #286	-> 151
/*      */     //   #287	-> 157
/*      */     //   #288	-> 175
/*      */     //   #289	-> 186
/*      */     //   #290	-> 192
/*      */     //   #293	-> 195
/*      */     //   #294	-> 202
/*      */     //   #287	-> 215
/*      */     //   #299	-> 221
/*      */     //   #300	-> 226
/*      */     //   #301	-> 237
/*      */     //   #306	-> 243
/*      */     //   #307	-> 251
/*      */     //   #308	-> 257
/*      */     //   #309	-> 265
/*      */     //   #310	-> 272
/*      */     //   #312	-> 288
/*      */     //   #314	-> 291
/*      */     //   #315	-> 303
/*      */     //   #316	-> 328
/*      */     //   #317	-> 337
/*      */     //   #319	-> 374
/*      */     //   #320	-> 382
/*      */     //   #321	-> 388
/*      */     //   #322	-> 397
/*      */     //   #323	-> 410
/*      */     //   #324	-> 415
/*      */     //   #325	-> 421
/*      */     //   #326	-> 452
/*      */     //   #328	-> 459
/*      */     //   #330	-> 469
/*      */     //   #332	-> 472
/*      */     //   #334	-> 481
/*      */     //   #338	-> 505
/*      */     //   #339	-> 531
/*      */     //   #340	-> 556
/*      */     //   #342	-> 581
/*      */     //   #344	-> 606
/*      */     //   #345	-> 618
/*      */     //   #347	-> 636
/*      */     //   #300	-> 642
/*      */     //   #352	-> 652
/*      */     //   #353	-> 663
/*      */     //   #352	-> 674
/*      */     //   #355	-> 684
/*      */     //   #356	-> 697
/*      */     //   #360	-> 709
/*      */     //   #361	-> 714
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   113	25	8	block	Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   186	29	10	size	I
/*      */     //   160	61	9	i	I
/*      */     //   104	117	6	sizedBlocks	[Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   107	114	7	index	I
/*      */     //   157	64	8	instructionCount	I
/*      */     //   328	141	9	methodname	Ljava/lang/String;
/*      */     //   337	132	10	innerMethodIL	Lorg/apache/bcel/generic/InstructionList;
/*      */     //   374	95	11	mgInner	Lorg/apache/bcel/generic/MethodGen;
/*      */     //   382	87	12	headSize	I
/*      */     //   272	334	8	size	I
/*      */     //   251	391	7	blockIL	Lorg/apache/bcel/generic/InstructionList;
/*      */     //   232	420	6	block	Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   658	26	6	block	Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;
/*      */     //   80	629	4	methodBlocks	Ljava/util/Set;
/*      */     //   86	623	5	maxCount	I
/*      */     //   0	715	0	this	Lorg/jpsx/runtime/components/emulator/compiler/Stage1Generator;
/*      */     //   0	715	1	flowInfo	Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$FlowInfo;
/*      */     //   8	707	2	methodIL	Lorg/apache/bcel/generic/InstructionList;
/*      */     //   65	650	3	mg	Lorg/apache/bcel/generic/MethodGen;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*  727 */     //   80	629	4	methodBlocks	Ljava/util/Set<Lorg/jpsx/runtime/components/emulator/compiler/FlowAnalyzer$BasicBlock;>; } protected InstructionList getInstructionList(FlowAnalyzer.BasicBlock block) { if (block.size != 0) return this.instructionLists[block.offset];  InstructionList rc = (InstructionList)this.extraInstructionLists.get(block); if (rc == null) { rc = new InstructionList(); this.extraInstructionLists.put(block, rc); }  return rc; } protected void disassemble(int index) { int address = this.contextBase + (index << 2); String prefix = ""; String prefix1 = ""; String suffix = ""; int ci = this.opCodes[index]; String dis = this.r3000.disassemble(address, ci); this.codeWriter.println("                                                                   " + prefix + " " + prefix1 + " " + MiscUtil.toHex(address, 8) + ": " + MiscUtil.toHex(ci, 8) + " " + dis + suffix); } protected void addMethod(MethodGen mg) { mg.setMaxLocals(8); mg.setMaxStack(); Method m = mg.getMethod(); if (m.getCode().getCode().length > 8000 && log.isDebugEnabled()) log.debug(this.contextClassGen.getClassName() + "." + m.getName() + " has " + m.getCode().getCode().length + " bytes bytcode");  this.contextClassGen.addMethod(m); if (MultiStageCompiler.Settings.printCode && shouldPrintCode()) { this.printCodeIL.append(mg.getInstructionList()); } else { mg.getInstructionList().dispose(); }  } protected void emitConstructor() { this.contextClassGen.addEmptyConstructor(1); } public JavaClass createJavaClass(CodeUnit unit) { return createJavaClass(unit, getClassName(getClassNamePrefix(unit), unit.getBase())); } public JavaClass createJavaClass(CodeUnit unit, String classname) { this.contextUnit = unit; this.contextBase = unit.getBase(); this.contextClassGen = new ClassGen(classname, "java.lang.Object", "<jpsx>", 33, null); this.contextCP = this.contextClassGen.getConstantPool(); emitConstructor(); long t0 = 0L; FlowAnalyzer.FlowInfo flowInfo = unit.getFlowInfo(this.analyzer); initBlockStructures(flowInfo); emitMethods(flowInfo); JavaClass jclass = this.contextClassGen.getJavaClass(); if (MultiStageCompiler.Settings.printCode && shouldPrintCode()) { ConstantPool cp = jclass.getConstantPool(); this.codeWriter.println(getClassNamePrefix(unit) + " unit at " + MiscUtil.toHex(this.contextBase, 8)); InstructionHandle h = this.printCodeIL.getStart(); InstructionHandle hLast = null; for (FlowAnalyzer.BasicBlock block = flowInfo.root; block != null; block = block.next) { this.codeWriter.println(" " + block); int size = block.size; if (block.branchOut != null && block.includesDelaySlot) size--;  for (int index = block.offset; index < block.offset + size; index++) { disassemble(index); if (0 != (this.flags[index] & true)) disassemble(index + 1);  InstructionHandle hEnd = this.endHandles[index]; assert hEnd != null; if (hEnd != hLast) while (h != null) { String bo = "" + h.getPosition(); while (bo.length() < 5) bo = " " + bo;  this.codeWriter.println(bo + " " + h.getInstruction().toString(cp)); hLast = h; h = h.getNext(); if (hLast == hEnd) break;  }   if (0 != (this.flags[index] & true)) index++;  }  }  this.printCodeIL.dispose(); }  if (MultiStageCompiler.Settings.saveClasses) try { jclass.dump(this.codeFilename + classname + ".class"); } catch (IOException ioe) {}  return jclass; } protected int getSizeWithoutBranch(FlowAnalyzer.BasicBlock b) { if (b.branchOut == null) return b.size;  return b.branchOffset - b.offset; } protected void emitCode(InstructionList il, int startOffset, int endOffset) { startOffset += this.contextBlock.offset; endOffset += this.contextBlock.offset; for (this.contextOffset = startOffset; this.contextOffset < endOffset; this.contextOffset++) { if (this.contextDelaySlotEmitted) { this.contextDelaySlotEmitted = false; } else { emitContextInstruction(il); }  }  } protected void emitDebugs(InstructionList il) { if (this.contextBase == -1077929760) { il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "compilerToInterpreter", "()V"))); il.append(new INVOKESTATIC(this.contextCP.addMethodref(R3000_CLASS, "debugPrintf", "()V"))); il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "interpreterToCompiler", "()V"))); }  } public void emitContextInstruction(InstructionList il) { this.contextAddress = this.contextBase + (this.contextOffset << 2); InstructionHandle endHandle = null; endHandle = il.getEnd(); if (this.contextBlock.branchOut != null && this.contextBlock.branchOffset == this.contextOffset) { assert 0 != (this.flags[this.contextOffset] & true) : this.contextBlock + " " + MiscUtil.toHex(this.contextAddress, 8); if (this.contextBlock.branchOut.offset <= this.contextBlock.offset) emitBreakoutCheck(il);  }  if (0 != (this.flags[this.contextOffset] & 0x70000)) { il.append(new PUSH(this.contextCP, this.contextAddress)); il.append(new PUTSTATIC(this.contextCP.addFieldref(R3000_CLASS, "reg_pc", "I"))); }  emitContextInstructionGuts(il); if (0 != (this.flags[this.contextOffset] & 0x20000)) il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "interpreterToCompiler", "()V")));  if (endHandle != il.getEnd()) { InstructionHandle first = (endHandle == null) ? il.getStart() : endHandle.getNext(); this.contextMethodGen.addLineNumber(first, this.contextOffset); }  if (MultiStageCompiler.Settings.printCode && shouldPrintCode()) { endHandle = il.getEnd(); if (endHandle == null) endHandle = il.append(new NOP());  this.endHandles[this.contextOffset] = endHandle; }  } protected void emitBreakoutCheck(InstructionList il) { if (!this.noInterruptCheck) { il.append(new GETSTATIC(this.contextCP.addFieldref(COMPILER_CLASS, "isInterrupted", "Z"))); IFEQ ieq = new IFEQ(null); il.append(ieq); il.append(new PUSH(this.contextCP, this.contextAddress)); il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "c_interrupted", "(I)V"))); ieq.setTarget(il.append(new NOP())); }  } protected void emitContextInstructionGuts(InstructionList il) { if (this.regsRead[this.contextOffset] == 1 && 0 != (this.flags[this.contextOffset] & 0x20) && this.instructions[this.contextOffset].simulate(this.opCodes[this.contextOffset], this.simulateRegs)) { for (int i = 1; i < 32; i++) { if ((this.regsWritten[this.contextOffset] & 1 << i) != 0) { il.append(new PUSH(this.contextCP, this.simulateRegs[i])); emitSetReg(il, i); }  }  } else { this.instructions[this.contextOffset].compile(this, this.contextAddress, this.opCodes[this.contextOffset], il); }  } public InstructionHandle getStartHandle(FlowAnalyzer.BasicBlock block) { InstructionHandle rc = getInstructionList(block).getStart(); if (rc == null) rc = getInstructionList(block).append(new NOP());  return rc; } public ConstantPoolGen getConstantPoolGen() { return this.contextCP; } protected void invokeStaticMethod(Method method) {} public void emitGetReg(InstructionList il, int reg) { il.append(new GETSTATIC(this.contextCP.addFieldref(COMPILER_CLASS, "reg_" + reg, "I"))); }
/*      */ 
/*      */   
/*      */   public void emitSetReg(InstructionList il, int reg) {
/*  731 */     assert reg != 0;
/*  732 */     il.append(new PUTSTATIC(this.contextCP.addFieldref(COMPILER_CLASS, "reg_" + reg, "I")));
/*      */   }
/*      */   
/*      */   public int getRegValue(int reg) {
/*  736 */     assert reg == 0;
/*  737 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*  741 */   public int getConstantRegs() { return 1; }
/*      */ 
/*      */ 
/*      */   
/*  745 */   public int getWritesReg() { return this.regsWritten[this.contextOffset]; }
/*      */ 
/*      */ 
/*      */   
/*  749 */   public int getReadsReg() { return this.regsRead[this.contextOffset]; }
/*      */ 
/*      */   
/*      */   public void emitJump(InstructionList il, int address) {
/*  753 */     il.append(new PUSH(this.contextCP, address));
/*  754 */     emitJump(il);
/*      */   }
/*      */ 
/*      */   
/*      */   public void emitJump(InstructionList il) {
/*  759 */     il.append(new ISTORE(2));
/*  760 */     InstructionHandle loop = il.append(new ILOAD(2));
/*  761 */     il.append(new ILOAD(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  767 */     IF_ICMPEQ icmpeq = new IF_ICMPEQ(null);
/*  768 */     il.append(icmpeq);
/*      */     
/*  770 */     il.append(new ILOAD(true));
/*  771 */     IFEQ ieq = new IFEQ(null);
/*  772 */     il.append(ieq);
/*      */     
/*  774 */     icmpeq.setTarget(il.append(new ILOAD(2)));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  779 */     il.append(new IRETURN());
/*  780 */     ieq.setTarget(il.append(new ILOAD(2)));
/*  781 */     il.append(new ILOAD(false));
/*  782 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "c_jump", "(II)I")));
/*  783 */     il.append(new ISTORE(2));
/*  784 */     il.append(new GOTO(loop));
/*      */   }
/*      */   
/*      */   public InstructionHandle getBranchTarget(int address) {
/*  788 */     assert this.contextBlock.branchOut != null;
/*      */     
/*  790 */     assert this.contextBase + (this.contextBlock.branchOut.offset << 2) == address : this.contextBlock + ": Expected branch target " + MiscUtil.toHex(this.contextBase + (this.contextBlock.branchOut.offset << 2), 8) + " != actual " + MiscUtil.toHex(address, 8);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  795 */     return getStartHandle(this.contextBlock.branchOut);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void emitCall(InstructionList il, int address, int retAddr) {
/*  812 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagClearPollCounters", "()V")));
/*      */     
/*  814 */     if (AddressSpace.Util.isBIOS(this.contextAddress) && !AddressSpace.Util.isBIOS(address)) {
/*      */ 
/*      */ 
/*      */       
/*  818 */       il.append(new PUSH(this.contextCP, address));
/*  819 */       il.append(new PUSH(this.contextCP, retAddr));
/*  820 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "c_call", "(II)V")));
/*      */     } else {
/*  822 */       il.append(new PUSH(this.contextCP, retAddr));
/*  823 */       il.append(new PUSH(this.contextCP, false));
/*  824 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(getClassName("_1", address), "s", "(IZ)I")));
/*  825 */       il.append(new POP());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void emitCall(InstructionList il, int retAddr) {
/*  841 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagClearPollCounters", "()V")));
/*  842 */     il.append(new PUSH(this.contextCP, retAddr));
/*  843 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "c_call", "(II)V")));
/*      */   }
/*      */   
/*      */   public void emitReadMem8(InstructionList il, int address, boolean signed) {
/*  847 */     this.rr.mem = null;
/*  848 */     this.addressSpace.resolve(address, this.rr);
/*  849 */     if (this.rr.tag == 1)
/*  850 */     { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  851 */       il.append(new PUSH(this.contextCP, this.rr.offset));
/*  852 */       il.append(new IALOAD()); }
/*  853 */     else if (this.rr.tag == 2)
/*  854 */     { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  855 */       il.append(new PUSH(this.contextCP, this.rr.offset));
/*  856 */       il.append(new IALOAD()); }
/*  857 */     else if (this.rr.tag == 8)
/*  858 */     { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  859 */       il.append(new PUSH(this.contextCP, this.rr.offset));
/*  860 */       il.append(new IALOAD()); }
/*  861 */     else { if (this.rr.tag == 4) {
/*  862 */         il.append(new PUSH(this.contextCP, address));
/*  863 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read8", "(I)I")));
/*      */         return;
/*      */       } 
/*  866 */       il.append(new PUSH(this.contextCP, address));
/*  867 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8", "(I)I"))); }
/*      */     
/*  869 */     if (signed) {
/*  870 */       switch (address & 0x3) {
/*      */         case 2:
/*  872 */           il.append(new PUSH(this.contextCP, 8));
/*  873 */           il.append(new ISHL());
/*      */           break;
/*      */         case 1:
/*  876 */           il.append(new PUSH(this.contextCP, 16));
/*  877 */           il.append(new ISHL());
/*      */           break;
/*      */         case 0:
/*  880 */           il.append(new PUSH(this.contextCP, 24));
/*  881 */           il.append(new ISHL());
/*      */           break;
/*      */       } 
/*  884 */       il.append(new PUSH(this.contextCP, 24));
/*  885 */       il.append(new ISHR());
/*      */     } else {
/*  887 */       switch (address & 0x3) {
/*      */         case 3:
/*  889 */           il.append(new PUSH(this.contextCP, 24));
/*  890 */           il.append(new ISHR());
/*      */           break;
/*      */         case 2:
/*  893 */           il.append(new PUSH(this.contextCP, 16));
/*  894 */           il.append(new ISHR());
/*      */           break;
/*      */         case 1:
/*  897 */           il.append(new PUSH(this.contextCP, 8));
/*  898 */           il.append(new ISHR());
/*      */           break;
/*      */       } 
/*  901 */       il.append(new PUSH(this.contextCP, 'ÿ'));
/*  902 */       il.append(new IAND());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitReadMem8(InstructionList il, int reg, int offset) {
/*  907 */     emitGetReg(il, reg);
/*  908 */     if (offset != 0) {
/*  909 */       il.append(new PUSH(this.contextCP, offset));
/*  910 */       il.append(new IADD());
/*      */     } 
/*  912 */     if (0 == (0x20000000 & 1 << reg)) {
/*  913 */       il.append(new ISTORE(2));
/*  914 */       il.append(new PUSH(this.contextCP, this.contextAddress));
/*  915 */       il.append(new ILOAD(2));
/*  916 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagAddressAccessRead8", "(II)V")));
/*  917 */       il.append(new ILOAD(2));
/*      */     } 
/*  919 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8", "(I)I")));
/*      */   }
/*      */   
/*      */   public void emitReadMem16(InstructionList il, int address, boolean signed) {
/*  923 */     this.rr.mem = null;
/*  924 */     if (0 == (address & true)) {
/*  925 */       this.addressSpace.resolve(address, this.rr);
/*  926 */       if (this.rr.tag == 1)
/*  927 */       { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  928 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  929 */         il.append(new IALOAD()); }
/*  930 */       else if (this.rr.tag == 2)
/*  931 */       { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  932 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  933 */         il.append(new IALOAD()); }
/*  934 */       else if (this.rr.tag == 8)
/*  935 */       { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  936 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  937 */         il.append(new IALOAD()); }
/*  938 */       else { if (this.rr.tag == 4) {
/*  939 */           il.append(new PUSH(this.contextCP, address));
/*  940 */           il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read16", "(I)I")));
/*      */           return;
/*      */         } 
/*  943 */         il.append(new PUSH(this.contextCP, address));
/*  944 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16", "(I)I"))); }
/*      */     
/*      */     } else {
/*  947 */       il.append(new PUSH(this.contextCP, address));
/*  948 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16", "(I)I")));
/*      */     } 
/*  950 */     if (signed) {
/*  951 */       if (0 == (address & 0x2)) {
/*  952 */         il.append(new PUSH(this.contextCP, 16));
/*  953 */         il.append(new ISHL());
/*      */       } 
/*  955 */       il.append(new PUSH(this.contextCP, 16));
/*  956 */       il.append(new ISHR());
/*      */     } else {
/*  958 */       if (0 != (address & 0x2)) {
/*  959 */         il.append(new PUSH(this.contextCP, 16));
/*  960 */         il.append(new ISHR());
/*      */       } 
/*  962 */       il.append(new PUSH(this.contextCP, '￿'));
/*  963 */       il.append(new IAND());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitReadMem16(InstructionList il, int reg, int offset) {
/*  968 */     emitGetReg(il, reg);
/*  969 */     if (offset != 0) {
/*  970 */       il.append(new PUSH(this.contextCP, offset));
/*  971 */       il.append(new IADD());
/*      */     } 
/*  973 */     if (0 == (0x20000000 & 1 << reg)) {
/*  974 */       il.append(new ISTORE(2));
/*  975 */       il.append(new PUSH(this.contextCP, this.contextAddress));
/*  976 */       il.append(new ILOAD(2));
/*  977 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagAddressAccessRead16", "(II)V")));
/*  978 */       il.append(new ILOAD(2));
/*      */     } 
/*  980 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16", "(I)I")));
/*      */   }
/*      */   
/*      */   public void emitReadMem32(InstructionList il, int address, boolean forceAlign) {
/*  984 */     this.rr.mem = null;
/*  985 */     if (forceAlign) {
/*  986 */       address &= 0xFFFFFFFC;
/*      */     }
/*  988 */     if (0 == (address & 0x3)) {
/*  989 */       this.addressSpace.resolve(address, this.rr);
/*  990 */       if (this.rr.tag == 1) {
/*  991 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  992 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  993 */         il.append(new IALOAD());
/*  994 */       } else if (this.rr.tag == 2) {
/*  995 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  996 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  997 */         il.append(new IALOAD());
/*  998 */       } else if (this.rr.tag == 8) {
/*  999 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/* 1000 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/* 1001 */         il.append(new IALOAD());
/* 1002 */       } else if (this.rr.tag == 4) {
/* 1003 */         il.append(new PUSH(this.contextCP, address));
/* 1004 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "_read32", "(I)I")));
/*      */       } else {
/* 1006 */         il.append(new PUSH(this.contextCP, address));
/* 1007 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read32", "(I)I")));
/*      */       } 
/*      */     } else {
/* 1010 */       il.append(new PUSH(this.contextCP, address));
/* 1011 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "read32", "(I)I")));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitReadMem32(InstructionList il, int reg, int offset, boolean forceAlign) {
/* 1016 */     emitGetReg(il, reg);
/* 1017 */     if (offset != 0) {
/* 1018 */       il.append(new PUSH(this.contextCP, offset));
/* 1019 */       il.append(new IADD());
/*      */     } 
/* 1021 */     if (forceAlign) {
/* 1022 */       il.append(new PUSH(this.contextCP, -4));
/* 1023 */       il.append(new IAND());
/*      */     } 
/* 1025 */     if (0 == (0x20000000 & 1 << reg)) {
/* 1026 */       il.append(new ISTORE(2));
/* 1027 */       il.append(new PUSH(this.contextCP, this.contextAddress));
/* 1028 */       il.append(new ILOAD(2));
/* 1029 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagAddressAccessRead32", "(II)V")));
/* 1030 */       il.append(new ILOAD(2));
/*      */     } 
/* 1032 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read32", "(I)I")));
/*      */   }
/*      */   
/*      */   public void emitWriteMem8(InstructionList il, int address, InstructionList il2) {
/* 1036 */     InstructionList il3 = new InstructionList();
/* 1037 */     emitReadMem32(il3, address, true);
/* 1038 */     switch (address & 0x3) {
/*      */       case 0:
/* 1040 */         il3.append(new PUSH(this.contextCP, -256));
/* 1041 */         il3.append(new IAND());
/* 1042 */         il3.append(il2);
/* 1043 */         il3.append(new PUSH(this.contextCP, 'ÿ'));
/* 1044 */         il3.append(new IAND());
/* 1045 */         il3.append(new IOR());
/*      */         break;
/*      */       case 1:
/* 1048 */         il3.append(new PUSH(this.contextCP, -65281));
/* 1049 */         il3.append(new IAND());
/* 1050 */         il3.append(il2);
/* 1051 */         il3.append(new PUSH(this.contextCP, 'ÿ'));
/* 1052 */         il3.append(new IAND());
/* 1053 */         il3.append(new PUSH(this.contextCP, 8));
/* 1054 */         il3.append(new ISHL());
/* 1055 */         il3.append(new IOR());
/*      */         break;
/*      */       case 2:
/* 1058 */         il3.append(new PUSH(this.contextCP, -16711681));
/* 1059 */         il3.append(new IAND());
/* 1060 */         il3.append(il2);
/* 1061 */         il3.append(new PUSH(this.contextCP, 'ÿ'));
/* 1062 */         il3.append(new IAND());
/* 1063 */         il3.append(new PUSH(this.contextCP, 16));
/* 1064 */         il3.append(new ISHL());
/* 1065 */         il3.append(new IOR());
/*      */         break;
/*      */       default:
/* 1068 */         il3.append(new PUSH(this.contextCP, 16777215));
/* 1069 */         il3.append(new IAND());
/* 1070 */         il3.append(il2);
/* 1071 */         il3.append(new PUSH(this.contextCP, 24));
/* 1072 */         il3.append(new ISHL());
/* 1073 */         il3.append(new IOR()); break;
/*      */     } 
/* 1075 */     emitWriteMem32(il, address, il3, true);
/* 1076 */     il3.dispose();
/*      */   }
/*      */   
/*      */   public void emitWriteMem8(InstructionList il, int reg, int offset) {
/* 1080 */     emitGetReg(il, reg);
/* 1081 */     if (offset != 0) {
/* 1082 */       il.append(new PUSH(this.contextCP, offset));
/* 1083 */       il.append(new IADD());
/*      */     } 
/* 1085 */     if (0 == (0x20000000 & 1 << reg)) {
/* 1086 */       il.append(new ISTORE(2));
/* 1087 */       il.append(new PUSH(this.contextCP, this.contextAddress));
/* 1088 */       il.append(new ILOAD(2));
/* 1089 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagAddressAccessWrite", "(II)V")));
/* 1090 */       il.append(new ILOAD(2));
/*      */     } 
/* 1092 */     il.append(new SWAP());
/* 1093 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write8", "(II)V")));
/*      */   }
/*      */   
/*      */   public void emitWriteMem16(InstructionList il, int address, InstructionList il2) {
/* 1097 */     if ((address & true) != 0) {
/* 1098 */       il.append(new PUSH(this.contextCP, address));
/* 1099 */       il.append(il2);
/* 1100 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16", "(II)V")));
/*      */     } else {
/* 1102 */       InstructionList il3 = new InstructionList();
/*      */       
/* 1104 */       emitReadMem32(il3, address, true);
/* 1105 */       switch (address & 0x3) {
/*      */         
/*      */         case 0:
/* 1108 */           il3.append(new PUSH(this.contextCP, -65536));
/* 1109 */           il3.append(new IAND());
/*      */           
/* 1111 */           il3.append(il2);
/*      */           
/* 1113 */           il3.append(new PUSH(this.contextCP, '￿'));
/*      */           
/* 1115 */           il3.append(new IAND());
/*      */           
/* 1117 */           il3.append(new IOR());
/*      */           break;
/*      */         
/*      */         default:
/* 1121 */           il3.append(new PUSH(this.contextCP, '￿'));
/* 1122 */           il3.append(new IAND());
/* 1123 */           il3.append(il2);
/* 1124 */           il3.append(new PUSH(this.contextCP, 16));
/* 1125 */           il3.append(new ISHL());
/* 1126 */           il3.append(new IOR()); break;
/*      */       } 
/* 1128 */       emitWriteMem32(il, address, il3, true);
/* 1129 */       il3.dispose();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitWriteMem16(InstructionList il, int reg, int offset) {
/* 1134 */     emitGetReg(il, reg);
/* 1135 */     if (offset != 0) {
/* 1136 */       il.append(new PUSH(this.contextCP, offset));
/* 1137 */       il.append(new IADD());
/*      */     } 
/* 1139 */     if (0 == (0x20000000 & 1 << reg)) {
/* 1140 */       il.append(new ISTORE(2));
/* 1141 */       il.append(new PUSH(this.contextCP, this.contextAddress));
/* 1142 */       il.append(new ILOAD(2));
/* 1143 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagAddressAccessWrite", "(II)V")));
/* 1144 */       il.append(new ILOAD(2));
/*      */     } 
/* 1146 */     il.append(new SWAP());
/* 1147 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16", "(II)V")));
/*      */   }
/*      */   
/*      */   public void emitWriteMem32(InstructionList il, int address, InstructionList il2, boolean forceAlign) {
/* 1151 */     this.rr.mem = null;
/* 1152 */     if (forceAlign) {
/* 1153 */       address &= 0xFFFFFFFC;
/*      */     }
/* 1155 */     if (0 == (address & 0x3))
/* 1156 */     { this.addressSpace.resolve(address, this.rr);
/* 1157 */       if (this.rr.tag == 1) {
/* 1158 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/* 1159 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/* 1160 */         il.append(il2);
/* 1161 */         il.append(new IASTORE());
/* 1162 */       } else if (this.rr.tag == 2) {
/* 1163 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/* 1164 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/* 1165 */         il.append(il2);
/* 1166 */         il.append(new IASTORE());
/* 1167 */       } else if (this.rr.tag != 8) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1173 */         if (this.rr.tag == 4) {
/* 1174 */           il.append(new PUSH(this.contextCP, address));
/* 1175 */           il.append(il2);
/* 1176 */           il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "write32", "(II)V")));
/*      */         } else {
/* 1178 */           il.append(new PUSH(this.contextCP, address));
/* 1179 */           il.append(il2);
/* 1180 */           il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write32", "(II)V")));
/*      */         } 
/*      */       }  }
/* 1183 */     else { il.append(new PUSH(this.contextCP, address));
/* 1184 */       il.append(il2);
/* 1185 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write32", "(II)V"))); }
/*      */   
/*      */   }
/*      */   
/*      */   public void emitWriteMem32(InstructionList il, int reg, int offset, InstructionList il2, boolean forceAlign) {
/* 1190 */     emitGetReg(il, reg);
/* 1191 */     if (offset != 0) {
/* 1192 */       il.append(new PUSH(this.contextCP, offset));
/* 1193 */       il.append(new IADD());
/*      */     } 
/* 1195 */     if (forceAlign) {
/* 1196 */       il.append(new PUSH(this.contextCP, -4));
/* 1197 */       il.append(new IAND());
/*      */     } 
/* 1199 */     if (0 == (0x20000000 & 1 << reg)) {
/* 1200 */       il.append(new ISTORE(2));
/* 1201 */       il.append(new PUSH(this.contextCP, this.contextAddress));
/* 1202 */       il.append(new ILOAD(2));
/* 1203 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_tagAddressAccessWrite", "(II)V")));
/* 1204 */       il.append(new ILOAD(2));
/*      */     } 
/* 1206 */     il.append(il2);
/* 1207 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write32", "(II)V")));
/*      */   }
/*      */   
/*      */   public void emitDelaySlot(InstructionList il) {
/* 1211 */     this.contextOffset++;
/* 1212 */     this.contextIsDelaySlot = true;
/* 1213 */     emitContextInstruction(il);
/* 1214 */     this.contextIsDelaySlot = false;
/* 1215 */     this.contextDelaySlotEmitted = true;
/* 1216 */     this.contextOffset--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTempLocal(int index) {
/* 1226 */     int rc = 3 + index;
/* 1227 */     if (rc >= 8)
/* 1228 */       throw new IllegalStateException("too many locals!"); 
/* 1229 */     return rc;
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\Stage1Generator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */