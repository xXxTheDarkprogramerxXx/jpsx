/*      */ package classes.runtime.org.jpsx.runtime.components.emulator.compiler;
/*      */ 
/*      */ import java.util.Stack;
/*      */ import org.apache.bcel.generic.FieldGen;
/*      */ import org.apache.bcel.generic.GETSTATIC;
/*      */ import org.apache.bcel.generic.IADD;
/*      */ import org.apache.bcel.generic.IALOAD;
/*      */ import org.apache.bcel.generic.IAND;
/*      */ import org.apache.bcel.generic.IASTORE;
/*      */ import org.apache.bcel.generic.IFEQ;
/*      */ import org.apache.bcel.generic.ILOAD;
/*      */ import org.apache.bcel.generic.INVOKESTATIC;
/*      */ import org.apache.bcel.generic.IOR;
/*      */ import org.apache.bcel.generic.IRETURN;
/*      */ import org.apache.bcel.generic.ISHL;
/*      */ import org.apache.bcel.generic.ISHR;
/*      */ import org.apache.bcel.generic.IXOR;
/*      */ import org.apache.bcel.generic.InstructionList;
/*      */ import org.apache.bcel.generic.NOP;
/*      */ import org.apache.bcel.generic.POP;
/*      */ import org.apache.bcel.generic.PUSH;
/*      */ import org.apache.bcel.generic.SWAP;
/*      */ import org.apache.bcel.generic.Type;
/*      */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*      */ import org.jpsx.api.components.core.cpu.R3000;
/*      */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*      */ import org.jpsx.runtime.components.emulator.compiler.CodeUnit;
/*      */ import org.jpsx.runtime.components.emulator.compiler.FlowAnalyzer;
/*      */ import org.jpsx.runtime.components.emulator.compiler.MultiStageCompiler;
/*      */ import org.jpsx.runtime.components.emulator.compiler.Stage1Generator;
/*      */ import org.jpsx.runtime.components.emulator.compiler.Stage2Generator;
/*      */ import org.jpsx.runtime.util.MiscUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Stage2Generator
/*      */   extends Stage1Generator
/*      */ {
/*   50 */   protected static String CLASS_NAME_PREFIX = "_2";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int READ_TAG_MASK = 63;
/*      */ 
/*      */ 
/*      */   
/*   59 */   private int getRegsOffset = -1;
/*   60 */   private int[] regsAtOffset = new int[32];
/*   61 */   private int CRAtOffset = 0;
/*   62 */   private final AddressSpace addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*   63 */   private final R3000 r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/*      */   
/*      */   public Stage2Generator(String codeFilename) {
/*   66 */     super(codeFilename);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  110 */     this.blockInfo = new BlockInfo[8000];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  115 */     this.simulated = new boolean[8000];
/*  116 */     this.dirtyBlocks = new Stack();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final boolean debugCR = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BlockInfo[] blockInfo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean[] simulated;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Stack dirtyBlocks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int visitCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] contextRegValues;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int contextCR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int contextUnwrittenRegs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getClassNamePrefix(CodeUnit unit) { return "_" + (2 + unit.stage2Version); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getNextClassNamePrefix(CodeUnit unit) { return "_" + (3 + unit.stage2Version); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void emitBreakoutCheck(InstructionList il) {
/*      */     writeBackRegs(il, -1);
/*      */     super.emitBreakoutCheck(il);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void emitMethodHeader(InstructionList il) {
/*      */     FieldGen fg = new FieldGen(9, Type.BOOLEAN, "replaced", this.contextCP);
/*      */     this.contextClassGen.addField(fg.getField());
/*      */     il.append(new GETSTATIC(this.contextCP.addFieldref(this.contextClassGen.getClassName(), "replaced", "Z")));
/*      */     IFEQ ifeq = new IFEQ(null);
/*      */     il.append(ifeq);
/*      */     il.append(new ILOAD(false));
/*      */     il.append(new ILOAD(true));
/*      */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(getClassName(getNextClassNamePrefix(this.contextUnit), this.contextBase), "s", "(IZ)I")));
/*      */     il.append(new IRETURN());
/*      */     ifeq.setTarget(il.append(new NOP()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBlockStructures(FlowAnalyzer.FlowInfo flowInfo) {
/*  287 */     super.initBlockStructures(flowInfo);
/*  288 */     for (FlowAnalyzer.BasicBlock block = flowInfo.root; block != null; block = block.next) {
/*  289 */       if (block.type == 0) {
/*  290 */         this.blockInfo[block.offset] = new BlockInfo(this, block);
/*      */       }
/*      */     } 
/*      */     
/*  294 */     this.visitCount = 0;
/*      */     
/*  296 */     assert this.dirtyBlocks.isEmpty();
/*  297 */     this.blockInfo[0].updateIncoming(1, new int[32]);
/*  298 */     if (MultiStageCompiler.Settings.printCode && shouldPrintCode()) {
/*  299 */       this.codeWriter.println("...");
/*      */     }
/*  301 */     while (!this.dirtyBlocks.isEmpty()) {
/*  302 */       ((BlockInfo)this.dirtyBlocks.pop()).visit();
/*      */     }
/*  304 */     if (MultiStageCompiler.Settings.printCode && shouldPrintCode()) {
/*      */       
/*  306 */       this.codeWriter.println("CR took " + this.visitCount + " iterations for " + flowInfo.blockCount + " blocks: " + (this.visitCount / flowInfo.blockCount));
/*  307 */       for (FlowAnalyzer.BasicBlock block = flowInfo.root; block != null; block = block.next) {
/*  308 */         if (block.type == 0) {
/*  309 */           BlockInfo info = this.blockInfo[block.offset];
/*  310 */           this.codeWriter.println("--- " + info);
/*  311 */           for (int offset = block.offset; offset < block.offset + block.size; offset++) {
/*  312 */             int address = flowInfo.base + offset * 4;
/*  313 */             int ci = this.addressSpace.internalRead32(address);
/*  314 */             String debug = this.simulated[offset] ? "* " : "  ";
/*  315 */             debug = debug + MiscUtil.toHex(address, 8) + " " + this.r3000.disassemble(address, ci);
/*  316 */             this.codeWriter.println(debug);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void emitBlockHeader(InstructionList il) {
/*  325 */     if (this.contextBlock.type == 0) {
/*  326 */       this.contextRegValues = (this.blockInfo[this.contextBlock.offset]).incomingRegValues;
/*  327 */       this.contextCR = (this.blockInfo[this.contextBlock.offset]).ICR;
/*  328 */       this.contextUnwrittenRegs = 0;
/*      */     } 
/*  330 */     super.emitBlockHeader(il);
/*      */   }
/*      */   
/*      */   protected void emitBlockFooter(InstructionList il) {
/*  334 */     writeBackRegs(il, -1);
/*  335 */     super.emitBlockFooter(il);
/*      */   }
/*      */   
/*      */   protected void emitContextInstructionGuts(InstructionList il) {
/*  339 */     if (0 != (this.flags[this.contextOffset] & 0x20000)) {
/*  340 */       writeBackRegs(il, -1);
/*      */     }
/*      */     
/*  343 */     if (this.simulated[this.contextOffset]) {
/*  344 */       this.instructions[this.contextOffset].simulate(this.opCodes[this.contextOffset], this.contextRegValues);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  352 */       this.contextUnwrittenRegs |= this.regsWritten[this.contextOffset];
/*  353 */       this.contextCR |= this.regsWritten[this.contextOffset];
/*      */     }
/*      */     else {
/*      */       
/*  357 */       writeBackRegs(il, this.regsRead[this.contextOffset]);
/*  358 */       if (this.contextUnwrittenRegs != 0)
/*      */       {
/*  360 */         this.addressSpace.orTag(this.contextAddress, (byte)64);
/*      */       }
/*  362 */       this.instructions[this.contextOffset].compile(this, this.contextAddress, this.opCodes[this.contextOffset], il);
/*  363 */       this.contextUnwrittenRegs &= (this.regsWritten[this.contextOffset] ^ 0xFFFFFFFF);
/*  364 */       this.contextCR &= (this.regsWritten[this.contextOffset] ^ 0xFFFFFFFF);
/*      */     } 
/*      */     
/*  367 */     if (this.contextIsDelaySlot) {
/*  368 */       writeBackRegs(il, -1);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void writeBackRegs(InstructionList il, int regs) {
/*  373 */     int toWrite = this.contextUnwrittenRegs & regs;
/*  374 */     if (toWrite != 0) {
/*  375 */       for (int reg = 1; reg < 32; reg++) {
/*  376 */         if (0 != (toWrite & 1 << reg)) {
/*  377 */           il.append(new PUSH(this.contextCP, this.contextRegValues[reg]));
/*  378 */           emitSetReg(il, reg);
/*      */         } 
/*      */       } 
/*  381 */       this.contextUnwrittenRegs &= (regs ^ 0xFFFFFFFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRegValue(int reg) {
/*  390 */     assert 0 != (this.contextCR & 1 << reg);
/*  391 */     return this.contextRegValues[reg];
/*      */   }
/*      */   
/*      */   public int getConstantRegs() {
/*  395 */     assert 1 == (this.contextCR & true);
/*  396 */     return this.contextCR;
/*      */   }
/*      */   
/*      */   protected void disassemble(int index) {
/*  400 */     int address = this.contextBase + (index << 2);
/*  401 */     String prefix = "";
/*  402 */     if (this.simulated[index]) {
/*  403 */       prefix = "X";
/*      */     } else {
/*  405 */       prefix = " ";
/*      */     } 
/*  407 */     if (this.regsRead[index] == (this.contextCR & this.regsRead[index])) {
/*  408 */       prefix = prefix + "C";
/*      */     } else {
/*  410 */       prefix = prefix + " ";
/*      */     } 
/*  412 */     if (0 != (this.addressSpace.getTag(address) & 0x40)) {
/*  413 */       prefix = prefix + ">";
/*      */     } else {
/*  415 */       prefix = prefix + " ";
/*      */     } 
/*  417 */     String prefix1 = "";
/*  418 */     String suffix = "";
/*  419 */     int ci = this.opCodes[index];
/*  420 */     String dis = this.r3000.disassemble(address, ci);
/*  421 */     this.codeWriter.println("                                                                   " + prefix + " " + prefix1 + " " + MiscUtil.toHex(address, 8) + ": " + MiscUtil.toHex(ci, 8) + " " + dis + suffix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void emitCall(InstructionList il, int address, int retAddr) {
/*  431 */     if (AddressSpace.Util.isBIOS(this.contextAddress) && !AddressSpace.Util.isBIOS(address)) {
/*      */       
/*  433 */       System.out.println("Emitting bios to ram call");
/*  434 */       il.append(new PUSH(this.contextCP, address));
/*  435 */       il.append(new PUSH(this.contextCP, retAddr));
/*  436 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "c_call", "(II)V")));
/*      */     } else {
/*  438 */       il.append(new PUSH(this.contextCP, retAddr));
/*  439 */       il.append(new PUSH(this.contextCP, false));
/*  440 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(getClassName("_1", address), "s", "(IZ)I")));
/*  441 */       il.append(new POP());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void emitCall(InstructionList il, int retAddr) {
/*  450 */     il.append(new PUSH(this.contextCP, retAddr));
/*  451 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(COMPILER_CLASS, "c_call", "(II)V")));
/*      */   }
/*      */   
/*      */   public void emitReadMem8(InstructionList il, int address, boolean signed) {
/*  455 */     int tag = this.addressSpace.getTag(this.contextAddress) & 0x3F;
/*      */     
/*  457 */     if (tag == 0 || 0 != (tag & 0x20)) {
/*  458 */       il.append(new PUSH(this.contextCP, address));
/*  459 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_checkPoll8", "(I)V")));
/*      */     } 
/*  461 */     this.rr.mem = null;
/*  462 */     this.addressSpace.resolve(address, this.rr);
/*  463 */     if (this.rr.tag == 1)
/*  464 */     { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  465 */       il.append(new PUSH(this.contextCP, this.rr.offset));
/*  466 */       il.append(new IALOAD()); }
/*  467 */     else if (this.rr.tag == 2)
/*  468 */     { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  469 */       il.append(new PUSH(this.contextCP, this.rr.offset));
/*  470 */       il.append(new IALOAD()); }
/*  471 */     else if (this.rr.tag == 8)
/*  472 */     { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  473 */       il.append(new PUSH(this.contextCP, this.rr.offset));
/*  474 */       il.append(new IALOAD()); }
/*  475 */     else { if (this.rr.tag == 4) {
/*  476 */         il.append(new PUSH(this.contextCP, address));
/*  477 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read8", "(I)I")));
/*      */         return;
/*      */       } 
/*  480 */       il.append(new PUSH(this.contextCP, address));
/*  481 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8", "(I)I"))); }
/*      */     
/*  483 */     if (signed) {
/*  484 */       switch (address & 0x3) {
/*      */         case 2:
/*  486 */           il.append(new PUSH(this.contextCP, 8));
/*  487 */           il.append(new ISHL());
/*      */           break;
/*      */         case 1:
/*  490 */           il.append(new PUSH(this.contextCP, 16));
/*  491 */           il.append(new ISHL());
/*      */           break;
/*      */         case 0:
/*  494 */           il.append(new PUSH(this.contextCP, 24));
/*  495 */           il.append(new ISHL());
/*      */           break;
/*      */       } 
/*  498 */       il.append(new PUSH(this.contextCP, 24));
/*  499 */       il.append(new ISHR());
/*      */     } else {
/*  501 */       switch (address & 0x3) {
/*      */         case 3:
/*  503 */           il.append(new PUSH(this.contextCP, 24));
/*  504 */           il.append(new ISHR());
/*      */           break;
/*      */         case 2:
/*  507 */           il.append(new PUSH(this.contextCP, 16));
/*  508 */           il.append(new ISHR());
/*      */           break;
/*      */         case 1:
/*  511 */           il.append(new PUSH(this.contextCP, 8));
/*  512 */           il.append(new ISHR());
/*      */           break;
/*      */       } 
/*  515 */       il.append(new PUSH(this.contextCP, 'ÿ'));
/*  516 */       il.append(new IAND());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitReadMem8(InstructionList il, int reg, int offset) {
/*  521 */     int tag = (0 != (1 << reg & 0x20000000)) ? 1 : (this.addressSpace.getTag(this.contextAddress) & 0x3F);
/*  522 */     if (0 == tag || 0 != (tag & 0x20)) {
/*  523 */       emitGetReg(il, reg);
/*  524 */       if (offset != 0) {
/*  525 */         il.append(new PUSH(this.contextCP, offset));
/*  526 */         il.append(new IADD());
/*      */       } 
/*  528 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_checkPoll8", "(I)V")));
/*  529 */       tag &= 0xFFFFFFDF;
/*      */     } 
/*  531 */     switch (tag) {
/*      */       case 1:
/*  533 */         emitGetReg(il, reg);
/*  534 */         if (offset != 0) {
/*  535 */           il.append(new PUSH(this.contextCP, offset));
/*  536 */           il.append(new IADD());
/*      */         } 
/*  538 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8Ram", "(I)I")));
/*      */         return;
/*      */       case 2:
/*  541 */         emitGetReg(il, reg);
/*  542 */         if (offset != 0) {
/*  543 */           il.append(new PUSH(this.contextCP, offset));
/*  544 */           il.append(new IADD());
/*      */         } 
/*  546 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8Scratch", "(I)I")));
/*      */         return;
/*      */       case 8:
/*  549 */         emitGetReg(il, reg);
/*  550 */         if (offset != 0) {
/*  551 */           il.append(new PUSH(this.contextCP, offset));
/*  552 */           il.append(new IADD());
/*      */         } 
/*  554 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8Bios", "(I)I")));
/*      */         return;
/*      */       case 4:
/*  557 */         emitGetReg(il, reg);
/*  558 */         if (offset != 0) {
/*  559 */           il.append(new PUSH(this.contextCP, offset));
/*  560 */           il.append(new IADD());
/*      */         } 
/*  562 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read8", "(I)I")));
/*      */         return;
/*      */     } 
/*  565 */     emitGetReg(il, reg);
/*  566 */     if (offset != 0) {
/*  567 */       il.append(new PUSH(this.contextCP, offset));
/*  568 */       il.append(new IADD());
/*      */     } 
/*  570 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read8", "(I)I")));
/*      */   }
/*      */ 
/*      */   
/*      */   public void emitReadMem16(InstructionList il, int address, boolean signed) {
/*  575 */     int tag = this.addressSpace.getTag(this.contextAddress) & 0x3F;
/*      */     
/*  577 */     if (tag == 0 || 0 != (tag & 0x20)) {
/*  578 */       il.append(new PUSH(this.contextCP, address));
/*  579 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_checkPoll16", "(I)V")));
/*      */     } 
/*  581 */     this.rr.mem = null;
/*  582 */     if (0 == (address & true)) {
/*  583 */       this.addressSpace.resolve(address, this.rr);
/*  584 */       if (this.rr.tag == 1)
/*  585 */       { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  586 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  587 */         il.append(new IALOAD()); }
/*  588 */       else if (this.rr.tag == 2)
/*  589 */       { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  590 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  591 */         il.append(new IALOAD()); }
/*  592 */       else if (this.rr.tag == 8)
/*  593 */       { il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  594 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  595 */         il.append(new IALOAD()); }
/*  596 */       else { if (this.rr.tag == 4) {
/*  597 */           il.append(new PUSH(this.contextCP, address));
/*  598 */           il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read16", "(I)I")));
/*      */           return;
/*      */         } 
/*  601 */         il.append(new PUSH(this.contextCP, address));
/*  602 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16", "(I)I"))); }
/*      */     
/*      */     } else {
/*  605 */       il.append(new PUSH(this.contextCP, address));
/*  606 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16", "(I)I")));
/*      */     } 
/*  608 */     if (signed) {
/*  609 */       if (0 == (address & 0x2)) {
/*  610 */         il.append(new PUSH(this.contextCP, 16));
/*  611 */         il.append(new ISHL());
/*      */       } 
/*  613 */       il.append(new PUSH(this.contextCP, 16));
/*  614 */       il.append(new ISHR());
/*      */     } else {
/*  616 */       if (0 != (address & 0x2)) {
/*  617 */         il.append(new PUSH(this.contextCP, 16));
/*  618 */         il.append(new ISHR());
/*      */       } 
/*  620 */       il.append(new PUSH(this.contextCP, '￿'));
/*  621 */       il.append(new IAND());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitReadMem16(InstructionList il, int reg, int offset) {
/*  626 */     int tag = (0 != (1 << reg & 0x20000000)) ? 1 : (this.addressSpace.getTag(this.contextAddress) & 0x3F);
/*  627 */     if (0 == tag || 0 != (tag & 0x20)) {
/*  628 */       emitGetReg(il, reg);
/*  629 */       if (offset != 0) {
/*  630 */         il.append(new PUSH(this.contextCP, offset));
/*  631 */         il.append(new IADD());
/*      */       } 
/*  633 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_checkPoll16", "(I)V")));
/*  634 */       tag &= 0xFFFFFFDF;
/*      */     } 
/*  636 */     switch (tag) {
/*      */       case 1:
/*  638 */         emitGetReg(il, reg);
/*  639 */         if (offset != 0) {
/*  640 */           il.append(new PUSH(this.contextCP, offset));
/*  641 */           il.append(new IADD());
/*      */         } 
/*  643 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16Ram", "(I)I")));
/*      */         return;
/*      */       case 2:
/*  646 */         emitGetReg(il, reg);
/*  647 */         if (offset != 0) {
/*  648 */           il.append(new PUSH(this.contextCP, offset));
/*  649 */           il.append(new IADD());
/*      */         } 
/*  651 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16Scratch", "(I)I")));
/*      */         return;
/*      */       case 8:
/*  654 */         emitGetReg(il, reg);
/*  655 */         if (offset != 0) {
/*  656 */           il.append(new PUSH(this.contextCP, offset));
/*  657 */           il.append(new IADD());
/*      */         } 
/*  659 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16Bios", "(I)I")));
/*      */         return;
/*      */       case 4:
/*  662 */         emitGetReg(il, reg);
/*  663 */         if (offset != 0) {
/*  664 */           il.append(new PUSH(this.contextCP, offset));
/*  665 */           il.append(new IADD());
/*      */         } 
/*  667 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read16", "(I)I")));
/*      */         return;
/*      */     } 
/*  670 */     emitGetReg(il, reg);
/*  671 */     if (offset != 0) {
/*  672 */       il.append(new PUSH(this.contextCP, offset));
/*  673 */       il.append(new IADD());
/*      */     } 
/*  675 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read16", "(I)I")));
/*      */   }
/*      */ 
/*      */   
/*      */   public void emitReadMem32(InstructionList il, int address, boolean forceAlign) {
/*  680 */     int tag = this.addressSpace.getTag(this.contextAddress) & 0x3F;
/*      */     
/*  682 */     if (tag == 0 || 0 != (tag & 0x20)) {
/*  683 */       il.append(new PUSH(this.contextCP, address));
/*  684 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_checkPoll32", "(I)V")));
/*      */     } 
/*  686 */     this.rr.mem = null;
/*  687 */     if (forceAlign) {
/*  688 */       address &= 0xFFFFFFFC;
/*      */     }
/*  690 */     if (0 == (address & 0x3)) {
/*  691 */       this.addressSpace.resolve(address, this.rr);
/*  692 */       if (this.rr.tag == 1) {
/*  693 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  694 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  695 */         il.append(new IALOAD());
/*  696 */       } else if (this.rr.tag == 2) {
/*  697 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  698 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  699 */         il.append(new IALOAD());
/*  700 */       } else if (this.rr.tag == 8) {
/*  701 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  702 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  703 */         il.append(new IALOAD());
/*  704 */       } else if (this.rr.tag == 4) {
/*  705 */         il.append(new PUSH(this.contextCP, address));
/*  706 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read32", "(I)I")));
/*      */       } else {
/*  708 */         il.append(new PUSH(this.contextCP, address));
/*  709 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read32", "(I)I")));
/*      */       } 
/*      */     } else {
/*  712 */       il.append(new PUSH(this.contextCP, address));
/*  713 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read32", "(I)I")));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitReadMem32(InstructionList il, int reg, int offset, boolean forceAlign) {
/*  718 */     int tag = (0 != (1 << reg & 0x20000000)) ? 1 : (this.addressSpace.getTag(this.contextAddress) & 0x3F);
/*  719 */     if (0 == tag || 0 != (tag & 0x20)) {
/*  720 */       emitGetReg(il, reg);
/*  721 */       if (offset != 0) {
/*  722 */         il.append(new PUSH(this.contextCP, offset));
/*  723 */         il.append(new IADD());
/*      */       } 
/*  725 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_checkPoll32", "(I)V")));
/*  726 */       tag &= 0xFFFFFFDF;
/*      */     } 
/*  728 */     switch (tag) {
/*      */       case 1:
/*  730 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  731 */         emitGetReg(il, reg);
/*  732 */         if (offset != 0) {
/*  733 */           il.append(new PUSH(this.contextCP, offset));
/*  734 */           il.append(new IADD());
/*      */         } 
/*  736 */         il.append(new PUSH(this.contextCP, 1610612735));
/*  737 */         il.append(new IAND());
/*  738 */         il.append(new PUSH(this.contextCP, 2));
/*  739 */         il.append(new ISHR());
/*  740 */         il.append(new IALOAD());
/*      */         return;
/*      */       case 2:
/*  743 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  744 */         emitGetReg(il, reg);
/*  745 */         if (offset != 0) {
/*  746 */           il.append(new PUSH(this.contextCP, offset));
/*  747 */           il.append(new IADD());
/*      */         } 
/*  749 */         il.append(new PUSH(this.contextCP, 528482304));
/*  750 */         il.append(new IXOR());
/*  751 */         il.append(new PUSH(this.contextCP, 2));
/*  752 */         il.append(new ISHR());
/*  753 */         il.append(new IALOAD());
/*      */         return;
/*      */       case 8:
/*  756 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  757 */         emitGetReg(il, reg);
/*  758 */         if (offset != 0) {
/*  759 */           il.append(new PUSH(this.contextCP, offset));
/*  760 */           il.append(new IADD());
/*      */         } 
/*  762 */         il.append(new PUSH(this.contextCP, -1077936128));
/*  763 */         il.append(new IXOR());
/*  764 */         il.append(new PUSH(this.contextCP, 2));
/*  765 */         il.append(new ISHR());
/*  766 */         il.append(new IALOAD());
/*      */         return;
/*      */       case 4:
/*  769 */         emitGetReg(il, reg);
/*  770 */         if (offset != 0) {
/*  771 */           il.append(new PUSH(this.contextCP, offset));
/*  772 */           il.append(new IADD());
/*      */         } 
/*  774 */         if (forceAlign) {
/*  775 */           il.append(new PUSH(this.contextCP, -4));
/*  776 */           il.append(new IAND());
/*      */         } 
/*  778 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "read32", "(I)I")));
/*      */         return;
/*      */     } 
/*  781 */     emitGetReg(il, reg);
/*  782 */     if (offset != 0) {
/*  783 */       il.append(new PUSH(this.contextCP, offset));
/*  784 */       il.append(new IADD());
/*      */     } 
/*  786 */     if (forceAlign) {
/*  787 */       il.append(new PUSH(this.contextCP, -4));
/*  788 */       il.append(new IAND());
/*      */     } 
/*  790 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_read32", "(I)I")));
/*      */   }
/*      */ 
/*      */   
/*      */   public void emitWriteMem8(InstructionList il, int address, InstructionList il2) {
/*  795 */     InstructionList il3 = new InstructionList();
/*  796 */     emitReadMem32(il3, address, true);
/*  797 */     switch (address & 0x3) {
/*      */       case 0:
/*  799 */         il3.append(new PUSH(this.contextCP, -256));
/*  800 */         il3.append(new IAND());
/*  801 */         il3.append(il2);
/*  802 */         il3.append(new PUSH(this.contextCP, 'ÿ'));
/*  803 */         il3.append(new IAND());
/*  804 */         il3.append(new IOR());
/*      */         break;
/*      */       case 1:
/*  807 */         il3.append(new PUSH(this.contextCP, -65281));
/*  808 */         il3.append(new IAND());
/*  809 */         il3.append(il2);
/*  810 */         il3.append(new PUSH(this.contextCP, 'ÿ'));
/*  811 */         il3.append(new IAND());
/*  812 */         il3.append(new PUSH(this.contextCP, 8));
/*  813 */         il3.append(new ISHL());
/*  814 */         il3.append(new IOR());
/*      */         break;
/*      */       case 2:
/*  817 */         il3.append(new PUSH(this.contextCP, -16711681));
/*  818 */         il3.append(new IAND());
/*  819 */         il3.append(il2);
/*  820 */         il3.append(new PUSH(this.contextCP, 'ÿ'));
/*  821 */         il3.append(new IAND());
/*  822 */         il3.append(new PUSH(this.contextCP, 16));
/*  823 */         il3.append(new ISHL());
/*  824 */         il3.append(new IOR());
/*      */         break;
/*      */       default:
/*  827 */         il3.append(new PUSH(this.contextCP, 16777215));
/*  828 */         il3.append(new IAND());
/*  829 */         il3.append(il2);
/*  830 */         il3.append(new PUSH(this.contextCP, 24));
/*  831 */         il3.append(new ISHL());
/*  832 */         il3.append(new IOR()); break;
/*      */     } 
/*  834 */     emitWriteMem32(il, address, il3, true);
/*  835 */     il3.dispose();
/*      */   }
/*      */   
/*      */   public void emitWriteMem8(InstructionList il, int reg, int offset) {
/*  839 */     int tag = (0 != (1 << reg & 0x20000000)) ? 1 : (this.addressSpace.getTag(this.contextAddress) & 0x3F);
/*  840 */     switch (tag) {
/*      */       case 1:
/*  842 */         emitGetReg(il, reg);
/*  843 */         if (offset != 0) {
/*  844 */           il.append(new PUSH(this.contextCP, offset));
/*  845 */           il.append(new IADD());
/*      */         } 
/*  847 */         il.append(new SWAP());
/*  848 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write8Ram", "(II)V")));
/*      */         return;
/*      */       case 2:
/*  851 */         emitGetReg(il, reg);
/*  852 */         if (offset != 0) {
/*  853 */           il.append(new PUSH(this.contextCP, offset));
/*  854 */           il.append(new IADD());
/*      */         } 
/*  856 */         il.append(new SWAP());
/*  857 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write8Scratch", "(II)V")));
/*      */         return;
/*      */       case 8:
/*  860 */         emitGetReg(il, reg);
/*  861 */         if (offset != 0) {
/*  862 */           il.append(new PUSH(this.contextCP, offset));
/*  863 */           il.append(new IADD());
/*      */         } 
/*  865 */         il.append(new SWAP());
/*  866 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write8Bios", "(II)V")));
/*      */         return;
/*      */       case 4:
/*  869 */         emitGetReg(il, reg);
/*  870 */         if (offset != 0) {
/*  871 */           il.append(new PUSH(this.contextCP, offset));
/*  872 */           il.append(new IADD());
/*      */         } 
/*  874 */         il.append(new SWAP());
/*  875 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "write8", "(II)V")));
/*      */         return;
/*      */     } 
/*  878 */     emitGetReg(il, reg);
/*  879 */     if (offset != 0) {
/*  880 */       il.append(new PUSH(this.contextCP, offset));
/*  881 */       il.append(new IADD());
/*      */     } 
/*  883 */     il.append(new SWAP());
/*  884 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write8", "(II)V")));
/*      */   }
/*      */ 
/*      */   
/*      */   public void emitWriteMem16(InstructionList il, int address, InstructionList il2) {
/*  889 */     if ((address & true) != 0) {
/*  890 */       il.append(new PUSH(this.contextCP, address));
/*  891 */       il.append(il2);
/*  892 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16", "(II)V")));
/*      */     } else {
/*  894 */       InstructionList il3 = new InstructionList();
/*      */       
/*  896 */       emitReadMem32(il3, address, true);
/*  897 */       switch (address & 0x3) {
/*      */         
/*      */         case 0:
/*  900 */           il3.append(new PUSH(this.contextCP, -65536));
/*  901 */           il3.append(new IAND());
/*      */           
/*  903 */           il3.append(il2);
/*      */           
/*  905 */           il3.append(new PUSH(this.contextCP, '￿'));
/*      */           
/*  907 */           il3.append(new IAND());
/*      */           
/*  909 */           il3.append(new IOR());
/*      */           break;
/*      */         
/*      */         default:
/*  913 */           il3.append(new PUSH(this.contextCP, '￿'));
/*  914 */           il3.append(new IAND());
/*  915 */           il3.append(il2);
/*  916 */           il3.append(new PUSH(this.contextCP, 16));
/*  917 */           il3.append(new ISHL());
/*  918 */           il3.append(new IOR()); break;
/*      */       } 
/*  920 */       emitWriteMem32(il, address, il3, true);
/*  921 */       il3.dispose();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitWriteMem16(InstructionList il, int reg, int offset) {
/*  926 */     int tag = (0 != (1 << reg & 0x20000000)) ? 1 : (this.addressSpace.getTag(this.contextAddress) & 0x3F);
/*  927 */     switch (tag) {
/*      */       case 1:
/*  929 */         emitGetReg(il, reg);
/*  930 */         if (offset != 0) {
/*  931 */           il.append(new PUSH(this.contextCP, offset));
/*  932 */           il.append(new IADD());
/*      */         } 
/*  934 */         il.append(new SWAP());
/*  935 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16Ram", "(II)V")));
/*      */         return;
/*      */       case 2:
/*  938 */         emitGetReg(il, reg);
/*  939 */         if (offset != 0) {
/*  940 */           il.append(new PUSH(this.contextCP, offset));
/*  941 */           il.append(new IADD());
/*      */         } 
/*  943 */         il.append(new SWAP());
/*  944 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16Scratch", "(II)V")));
/*      */         return;
/*      */       case 8:
/*  947 */         emitGetReg(il, reg);
/*  948 */         if (offset != 0) {
/*  949 */           il.append(new PUSH(this.contextCP, offset));
/*  950 */           il.append(new IADD());
/*      */         } 
/*  952 */         il.append(new SWAP());
/*  953 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16Bios", "(II)V")));
/*      */         return;
/*      */       case 4:
/*  956 */         emitGetReg(il, reg);
/*  957 */         if (offset != 0) {
/*  958 */           il.append(new PUSH(this.contextCP, offset));
/*  959 */           il.append(new IADD());
/*      */         } 
/*  961 */         il.append(new SWAP());
/*  962 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "write16", "(II)V")));
/*      */         return;
/*      */     } 
/*  965 */     emitGetReg(il, reg);
/*  966 */     if (offset != 0) {
/*  967 */       il.append(new PUSH(this.contextCP, offset));
/*  968 */       il.append(new IADD());
/*      */     } 
/*  970 */     il.append(new SWAP());
/*  971 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write16", "(II)V")));
/*      */   }
/*      */ 
/*      */   
/*      */   public void emitWriteMem32(InstructionList il, int address, InstructionList il2, boolean forceAlign) {
/*  976 */     this.rr.mem = null;
/*  977 */     if (forceAlign) {
/*  978 */       address &= 0xFFFFFFFC;
/*      */     }
/*  980 */     if (0 == (address & 0x3)) {
/*  981 */       this.addressSpace.resolve(address, this.rr);
/*  982 */       if (this.rr.tag == 1) {
/*  983 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/*  984 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  985 */         il.append(il2);
/*  986 */         il.append(new IASTORE());
/*  987 */       } else if (this.rr.tag == 2) {
/*  988 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/*  989 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  990 */         il.append(il2);
/*  991 */         il.append(new IASTORE());
/*  992 */       } else if (this.rr.tag == 8) {
/*      */         
/*  994 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/*  995 */         il.append(new PUSH(this.contextCP, this.rr.offset));
/*  996 */         il.append(il2);
/*  997 */         il.append(new IALOAD());
/*  998 */         il.append(new POP());
/*  999 */       } else if (this.rr.tag == 4) {
/* 1000 */         il.append(new PUSH(this.contextCP, address));
/* 1001 */         il.append(il2);
/* 1002 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "write32", "(II)V")));
/*      */       } else {
/* 1004 */         il.append(new PUSH(this.contextCP, address));
/* 1005 */         il.append(il2);
/* 1006 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write32", "(II)V")));
/*      */       } 
/*      */     } else {
/* 1009 */       il.append(new PUSH(this.contextCP, address));
/* 1010 */       il.append(il2);
/* 1011 */       il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write32", "(II)V")));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void emitWriteMem32(InstructionList il, int reg, int offset, InstructionList il2, boolean forceAlign) {
/* 1016 */     int tag = (0 != (1 << reg & 0x20000000)) ? 1 : (this.addressSpace.getTag(this.contextAddress) & 0x3F);
/* 1017 */     switch (tag) {
/*      */       case 1:
/* 1019 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "ramD", "[I")));
/* 1020 */         emitGetReg(il, reg);
/* 1021 */         if (offset != 0) {
/* 1022 */           il.append(new PUSH(this.contextCP, offset));
/* 1023 */           il.append(new IADD());
/*      */         } 
/* 1025 */         il.append(new PUSH(this.contextCP, 1610612735));
/* 1026 */         il.append(new IAND());
/* 1027 */         il.append(new PUSH(this.contextCP, 2));
/* 1028 */         il.append(new ISHR());
/* 1029 */         il.append(il2);
/* 1030 */         il.append(new IASTORE());
/*      */         return;
/*      */       case 2:
/* 1033 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "scratch", "[I")));
/* 1034 */         emitGetReg(il, reg);
/* 1035 */         if (offset != 0) {
/* 1036 */           il.append(new PUSH(this.contextCP, offset));
/* 1037 */           il.append(new IADD());
/*      */         } 
/* 1039 */         il.append(new PUSH(this.contextCP, 528482304));
/* 1040 */         il.append(new IXOR());
/* 1041 */         il.append(new PUSH(this.contextCP, 2));
/* 1042 */         il.append(new ISHR());
/* 1043 */         il.append(il2);
/* 1044 */         il.append(new IASTORE());
/*      */         return;
/*      */       case 8:
/* 1047 */         il.append(new GETSTATIC(this.contextCP.addFieldref(ADDRESS_SPACE_CLASS, "bios", "[I")));
/* 1048 */         emitGetReg(il, reg);
/* 1049 */         if (offset != 0) {
/* 1050 */           il.append(new PUSH(this.contextCP, offset));
/* 1051 */           il.append(new IADD());
/*      */         } 
/* 1053 */         il.append(new PUSH(this.contextCP, -1077936128));
/* 1054 */         il.append(new IXOR());
/* 1055 */         il.append(new PUSH(this.contextCP, 2));
/* 1056 */         il.append(new ISHR());
/* 1057 */         il.append(il2);
/*      */         
/* 1059 */         il.append(new IALOAD());
/* 1060 */         il.append(new POP());
/*      */         return;
/*      */       case 4:
/* 1063 */         emitGetReg(il, reg);
/* 1064 */         if (offset != 0) {
/* 1065 */           il.append(new PUSH(this.contextCP, offset));
/* 1066 */           il.append(new IADD());
/*      */         } 
/* 1068 */         if (forceAlign) {
/* 1069 */           il.append(new PUSH(this.contextCP, -4));
/* 1070 */           il.append(new IAND());
/*      */         } 
/* 1072 */         il.append(il2);
/* 1073 */         il.append(new INVOKESTATIC(this.contextCP.addMethodref(HW_CLASS, "write32", "(II)V")));
/*      */         return;
/*      */     } 
/* 1076 */     emitGetReg(il, reg);
/* 1077 */     if (offset != 0) {
/* 1078 */       il.append(new PUSH(this.contextCP, offset));
/* 1079 */       il.append(new IADD());
/*      */     } 
/* 1081 */     if (forceAlign) {
/* 1082 */       il.append(new PUSH(this.contextCP, -4));
/* 1083 */       il.append(new IAND());
/*      */     } 
/* 1085 */     il.append(il2);
/* 1086 */     il.append(new INVOKESTATIC(this.contextCP.addMethodref(ADDRESS_SPACE_CLASS, "_write32", "(II)V")));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1091 */   protected boolean shouldPrintCode() { return true; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fixupUnwrittenRegs(CodeUnit unit, int pc) {
/* 1096 */     FlowAnalyzer.FlowInfo flowInfo = unit.getFlowInfo(this.analyzer);
/* 1097 */     this.getRegsOffset = pc - unit.base >> 2;
/* 1098 */     initBlockStructures(flowInfo);
/* 1099 */     if (0 != (this.CRAtOffset & 0x2)) {
/* 1100 */       MultiStageCompiler.reg_1 = this.regsAtOffset[1];
/*      */     }
/* 1102 */     if (0 != (this.CRAtOffset & 0x4)) {
/* 1103 */       MultiStageCompiler.reg_2 = this.regsAtOffset[2];
/*      */     }
/* 1105 */     if (0 != (this.CRAtOffset & 0x8)) {
/* 1106 */       MultiStageCompiler.reg_3 = this.regsAtOffset[3];
/*      */     }
/* 1108 */     if (0 != (this.CRAtOffset & 0x10)) {
/* 1109 */       MultiStageCompiler.reg_4 = this.regsAtOffset[4];
/*      */     }
/* 1111 */     if (0 != (this.CRAtOffset & 0x20)) {
/* 1112 */       MultiStageCompiler.reg_5 = this.regsAtOffset[5];
/*      */     }
/* 1114 */     if (0 != (this.CRAtOffset & 0x40)) {
/* 1115 */       MultiStageCompiler.reg_6 = this.regsAtOffset[6];
/*      */     }
/* 1117 */     if (0 != (this.CRAtOffset & 0x80)) {
/* 1118 */       MultiStageCompiler.reg_7 = this.regsAtOffset[7];
/*      */     }
/* 1120 */     if (0 != (this.CRAtOffset & 0x100)) {
/* 1121 */       MultiStageCompiler.reg_8 = this.regsAtOffset[8];
/*      */     }
/* 1123 */     if (0 != (this.CRAtOffset & 0x200)) {
/* 1124 */       MultiStageCompiler.reg_9 = this.regsAtOffset[9];
/*      */     }
/* 1126 */     if (0 != (this.CRAtOffset & 0x400)) {
/* 1127 */       MultiStageCompiler.reg_10 = this.regsAtOffset[10];
/*      */     }
/* 1129 */     if (0 != (this.CRAtOffset & 0x800)) {
/* 1130 */       MultiStageCompiler.reg_11 = this.regsAtOffset[11];
/*      */     }
/* 1132 */     if (0 != (this.CRAtOffset & 0x1000)) {
/* 1133 */       MultiStageCompiler.reg_12 = this.regsAtOffset[12];
/*      */     }
/* 1135 */     if (0 != (this.CRAtOffset & 0x2000)) {
/* 1136 */       MultiStageCompiler.reg_12 = this.regsAtOffset[13];
/*      */     }
/* 1138 */     if (0 != (this.CRAtOffset & 0x4000)) {
/* 1139 */       MultiStageCompiler.reg_14 = this.regsAtOffset[14];
/*      */     }
/* 1141 */     if (0 != (this.CRAtOffset & 0x8000)) {
/* 1142 */       MultiStageCompiler.reg_15 = this.regsAtOffset[15];
/*      */     }
/* 1144 */     if (0 != (this.CRAtOffset & 0x10000)) {
/* 1145 */       MultiStageCompiler.reg_16 = this.regsAtOffset[16];
/*      */     }
/* 1147 */     if (0 != (this.CRAtOffset & 0x20000)) {
/* 1148 */       MultiStageCompiler.reg_17 = this.regsAtOffset[17];
/*      */     }
/* 1150 */     if (0 != (this.CRAtOffset & 0x40000)) {
/* 1151 */       MultiStageCompiler.reg_18 = this.regsAtOffset[18];
/*      */     }
/* 1153 */     if (0 != (this.CRAtOffset & 0x80000)) {
/* 1154 */       MultiStageCompiler.reg_19 = this.regsAtOffset[19];
/*      */     }
/* 1156 */     if (0 != (this.CRAtOffset & 0x100000)) {
/* 1157 */       MultiStageCompiler.reg_20 = this.regsAtOffset[20];
/*      */     }
/* 1159 */     if (0 != (this.CRAtOffset & 0x200000)) {
/* 1160 */       MultiStageCompiler.reg_21 = this.regsAtOffset[21];
/*      */     }
/* 1162 */     if (0 != (this.CRAtOffset & 0x400000)) {
/* 1163 */       MultiStageCompiler.reg_22 = this.regsAtOffset[22];
/*      */     }
/* 1165 */     if (0 != (this.CRAtOffset & 0x800000)) {
/* 1166 */       MultiStageCompiler.reg_23 = this.regsAtOffset[23];
/*      */     }
/* 1168 */     if (0 != (this.CRAtOffset & 0x1000000)) {
/* 1169 */       MultiStageCompiler.reg_24 = this.regsAtOffset[24];
/*      */     }
/* 1171 */     if (0 != (this.CRAtOffset & 0x2000000)) {
/* 1172 */       MultiStageCompiler.reg_25 = this.regsAtOffset[25];
/*      */     }
/* 1174 */     if (0 != (this.CRAtOffset & 0x4000000)) {
/* 1175 */       MultiStageCompiler.reg_26 = this.regsAtOffset[26];
/*      */     }
/* 1177 */     if (0 != (this.CRAtOffset & 0x8000000)) {
/* 1178 */       MultiStageCompiler.reg_27 = this.regsAtOffset[27];
/*      */     }
/* 1180 */     if (0 != (this.CRAtOffset & 0x10000000)) {
/* 1181 */       MultiStageCompiler.reg_28 = this.regsAtOffset[28];
/*      */     }
/* 1183 */     if (0 != (this.CRAtOffset & 0x20000000)) {
/* 1184 */       MultiStageCompiler.reg_29 = this.regsAtOffset[29];
/*      */     }
/* 1186 */     if (0 != (this.CRAtOffset & 0x40000000)) {
/* 1187 */       MultiStageCompiler.reg_30 = this.regsAtOffset[30];
/*      */     }
/* 1189 */     if (0 != (this.CRAtOffset & 0x80000000))
/* 1190 */       MultiStageCompiler.reg_31 = this.regsAtOffset[31]; 
/*      */   }
/*      */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\Stage2Generator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */