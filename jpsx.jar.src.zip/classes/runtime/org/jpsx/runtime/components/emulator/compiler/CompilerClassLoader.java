/*    */ package classes.runtime.org.jpsx.runtime.components.emulator.compiler;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jpsx.runtime.components.emulator.compiler.CompilerClassLoader;
/*    */ import org.jpsx.runtime.components.emulator.compiler.MultiStageCompiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompilerClassLoader
/*    */   extends ClassLoader
/*    */ {
/* 25 */   private static final Logger logger = Logger.getLogger("Compiler");
/*    */   private String description;
/*    */   
/*    */   public CompilerClassLoader(String description, ClassLoader parent) {
/* 29 */     super(parent);
/* 30 */     this.description = description;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class findClass(String name) throws ClassNotFoundException {
/* 35 */     Class c = findLoadedClass(name);
/* 36 */     if (c == null) {
/* 37 */       if (logger.isDebugEnabled()) {
/* 38 */         logger.debug(this.description + ": createClass " + name);
/*    */       }
/* 40 */       c = MultiStageCompiler.generateClass(name);
/*    */     } 
/* 42 */     return c;
/*    */   }
/*    */   
/*    */   public Class createClass(String name, byte[] classData) {
/* 46 */     if (logger.isDebugEnabled()) {
/* 47 */       logger.debug(this.description + ": createClass " + name);
/*    */     }
/* 49 */     return defineClass(name, classData, 0, classData.length, null);
/*    */   }
/*    */ 
/*    */   
/* 53 */   public String toString() { return this.description; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\CompilerClassLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */