/*    */ package classes.runtime.org.jpsx.runtime.components.emulator.disassemblers;
/*    */ 
/*    */ import org.jpsx.api.components.core.cpu.InstructionProvider;
/*    */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*    */ import org.jpsx.runtime.components.emulator.disassemblers.DisassemblerComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DisassemblerComponent
/*    */   extends JPSXComponent
/*    */   implements InstructionProvider
/*    */ {
/* 29 */   protected DisassemblerComponent(String description) { super(description); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 34 */     super.init();
/* 35 */     CoreComponentConnections.INSTRUCTION_PROVIDERS.add(this);
/*    */   }
/*    */ 
/*    */   
/* 39 */   protected static String padString(String s) { return padString(s, 8); }
/*    */ 
/*    */   
/*    */   protected static String padString(String val, int chars) {
/* 43 */     String rc = val + "                                                ";
/* 44 */     return rc.substring(0, chars);
/*    */   }
/*    */   
/*    */   public abstract void addInstructions(InstructionRegistrar paramInstructionRegistrar);
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\disassemblers\DisassemblerComponent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */