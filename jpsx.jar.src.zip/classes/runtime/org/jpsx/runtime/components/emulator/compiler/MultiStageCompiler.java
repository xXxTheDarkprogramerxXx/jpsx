/*     */ package classes.runtime.org.jpsx.runtime.components.emulator.compiler;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Map;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.ContinueExecutionException;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.cpu.CPUInstruction;
/*     */ import org.jpsx.api.components.core.cpu.NativeCompiler;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*     */ import org.jpsx.runtime.SingletonJPSXComponent;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.emulator.compiler.CodeUnit;
/*     */ import org.jpsx.runtime.components.emulator.compiler.CompilerClassLoader;
/*     */ import org.jpsx.runtime.components.emulator.compiler.Executable;
/*     */ import org.jpsx.runtime.components.emulator.compiler.MultiStageCompiler;
/*     */ import org.jpsx.runtime.components.emulator.compiler.Stage1Generator;
/*     */ import org.jpsx.runtime.components.emulator.compiler.Stage2Generator;
/*     */ import org.jpsx.runtime.util.MiscUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiStageCompiler
/*     */   extends SingletonJPSXComponent
/*     */   implements NativeCompiler
/*     */ {
/*     */   public static final String CATEGORY = "Compiler";
/*  50 */   private static final Logger log = Logger.getLogger("Compiler");
/*     */   
/*  52 */   protected static String CLASS = MultiStageCompiler.class.getName();
/*     */ 
/*     */   
/*     */   protected static Stage1Generator immediateGenerator;
/*     */   
/*     */   private static Stage2Generator fixupStage2Generator;
/*     */   
/*     */   protected static CompilerClassLoader ramLoader;
/*     */   
/*     */   protected static CompilerClassLoader romLoader;
/*     */   
/*  63 */   protected static int ramLoaderCount = 0;
/*     */   
/*  65 */   protected static Map<Integer, CodeUnit> romUnits = CollectionsFactory.newHashMap();
/*  66 */   protected static Map<Integer, CodeUnit> ramUnits = CollectionsFactory.newHashMap();
/*     */   
/*     */   protected static CompilationBroker broker;
/*     */   
/*     */   private static final int MAX_BREAKPOINTS = 64;
/*     */   
/*  72 */   private static int[] breakpoints = new int[64];
/*     */ 
/*     */   
/*     */   private static int breakpointLimit;
/*     */ 
/*     */   
/*     */   private static R3000 r3000;
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveConnections() {
/*  83 */     super.resolveConnections();
/*  84 */     addressSpace = (AddressSpace)CoreComponentConnections.ADDRESS_SPACE.resolve();
/*  85 */     r3000 = (R3000)CoreComponentConnections.R3000.resolve();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   protected static int contextDepth = 0;
/*     */ 
/*     */   
/*     */   protected static ExecutionContext context;
/*     */ 
/*     */   
/*     */   protected static final int MAX_CONTEXT_DEPTH = 4;
/*     */ 
/*     */   
/* 102 */   public MultiStageCompiler() { super("JPSX Multi-Stage Compiler"); }
/*     */ 
/*     */   
/*     */   protected static boolean ownRegs;
/*     */   
/*     */   private static AddressSpace addressSpace;
/*     */   
/*     */   public static int reg_1;
/*     */   
/*     */   public static int reg_2;
/*     */   
/*     */   public static int reg_3;
/* 114 */   protected static final ExecutionContext[] contexts = new ExecutionContext[4]; static  {
/* 115 */     for (i = 0; i < 4; i++) {
/* 116 */       contexts[i] = new ExecutionContext();
/*     */     }
/* 118 */     context = contexts[0];
/*     */   }
/*     */   public static int reg_4;
/*     */   public static int reg_5;
/*     */   public static int reg_6;
/*     */   public static int reg_7;
/*     */   public static int reg_8;
/*     */   public static int reg_9;
/*     */   public static int reg_10;
/*     */   public static int reg_11;
/*     */   public static int reg_12;
/*     */   public static int reg_13;
/*     */   public static int reg_14;
/*     */   public static int reg_15;
/*     */   public static int reg_16;
/*     */   public static int reg_17;
/*     */   public static int reg_18;
/*     */   public static int reg_19;
/*     */   public static int reg_20;
/*     */   public static int reg_21;
/*     */   public static int reg_22;
/*     */   public static int reg_23;
/*     */   public static int reg_24;
/*     */   public static int reg_25;
/*     */   public static int reg_26;
/*     */   public static int reg_27;
/*     */   public static int reg_28;
/*     */   public static int reg_29;
/*     */   public static int reg_30;
/*     */   public static int reg_31;
/*     */   public static boolean isInterrupted;
/*     */   public static final String INTERPRETER_TO_COMPILER_METHOD = "interpreterToCompiler";
/*     */   public static final String COMPILER_TO_INTERPRETER_METHOD = "compilerToInterpreter";
/*     */   public static final String INTERRUPTED_METHOD = "c_interrupted";
/*     */   public static final String SAEF_RETURN_METHOD = "c_safe_return";
/*     */   public static final String JUMP_METHOD = "c_jump";
/*     */   public static final String CALL_METHOD = "c_call";
/*     */   
/*     */   public void init() {
/* 157 */     super.init();
/* 158 */     Settings.setComponent(this);
/* 159 */     log.info("printCode " + Settings.printCode);
/* 160 */     log.info("Second stage enabled = " + Settings.enableSecondStage);
/* 161 */     CoreComponentConnections.NATIVE_COMPILER.set(this);
/*     */   }
/*     */   
/*     */   public void begin() {
/* 165 */     immediateGenerator = new Stage1Generator("c1gen.out");
/* 166 */     romLoader = new CompilerClassLoader("ROM classloader", MultiStageCompiler.class.getClassLoader());
/* 167 */     broker = new CompilationBroker();
/* 168 */     broker.begin();
/* 169 */     clearCache();
/*     */   }
/*     */   
/*     */   public boolean jumpAndLink(int address, int returnAddress) {
/* 173 */     int oldNativeDepth = (contexts[contextDepth]).nativeDepth;
/*     */     
/* 175 */     context = contexts[++contextDepth];
/* 176 */     assert !context.cacheStale;
/*     */     
/* 178 */     CodeUnit unit = getCodeUnit(address);
/*     */     
/* 180 */     Executable exec = unit.getExecutable();
/* 181 */     if (exec == null) {
/* 182 */       exec = makeExecutable(unit);
/* 183 */       if (exec == null) {
/* 184 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 188 */     context.nativeDepth = oldNativeDepth;
/* 189 */     if (!ownRegs) {
/* 190 */       interpreterToCompiler();
/*     */     }
/* 192 */     int retaddr = exec.e(returnAddress, false);
/* 193 */     compilerToInterpreter();
/* 194 */     assert retaddr == returnAddress;
/* 195 */     assert oldNativeDepth == context.nativeDepth : "nativeDepth mismatch for " + MiscUtil.toHex(address, 8) + " " + oldNativeDepth + "!=" + context.nativeDepth;
/* 196 */     contextDepth--;
/* 197 */     assert contextDepth >= 0;
/* 198 */     r3000.setPC(retaddr);
/* 199 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Executable makeExecutable(CodeUnit unit) {
/* 207 */     assert r3000.isExecutionThread();
/* 208 */     JavaClass jclass = unit.getStage1JavaClass(immediateGenerator, true);
/* 209 */     Class clazz = createClass(unit, jclass);
/* 210 */     unit.stage1ClassReady();
/*     */     try {
/* 212 */       Executable executable = (Executable)clazz.newInstance();
/* 213 */       Field field = clazz.getField("unit");
/* 214 */       field.set(executable, unit);
/* 215 */       broker.registerLinkedFunctions(unit, true);
/* 216 */       unit.setExecutable(executable);
/* 217 */       return executable;
/* 218 */     } catch (Throwable t) {
/* 219 */       t.printStackTrace();
/* 220 */       throw new IllegalStateException("could not create/cast to CodeUnit " + clazz.getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearCache() {
/* 225 */     synchronized (getClass()) {
/* 226 */       broker.reset();
/* 227 */       ramLoaderCount++;
/*     */       
/* 229 */       ramLoader = new CompilerClassLoader("RAM classloader " + ramLoaderCount, romLoader);
/* 230 */       synchronized (ramUnits) {
/* 231 */         ramUnits.clear();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 236 */       for (int i = 1; i < contextDepth; i++) {
/* 237 */         (contexts[i]).cacheStale = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exceptionInCompiler(Throwable t) {
/* 244 */     assert contextDepth >= 1;
/* 245 */     context = contexts[--contextDepth];
/* 246 */     compilerToInterpreter();
/* 247 */     if (t instanceof org.jpsx.api.components.core.ReturnFromExceptionException || t instanceof ContinueExecutionException)
/*     */     {
/* 249 */       return true;
/*     */     }
/*     */     
/* 252 */     StackTraceElement[] trace = t.getStackTrace();
/* 253 */     int pc = -1;
/* 254 */     int base = 0;
/* 255 */     String className = null;
/* 256 */     for (int i = 0; i < trace.length; i++) {
/* 257 */       className = trace[i].getClassName();
/* 258 */       if (className.length() == 10 && className.startsWith("_")) {
/* 259 */         String methodName = trace[i].getMethodName();
/* 260 */         if (methodName.equals("s") || methodName.startsWith("_")) {
/* 261 */           pc = base = MiscUtil.parseHex(className.substring(2));
/* 262 */           int ln = trace[i].getLineNumber();
/* 263 */           if (ln >= 0) {
/* 264 */             pc += ln * 4;
/*     */           }
/*     */           break;
/*     */         } 
/* 268 */         if (methodName.equals("e")) {
/* 269 */           System.out.println("Can't get PC!");
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 274 */     if (pc != -1) {
/* 275 */       r3000.setPC(pc);
/* 276 */       if (!className.startsWith("_1")) {
/* 277 */         if (0 != (addressSpace.getTag(pc) & 0x40)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 282 */           if (log.isDebugEnabled()) {
/* 283 */             log.debug("NEED REG WRITEBACK AT " + MiscUtil.toHex(pc, 8));
/*     */           }
/* 285 */           fixupUnwrittenCompilerRegs(base, pc);
/*     */         } 
/* 287 */         if (t.getClass() == ArrayIndexOutOfBoundsException.class) {
/*     */           
/* 289 */           int ci = addressSpace.internalRead32(pc);
/* 290 */           CPUInstruction inst = r3000.decodeInstruction(ci);
/* 291 */           if (0 != (inst.getFlags() & 0xE000)) {
/* 292 */             if (log.isDebugEnabled()) {
/* 293 */               log.debug("***** Mispredicted memory access at " + MiscUtil.toHex(pc, 8));
/*     */             }
/* 295 */             CodeUnit unit = getCodeUnit(base);
/* 296 */             assert unit.useStage2;
/* 297 */             unit.stage2ClassBroken();
/* 298 */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 303 */     return false;
/*     */   }
/*     */ 
/*     */   
/* 307 */   public void interrupt() { isInterrupted = true; }
/*     */ 
/*     */   
/*     */   public boolean addBreakpoint(int address) {
/* 311 */     boolean ok = false;
/* 312 */     for (int i = 0; i < breakpointLimit; i++) {
/* 313 */       if (breakpoints[i] == -1) {
/* 314 */         breakpoints[i] = address;
/* 315 */         ok = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 319 */     if (!ok) {
/* 320 */       if (breakpointLimit == 64) {
/* 321 */         return false;
/*     */       }
/* 323 */       breakpoints[breakpointLimit++] = address;
/*     */     } 
/* 325 */     Map<Integer, CodeUnit> map = AddressSpace.Util.isBIOS(address) ? romUnits : ramUnits;
/* 326 */     synchronized (map) {
/* 327 */       for (CodeUnit unit : map.values()) {
/* 328 */         unit.breakpointAdded(address);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 333 */     for (int i = 1; i < contextDepth; i++) {
/* 334 */       (contexts[i]).cacheStale = true;
/*     */     }
/* 336 */     return true;
/*     */   }
/*     */   
/*     */   public void removeBreakpoint(int address) {
/* 340 */     for (int i = 0; i < breakpointLimit; i++) {
/* 341 */       if (breakpoints[i] == address) {
/* 342 */         breakpoints[i] = -1;
/* 343 */         if (i == breakpointLimit - 1) {
/* 344 */           breakpointLimit--;
/*     */         }
/* 346 */         Map<Integer, CodeUnit> map = AddressSpace.Util.isBIOS(address) ? romUnits : ramUnits;
/* 347 */         synchronized (map) {
/* 348 */           for (CodeUnit unit : map.values()) {
/* 349 */             unit.breakpointRemoved(address);
/*     */           }
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/* 355 */     assert false : "attempt to remove non-existant breakpoint " + MiscUtil.toHex(address, 8);
/*     */   }
/*     */   
/*     */   public static void enumerateBreakpoints(CodeUnit unit) {
/* 359 */     for (int i = 0; i < breakpointLimit; i++) {
/* 360 */       if (breakpoints[i] != -1) {
/* 361 */         unit.breakpointAdded(breakpoints[i]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getReg(int index) {
/*     */     assert false;
/* 368 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReg(int index, int value) { assert false; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class generateClass(String classname) {
/* 380 */     if (classname.startsWith("_1")) {
/* 381 */       int address = MiscUtil.parseHex(classname.substring(2));
/* 382 */       CodeUnit unit = getCodeUnit(address);
/* 383 */       Executable executable = makeExecutable(unit);
/*     */       
/* 385 */       return executable.getClass();
/*     */     } 
/* 387 */     throw new IllegalStateException("findClass not called for C1: " + classname);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Class createClass(CodeUnit unit, JavaClass jclass) {
/* 392 */     if (AddressSpace.Util.isBIOS(unit.getBase())) {
/* 393 */       return romLoader.createClass(jclass.getClassName(), jclass.getBytes());
/*     */     }
/* 395 */     return ramLoader.createClass(jclass.getClassName(), jclass.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void returnToInterpreter(int address) {
/* 400 */     compilerToInterpreter();
/* 401 */     r3000.setPC(address);
/* 402 */     throw ContinueExecutionException.DONT_SKIP_CURRENT;
/*     */   }
/*     */ 
/*     */   
/* 406 */   public static void registerForStage2(CodeUnit unit) { broker.registerForStage2(unit); }
/*     */ 
/*     */   
/*     */   protected static CodeUnit getCodeUnit(int address) {
/* 410 */     Map<Integer, CodeUnit> map = AddressSpace.Util.isBIOS(address) ? romUnits : ramUnits;
/* 411 */     Integer key = Integer.valueOf(address);
/* 412 */     synchronized (map) {
/* 413 */       CodeUnit rc = (CodeUnit)map.get(key);
/* 414 */       if (rc == null) {
/* 415 */         rc = new CodeUnit(address);
/* 416 */         map.put(key, rc);
/*     */       } 
/* 418 */       return rc;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void interpreterToCompiler() {
/* 614 */     assert !ownRegs;
/* 615 */     reg_1 = Refs.interpreterRegs[1];
/* 616 */     reg_2 = Refs.interpreterRegs[2];
/* 617 */     reg_3 = Refs.interpreterRegs[3];
/* 618 */     reg_4 = Refs.interpreterRegs[4];
/* 619 */     reg_5 = Refs.interpreterRegs[5];
/* 620 */     reg_6 = Refs.interpreterRegs[6];
/* 621 */     reg_7 = Refs.interpreterRegs[7];
/* 622 */     reg_8 = Refs.interpreterRegs[8];
/* 623 */     reg_9 = Refs.interpreterRegs[9];
/* 624 */     reg_10 = Refs.interpreterRegs[10];
/* 625 */     reg_11 = Refs.interpreterRegs[11];
/* 626 */     reg_12 = Refs.interpreterRegs[12];
/* 627 */     reg_13 = Refs.interpreterRegs[13];
/* 628 */     reg_14 = Refs.interpreterRegs[14];
/* 629 */     reg_15 = Refs.interpreterRegs[15];
/* 630 */     reg_16 = Refs.interpreterRegs[16];
/* 631 */     reg_17 = Refs.interpreterRegs[17];
/* 632 */     reg_18 = Refs.interpreterRegs[18];
/* 633 */     reg_19 = Refs.interpreterRegs[19];
/* 634 */     reg_20 = Refs.interpreterRegs[20];
/* 635 */     reg_21 = Refs.interpreterRegs[21];
/* 636 */     reg_22 = Refs.interpreterRegs[22];
/* 637 */     reg_23 = Refs.interpreterRegs[23];
/* 638 */     reg_24 = Refs.interpreterRegs[24];
/* 639 */     reg_25 = Refs.interpreterRegs[25];
/* 640 */     reg_26 = Refs.interpreterRegs[26];
/* 641 */     reg_27 = Refs.interpreterRegs[27];
/* 642 */     reg_28 = Refs.interpreterRegs[28];
/* 643 */     reg_29 = Refs.interpreterRegs[29];
/* 644 */     reg_30 = Refs.interpreterRegs[30];
/* 645 */     reg_31 = Refs.interpreterRegs[31];
/*     */     
/* 647 */     ownRegs = true;
/*     */   }
/*     */ 
/*     */   
/* 651 */   public void restoreInterpreterState() { compilerToInterpreter(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void compilerToInterpreter() {
/* 657 */     if (ownRegs) {
/*     */       
/* 659 */       ownRegs = false;
/* 660 */       Refs.interpreterRegs[1] = reg_1;
/* 661 */       Refs.interpreterRegs[2] = reg_2;
/* 662 */       Refs.interpreterRegs[3] = reg_3;
/* 663 */       Refs.interpreterRegs[4] = reg_4;
/* 664 */       Refs.interpreterRegs[5] = reg_5;
/* 665 */       Refs.interpreterRegs[6] = reg_6;
/* 666 */       Refs.interpreterRegs[7] = reg_7;
/* 667 */       Refs.interpreterRegs[8] = reg_8;
/* 668 */       Refs.interpreterRegs[9] = reg_9;
/* 669 */       Refs.interpreterRegs[10] = reg_10;
/* 670 */       Refs.interpreterRegs[11] = reg_11;
/* 671 */       Refs.interpreterRegs[12] = reg_12;
/* 672 */       Refs.interpreterRegs[13] = reg_13;
/* 673 */       Refs.interpreterRegs[14] = reg_14;
/* 674 */       Refs.interpreterRegs[15] = reg_15;
/* 675 */       Refs.interpreterRegs[16] = reg_16;
/* 676 */       Refs.interpreterRegs[17] = reg_17;
/* 677 */       Refs.interpreterRegs[18] = reg_18;
/* 678 */       Refs.interpreterRegs[19] = reg_19;
/* 679 */       Refs.interpreterRegs[20] = reg_20;
/* 680 */       Refs.interpreterRegs[21] = reg_21;
/* 681 */       Refs.interpreterRegs[22] = reg_22;
/* 682 */       Refs.interpreterRegs[23] = reg_23;
/* 683 */       Refs.interpreterRegs[24] = reg_24;
/* 684 */       Refs.interpreterRegs[25] = reg_25;
/* 685 */       Refs.interpreterRegs[26] = reg_26;
/* 686 */       Refs.interpreterRegs[27] = reg_27;
/* 687 */       Refs.interpreterRegs[28] = reg_28;
/* 688 */       Refs.interpreterRegs[29] = reg_29;
/* 689 */       Refs.interpreterRegs[30] = reg_30;
/* 690 */       Refs.interpreterRegs[31] = reg_31;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void c_interrupted(int address) {
/* 701 */     r3000.setPC(address);
/* 702 */     isInterrupted = false;
/* 703 */     r3000.compilerInterrupted();
/*     */     
/* 705 */     if (context.cacheStale) {
/* 706 */       context.cacheStale = false;
/* 707 */       throw ContinueExecutionException.DONT_SKIP_CURRENT;
/*     */     } 
/* 709 */     if (!ownRegs) {
/* 710 */       interpreterToCompiler();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void c_safe_return() {
/* 721 */     if (!ownRegs) {
/* 722 */       interpreterToCompiler();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int c_jump(int address, int returnAddress) {
/* 729 */     context.nativeDepth++;
/* 730 */     if (context.nativeDepth > 100) {
/* 731 */       log.info("STACK OVERFLOW; COLLAPSING...");
/* 732 */       returnToInterpreter(address);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 737 */     CodeUnit unit = getCodeUnit(address);
/*     */     
/* 739 */     Executable exec = unit.getExecutable();
/* 740 */     if (exec == null) {
/* 741 */       exec = makeExecutable(unit);
/* 742 */       if (exec == null) {
/* 743 */         returnToInterpreter(address);
/*     */       }
/*     */     } 
/* 746 */     int rc = exec.e(returnAddress, true);
/* 747 */     context.nativeDepth--;
/* 748 */     return rc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void c_call(int address, int returnAddress) {
/* 754 */     context.nativeDepth++;
/* 755 */     if (context.nativeDepth > 100) {
/* 756 */       log.info("STACK OVERFLOW; COLLAPSING...");
/* 757 */       returnToInterpreter(address);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 762 */     CodeUnit unit = getCodeUnit(address);
/*     */     
/* 764 */     Executable exec = unit.getExecutable();
/* 765 */     if (exec == null) {
/* 766 */       exec = makeExecutable(unit);
/* 767 */       if (exec == null) {
/* 768 */         returnToInterpreter(address);
/*     */       }
/*     */     } 
/* 771 */     int rc = exec.e(returnAddress, false);
/* 772 */     assert rc == returnAddress : "call to unit should always return to the right spot";
/* 773 */     context.nativeDepth--;
/*     */   }
/*     */ 
/*     */   
/* 777 */   public static void traceEnterUnit(int address, int returnAddress, boolean jump) { System.out.println("Entering compiled unit " + MiscUtil.toHex(address, 8) + " retaddr=" + MiscUtil.toHex(returnAddress, 8) + " jump=" + jump + " r31=" + MiscUtil.toHex(reg_31, 8)); }
/*     */ 
/*     */ 
/*     */   
/* 781 */   public static void traceCheckJumpTarget(int target, int returnAddress) { System.out.println("Check jump target " + MiscUtil.toHex(target, 8) + ", retaddr " + MiscUtil.toHex(returnAddress, 8)); }
/*     */ 
/*     */ 
/*     */   
/* 785 */   public static void traceDirectCall(int address, int returnAddress) { System.out.println("Direct compiled call " + MiscUtil.toHex(address, 8) + " with retaddr " + MiscUtil.toHex(returnAddress, 8)); }
/*     */ 
/*     */ 
/*     */   
/* 789 */   public static void traceDirectJump(int address, int returnAddress) { System.out.println("Direct compiled jump " + MiscUtil.toHex(address, 8) + " with retaddr " + MiscUtil.toHex(returnAddress, 8)); }
/*     */ 
/*     */ 
/*     */   
/* 793 */   public static void traceLeaveUnit(int address) { System.out.println("Leaving compiled unit " + MiscUtil.toHex(address, 8)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fixupUnwrittenCompilerRegs(int base, int pc) {
/* 809 */     if (fixupStage2Generator == null) {
/* 810 */       fixupStage2Generator = new Stage2Generator("c2fixup.out");
/*     */     }
/* 812 */     CodeUnit unit = getCodeUnit(base);
/* 813 */     assert unit.useStage2;
/* 814 */     fixupStage2Generator.fixupUnwrittenRegs(unit, pc);
/*     */   }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\MultiStageCompiler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */