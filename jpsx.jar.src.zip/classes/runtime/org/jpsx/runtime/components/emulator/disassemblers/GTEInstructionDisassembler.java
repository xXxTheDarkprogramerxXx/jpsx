/*    */ package classes.runtime.org.jpsx.runtime.components.emulator.disassemblers;
/*    */ 
/*    */ import org.jpsx.api.components.core.cpu.InstructionRegistrar;
/*    */ import org.jpsx.runtime.components.emulator.disassemblers.DisassemblerComponent;
/*    */ import org.jpsx.runtime.components.emulator.disassemblers.GTEInstructionDisassembler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GTEInstructionDisassembler
/*    */   extends DisassemblerComponent
/*    */ {
/* 28 */   public GTEInstructionDisassembler() { super("JPSX Disassembler for GTE Instructions"); }
/*    */ 
/*    */   
/*    */   public void addInstructions(InstructionRegistrar registrar) {
/* 32 */     DisassemblerComponent.DIS dis = new DisassemblerComponent.DIS();
/* 33 */     registrar.setInstructionDisassembler("eret", dis);
/* 34 */     registrar.setInstructionDisassembler("mtc2", new DIS_MTC2(null));
/* 35 */     registrar.setInstructionDisassembler("mfc2", new DIS_MFC2(null));
/* 36 */     registrar.setInstructionDisassembler("ctc2", new DIS_CTC2(null));
/* 37 */     registrar.setInstructionDisassembler("cfc2", new DIS_CFC2(null));
/* 38 */     registrar.setInstructionDisassembler("lwc2", new DIS_LWC2(null));
/* 39 */     registrar.setInstructionDisassembler("swc2", new DIS_SWC2(null));
/* 40 */     registrar.setInstructionDisassembler("rtpt", dis);
/* 41 */     registrar.setInstructionDisassembler("rtps", dis);
/* 42 */     registrar.setInstructionDisassembler("mvmva", dis);
/* 43 */     registrar.setInstructionDisassembler("op", dis);
/* 44 */     registrar.setInstructionDisassembler("avsz3", dis);
/* 45 */     registrar.setInstructionDisassembler("avsz4", dis);
/* 46 */     registrar.setInstructionDisassembler("nclip", dis);
/* 47 */     registrar.setInstructionDisassembler("ncct", dis);
/* 48 */     registrar.setInstructionDisassembler("gpf", dis);
/* 49 */     registrar.setInstructionDisassembler("dcpl", dis);
/* 50 */     registrar.setInstructionDisassembler("dpcs", dis);
/* 51 */     registrar.setInstructionDisassembler("intpl", dis);
/* 52 */     registrar.setInstructionDisassembler("sqr", dis);
/* 53 */     registrar.setInstructionDisassembler("ncs", dis);
/* 54 */     registrar.setInstructionDisassembler("nct", dis);
/* 55 */     registrar.setInstructionDisassembler("ncds", dis);
/* 56 */     registrar.setInstructionDisassembler("ncdt", dis);
/* 57 */     registrar.setInstructionDisassembler("dpct", dis);
/* 58 */     registrar.setInstructionDisassembler("nccs", dis);
/* 59 */     registrar.setInstructionDisassembler("cdp", dis);
/* 60 */     registrar.setInstructionDisassembler("cc", dis);
/* 61 */     registrar.setInstructionDisassembler("gpl", dis);
/*    */   }
/*    */   
/*    */   private static final String[] gteNames = { 
/* 65 */       "vxy0", "vz0", "vxy1", "vz1", "vxy2", "vz2", "rgb", "otz", "ir0", "ir1", "ir2", "ir3", "sxy0", "sxy1", "sxy2", "sxyp", "szx", "sz0", "sz1", "sz2", "rgb0", "rgb1", "rgb2", "res1", "mac0", "mac1", "mac2", "mac3", "irgb", "orgb", "lzcs", "lzcr", "r11r12", "r13r21", "r22r23", "r31r32", "r33", "trx", "try", "trz", "l11l12", "l13l21", "l22l23", "l31l32", "l33", "rbk", "gbk", "bbk", "lr1lr2", "lr3lg1", "lg2lg3", "lb1lb2", "lb3", "rfc", "gfc", "bfc", "ofx", "ofy", "h", "dqa", "dqb", "zsf3", "zsf4", "flag" };
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\disassemblers\GTEInstructionDisassembler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */