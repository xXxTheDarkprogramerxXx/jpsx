/*     */ package classes.runtime.org.jpsx.runtime.components.emulator.compiler;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.components.core.ContinueExecutionException;
/*     */ import org.jpsx.api.components.core.addressspace.AddressSpace;
/*     */ import org.jpsx.api.components.core.cpu.R3000;
/*     */ import org.jpsx.runtime.components.core.CoreComponentConnections;
/*     */ import org.jpsx.runtime.components.emulator.compiler.CodeUnit;
/*     */ import org.jpsx.runtime.components.emulator.compiler.Executable;
/*     */ import org.jpsx.runtime.components.emulator.compiler.FlowAnalyzer;
/*     */ import org.jpsx.runtime.components.emulator.compiler.MultiStageCompiler;
/*     */ import org.jpsx.runtime.components.emulator.compiler.Stage1Generator;
/*     */ import org.jpsx.runtime.components.emulator.compiler.Stage2Generator;
/*     */ import org.jpsx.runtime.util.MiscUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeUnit
/*     */ {
/*     */   Logger log;
/*     */   public int count;
/*     */   private Class stage2Class;
/*     */   private int state;
/*     */   protected final int base;
/*     */   private int end;
/*     */   private final boolean rom;
/*     */   private Executable executable;
/*     */   protected boolean linksFollowed;
/*     */   private boolean stage1Ready;
/*     */   
/*     */   public CodeUnit(int base) {
/*  38 */     this.log = Logger.getLogger("CodeUnit");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.count = 30;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.flowInfoRef = new SoftReference(null);
/*  83 */     this.stage1JavaClassRef = new SoftReference(null);
/*     */ 
/*     */     
/*  86 */     this.base = base;
/*  87 */     this.rom = AddressSpace.Util.isBIOS(base);
/*     */   }
/*     */   protected int stage2Version; private int preBreakpointState; private boolean preBreakpointUseStage2; private int breakpointCount; private static final int STATE_STAGE1 = 0; private static final int STATE_WAITING_FOR_STAGE2 = 1; private static final int STATE_STAGE2 = 2; private static final int STATE_BREAKPOINT = 3; private SoftReference flowInfoRef; private SoftReference stage1JavaClassRef;
/*     */   
/*  91 */   public final int getBase() { return this.base; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public final boolean isROM() { return this.rom; }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public Executable getExecutable() { return this.executable; }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void setExecutable(Executable executable) { this.executable = executable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowAnalyzer.FlowInfo getFlowInfo(FlowAnalyzer flowAnalyzer) {
/* 111 */     FlowAnalyzer.FlowInfo rc = (FlowAnalyzer.FlowInfo)this.flowInfoRef.get();
/* 112 */     if (rc == null) {
/* 113 */       rc = flowAnalyzer.buildFlowGraph(this.base);
/* 114 */       this.end = rc.end;
/* 115 */       this.flowInfoRef = new SoftReference(rc);
/*     */     } 
/* 117 */     return rc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaClass getStage1JavaClass(Stage1Generator generator, boolean executionThread) {
/* 132 */     if (!executionThread && this.stage1Ready) {
/* 133 */       return null;
/*     */     }
/* 135 */     JavaClass rc = (JavaClass)this.stage1JavaClassRef.get();
/*     */     
/* 137 */     if (rc == null) {
/* 138 */       rc = generator.createJavaClass(this);
/* 139 */       if (!executionThread) {
/* 140 */         this.stage1JavaClassRef = new SoftReference(rc);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 145 */     return rc;
/*     */   }
/*     */   
/*     */   public void stage1ClassReady() {
/* 149 */     this.stage1Ready = true;
/*     */     
/* 151 */     this.stage1JavaClassRef.clear();
/*     */     
/* 153 */     MultiStageCompiler.enumerateBreakpoints(this);
/*     */   }
/*     */ 
/*     */   
/* 157 */   public JavaClass getStage2JavaClass(Stage2Generator generator) { return generator.createJavaClass(this); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stage2ClassReady(Class stage2Class) {
/* 162 */     this.stage2Class = stage2Class;
/* 163 */     this.count = Integer.MAX_VALUE;
/* 164 */     this.state = 2;
/* 165 */     this.stage2Version++;
/* 166 */     this.useStage2 = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stage2ClassBroken() {
/* 171 */     assert this.state != 3;
/*     */     
/* 173 */     if (this.stage2Version < 5) {
/*     */       try {
/* 175 */         this.stage2Class.getField("replaced").setBoolean(null, true);
/* 176 */       } catch (Throwable ignore) {
/*     */         assert false;
/*     */       } 
/* 179 */       if (this.log.isDebugEnabled()) {
/* 180 */         this.log.debug("Re-write " + MiscUtil.toHex(this.base, 8) + " version " + (this.stage2Version + 1));
/*     */       }
/* 182 */       this.count = 30;
/* 183 */       this.state = 0;
/*     */     } else {
/*     */       
/* 186 */       if (this.log.isDebugEnabled()) {
/* 187 */         this.log.debug("Too many rewrites for " + MiscUtil.toHex(this.base, 8));
/*     */       }
/* 189 */       this.state = 1;
/*     */     } 
/* 191 */     this.useStage2 = false;
/*     */   }
/*     */   
/*     */   public void breakpointAdded(int address) {
/* 195 */     if (this.stage1Ready) {
/* 196 */       assert this.end != 0;
/* 197 */       if (address >= this.base && address < this.end) {
/* 198 */         this.breakpointCount++;
/* 199 */         if (this.breakpointCount == 1) {
/* 200 */           this.log.info("HAVE BREAKPOINT IN " + MiscUtil.toHex(this.base, 8));
/* 201 */           this.preBreakpointState = this.state;
/* 202 */           this.preBreakpointUseStage2 = this.useStage2;
/* 203 */           this.state = 3;
/* 204 */           this.count = 0;
/* 205 */           this.useStage2 = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void breakpointRemoved(int address) {
/* 212 */     if (this.stage1Ready) {
/* 213 */       assert this.end != 0;
/* 214 */       if (address >= this.base && address < this.end) {
/* 215 */         this.breakpointCount--;
/* 216 */         if (this.breakpointCount == 0) {
/* 217 */           this.count = 30;
/* 218 */           this.state = this.preBreakpointState;
/* 219 */           this.useStage2 = this.preBreakpointUseStage2;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void countComplete() {
/* 226 */     switch (this.state) {
/*     */       case 0:
/* 228 */         this.state = 1;
/* 229 */         this.count = Integer.MAX_VALUE;
/* 230 */         if (MultiStageCompiler.Settings.enableSecondStage) {
/* 231 */           MultiStageCompiler.registerForStage2(this);
/*     */         }
/*     */         return;
/*     */       
/*     */       case 3:
/* 236 */         ((R3000)CoreComponentConnections.R3000.resolve()).setPC(this.base);
/* 237 */         this.count = 0;
/*     */         
/* 239 */         throw ContinueExecutionException.DONT_SKIP_CURRENT;
/*     */     } 
/* 241 */     this.count = Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public boolean stage1Ready() { return this.stage1Ready; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\components\emulator\compiler\CodeUnit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */