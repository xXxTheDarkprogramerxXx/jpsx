/*    */ package classes.runtime.org.jpsx.runtime;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JPSXComponent
/*    */ {
/*    */   private Properties properties;
/*    */   private String description;
/*    */   
/*    */   protected JPSXComponent(String description) {
/* 23 */     this.properties = new Properties();
/*    */ 
/*    */ 
/*    */     
/* 27 */     this.description = description;
/*    */   }
/*    */ 
/*    */   
/* 31 */   public String getDescription() { return this.description; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resolveConnections() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void begin() {}
/*    */ 
/*    */ 
/*    */   
/* 49 */   public void setProperty(String name, String value) { this.properties.put(name, value); }
/*    */ 
/*    */ 
/*    */   
/* 53 */   public String getProperty(String name, String defaultValue) { return this.properties.getProperty(name, defaultValue); }
/*    */ 
/*    */   
/*    */   public boolean getBooleanProperty(String name, boolean defaultValue) {
/* 57 */     String val = this.properties.getProperty(name, String.valueOf(defaultValue));
/* 58 */     return Boolean.valueOf(val).booleanValue();
/*    */   }
/*    */   
/*    */   public int getIntProperty(String name, int defaultValue) {
/* 62 */     int rc = defaultValue;
/* 63 */     String val = this.properties.getProperty(name);
/* 64 */     if (val != null) {
/*    */       try {
/* 66 */         rc = Integer.parseInt(val);
/* 67 */       } catch (NumberFormatException e) {}
/*    */     }
/*    */ 
/*    */     
/* 71 */     return rc;
/*    */   }
/*    */ 
/*    */   
/* 75 */   protected Properties getProperties() { return this.properties; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\JPSXComponent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */