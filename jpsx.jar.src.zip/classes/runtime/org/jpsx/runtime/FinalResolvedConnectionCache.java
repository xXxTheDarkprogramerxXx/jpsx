/*    */ package classes.runtime.org.jpsx.runtime;
/*    */ 
/*    */ import org.jpsx.bootstrap.connection.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinalResolvedConnectionCache
/*    */ {
/* 25 */   public static <I> I resolve(Connection<I> connection) { return (I)connection.resolve(); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\FinalResolvedConnectionCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */