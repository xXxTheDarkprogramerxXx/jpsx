/*    */ package classes.runtime.org.jpsx.runtime;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.jpsx.api.InvalidConfigurationException;
/*    */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*    */ import org.jpsx.runtime.JPSXComponent;
/*    */ import org.jpsx.runtime.SingletonJPSXComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SingletonJPSXComponent
/*    */   extends JPSXComponent
/*    */ {
/* 31 */   private static Set<String> usedClasses = CollectionsFactory.newHashSet();
/*    */ 
/*    */   
/* 34 */   protected SingletonJPSXComponent(String description) { super(description); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 39 */     super.init();
/* 40 */     if (!usedClasses.add(getClass().getName()))
/* 41 */       throw new InvalidConfigurationException("Attempted to create multiple instances of " + getClass().getName()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\SingletonJPSXComponent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */