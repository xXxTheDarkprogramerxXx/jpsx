/*    */ package classes.runtime.org.jpsx.runtime.util;
/*    */ 
/*    */ import org.jpsx.runtime.util.MiscUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MiscUtil
/*    */ {
/*    */   public static String toHex(int val, int digits) {
/* 22 */     String rc = Integer.toHexString(val);
/* 23 */     if (rc.length() != digits) {
/* 24 */       rc = "0000000000000000" + rc;
/* 25 */       rc = rc.substring(rc.length() - digits, rc.length());
/*    */     } 
/* 27 */     return rc;
/*    */   }
/*    */   
/* 30 */   protected static String ALPHA = "0123456789abcdef";
/*    */   
/*    */   public static int parseHex(String hex) {
/* 33 */     int rc = 0;
/* 34 */     hex = hex.trim().toLowerCase();
/* 35 */     for (int i = 0; i < hex.length(); i++) {
/* 36 */       int val = ALPHA.indexOf(hex.charAt(i));
/* 37 */       if (val == -1) {
/*    */         break;
/*    */       }
/* 40 */       rc = (rc << 4) + val;
/*    */     } 
/* 42 */     return rc;
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtim\\util\MiscUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */