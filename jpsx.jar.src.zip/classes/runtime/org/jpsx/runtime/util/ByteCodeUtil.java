/*    */ package classes.runtime.org.jpsx.runtime.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.SortedMap;
/*    */ import org.apache.bcel.generic.BranchHandle;
/*    */ import org.apache.bcel.generic.ConstantPoolGen;
/*    */ import org.apache.bcel.generic.GOTO;
/*    */ import org.apache.bcel.generic.IF_ICMPGE;
/*    */ import org.apache.bcel.generic.IF_ICMPNE;
/*    */ import org.apache.bcel.generic.ILOAD;
/*    */ import org.apache.bcel.generic.InstructionList;
/*    */ import org.apache.bcel.generic.NOP;
/*    */ import org.apache.bcel.generic.PUSH;
/*    */ import org.jpsx.runtime.util.ByteCodeUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteCodeUtil
/*    */ {
/*    */   public static void emitSwitch(ConstantPoolGen cp, InstructionList il, int localIndex, SortedMap<Integer, InstructionList> cases, int resolution, int lowBound, int highBound) {
/* 30 */     if (cases.size() == 0)
/*    */       return; 
/* 32 */     emitBinaryTree(cp, il, localIndex, cases, resolution, lowBound, highBound);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void emitBinaryTree(ConstantPoolGen cp, InstructionList il, int localIndex, SortedMap<Integer, InstructionList> cases, int resolution, int lowBound, int highBound) {
/* 37 */     List<Integer> keys = new ArrayList<Integer>();
/* 38 */     keys.addAll(cases.keySet());
/* 39 */     emitBinaryTree(cp, il, localIndex, keys, cases, resolution, lowBound, highBound, 0, keys.size() - 1);
/*    */   }
/*    */   
/*    */   public static void emitBinaryTree(ConstantPoolGen cp, InstructionList il, int localIndex, List<Integer> keys, SortedMap<Integer, InstructionList> cases, int resolution, int lowBound, int highBound, int start, int end) {
/* 43 */     if (start == end) {
/* 44 */       IF_ICMPNE cmpne = null;
/* 45 */       Integer key = (Integer)keys.get(start);
/* 46 */       boolean requireIf = (key.intValue() != lowBound || key.intValue() != highBound);
/* 47 */       if (requireIf) {
/* 48 */         il.append(new ILOAD(localIndex));
/* 49 */         il.append(new PUSH(cp, key));
/* 50 */         cmpne = new IF_ICMPNE(null);
/* 51 */         il.append(cmpne);
/*    */       } 
/* 53 */       il.append((InstructionList)cases.get(key));
/* 54 */       if (requireIf) {
/* 55 */         cmpne.setTarget(il.append(new NOP()));
/*    */       }
/*    */     } else {
/* 58 */       int middle = (start + end + 1) / 2;
/* 59 */       int middleValue = ((Integer)keys.get(middle)).intValue();
/*    */       
/* 61 */       il.append(new ILOAD(localIndex));
/* 62 */       il.append(new PUSH(cp, middleValue));
/* 63 */       IF_ICMPGE cmpge = new IF_ICMPGE(null);
/* 64 */       il.append(cmpge);
/* 65 */       emitBinaryTree(cp, il, localIndex, keys, cases, resolution, lowBound, middleValue - resolution, start, middle - 1);
/* 66 */       GOTO gt = new GOTO(null);
/* 67 */       BranchHandle branchHandle = il.append(gt);
/* 68 */       emitBinaryTree(cp, il, localIndex, keys, cases, resolution, middleValue, highBound, middle, end);
/* 69 */       gt.setTarget(il.append(new NOP()));
/* 70 */       cmpge.setTarget(branchHandle.getNext());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtim\\util\ByteCodeUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */