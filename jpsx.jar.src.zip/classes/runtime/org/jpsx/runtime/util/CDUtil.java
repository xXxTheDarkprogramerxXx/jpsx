/*    */ package classes.runtime.org.jpsx.runtime.util;
/*    */ 
/*    */ import org.jpsx.api.components.hardware.cd.CDMedia;
/*    */ import org.jpsx.api.components.hardware.cd.MediaException;
/*    */ import org.jpsx.runtime.util.CDUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDUtil
/*    */ {
/*    */   public static final int MEDIA_PRESENT = 1;
/*    */   public static final int MEDIA_HAS_DATA = 2;
/*    */   public static final int MEDIA_HAS_AUDIO = 4;
/*    */   public static final int MEDIA_PLAYSTATION = 8;
/*    */   public static final int MEDIA_REGION_EUROPE = 16;
/*    */   public static final int MEDIA_REGION_USA = 32;
/*    */   public static final int MEDIA_REGION_JAPAN = 64;
/*    */   
/* 34 */   public static int toBCD(int x) { return x % 10 + (x / 10 << 4); }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public static int fromBCD(int x) { return (x >> 4) * 10 + (x & 0xF); }
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getMediaType(CDMedia media) {
/* 43 */     int rc = 0;
/* 44 */     if (media != null) {
/* 45 */       rc |= 0x1;
/* 46 */       for (i = media.getFirstTrack(); i <= media.getLastTrack(); i++) {
/* 47 */         CDMedia.TrackType tt = media.getTrackType(i);
/* 48 */         if (tt == CDMedia.TrackType.AUDIO) {
/* 49 */           rc |= 0x4;
/* 50 */         } else if (tt == CDMedia.TrackType.MODE2_2352) {
/* 51 */           rc |= 0x2;
/*    */         } 
/*    */       } 
/* 54 */       if (0 != (rc & 0x2))
/*    */         try {
/* 56 */           int[] sector = new int[588];
/* 57 */           media.readSector(4, sector);
/* 58 */           int countryCode = sector[21] & 0xFF;
/* 59 */           if (countryCode == 69) {
/* 60 */             rc |= 0x10;
/*    */           }
/*    */         }
/* 63 */         catch (MediaException i) {
/*    */           MediaException e;
/*    */         }  
/*    */     } 
/* 67 */     return rc;
/*    */   }
/*    */ 
/*    */   
/* 71 */   public static int toMSF(int m, int s, int f) { return toBCD(m << 16) | toBCD(s) << 8 | toBCD(f); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtim\\util\CDUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */