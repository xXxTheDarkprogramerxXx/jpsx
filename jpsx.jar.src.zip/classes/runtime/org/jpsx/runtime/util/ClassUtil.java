/*    */ package classes.runtime.org.jpsx.runtime.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassUtil
/*    */ {
/* 23 */   public static String signatureOfClass(String clazz) { return "L" + clazz.replace('.', '/') + ";"; }
/*    */ 
/*    */ 
/*    */   
/* 27 */   public static String innerClassName(Class clazz, String innerClass) { return clazz.getName() + "$" + innerClass; }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtim\\util\ClassUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */