/*    */ package classes.runtime.org.jpsx.runtime;
/*    */ 
/*    */ import java.awt.event.KeyListener;
/*    */ import org.jpsx.api.CPUControl;
/*    */ import org.jpsx.bootstrap.connection.MultipleConnection;
/*    */ import org.jpsx.bootstrap.connection.SimpleConnection;
/*    */ import org.jpsx.runtime.JPSXMachine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeConnections
/*    */ {
/* 30 */   public static final SimpleConnection<JPSXMachine> MACHINE = SimpleConnection.create("JPSX Machine", JPSXMachine.class);
/*    */   
/* 32 */   public static final SimpleConnection<CPUControl> CPU_CONTROL = SimpleConnection.create("CPU Control", CPUControl.class);
/* 33 */   public static final MultipleConnection<KeyListener> KEY_LISTENERS = MultipleConnection.create("Key Listeners", KeyListener.class);
/* 34 */   public static final SimpleConnection<Runnable> MAIN = SimpleConnection.create("JPSX Main", Runnable.class);
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\RuntimeConnections.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */