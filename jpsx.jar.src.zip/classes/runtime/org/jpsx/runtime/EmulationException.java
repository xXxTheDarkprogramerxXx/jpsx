/*    */ package classes.runtime.org.jpsx.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmulationException
/*    */   extends RuntimeException
/*    */ {
/* 22 */   public EmulationException(String message) { super(message); }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public EmulationException(String message, Throwable cause) { super(message, cause); }
/*    */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\EmulationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */