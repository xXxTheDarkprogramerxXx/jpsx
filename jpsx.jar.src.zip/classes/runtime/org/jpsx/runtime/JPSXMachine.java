package classes.runtime.org.jpsx.runtime;

public interface JPSXMachine {
  public static final int PRIORITY_RESOLVE_CONNECTIONS = 90000;
  
  public static final int PRIORITY_ADD_INSTRUCTIONS = 50000;
  
  public static final int PRIORITY_DMA_CONTROLLER = 40000;
  
  public static final int PRIORITY_IRQ_CONTROLLER = 35000;
  
  public static final int PRIORITY_REGISTER_ADDRESSES = 30000;
  
  public static final int PRIORITY_POPULATE_MEMORY = 10000;
  
  public static final int PRIORITY_FREEZE_SETTINGS = 5000;
  
  void addInitializer(int paramInt, Runnable paramRunnable);
  
  void close();
}


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\JPSXMachine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */