/*     */ package classes.runtime.org.jpsx.runtime;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jpsx.api.CPUControl;
/*     */ import org.jpsx.api.InvalidConfigurationException;
/*     */ import org.jpsx.bootstrap.JPSXMachineLifecycle;
/*     */ import org.jpsx.bootstrap.configuration.ComponentDefinition;
/*     */ import org.jpsx.bootstrap.configuration.MachineDefinition;
/*     */ import org.jpsx.bootstrap.util.CollectionsFactory;
/*     */ import org.jpsx.runtime.JPSXComponent;
/*     */ import org.jpsx.runtime.JPSXMachine;
/*     */ import org.jpsx.runtime.JPSXMachineImpl;
/*     */ import org.jpsx.runtime.RuntimeConnections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPSXMachineImpl
/*     */   implements JPSXMachine, JPSXMachineLifecycle
/*     */ {
/*     */   public static final String CATEGORY = "Machine";
/*  36 */   private static Logger log = Logger.getLogger("Machine");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private List<JPSXComponent> components = CollectionsFactory.newArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private Map<Integer, List<Runnable>> initializers = CollectionsFactory.newTreeMap(Collections.reverseOrder());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean settingsFrozen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(MachineDefinition machine) { // Byte code:
/*     */     //   0: getstatic org/jpsx/runtime/RuntimeConnections.MACHINE : Lorg/jpsx/bootstrap/connection/SimpleConnection;
/*     */     //   3: aload_0
/*     */     //   4: invokevirtual set : (Ljava/lang/Object;)V
/*     */     //   7: aload_0
/*     */     //   8: aload_1
/*     */     //   9: invokevirtual addMachineElements : (Lorg/jpsx/bootstrap/configuration/MachineDefinition;)V
/*     */     //   12: aload_0
/*     */     //   13: ldc 90000
/*     */     //   15: new org/jpsx/runtime/JPSXMachineImpl$1
/*     */     //   18: dup
/*     */     //   19: aload_0
/*     */     //   20: invokespecial <init> : (Lorg/jpsx/runtime/JPSXMachineImpl;)V
/*     */     //   23: invokevirtual addInitializer : (ILjava/lang/Runnable;)V
/*     */     //   26: aload_0
/*     */     //   27: sipush #5000
/*     */     //   30: new org/jpsx/runtime/JPSXMachineImpl$2
/*     */     //   33: dup
/*     */     //   34: aload_0
/*     */     //   35: invokespecial <init> : (Lorg/jpsx/runtime/JPSXMachineImpl;)V
/*     */     //   38: invokevirtual addInitializer : (ILjava/lang/Runnable;)V
/*     */     //   41: getstatic org/jpsx/runtime/JPSXMachineImpl.log : Lorg/apache/log4j/Logger;
/*     */     //   44: ldc 'Pre-initializing components...'
/*     */     //   46: invokevirtual info : (Ljava/lang/Object;)V
/*     */     //   49: aload_0
/*     */     //   50: getfield components : Ljava/util/List;
/*     */     //   53: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   58: astore_2
/*     */     //   59: aload_2
/*     */     //   60: invokeinterface hasNext : ()Z
/*     */     //   65: ifeq -> 85
/*     */     //   68: aload_2
/*     */     //   69: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   74: checkcast org/jpsx/runtime/JPSXComponent
/*     */     //   77: astore_3
/*     */     //   78: aload_3
/*     */     //   79: invokevirtual init : ()V
/*     */     //   82: goto -> 59
/*     */     //   85: aload_0
/*     */     //   86: invokespecial runInitializers : ()V
/*     */     //   89: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #51	-> 0
/*     */     //   #52	-> 7
/*     */     //   #55	-> 12
/*     */     //   #64	-> 26
/*     */     //   #70	-> 41
/*     */     //   #71	-> 49
/*     */     //   #72	-> 78
/*     */     //   #76	-> 85
/*     */     //   #77	-> 89
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   78	4	3	component	Lorg/jpsx/runtime/JPSXComponent;
/*     */     //   59	26	2	i$	Ljava/util/Iterator;
/*     */     //   0	90	0	this	Lorg/jpsx/runtime/JPSXMachineImpl;
/*     */     //   0	90	1	machine	Lorg/jpsx/bootstrap/configuration/MachineDefinition; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  80 */     for (JPSXComponent component : this.components) {
/*  81 */       component.begin();
/*     */     }
/*     */     
/*  84 */     Runnable entryPoint = (Runnable)RuntimeConnections.MAIN.peek();
/*  85 */     if (entryPoint != null) {
/*  86 */       entryPoint.run();
/*     */     } else {
/*     */       
/*  89 */       ((CPUControl)RuntimeConnections.CPU_CONTROL.resolve()).go();
/*     */       
/*     */       try {
/*     */         while (true)
/*  93 */           Thread.sleep(2147483647L); 
/*  94 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     close();
/*     */   }
/*     */   
/*     */   public void addInitializer(int priority, Runnable initializer) {
/* 104 */     List<Runnable> list = (List)this.initializers.get(Integer.valueOf(priority));
/* 105 */     if (list == null) {
/* 106 */       list = CollectionsFactory.newArrayList();
/* 107 */       this.initializers.put(Integer.valueOf(priority), list);
/*     */     } 
/* 109 */     list.add(initializer);
/*     */   }
/*     */   
/*     */   protected void addMachineElements(MachineDefinition machineDef) {
/* 113 */     for (ComponentDefinition componentDef : machineDef.getComponents()) {
/* 114 */       JPSXComponent component = createComponent(componentDef.getClassName());
/* 115 */       for (Map.Entry<String, String> entry : componentDef.getProperties().entrySet()) {
/* 116 */         component.setProperty((String)entry.getKey(), (String)entry.getValue());
/*     */       }
/* 118 */       log.info("Adding component " + component.getDescription());
/* 119 */       this.components.add(component);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JPSXComponent createComponent(String className) {
/*     */     try {
/* 126 */       Class clazz = Class.forName(className);
/* 127 */       return (JPSXComponent)clazz.newInstance();
/* 128 */     } catch (ClassCastException e) {
/* 129 */       throw new InvalidConfigurationException("Class " + className + " does not extend JPSXComponent");
/* 130 */     } catch (Throwable e) {
/* 131 */       throw new InvalidConfigurationException("Can't create instance of class " + className, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void runInitializers() {
/* 136 */     for (List<Runnable> list : this.initializers.values()) {
/* 137 */       for (Runnable initializer : list) {
/* 138 */         initializer.run();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() {
/* 144 */     log.info("Closing...\n");
/*     */     
/* 146 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   
/* 150 */   public boolean settingsFrozen() { return this.settingsFrozen; }
/*     */ }


/* Location:              C:\Users\3deEchelon\Downloads\jpsx\jpsx\jpsx.jar!\classes\runtime\org\jpsx\runtime\JPSXMachineImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.6
 */